package it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.test.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class PropertyInserisciProcessorMock 
{
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;
	private static Boolean isMessageRemoved = false;
	
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}
	public  static void setRemoteException() 
	{
		remoteException = true;
	}
	
	public  static void setMessageRemove() 
	{
		isMessageRemoved = true;
	}
	
	
	@Mock
	public static Map getResultMap( RequestEvent reqEvent ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
		
		if (remoteException) 
		{
			remoteException = false;
			throw new RemoteException() ;
		}
		
		final Map resultMap = new HashMap();		
		resultMap.put(ITPConstants.MSG,"abc");	
		String[] arguments={"Lee", "Freddy", "Dorris", "Mary","Anne"};
		resultMap.put(ITPConstants.ARGUMENT,arguments);
		resultMap.put(ITPConstants.PR_KEY,"abc");
		resultMap.put(ITPConstants.PR_VALUE,"abc");
		if( isMessageRemoved )
		{
			resultMap.remove( ITPConstants.MSG );
		}
		 
		return resultMap;
	}

}
