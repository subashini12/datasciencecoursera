package it.sella.tracciabilitaplichi.executer.test.processor;

import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ExecutersHelperMock {
	private static Boolean remoteException = false;
	private static Boolean checkNullDate = false;
	private static Boolean data = false ;
	
	public static void setCorrectedData()
	{
		data = true ;
	}

	public static void setCheckNullDate() {
		remoteException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	@Mock
	public static OggettoView getOggettoView(final Map userDetail,
			final String causale) throws RemoteException,
			TracciabilitaException {
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final OggettoView oggettoView = new OggettoView();
		oggettoView.setBankDescription("Bank Description");
		return oggettoView;
	}

	@Mock
	public static PlichiAttributeView getPlichiAttributeView(
			final String barCode) {
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView();
		plichiAttributeView.setBarCode(barCode);
		return plichiAttributeView;
	}

	@Mock
	public static Collection getFilteredTipoConrollo(
			final Collection esitiCollection,
			final Collection tipoControlloCollection) {
		final Collection collection = new ArrayList();
		collection.add("abc");
		return collection;
	}

	@Mock
	public static String getDateFromReqEvent(final RequestEvent rqEvent,
			final String strDD, final String strMM, final String strYY) {
		String date = "12/12/2011";
		if (checkNullDate) {
			date = null;
		}
		return date;

	}

	@Mock
	public static void setSituazionePlichiListExcelData(
			final LazyFetchCollection situazioneRicercaDataColl,
			final Map mapSituazioneListData,
			final Collection<String> orderOfColumnHeading,
			final Boolean isBustaNeraWithCdrMittSearch,
			final Map<Long, String> folderTypesMap) {
	}

	@Mock
	public static void updateStampeXML(final String stampeXML,
			final String stampeId) throws TracciabilitaException,
			RemoteException {
		return;
	}
	
	@Mock
	public static String getCorrectedData( final RequestEvent rqEvent, final String name )
	{
		String flag = "";
		
		if (data)
		{
			flag = "1";
		}
		
		return flag ;
	}
	
	@Mock
	public static Long insertIntoStampe( final StateMachineSession smSession, final String barcode, final String noOfPages ) throws TracciabilitaException, RemoteException
	{
		return 2L ;
	}
	
	@Mock
	public static Map checkContract( final Collection<BustaDeiciAttributeView> bustaDeiciCollection ) throws TracciabilitaException, RemoteException
	   {
		final Map map = new HashMap() ;
		map.put(CONSTANTS.ERROR_MESSAGE ,"");
		map.put(CONSTANTS.ARGUMENT,"");
		return map ;
	   }
}
