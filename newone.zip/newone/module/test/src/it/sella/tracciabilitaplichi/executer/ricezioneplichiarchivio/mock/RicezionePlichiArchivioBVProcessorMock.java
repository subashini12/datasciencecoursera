package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.mock;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Map;

import mockit.Mock;

public class RicezionePlichiArchivioBVProcessorMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	
	@Mock
	public static String archiveBorsaVerde( final Collection validEmptyGBAttributeColl, final Map validGBPlichiMap, final Collection archivedBVAttrColl ) throws TracciabilitaException, RemoteException
	{
		if(tracciabilitaException)
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if(remoteException)
		{
			remoteException = false;
			throw new RemoteException();
		}
		return "TRPL-1039" ;
	}
}
