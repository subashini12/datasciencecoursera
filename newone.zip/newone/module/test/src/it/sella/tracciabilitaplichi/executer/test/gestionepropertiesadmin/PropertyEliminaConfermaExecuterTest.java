/*package it.sella.tracciabilitaplichi.executer.test.gestionepropertiesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.PropertyEliminaConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.TracciabilitaPlichiManagerMock;

import java.io.Serializable;
import java.util.HashMap;

import org.easymock.EasyMock;

public class PropertyEliminaConfermaExecuterTest extends AbstractSellaExecuterTest{

	PropertyEliminaConfermaExecuter propertyEliminaConfermaExecuterTest = new PropertyEliminaConfermaExecuter();
	public PropertyEliminaConfermaExecuterTest(String name) {
		super(name);
	}
	
	public void testPropertyEliminaConfermaExecuter_01()
	{
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("PR_KEY")).andReturn("a");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE);
		expecting( getStateMachineSession().get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		playAll();
		propertyEliminaConfermaExecuterTest.execute(getRequestEvent());
	}
	
	public void testPropertyEliminaConfermaExecuter_02()
	{
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("PR_KEY")).andReturn("a");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.FALSE);
		expecting( getStateMachineSession().get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  (Serializable)EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		propertyEliminaConfermaExecuterTest.execute(getRequestEvent());
	}
		
	public void testPropertyEliminaConfermaExecuter_03(){
		expecting(getRequestEvent().getAttribute("PR_KEY")).andReturn("");
		expecting(getStateMachineSession().containsKey(("GESTIONE_PROPERTIES_ADMIN_MAP"))).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("GESTIONE_PROPERTIES_ADMIN_MAP")).andReturn(new HashMap()).anyTimes();
		playAll();
		TracciabilitaPlichiManagerMock.mockEJB();
		ExecuteResult executeResult = propertyEliminaConfermaExecuterTest.execute(getRequestEvent());
		assertEquals("TrFail" ,executeResult.getTransition() );
		assertEquals("TRPL-1500" ,executeResult.getAttribute("MSG") );
	} 
	
	public void testPropertyEliminaConfermaExecuter_04()
	{
		GestioneSollecitiDataAccessMock.setTpMaPropertiesViewNull();
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("PR_KEY")).andReturn("a");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.FALSE);
		expecting( getStateMachineSession().get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  (Serializable)EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		propertyEliminaConfermaExecuterTest.execute(getRequestEvent());
	}
	
	
	public void testPropertyEliminaConfermaExecuter_05()
	{
		GestioneSollecitiDataAccessMock.setTpMaPropertiesViewNull();
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("PR_KEY")).andReturn("a");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.FALSE);
		expecting( getStateMachineSession().get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  (Serializable)EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		propertyEliminaConfermaExecuterTest.execute(getRequestEvent());
	}
	
	
	public void testPropertyEliminaConfermaExecuter_06()
	{
		GestioneSollecitiDataAccessMock.setTracciabilitaException();
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("PR_KEY")).andReturn("a");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.FALSE);
		expecting( getStateMachineSession().get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  (Serializable)EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		propertyEliminaConfermaExecuterTest.execute(getRequestEvent());
	}
		 	
}
*/