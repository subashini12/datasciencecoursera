package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.ComboView;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import mockit.Mock;

public class TPBustaDeiciDataAccessMock 
{
	private static Boolean tracciabilitaException = false;	
	private static Boolean isBustaDeiciAttributeViewNull = false;
	private static Boolean isSetALL_GKOKey = false;
	private static Boolean isSetALL_KOKey = false;
	private static Boolean isSetALL_AKOKey = false;
	private static Boolean isPreparataStatus = false;
	private static Boolean isOggettoColl = false;
	
	public static void setOggettoColl() {
		isOggettoColl = true;
	}

	public static void setALL_AKOKey() {
		isSetALL_AKOKey = true;
	}
	
	public static void setALL_KOKey() {
		isSetALL_KOKey = true;
	}
	
	public static void setALL_GKOKey() {
		isSetALL_GKOKey = true;
	}
	
	public static void setPreparataStatus() {
		isPreparataStatus = true;
	}

	private static Boolean remoteException = false;

	public static void setRemoteException() {
		remoteException = true;
	}

	
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}

	public  static void setBustaDeiciAttributeViewToNull() 
	{
		isBustaDeiciAttributeViewNull = true;
	}
	
	@Mock
	public BustaDeiciAttributeView getBustaDeiciViewById( final long bustaDeiciId ) throws TracciabilitaException
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
		BustaDeiciAttributeView bustaDeiciView = new BustaDeiciAttributeView();
		
		if( isBustaDeiciAttributeViewNull )
		{
			isBustaDeiciAttributeViewNull= false;
			bustaDeiciView=null;
			
		}
		return bustaDeiciView;
	}
	@Mock
	
	public boolean isInPreparataStatus( final Map finalData ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
		
		if (remoteException) {
			throw new RemoteException();
		}
		
		boolean flag = true ;
		if(isPreparataStatus)
		{
			flag = false ;
		}
		return flag;
	}
	
	@Mock
	public Collection getOggettoIdsForB10Ids( final Collection b10Ids ) throws TracciabilitaException
	{
		final Collection oggettoCollection = new ArrayList();
		final BustaDeiciAttributeView bustaDeiciAttributeView = new BustaDeiciAttributeView();
		bustaDeiciAttributeView.setIdSuccursale(1L);
		bustaDeiciAttributeView.setAnagrafica("ravi");
		bustaDeiciAttributeView.setCodiceDipendenteLastControl("");
		bustaDeiciAttributeView.setDataLastControl(new Timestamp(1L));
		bustaDeiciAttributeView.setDataVistoFirmare(new Timestamp(1L));
		bustaDeiciAttributeView.setBustaDeiciId(1L);
		bustaDeiciAttributeView.setOggettoId(1L);
		bustaDeiciAttributeView.setCodProdottoContratto("");
		bustaDeiciAttributeView.setNumeroCodiceDerivati("9011100012993" );
		bustaDeiciAttributeView.setCodProdottoContratto("1011");
		bustaDeiciAttributeView.setNumeroConto("T1A9679837670");
		bustaDeiciAttributeView.setOttoCifre("67983767");
		
		if(isOggettoColl)
		{
			oggettoCollection.add(bustaDeiciAttributeView);
		}
		
		return oggettoCollection ;
	}
	
	@Mock
	public List getUltimoEsitoCollection() throws TracciabilitaException
	{
		 List<ComboView> list = null ;
		 ComboView comboView = null ;
		if(isSetALL_GKOKey)
		{
			list = new ArrayList<ComboView>();
			comboView = new ComboView() ;
			comboView.setKey("G_KO");
			comboView.setValue("G KO");
			list.add(comboView);
		}
		if(isSetALL_KOKey)
		{
		list = new ArrayList<ComboView>();
		comboView = new ComboView() ;
		comboView.setKey("KO");
		comboView.setValue("KO");
		list.add(comboView);
		}
		if(isSetALL_AKOKey)
		{
			list = new ArrayList<ComboView>();
			comboView = new ComboView() ;
			comboView.setKey("A_OK");
			comboView.setValue("A_OK");
			list.add(comboView);
		}
		return list ;
	}
	
	@Mock
	public Map<Enum<CONSTANTS>, Collection<String>> getBustaDieciValues( final String query, final List paramValues ) throws TracciabilitaException, RemoteException {
		
		final Map<Enum<CONSTANTS>, Collection<String>> distinctValuesMap = new HashMap<Enum<CONSTANTS>, Collection<String>>( 3 );
		final Set<String> contractTypeColl = new TreeSet<String>( String.CASE_INSENSITIVE_ORDER );
		distinctValuesMap.put( CONSTANTS.CONTRATTI_MACRO_CATEGORIA, contractTypeColl );
		final Set<String> userIds = new TreeSet<String>( );
		distinctValuesMap.put( CONSTANTS.USER_IDS, userIds );		
		new TreeSet<Date>();	
		final Set<String> strDatas= new LinkedHashSet<String>();
		distinctValuesMap.put( CONSTANTS.DATAS, strDatas);	
		final Set<String> statusTypes = new HashSet<String>( );
		distinctValuesMap.put( CONSTANTS.STATUS, statusTypes );
		final Set<String> esitoIds = new HashSet<String>( );
		distinctValuesMap.put( CONSTANTS.ESITOS, esitoIds );
		return distinctValuesMap;
	}
}
