package it.sella.tracciabilitaplichi.executer.gestionesolleciti;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.mock.processor.ProrogheRicercaConfermaProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.processor.ProrogheRicercaConfermaProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.HashMap;

import org.easymock.EasyMock;



public class ProrogheRicercaConfermaExecuterTest extends AbstractSellaExecuterMock{

	public ProrogheRicercaConfermaExecuterTest(final String name) {
		super(name);
	}
	
	ProrogheRicercaConfermaExecuter executer=new ProrogheRicercaConfermaExecuter();
	
	public void testProrogheRicercaConfermaExecuter_01() {
		final HashMap hashMap=getHashMap();
		expecting(getRequestEvent().getAttribute(ITPConstants.BARCODE )).andReturn("1234567891234");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(hashMap);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}
	
	public void testProrogheRicercaConfermaExecuter_02() {
		setUpMockMethods(ProrogheRicercaConfermaProcessor.class, ProrogheRicercaConfermaProcessorMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.BARCODE )).andReturn("1234567891234");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( HashMap) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testProrogheRicercaConfermaExecuter_03() {
		ProrogheRicercaConfermaProcessorMock.setRemoteException();
		setUpMockMethods(ProrogheRicercaConfermaProcessor.class, ProrogheRicercaConfermaProcessorMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.BARCODE )).andReturn("1234567891234");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( HashMap) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public void testProrogheRicercaConfermaExecuter_04() {
		ProrogheRicercaConfermaProcessorMock.setTracciabilitaException();
		setUpMockMethods(ProrogheRicercaConfermaProcessor.class, ProrogheRicercaConfermaProcessorMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.BARCODE )).andReturn("1234567891234");
		expecting(getStateMachineSession().containsKey(ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( HashMap) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public static HashMap getHashMap() {
		final HashMap hashMap=new HashMap();
		hashMap.put(ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP, null);
		return hashMap;
	}
	
}
