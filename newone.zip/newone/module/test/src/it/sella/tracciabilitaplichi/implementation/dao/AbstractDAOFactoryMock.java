package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;
import it.sella.tracciabilitaplichi.interfaces.dao.IAltriWinboxDataAccess;
import it.sella.tracciabilitaplichi.interfaces.dao.IBorsaVerdeDataAccess;
import it.sella.tracciabilitaplichi.interfaces.dao.IBustaDieciDataAccess;
import it.sella.tracciabilitaplichi.interfaces.dao.IWinbox2DataAccess;
import it.sella.tracciabilitaplichi.persistence.dao.AbstractDAOFactory;
import mockit.Mock;

import org.easymock.EasyMock;

public class AbstractDAOFactoryMock extends AbstractDAOFactory {
	@Override
	@Mock
	public IBorsaVerdeDataAccess getBorsaVerdeDataAccess() {
		final BorsaVerdeAttributeView borsaVerdeAttributeView = new BorsaVerdeAttributeView();
		final IBorsaVerdeDataAccess iBorsaVerdeDataAccess = EasyMock.createMock(IBorsaVerdeDataAccess.class);
		final IBustaDieciDataAccess bustaDieciDataAccess = EasyMock.createMock(IBustaDieciDataAccess.class);
		final IWinbox2DataAccess winbox2DataAccess = EasyMock.createMock(IWinbox2DataAccess.class);
		EasyMock.replay(winbox2DataAccess);
			//EasyMock.expect(iBorsaVerdeDataAccess.isBorsaVerdeAlreadyExists(null)).andReturn(false).anyTimes();
			EasyMock.replay(bustaDieciDataAccess);
			EasyMock.replay(iBorsaVerdeDataAccess);
		return iBorsaVerdeDataAccess;
	}
	@Override
	@Mock
	public IWinbox2DataAccess getWinbox2DataAccess( )
	{
		final IWinbox2DataAccess winbox2DataAccess = null;		    
		return winbox2DataAccess;
	}
	@Override
	@Mock
	public IAltriWinboxDataAccess getAltriWinboxDataAccess( )
	{
		final IAltriWinboxDataAccess altriWinboxDataAccess = null;
		return altriWinboxDataAccess;
	}
}
