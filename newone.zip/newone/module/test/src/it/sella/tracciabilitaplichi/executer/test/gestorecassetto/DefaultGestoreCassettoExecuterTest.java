/*package it.sella.tracciabilitaplichi.executer.test.gestorecassetto;

import it.sella.tracciabilitaplichi.executer.gestorecassetto.DefaultGestoreCassettoExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.io.Serializable;

import org.easymock.EasyMock;

public class DefaultGestoreCassettoExecuterTest extends AbstractSellaExecuterTest
{

	public DefaultGestoreCassettoExecuterTest(final String name) 
	{
		super(name);
	}
	
	DefaultGestoreCassettoExecuter executer = new DefaultGestoreCassettoExecuter();
	
	public void testDefaultGestoreCassettoExecuter_successCase()
	{
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute( getRequestEvent());	
	}
	public void testDefaultGestoreCassettoExecuter_forTracciabilitaException()
	{
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		executer.execute( getRequestEvent());	
	}
	public void testDefaultGestoreCassettoExecuter_forRemoteException()
	{
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		executer.execute( getRequestEvent());	
	}

}
*/