package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichi;


import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class SituazionePlichiStatusUpdateExecuterTest extends AbstractSellaExecuterMock{

	public SituazionePlichiStatusUpdateExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SituazionePlichiStatusUpdateExecuter executer=new SituazionePlichiStatusUpdateExecuter();
	public void testSituazionePlichiStatusUpdateExecuter_01()
	{
		final Hashtable hashTable=getHashtable();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get( "GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiStatusUpdateExecuter_02()
	{
		getHashtable();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	
	public void testSituazionePlichiStatusUpdateExecuter_03()
	{
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Hashtable hashTable=getHashtable();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiStatusUpdateExecuter_04()
	{
		final Hashtable hashTable=getHashtable();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Hashtable getHashtable()
	{
		final Collection collection=new ArrayList();
		final Hashtable hashTable=new Hashtable();
		hashTable.put("BankViewList", "");
		hashTable.put("StatusViewList",collection );
		hashTable.put("WinboxViewList", collection);
		hashTable.put("TypesOfOggettos", "");
		return hashTable;
	}
	private static Hashtable getHashtableWithOutWinboxViewList()
	{
		final Collection collection=new ArrayList();
		final Hashtable hashTable=new Hashtable();
		hashTable.put("BankViewList", "");
		hashTable.put("StatusViewList",collection );
		hashTable.put("TypesOfOggettos", "");
		return hashTable;
	}
	public void testSituazionePlichiStatusUpdateExecuter_05()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Hashtable hashTable=getHashtable();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiStatusUpdateExecuter_06()
	{
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Hashtable hashTable=getHashtableWithOutWinboxViewList();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiStatusUpdateExecuter_07()
	{
		ClassificazioneWrapperMock.setBUSTN();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Hashtable hashTable=getHashtableWithOutWinboxViewList();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiStatusUpdateExecuter_08()
	{
		ClassificazioneWrapperMock.setTracciabilitaExternalServicesException();
		ClassificazioneWrapperMock.setBUSTN();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Hashtable hashTable=getHashtableWithOutWinboxViewList();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION" )).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashTable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
}
