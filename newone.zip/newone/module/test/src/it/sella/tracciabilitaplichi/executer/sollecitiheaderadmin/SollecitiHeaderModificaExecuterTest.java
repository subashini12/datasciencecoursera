package it.sella.tracciabilitaplichi.executer.sollecitiheaderadmin;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.view.TpTrSollecitiHeaderViewMock;
import it.sella.tracciabilitaplichi.implementation.view.TpTrSollecitiHeaderView;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;



public class SollecitiHeaderModificaExecuterTest extends AbstractSellaExecuterMock{

	public SollecitiHeaderModificaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SollecitiHeaderModificaExecuter executer=new SollecitiHeaderModificaExecuter();
	public void testSollecitiHeaderModificaExecuter_01()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("sender");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_02()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn(null);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_03()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("Recipient");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_04()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("Cc");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_05()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("Cc");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("1");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_06()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("status");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_07()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("1");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("status");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_08()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("disabled");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_09()
	{
		setUpMockMethods(TpTrSollecitiHeaderView.class, TpTrSollecitiHeaderViewMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSollecitiHeaderModificaExecuter_10()
	{
		TpTrSollecitiHeaderViewMock.setTracciabilitaException();
		setUpMockMethods(TpTrSollecitiHeaderView.class, TpTrSollecitiHeaderViewMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Map map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.SOLLECITI_HEADER_MAP)).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_SENDER)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_RECIPIENT )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_CC)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_MAIL_TYPE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_BANK_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_DISABLED)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.SH_STATUS )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	
	private static Map getMap()
	{
		Map map=new HashMap();
		TpTrSollecitiHeaderView tpTrSollecitiHeaderView=new TpTrSollecitiHeaderView();
		tpTrSollecitiHeaderView.setShBankId(Long.valueOf(1));
		tpTrSollecitiHeaderView.setShId(Long.valueOf(1));
		tpTrSollecitiHeaderView.setShSmId(Long.valueOf(1));
		tpTrSollecitiHeaderView.setShMailType(Long.valueOf(1));
		tpTrSollecitiHeaderView.setShRecipient("Recipient");
		tpTrSollecitiHeaderView.setShSender("sender");
		tpTrSollecitiHeaderView.setShCc("Cc");
		tpTrSollecitiHeaderView.setShStatus("status");
		tpTrSollecitiHeaderView.setShDisabled("Disabled");
		map.put(ITPConstants.TP_TR_SOLLECITI_HEADER_VIEW_OLD, tpTrSollecitiHeaderView);
		return map;
	}
}
