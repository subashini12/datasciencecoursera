package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.view.TpTrSollecitiHeaderView;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class SollecitiHeaderDataAccessTest
{
	SollecitiHeaderDataAccess commonDataAccess=null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		commonDataAccess = new SollecitiHeaderDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		commonDataAccess = null;
	}

	@Test
	public void getViewById() throws Exception{
		mockStatementProvider = new MockStatementProvider(getViewByIdQuerySt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 0, "SH_ID",1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, "SH_SM_ID",1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, "SH_SENDER","ravi");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 3, "SH_RECIPIENT","ranjith");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 4, "SH_CC","Banu");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 5, "SH_MAIL_TYPE",1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 6, "SH_STATUS","sending");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.DATE, 7, "SH_DATE",new java.sql.Date(0));
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 8, "SH_BANK_ID",1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 9, "SH_DISABLED","YES");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final TpTrSollecitiHeaderView headerView = commonDataAccess.getViewById(Long.valueOf("1"));
		Assert.assertEquals("ravi", headerView.getShSender());


	}

	private String getViewByIdQuerySt(){
		final String query = "select SH_ID,SH_SM_ID,SH_SENDER,SH_RECIPIENT,SH_CC,SH_MAIL_TYPE,SH_STATUS,SH_DATE,SH_BANK_ID,SH_DISABLED from TP_TR_SOLLECITI_HEADER where SH_ID = ?";;
		return query;
	}

}
