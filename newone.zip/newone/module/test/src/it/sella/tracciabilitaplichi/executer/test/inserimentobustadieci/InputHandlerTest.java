package it.sella.tracciabilitaplichi.executer.test.inserimentobustadieci;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.InputHandler;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class InputHandlerTest extends AbstractSellaExecuterMock
{
	
	private static final String BARCODE = "1044000000720";
	private static final CONSTANTS[ ] formParams = new CONSTANTS[ ] { CONSTANTS.BARCODE, CONSTANTS.BRANCH_CODE, CONSTANTS.TIPO_CONTO, CONSTANTS.OTTOCIFRE, CONSTANTS.MILLESIMO, CONSTANTS.CONTRATTI_MACRO_CATEGORIA, CONSTANTS.TIPO_CONTRATTI, CONSTANTS.ANAGRAFICA, CONSTANTS.N_PRAT, CONSTANTS.IS_MANUAL_PREFILL };
	
	public InputHandlerTest( final String name )
	{
		super( name );
	}
	
	public void testGetBarcode_1( )
	{
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.BARCODE.getValue( ) ) ).andReturn( null );
		playAll( );
 		assertEquals( "", InputHandler.getInstance( ).getBarcode( getRequestEvent( ) ) );
	}

	public void testGetBarcode_2( )
	{
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.BARCODE.getValue( ) ) ).andReturn( "" );
		playAll( );
 		assertEquals( "", InputHandler.getInstance( ).getBarcode( getRequestEvent( ) ) );
	}

	public void testGetBarcode_3( )
	{
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.BARCODE.getValue( ) ) ).andReturn( "   ".concat( BARCODE ).concat( " " ) );
		playAll( );
 		assertEquals( BARCODE, InputHandler.getInstance( ).getBarcode( getRequestEvent( ) ) );
	}
	
	public void testGetInserimentoContrattiInputParams_1( )
	{
		for ( final CONSTANTS formParam : formParams )
		{
			expecting( getRequestEvent( ).getAttribute( formParam.getValue( ) ) ).andReturn( null ).anyTimes( );
		}
		playAll( );
		final Map<Enum<CONSTANTS>, String> inputMap = InputHandler.getInstance( ).getInserimentoContrattiInputParams( getRequestEvent( ) );
		for( final CONSTANTS formParam : formParams )
		{
			assertEquals( "", inputMap.get( formParam ) );
		}
		assertEquals( "", inputMap.get( CONSTANTS.NUMEROCONTO ) );
	}

	public void testGetInserimentoContrattiInputParams_2( )
	{
		for ( final CONSTANTS formParam : formParams )
		{
			expecting( getRequestEvent( ).getAttribute( formParam.getValue( ) ) ).andReturn( "   " ).anyTimes( );
		}
		playAll( );
		final Map<Enum<CONSTANTS>, String> inputMap = InputHandler.getInstance( ).getInserimentoContrattiInputParams( getRequestEvent( ) );
		for( final CONSTANTS formParam : formParams )
		{
			assertEquals( "", inputMap.get( formParam ) );
		}
		assertEquals( "", inputMap.get( CONSTANTS.NUMEROCONTO ) );
	}

	public void testGetInserimentoContrattiInputParams_3( )
	{
		for ( final CONSTANTS formParam : formParams )
		{
			expecting( getRequestEvent( ).getAttribute( formParam.getValue( ) ) ).andReturn( "  ".concat( BARCODE ).concat( "   " ) ).anyTimes( );
		}
		playAll( );
		final Map<Enum<CONSTANTS>, String> inputMap = InputHandler.getInstance( ).getInserimentoContrattiInputParams( getRequestEvent( ) );
		for( final CONSTANTS formParam : formParams )
		{
			assertEquals( BARCODE, inputMap.get( formParam ) );
		}
	}
	
	public void testGetInserimentoContrattiInputParams_4( )
	{
		final List<CONSTANTS> contoParams = Arrays.asList( new CONSTANTS[ ] { CONSTANTS.BRANCH_CODE, CONSTANTS.TIPO_CONTO, CONSTANTS.OTTOCIFRE, CONSTANTS.MILLESIMO } );
		for ( final CONSTANTS formParam : formParams )
		{
			if ( !contoParams.contains( formParam ) )
			{
				expecting( getRequestEvent( ).getAttribute( formParam.getValue( ) ) ).andReturn( "  ".concat( BARCODE ).concat( "   " ) ).anyTimes( );
			}
		}
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.BRANCH_CODE.getValue( ) ) ).andReturn( "" ).times( 2 );
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.TIPO_CONTO.getValue( ) ) ).andReturn( "" ).times( 2 );
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.OTTOCIFRE.getValue( ) ) ).andReturn( "  12345678   " ).times( 2 );
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.MILLESIMO.getValue( ) ) ).andReturn( "" ).times( 2 );
		playAll( );
		final Map<Enum<CONSTANTS>, String> inputMap = InputHandler.getInstance( ).getInserimentoContrattiInputParams( getRequestEvent( ) );
		for( final CONSTANTS formParam : formParams )
		{
			if ( !contoParams.contains( formParam ) )
			{
				assertEquals( BARCODE, inputMap.get( formParam ) );
			}
		}
		assertEquals( "", inputMap.get( CONSTANTS.BRANCH_CODE ) );
		assertEquals( "", inputMap.get( CONSTANTS.TIPO_CONTO ) );
		assertEquals( "12345678", inputMap.get( CONSTANTS.OTTOCIFRE ) );
		assertEquals( "", inputMap.get( CONSTANTS.MILLESIMO ) );
		assertEquals( "12345678", inputMap.get( CONSTANTS.NUMEROCONTO ) );
	}

	public void testGetInserimentoContrattiInputParams_5( )
	{
		final List<CONSTANTS> contoParams = Arrays.asList( new CONSTANTS[ ] { CONSTANTS.BRANCH_CODE, CONSTANTS.TIPO_CONTO, CONSTANTS.OTTOCIFRE, CONSTANTS.MILLESIMO } );
		for ( final CONSTANTS formParam : formParams )
		{
			if ( !contoParams.contains( formParam ) )
			{
				expecting( getRequestEvent( ).getAttribute( formParam.getValue( ) ) ).andReturn( "  ".concat( BARCODE ).concat( "   " ) ).anyTimes( );
			}
		}
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.BRANCH_CODE.getValue( ) ) ).andReturn( " A1 " ).times( 2 );
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.TIPO_CONTO.getValue( ) ) ).andReturn( "29 " ).times( 2 );
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.OTTOCIFRE.getValue( ) ) ).andReturn( "  12345678   " ).times( 2 );
		expecting( getRequestEvent( ).getAttribute( CONSTANTS.MILLESIMO.getValue( ) ) ).andReturn( "  0  " ).times( 2 );
		playAll( );
		final Map<Enum<CONSTANTS>, String> inputMap = InputHandler.getInstance( ).getInserimentoContrattiInputParams( getRequestEvent( ) );
		for( final CONSTANTS formParam : formParams )
		{
			if ( !contoParams.contains( formParam ) )
			{
				assertEquals( BARCODE, inputMap.get( formParam ) );
			}
		}
		assertEquals( "A1", inputMap.get( CONSTANTS.BRANCH_CODE ) );
		assertEquals( "29", inputMap.get( CONSTANTS.TIPO_CONTO ) );
		assertEquals( "12345678", inputMap.get( CONSTANTS.OTTOCIFRE ) );
		assertEquals( "0", inputMap.get( CONSTANTS.MILLESIMO ) );
		assertEquals( "A129123456780", inputMap.get( CONSTANTS.NUMEROCONTO ) );
	}

}
