package it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.TracciabilitaPlichiFactory;
import it.sella.tracciabilitaplichi.TracciabilitaPlichiFactoryMock;
import it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessorMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccessMock;

import java.util.Collection;
import java.util.Map;

import org.easymock.EasyMock;

public class FrequentiDestinazioneCdrRicercaExecuterTest extends AbstractSellaExecuterMock {

	public FrequentiDestinazioneCdrRicercaExecuterTest(final String name) {
		super(name);
	}

	FrequentiDestinazioneCdrRicercaExecuter executer = new FrequentiDestinazioneCdrRicercaExecuter();

	public void testFrequentiDestinazioneCdrRicercaExecuter_04() {
		TPFrequentiDestinazioneCdrDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}

	public void testFrequentiDestinazioneCdrRicercaExecuter_06() {
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrError");
	}
	
	public void testFrequentiDestinazioneCdrRicercaExecuter_02() {
		TPFrequentiDestinazioneCdrDataAccessMock.setCollFrequentiDestinazioneCdrViewNotNull();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Collection) EasyMock.anyObject())).andReturn(null);
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Map) EasyMock.anyObject())).andReturn(null);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}

	public void testFrequentiDestinazioneCdrRicercaExecuter_03() {
		FrequentiDestinazioneCdrProcessorMock.setvalidateRicercaDataNotNull();
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Collection) EasyMock.anyObject())).andReturn(null);
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Map) EasyMock.anyObject())).andReturn(null);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrError");
	}

	public void testFrequentiDestinazioneCdrRicercaExecuter_05() {
		TPFrequentiDestinazioneCdrDataAccessMock.setCollFrequentiDestinazioneCdrViewNotNull();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Collection) EasyMock.anyObject())).andReturn(null);
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Map) EasyMock.anyObject())).andReturn(null);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrError");
	}
	
	public void testFrequentiDestinazioneCdrRicercaExecuter_07(){
		TracciabilitaPlichiFactoryMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiFactory.class,TracciabilitaPlichiFactoryMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}
	
}
