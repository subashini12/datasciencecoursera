package it.sella.tracciabilitaplichi.implementation;

import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.StatusModifierInfoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.pdfgenerator.AltriPlichiContentsPDFGenerator;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import mockit.Mockit;

import org.junit.Test;

public class AltriPlichiContentsPDFGeneratorTest {
	
	AltriPlichiContentsPDFGenerator altriPlichiContentsPDFGenerator = new AltriPlichiContentsPDFGenerator();
	
	@Test
	public void testGetDataXMLAltriPlichiContents(){
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
		Mockit.setUpMock(Util.class,UtilMock.class);
		try {
			altriPlichiContentsPDFGenerator.getDataXMLAltriPlichiContents(getTracciabilitaPlichiView(), getStatusModifierInfoView(), getStatusModifierInfoView(), 1L, getPlichiViewList());
		} catch (final Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	private TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		tracciabilitaPlichiView.setPlichiAttributeView(getPlichiAttributeView());
		return tracciabilitaPlichiView ;
	}
	
	private OggettoView getOggettoView()
	{
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setOggettoType(1L);
		oggettoView.setId(1L);
		return oggettoView ;
	}
	
	private static PlichiAttributeView getPlichiAttributeView()
	{
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView() ;
		plichiAttributeView.setBarCode("1234567891236");
		return plichiAttributeView ;
	}
	
	private StatusModifierInfoView getStatusModifierInfoView(){
		final StatusModifierInfoView infoView = new StatusModifierInfoView();
		infoView.setId(1L);
		infoView.setOpDate(new Timestamp(new Date().getTime()));
		infoView.setUserId("gbs03094");
		return infoView;		
	}
	
	 private Collection getPlichiViewList(){
		 final Collection plichiViewList = new ArrayList(); 
		 final PlichiAttributeView attributeView1 = new PlichiAttributeView();
		 attributeView1.setBankDescription("bankDescription1");
		 attributeView1.setCdrDestination("099231");
		 attributeView1.setBankDestination(1L);
		 final PlichiAttributeView attributeView2 = new PlichiAttributeView();
		 attributeView2.setBankDescription("bankDescription2");
		 attributeView2.setCdrDestination("099921");
		 attributeView2.setBankDestination(2L);
		 plichiViewList.add(attributeView1);
		 plichiViewList.add(attributeView2);
		 return plichiViewList;
	 }
	

}
