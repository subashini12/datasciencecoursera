package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaDataAccessException;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TPFrequentiDestinazioneCdrDataAccessTest {

	TPFrequentiDestinazioneCdrDataAccess tpFrequentiDestinazioneCdrDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		tpFrequentiDestinazioneCdrDataAccess = new TPFrequentiDestinazioneCdrDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		tpFrequentiDestinazioneCdrDataAccess = null;
	}

	@Test
	public void isfrequentiDestinazioneCdrExist_01() throws TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrExistSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final boolean isfrequentiDestinazioneCdrExist = tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrExist("12");
		Assert.assertTrue(isfrequentiDestinazioneCdrExist);
	}

	@Test(expected=TracciabilitaDataAccessException.class)
	public void isfrequentiDestinazioneCdrExist_02() throws TracciabilitaException
	{
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrExistSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrExist(null);
	}

	private String isfrequentiDestinazioneCdrExistSt(){
		return "SELECT 1 FROM TP_MA_WIDELY_USEDCDRS WHERE WU_ID=?";
	}
	@Test
	public void isfrequentiDestinazioneCdrExist4bank_01() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrExist4bankSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final boolean isfrequentiDestinazioneCdrExist = tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrExist4bank("12","099231");
		Assert.assertTrue(isfrequentiDestinazioneCdrExist);
	}
	@Test
	public void isfrequentiDestinazioneCdrExist4bank_02() throws TracciabilitaException {
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrExist4bankSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		try{
			tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrExist4bank(null,"099231");
		}catch(final Exception e){
			Assert.assertNotNull(e.getMessage());
		}
	}

	@Test(expected=TracciabilitaDataAccessException.class)
	public void isfrequentiDestinazioneCdrExist4bank_03() throws TracciabilitaException {
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrExist4bankSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrExist4bank("226",null);
	}
	private String isfrequentiDestinazioneCdrExist4bankSt(){
		return "SELECT 1 FROM TP_MA_WIDELY_USEDCDRS WHERE WU_BANK=? and WU_CDR=? ";
	}
	@Test
	public void isfrequentiDestinazioneCdrPosizioneExist4bank_01() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertTrue(tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrPosizioneExist4bank("2","3"));
	}
	@Test(expected=TracciabilitaDataAccessException.class)
	public void isfrequentiDestinazioneCdrPosizioneExist4bank_02() throws TracciabilitaException{
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertTrue(tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrPosizioneExist4bank(null,"3"));
	}

	@Test(expected=TracciabilitaDataAccessException.class)
	public void isfrequentiDestinazioneCdrPosizioneExist4bank_03() throws TracciabilitaException{
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(isfrequentiDestinazioneCdrSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertTrue(tpFrequentiDestinazioneCdrDataAccess.isfrequentiDestinazioneCdrPosizioneExist4bank("2",null));
	}

	private String isfrequentiDestinazioneCdrSt(){
		return "SELECT 1 FROM TP_MA_WIDELY_USEDCDRS WHERE WU_BANK=? and WU_ORDER_DISPLAY=?";
	}
	@Test
	public void getfrequentiDestinazioneCdr() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getfrequentiDestinazioneCdrSt());
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 0,"WU_ID",2l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,"WU_BANK",2l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 2,"WU_CDR","CDR");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 3,"WU_DESC","Desc");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 4,"WU_ORDER_DISPLAY",2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final FrequentiDestinazioneCdrView frequentiDestinazioneCdr = tpFrequentiDestinazioneCdrDataAccess.getfrequentiDestinazioneCdr("5");
		Assert.assertEquals("Desc", frequentiDestinazioneCdr.getDescription());

	}

	private String getfrequentiDestinazioneCdrSt(){
		return "SELECT WU_ID, WU_BANK, WU_CDR, WU_DESC, WU_ORDER_DISPLAY FROM TP_MA_WIDELY_USEDCDRS WHERE WU_ID=? ";
	}

}
