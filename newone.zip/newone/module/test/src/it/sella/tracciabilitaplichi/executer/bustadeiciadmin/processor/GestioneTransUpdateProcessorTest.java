package it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;


/**
 * @author gbs03134
 *
 */

public class GestioneTransUpdateProcessorTest extends AbstractSellaExecuterMock {

	public GestioneTransUpdateProcessorTest(final String name) {
		super(name);
	}

	GestioneTransUpdateProcessor processor = new GestioneTransUpdateProcessor() ;
	
	public void testGestioneTransUpdateProcessor_01() {
		ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("12");
		expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn(null);
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn(null);
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn(null);
		playAll();
		executeResult = processor.getControlliErrorExecuteResult(getRequestEvent(),executeResult , getControlliView());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	public void testGestioneTransUpdateProcessor_02() {
		ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("12");
		expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn("1990");
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn("1990");
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn("1990");
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn("11");
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn("11");
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn("11");
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("note")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("note")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("note")).andReturn("PBUSTAN");
		playAll();
		executeResult = processor.getControlliErrorExecuteResult(getRequestEvent(),executeResult , getControlliView());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	public void testGestioneTransUpdateProcessor_03() {
		ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		expecting(getRequestEvent().getAttribute("clCoddip")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataCondd")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn("1990");
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn("1990");
		expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn("1990");
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn("11");
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn("11");
		expecting(getRequestEvent().getAttribute("clContratoId")).andReturn("11");
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("clEsito")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("note")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("note")).andReturn("PBUSTAN");
		expecting(getRequestEvent().getAttribute("note")).andReturn("PBUSTAN");
		playAll();
		executeResult = processor.getControlliErrorExecuteResult(getRequestEvent(),executeResult , getControlliView());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	
	private static ControlliView getControlliView() {
		final ControlliView controlliView = new ControlliView() ;
		return controlliView ; 
	}
}
