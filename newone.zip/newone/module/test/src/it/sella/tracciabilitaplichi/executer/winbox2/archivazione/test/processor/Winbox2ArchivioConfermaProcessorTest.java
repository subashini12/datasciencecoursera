package it.sella.tracciabilitaplichi.executer.winbox2.archivazione.test.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.archivazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.archivazione.processor.Winbox2ArchivioConfermaProcessor;
import it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione.HelperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Collection;

import org.easymock.EasyMock;

public class Winbox2ArchivioConfermaProcessorTest extends
		AbstractSellaExecuterMock {

	public Winbox2ArchivioConfermaProcessorTest(final String name) {
		super(name);
	}

	Winbox2ArchivioConfermaProcessor winbox2ArchivioConfermaProcessor = new Winbox2ArchivioConfermaProcessor();

	public void testWinbox2ArchivioConfermaProcessor()
			throws TracciabilitaException, RemoteException {
		HelperMock.setMapWithOutWINBOX2INPUTPROCESSOR();
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( 1L ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Long) EasyMock.anyObject() ) ).andReturn( 1L ).anyTimes();
		playAll();
		winbox2ArchivioConfermaProcessor.execute(getRequestEvent());
	}

}
