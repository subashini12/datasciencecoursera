package it.sella.tracciabilitaplichi.executer.ise;

import it.sella.gestione_flussi.implementation.GestioneFlussiManagerFactoryImpl;
import it.sella.integrazione_sistemi_esterni.ServiceException;
import it.sella.tracciabilitaplichi.flussi.TracciabilitaPlichiHandler;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.mock.flussi.GestioneFlussiManagerFactoryMock;
import it.sella.tracciabilitaplichi.mock.flussi.TracciabilitaPlichiHandlerMock;
import it.sella.tracciabilitaplichi.persistence.log.InternalLoggerDAOImpl;
import it.sella.tracciabilitaplichi.persistence.log.InternalLoggerDAOImplMock;

import java.rmi.RemoteException;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TracciabilitaPlichiISESchedulerTest {
	
	private TracciabilitaPlichiISEScheduler iseScheduler;

	@Before
	public void setUp() throws Exception {
		iseScheduler = new TracciabilitaPlichiISEScheduler();
		Mockit.setUpMock(TracciabilitaPlichiISEDataAccess.class,TracciabilitaPlichiISEDataAccessMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(InternalLoggerDAOImpl.class,InternalLoggerDAOImplMock.class);
		Mockit.setUpMock(TracciabilitaPlichiHandler.class,TracciabilitaPlichiHandlerMock.class);
		Mockit.setUpMock(GestioneFlussiManagerFactoryImpl.class, GestioneFlussiManagerFactoryMock.class);  
	}

	@After
	public void tearDown() throws Exception {
		iseScheduler = null;
	}

	@Test
	public void testInvokeService() {
		try {
			iseScheduler.invokeService(null);
		} catch (final RemoteException e) {
			Assert.fail("TracciabilitaPlichiISESchedulerTest Failed "+e.getMessage());
		} catch (final ServiceException e) {
			Assert.fail("TracciabilitaPlichiISESchedulerTest Failed "+e.getMessage());
		}
	}
	
	@Test
	public void testInvokeServiceWithException() {
		try {
			TracciabilitaPlichiHandlerMock.setRemoteException() ;
			Mockit.setUpMock(TracciabilitaPlichiHandler.class,TracciabilitaPlichiHandlerMock.class);
			iseScheduler.invokeService(null);
			//Assert.fail("TracciabilitaPlichiISESchedulerTest Failed ");
		} catch (final RemoteException e) {
			
		} catch (final ServiceException e) {
			
		}
	}

}
