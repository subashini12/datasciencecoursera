package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.PlichiContentsPushExecuter;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;

import java.util.Stack;

import junit.framework.TestCase;

public class PlichiContentsPushExecuterTest extends TestCase
{
    RequestEvent requestEvent = null;
    StateMachineSession stateMachineSession = null;
    public PlichiContentsPushExecuterTest( final String name )
    {
        super( name );
    }

    protected void setUp( ) throws Exception
    {
        super.setUp( );
        this.requestEvent = createMock( RequestEvent.class );
        this.stateMachineSession = createMock( StateMachineSession.class );
    }
    public void testPlichiContentsPushExecuter( )
    {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession ).anyTimes( );
        expect( this.stateMachineSession.get( "Busta10PreparationPageView" ) ).andReturn( new Busta10PreparationPageView( ) );
        expect( this.requestEvent.getAttribute( "bustaId" ) ).andReturn( "1" );
        expect( this.requestEvent.getAttribute( "ID" ) ).andReturn( "2" );
        expect( this.stateMachineSession.put( "SearchFrom", "BustaDeici" ) ).andReturn( "BustaDeici" );
        final Stack stack = new Stack( );
        stack.push( "2" );
        expect( this.stateMachineSession.put( "BarCodeStack", stack ) ).andReturn( stack );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult actual = new PlichiContentsPushExecuter( ).execute( this.requestEvent );
        assertEquals( "TrConferma", actual.getTransition( ) );
    }
    protected void tearDown( ) throws Exception
    {
        super.tearDown( );
    }

}
