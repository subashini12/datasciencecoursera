package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.dao.AbstractDAOFactoryMock;
import it.sella.tracciabilitaplichi.implementation.dao.ArchivationBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.ArchivationBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;
import it.sella.tracciabilitaplichi.persistence.dao.AbstractDAOFactory;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

public class ArchivationHistoryProcessorTest extends AbstractSellaMock {

	public ArchivationHistoryProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ArchivationHistoryProcessor archivationHistoryProcessor = new ArchivationHistoryProcessor();

	public void testArchivationHistoryProcessor_01() {
		final Map<Enum<CONSTANTS>, String> map = new HashMap<Enum<CONSTANTS>, String>();
		setUpMockMethods(ArchivationBustaDeiciDataAccess.class, ArchivationBustaDeiciDataAccessMock.class);
		setUpMockMethods(AbstractDAOFactory.class, AbstractDAOFactoryMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		//final IBustaDieciDataAccess bustaDieciDataAccess =EasyMock.createMock(IBustaDieciDataAccess.class);
		try {
//			EasyMock.expect(bustaDieciDataAccess.getArchivedContract("1234567894561")).andReturn(map).anyTimes();
	//		play(bustaDieciDataAccess);
			archivationHistoryProcessor.getArchivationHistory("1234567812345");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
}
