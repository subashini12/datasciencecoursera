package it.sella.tracciabilitaplichi.executer.winbox2.archivazione;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class FolderChooserProcessorMock {
	@Mock
	public static Map<String, Collection<Long>> getSelectedFoldersPerWinBox2( final RequestEvent requestEvent, final Map<String, Collection<Folder>> confirmationNeededMap )
	{
		Map<String, Collection<Long>> map=new HashMap<String, Collection<Long>>();
		Collection<Long> longCollection=new ArrayList<Long>();
		longCollection.add(Long.valueOf(1));
		map.put("1",longCollection );
		return map;
	}
}
