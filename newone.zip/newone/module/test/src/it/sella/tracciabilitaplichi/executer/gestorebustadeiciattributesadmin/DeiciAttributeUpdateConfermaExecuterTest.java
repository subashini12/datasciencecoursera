package it.sella.tracciabilitaplichi.executer.gestorebustadeiciattributesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.BustaDeiciContrattiImpl;
import it.sella.tracciabilitaplichi.implementation.BustaDeiciContrattiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.Hashtable;

import mockit.Mockit;


public class DeiciAttributeUpdateConfermaExecuterTest extends AbstractSellaExecuterMock{

	public DeiciAttributeUpdateConfermaExecuterTest(final String name) {
		super(name);
	}

	DeiciAttributeUpdateConfermaExecuter executer = new DeiciAttributeUpdateConfermaExecuter() ;
	
	public void testDeiciAttributeUpdateConfermaExecuter_01() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setCdr();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().remove("DeiciAttributesNonEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("ModifiedDeiciAttrView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().remove("ContrProd")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"TrConferma");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_tracciabilitaException() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().remove("DeiciAttributesNonEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("ModifiedDeiciAttrView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().remove("ContrProd")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"TrFail");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_remoteException() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().remove("DeiciAttributesNonEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("ModifiedDeiciAttrView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().remove("ContrProd")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"TrFail");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_02() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setCdr();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().remove("DeiciAttributesNonEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("ModifiedDeiciAttrView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesEditableView")).andReturn("");
		expecting(getStateMachineSession().remove("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().remove("ContrProd")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"TrConferma");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_03() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setCdr();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().get("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().containsKey("ContrProd")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("ContrProd")).andReturn(new Hashtable()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedDeiciAttrView")).andReturn(Boolean.TRUE).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"back");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_04() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setCdr();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().get("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().containsKey("ContrProd")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().get("ContrProd")).andReturn(new Hashtable()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedDeiciAttrView")).andReturn(Boolean.TRUE).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"back");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_05() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().get("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().containsKey("ContrProd")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().get("ContrProd")).andReturn(new Hashtable()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedDeiciAttrView")).andReturn(Boolean.TRUE).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"back");
	}
	
	public void testDeiciAttributeUpdateConfermaExecuter_06() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(BustaDeiciContrattiImpl.class, BustaDeiciContrattiImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("ModifiedDeiciAttrView")).andReturn(getBustaDeiciAttributeView()).anyTimes();
		expecting(getStateMachineSession().get("DeiciAttributesView")).andReturn("");
		expecting(getStateMachineSession().containsKey("ContrProd")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().get("ContrProd")).andReturn(new Hashtable()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedDeiciAttrView")).andReturn(Boolean.TRUE).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),"back");
	}
	
	public BustaDeiciAttributeView getBustaDeiciAttributeView() {
		final BustaDeiciAttributeView bustaDeiciAttributeView = new BustaDeiciAttributeView() ;
		bustaDeiciAttributeView.setIdSuccursale(1L);
		bustaDeiciAttributeView.setAnagrafica("");
		bustaDeiciAttributeView.setCodiceDipendenteLastControl("");
		bustaDeiciAttributeView.setDataLastControl(new Timestamp(1L));
		bustaDeiciAttributeView.setDataVistoFirmare(new Timestamp(1L));
		bustaDeiciAttributeView.setBustaDeiciId(1L);
		bustaDeiciAttributeView.setOggettoId(1L);
		bustaDeiciAttributeView.setCodProdottoContratto("");
		return bustaDeiciAttributeView ;
	}
	
}
