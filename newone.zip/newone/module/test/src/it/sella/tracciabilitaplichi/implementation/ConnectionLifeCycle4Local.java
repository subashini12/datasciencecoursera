package it.sella.tracciabilitaplichi.implementation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;

public class ConnectionLifeCycle4Local {

    private Map<String, ConnectionInfo> connectionInfoPool = new HashMap<String, ConnectionInfo>();

    private Map<String, Connection> connectionPool = new HashMap<String, Connection>();

    private static final ConnectionLifeCycle4Local instance = new ConnectionLifeCycle4Local();

    public static ConnectionLifeCycle4Local getInstance() {
        return instance;
    }

    private ConnectionLifeCycle4Local() {
        registerConnection("clientPool", "jdbc:hsqldb:mem:testdb", "sa", "", "org.hsqldb.jdbcDriver");
    }

    public void registerConnection(String poolName, String url, String userName, String password) {
        registerConnection(poolName, url, userName, password, "oracle.jdbc.driver.OracleDriver");

    }

    public void registerConnection(String poolName, String url, String userName, String password, String driver) {
        connectionInfoPool.put(poolName, new ConnectionInfo(url, userName, password, driver));
    }

    private static class ConnectionInfo {

        private final String url;
        private final String userName;
        private final String password;
        private final String driver;

        private ConnectionInfo(String url, String userName, String password, String driver) {
            super();
            this.url = url;
            this.userName = userName;
            this.password = password;
            this.driver = driver;
        }

        public String getUrl() {
            return url;
        }

        public String getUserName() {
            return userName;
        }

        public String getPassword() {
            return password;
        }

        public String getDriver() {
            return driver;
        }

    }

    public Connection getConnection(String poolName) {
        Connection connection = null;
        ConnectionInfo info = connectionInfoPool.get(poolName);
        if (info == null) {
            throw new RuntimeException(poolName + " Info Not Registered ");
        }
        String url = info.getUrl();
        String serverName = info.getUserName();
        String passWord = info.getPassword();
        try {
            final long startTime = System.currentTimeMillis();
            System.out.println(" Getting  DB Connnection of URL : ( " + url + " )  server :: ( " + serverName + " ) Using PassWord ( " + passWord + " ) ");
            Class.forName(info.getDriver());
            connection = DriverManager.getConnection(url, serverName, passWord);
            System.out.println(" Connection Got : Time Taken to Getting Connectoin : ( " + ((System.currentTimeMillis() - startTime) / 1000) + " ) Seconds ");
        } catch (final ClassNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        } catch (final SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
        connectionPool.put(poolName, connection);
        return connection;
    }

    public void verifyConnectionClosed(String poolName) {
        Connection conn = connectionPool.get(poolName);
        if (conn != null) {
            try {
                boolean isClosed = conn.isClosed();
                Assert.assertTrue("Connection created for " + poolName + " is not closed", isClosed);
            } catch (SQLException e) {
                Assert.fail("Problem in verify closed Connection for " + poolName + " :: " + e.getMessage());
            }
        } else {
            Assert.fail("Connection is not found " + poolName);
        }
    }

}
