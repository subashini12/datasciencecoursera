package it.sella.tracciabilitaplichi.executer.gestionesolleciti.mock.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ProrogheListConfermaProcessorMock {
	@Mock
	public static Map validateProroghe(final RequestEvent reqEvent,
			final Map sollecitiRicercaMap) throws TracciabilitaException {
		final Map map1 = new HashMap();
		map1.put("1", "1");

		final Map map = new HashMap();
		map.put(ITPConstants.MSG, "");
		map.put(ITPConstants.ARGUMENT, "");
		map.put(ITPConstants.VALID_PROROGHE_RICERCA_LIST_MAP_NEW, map1);
		return map;
	}
}
