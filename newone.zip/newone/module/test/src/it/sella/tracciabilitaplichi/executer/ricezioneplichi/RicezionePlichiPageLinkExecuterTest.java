package it.sella.tracciabilitaplichi.executer.ricezioneplichi;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.RicezionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.RicezionePlichiCacheUtil;
import it.sella.tracciabilitaplichi.processor.RicezionePlichiProcessor;
import it.sella.tracciabilitaplichi.processor.mock.RicezionePlichiProcessorMock;

public class RicezionePlichiPageLinkExecuterTest extends
		AbstractSellaExecuterMock {

	public RicezionePlichiPageLinkExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezionePlichiPageLinkExecuter executer = new RicezionePlichiPageLinkExecuter();

	public void testRicezionePlichiPageLinkExecuter_01() {
		RicezionePlichiCacheUtilMock.setMapNotNull();
		setUpMockMethods(RicezionePlichiCacheUtil.class,
				RicezionePlichiCacheUtilMock.class);
		expecting(getRequestEvent().getAttribute("CheckedIds")).andReturn(
				"1212326563234");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("1");
		expecting(getRequestEvent().getAttribute("PrevPageNo")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicezionePlichiPageLinkExecuter_02() {
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class,
				TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class,
				RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class,
				RicezionePlichiProcessorMock.class);
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("1");
		expecting(getRequestEvent().getAttribute("CheckedIds")).andReturn("");
		expecting(getRequestEvent().getAttribute("PrevPageNo")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicezionePlichiPageLinkExecuter_03() {
		RicezionePlichiProcessorMock.setRemoteException();
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class,
				TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class,
				RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class,
				RicezionePlichiProcessorMock.class);
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("1");
		expecting(getRequestEvent().getAttribute("CheckedIds")).andReturn(
				"89:12");
		expecting(getRequestEvent().getAttribute("PrevPageNo")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}
}
