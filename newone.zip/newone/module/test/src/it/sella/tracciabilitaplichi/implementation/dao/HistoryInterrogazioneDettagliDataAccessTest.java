/*package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.SqlScriptExecuter;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;

import java.util.Calendar;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HistoryInterrogazioneDettagliDataAccessTest {
	
	HistoryInterrogazioneDettagliDataAccess historyInterrogazioneDettagliDataAccess = null;
	
	@Before
	public void setUp() throws Exception {
		historyInterrogazioneDettagliDataAccess = new HistoryInterrogazioneDettagliDataAccess();
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);		
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_OGGETTO (OG_TYPE numeric(12),OG_LID varchar(12),OG_OGGETTO_ACTUAL_DATE date,OG_USER varchar(12),OG_CDR varchar(12),OG_CURR_STATUS_ID numeric(12),OG_CURR_REF_ID numeric(12),OG_ID numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_OGGETTO (OG_TYPE,OG_LID,OG_OGGETTO_ACTUAL_DATE,OG_USER,OG_CDR,OG_CURR_STATUS_ID,OG_CURR_REF_ID,OG_ID) values(1,'1','2011-10-10','1','1',1,1,1)");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_PLICHI_ATTRIBUTE (PA_DOC_ID numeric(12),PA_BARCODE varchar(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_PLICHI_ATTRIBUTE (PA_DOC_ID) values(1,'123')");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_BUSTA_DEICI_ATTRIBUTE(BD_NC varchar(13),BD_ID numeric(12),BD_OC  varchar(13),BD_OGGETTO_ID numeric(12) ");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_BUSTA_DEICI_ATTRIBUTE(BD_NC ,BD_ID ,BD_OC ,BD_OGGETTO_ID ) values('1',1,'123',1)");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_BUSTA_CINQUE_ATTRIBUTE (BA_DOC_ID numeric(12), BA_ISBANKADMIN varchar(13)");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_BUSTA_CINQUE_ATTRIBUTE(BA_DOC_ID,BA_ISBANKADMIN) values(1,'1')");
	}
	
	@Test
	public void getRicercaView() {
		try {
			final Calendar cal = Calendar.getInstance();
		    cal.set( cal.YEAR, 1970 );
		    cal.set( cal.MONTH, cal.JANUARY );
		    cal.set( cal.DATE, 1 );
		    cal.set( cal.HOUR_OF_DAY, 0 );
		    cal.set( cal.MINUTE, 0 );
		    cal.set( cal.SECOND, 0 );
		    cal.set( cal.MILLISECOND, 0 );		    
		    final java.sql.Date jsqlD =  new java.sql.Date( cal.getTime().getTime() );
		    Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		    Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
			historyInterrogazioneDettagliDataAccess.getRicercaView(jsqlD, "123", "OttoCifre");
		}catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}	
	
	@After 
	 public void tearDown() throws Exception {
		 historyInterrogazioneDettagliDataAccess = null;
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_OGGETTO");
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_PLICHI_ATTRIBUTE");
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_BUSTA_DEICI_ATTRIBUTE");
	}

}
*/