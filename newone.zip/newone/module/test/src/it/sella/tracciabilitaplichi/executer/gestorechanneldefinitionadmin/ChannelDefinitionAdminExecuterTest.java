package it.sella.tracciabilitaplichi.executer.gestorechanneldefinitionadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorechanneldefinitionadmin.processor.ChannelDefinitionAdminProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.ChannelDefinitionAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.ChannelDefinitionAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.ChannelDefinitionView;

import java.util.Hashtable;

import mockit.Mockit;

import org.easymock.EasyMock;


public class ChannelDefinitionAdminExecuterTest extends AbstractSellaExecuterMock{

	public ChannelDefinitionAdminExecuterTest(final String name) {
		super(name);
	}

	ChannelDefinitionAdminExecuter executer = new ChannelDefinitionAdminExecuter() ;
	
	public void testChannelDefinitionAdminExecuter_01() {
		expecting(getRequestEvent().getEventName()).andReturn("ShowChannelDefinitionDetail").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrSelectedChannelInfo",executeResult.getTransition());
	}
	
	public void testChannelDefinitionAdminExecuter_02() {
		TracciabilitaPlichiImplMock.setCdr();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);	
		setUpMockMethods(ChannelDefinitionAdminImpl.class, ChannelDefinitionAdminImplMock.class);
		setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods(ChannelDefinitionAdminProcessor.class, ChannelDefinitionAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testChannelDefinitionAdminExecuter_03() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(ChannelDefinitionAdminImpl.class, ChannelDefinitionAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods(ChannelDefinitionAdminProcessor.class, ChannelDefinitionAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public void testChannelDefinitionAdminExecuter_07() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(ChannelDefinitionAdminImpl.class, ChannelDefinitionAdminImplMock.class);
		setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods(ChannelDefinitionAdminProcessor.class, ChannelDefinitionAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public void testChannelDefinitionAdminExecuter_04() {
		ChannelDefinitionAdminProcessorMock.setNullDefinitionId();
		TracciabilitaPlichiImplMock.setCdr();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(ChannelDefinitionAdminImpl.class, ChannelDefinitionAdminImplMock.class);
		setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods(ChannelDefinitionAdminProcessor.class, ChannelDefinitionAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());		
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testChannelDefinitionAdminExecuter_05() {
		ChannelDefinitionAdminProcessorMock.setError();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(ChannelDefinitionAdminImpl.class, ChannelDefinitionAdminImplMock.class);
		setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods(ChannelDefinitionAdminProcessor.class, ChannelDefinitionAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testChannelDefinitionAdminExecuter_06() {
		ChannelDefinitionAdminProcessorMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(ChannelDefinitionAdminImpl.class, ChannelDefinitionAdminImplMock.class);
		setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods(ChannelDefinitionAdminProcessor.class, ChannelDefinitionAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes();
		expecting(getStateMachineSession().get("ChannelDefinitionColl")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefnID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public ChannelDefinitionView getChannelDefinitionView() {
		final ChannelDefinitionView channelDefinitionView = new ChannelDefinitionView();
		channelDefinitionView.setChannelDefinitionId(1L);
		channelDefinitionView.setChannelDeadline(1L);
		channelDefinitionView.setChannelName("");
		return channelDefinitionView ;
	}
	
	public Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put(1L, getChannelDefinitionView());
		return hashtable ;
	}
	
}
