package it.sella.tracciabilitaplichi.executer.test.inserimentobustadieci;


import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.InserimentoContrattiHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

public class DefaultActionTest extends AbstractSellaExecuterMock
{
	
	public DefaultActionTest( final String name )
	{
		super( name );
	}
	
	@Override
	protected void setUp( ) throws Exception
	{
		super.setUp( );
		mockSecurityWrapper( );
	}
	public void testDefaultAction_1( )
	{
		/*mockContrattiHelper( Boolean.FALSE );
		mockViewHelper( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.ABILITATO.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		playAll( );
		AbstractInserimentoExecuter executer = new DefaultAction( );
		final ExecuteResult executeResult = executer.execute( getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), executeResult.getTransition( ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.VIEW_HELPER.toString( ) ) );*/
	}

	public void testDefaultAction_2( )
	{
		/*mockContrattiHelper( Boolean.FALSE );
		mockViewHelper( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.ABILITATO.toString( ) ) ).andReturn( Boolean.FALSE ).anyTimes( );
		expecting( getStateMachineSession( ).put( CONSTANTS.ABILITATO.toString( ), Boolean.TRUE ) ).andReturn( Boolean.TRUE ).anyTimes( );
		playAll( );
		final AbstractInserimentoExecuter executer = new DefaultAction( );
		final ExecuteResult executeResult = executer.execute( getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), executeResult.getTransition( ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.VIEW_HELPER.toString( ) ) );*/
	}

	public void testDefaultAction_3( )
	{
		/*mockContrattiHelper( Boolean.TRUE );
		mockViewHelper( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.ABILITATO.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		playAll( );
		final AbstractInserimentoExecuter executer = new DefaultAction( );
		final ExecuteResult executeResult = executer.execute( getRequestEvent( ) );
		assertNull( executeResult.getTransition( ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.VIEW_HELPER.toString( ) ) );*/
	}
	
	private void mockContrattiHelper( final Boolean isException )
	{
		redefineMethod( InserimentoContrattiHelper.class, new Object( ) {
			public Map<Enum<CONSTANTS>, Object> getSessionMap( final RequestEvent requestEvent )
			{
				return new HashMap<Enum<CONSTANTS>, Object>( 1 ); 
			}
			public void setDefaultPageDetails( final Map<Enum<CONSTANTS>, Object> sessionMap ) throws TracciabilitaException, RemoteException
			{
				if ( isException )
				{
					throw new TracciabilitaException( "TrTPException" );
				}
			}
		} );
	}
	private void mockSecurityWrapper( )
	{
		redefineMethod( SecurityWrapper.class, new Object( ) { 
			public String getDenominazioneCdr( )
			{
				return "099361";
			}
		} );
	}
	
}
