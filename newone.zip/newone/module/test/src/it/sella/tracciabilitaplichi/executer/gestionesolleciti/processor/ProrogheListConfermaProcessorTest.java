package it.sella.tracciabilitaplichi.executer.gestionesolleciti.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiDetailView;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiProrogheListView;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiProrogheView;

import java.util.HashMap;
import java.util.Map;


public class ProrogheListConfermaProcessorTest extends AbstractSellaExecuterMock{

	public ProrogheListConfermaProcessorTest(final String name) {
		super(name);
	}

	ProrogheListConfermaProcessor processor = new ProrogheListConfermaProcessor() ;
	
	public void testProrogheListConfermaProcessor_01() {
		UtilMock.setCheckNullFalse();
		ExternalServicesFactoryMock.setOperationAllowed();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		expecting(getRequestEvent().getAttribute("prGG1")).andReturn("12");
		expecting(getRequestEvent().getAttribute("prMM1")).andReturn("12");
		expecting(getRequestEvent().getAttribute("sdDisabled1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prAAAA1")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("prNote1")).andReturn("");
		playAll();
		try {
			assertNotNull(processor.validateProroghe(getRequestEvent(),getMap() ));
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testProrogheListConfermaProcessor_02() {
		ExternalServicesFactoryMock.setOperationAllowed();
		setUpMockMethods(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("prGG1")).andReturn("12");
		expecting(getRequestEvent().getAttribute("prMM1")).andReturn("12");
		expecting(getRequestEvent().getAttribute("sdDisabled1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prAAAA1")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("prNote1")).andReturn("Ajax");
		playAll();
		try {
			assertNotNull(processor.validateProroghe(getRequestEvent(),getMap() ));
		} catch (final TracciabilitaException e) {
			assertNotNull(e);		}
		}
	
	public void testProrogheListConfermaProcessor_03() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("prGG1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prMM1")).andReturn("");
		expecting(getRequestEvent().getAttribute("sdDisabled1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prAAAA1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prNote1")).andReturn("");
		playAll();
		try {
			assertNotNull(processor.validateProroghe(getRequestEvent(),getMap() ));
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	
	public void testProrogheListConfermaProcessor_04() {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("prGG1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prMM1")).andReturn("");
		expecting(getRequestEvent().getAttribute("sdDisabled1")).andReturn("hj");
		expecting(getRequestEvent().getAttribute("prAAAA1")).andReturn("");
		expecting(getRequestEvent().getAttribute("prNote1")).andReturn("");
		playAll();
		try {
			assertNotNull( processor.validateProroghe(getRequestEvent(),getMap()  ));
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	private static Map getMap() {
		final Map map =new HashMap();
		map.put(1L,getSollecitiProrogheListView());
		return map ;
	}
	
	private static SollecitiProrogheListView getSollecitiProrogheListView() {
		final SollecitiDetailView sollecitiDetailView = new SollecitiDetailView() ;
		sollecitiDetailView.setSdDisabled("");
		final SollecitiProrogheView sollecitiProrogheView = new SollecitiProrogheView() ;
		sollecitiProrogheView.setSpNote("");
		final SollecitiProrogheListView sollecitiProrogheListView= new SollecitiProrogheListView() ;
		sollecitiProrogheListView.setSollecitiDetailView(sollecitiDetailView);
		sollecitiProrogheListView.setSollecitiProrogheView(sollecitiProrogheView);
		return sollecitiProrogheListView ;
	}
	
}
