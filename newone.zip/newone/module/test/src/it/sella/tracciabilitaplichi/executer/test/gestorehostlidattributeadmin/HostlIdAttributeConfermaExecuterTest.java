package it.sella.tracciabilitaplichi.executer.test.gestorehostlidattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestorehostlidattributeadmin.HostlIdAttributeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccessMock;

import java.util.Hashtable;

import org.easymock.EasyMock;

public class HostlIdAttributeConfermaExecuterTest extends AbstractSellaExecuterMock
{

	public HostlIdAttributeConfermaExecuterTest(String name) 
	{
		super(name);
	}
	
	HostlIdAttributeConfermaExecuter executer = new HostlIdAttributeConfermaExecuter();
	
	public void testHostlIdAttributeConfermaExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiISEDataAccess.class, TracciabilitaPlichiISEDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("02").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "HostIdAttributeHt" )).andReturn(  new Hashtable()  ).anyTimes();
		expecting( getStateMachineSession().containsKey( "HostIdAttributeHt") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testHostlIdAttributeConfermaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiISEDataAccess.class, TracciabilitaPlichiISEDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("03").anyTimes();
		expecting( getStateMachineSession().get( "HostIdAttributeHt" )).andReturn(  new Hashtable()  ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testHostlIdAttributeConfermaExecuter_03()
	{
		setUpMockMethods(TracciabilitaPlichiISEDataAccess.class, TracciabilitaPlichiISEDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("03").anyTimes();
		expecting( getStateMachineSession().get( "HostIdAttributeHt" )).andReturn(  new Hashtable()  ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testHostlIdAttributeConfermaExecuter_04()
	{
		setUpMockMethods(TracciabilitaPlichiISEDataAccess.class, TracciabilitaPlichiISEDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("02").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "HostIdAttributeHt" )).andReturn(  new Hashtable()  ).anyTimes();
		expecting( getStateMachineSession().containsKey( "HostIdAttributeHt") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();		
		executer.execute(getRequestEvent());
	}
	public void testHostlIdAttributeConfermaExecuter_05()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException() ;
		setUpMockMethods(TracciabilitaPlichiISEDataAccess.class, TracciabilitaPlichiISEDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("02").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "HostIdAttributeHt" )).andReturn(  new Hashtable()  ).anyTimes();
		expecting( getStateMachineSession().containsKey( "HostIdAttributeHt") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();		
		executer.execute(getRequestEvent());
	}	

}
