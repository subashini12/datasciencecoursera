package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;


import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestoreCodiceHostModificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPCodiceHostDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPCodiceHostDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import mockit.Mockit;


public class GestoreCodiceHostModificaExecuterTestCase extends AbstractSellaExecuterMock {
	
	 public GestoreCodiceHostModificaExecuterTestCase( final String name )
	    {
	        super( name );
	        // TODO Auto-generated constructor stub
	    }
	 
	 @Override
	protected void setUp( ) throws Exception
	    {
	        super.setUp( );
	    }
	 
	 GestoreCodiceHostModificaExecuter gestoreCodiceHostModificaExecuter =  new GestoreCodiceHostModificaExecuter();
	 
	 
	 /*public void testGestoreCodiceHostModificaExecuterrTest_01(){
		 TPCodiceHostDataAccessMock.setCodiceHostExists();
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211221" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	    }*/
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_04(){
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211221" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	    }
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_05(){
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("122112421" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("R").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	    }
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_06(){
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211421" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("R").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	    }
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_07(){
		 TPUtilMock.setInValidBankId();
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211421" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("R").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00").anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	    }
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_08(){
		 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211421" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("R").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00").anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	 }
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_09(){
		 TracciabilitaPlichiImplMock.setRemoteException();
		 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211421" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("R").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00").anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	 }
	 
	 public void testGestoreCodiceHostModificaExecuterrTest_10(){
		 TracciabilitaPlichiImplMock.setTracciabilitaException();
		 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		 setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);
		 expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12211421" ).anyTimes();
		 expecting( getRequestEvent().getEventName()).andReturn("R").anyTimes();
		 expecting( getRequestEvent().getAttribute("id") ).andReturn("1212" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00").anyTimes();
		 expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12-Dec-2010" ).anyTimes();
		 expecting( getRequestEvent().getAttribute("toDate") ).andReturn("31-Feb-2011" ).anyTimes();
	     playAll();
	     final ExecuteResult executeResult =	gestoreCodiceHostModificaExecuter.execute(getRequestEvent());
	 }
}
