package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaDataAccessException;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.PAltriAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.PBustaNeraAttributeView;

import java.util.Collection;
import java.util.Date;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TracciabilitaPlichiAdminTransactionDataAccessTest {

	TracciabilitaPlichiAdminTransactionDataAccess adminTransactionDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		adminTransactionDataAccess = new TracciabilitaPlichiAdminTransactionDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		adminTransactionDataAccess = null;
	}

	@Test
	public void getPlichiAltriAttributeView() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider("SELECT PD_ID, PD_DOC_ID, PD_AW_ID, PD_DA_DATE, PD_A_DATE FROM  TP_TR_PALTRI_ATTRIBUTE  WHERE PD_ID=?");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,1,"4");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,2,"9");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"10");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.DATE, 1,4,new Date());
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.DATE, 1,5,new Date());
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final PAltriAttributeView pAltriAttributeView = adminTransactionDataAccess.getPlichiAltriAttributeView("12");
		Assert.assertEquals(Long.valueOf("10"),pAltriAttributeView.getAltriId());
	}

	@Test
	public void getAltriAttributeView() throws NumberFormatException, TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT AA.AA_ID, AA.AA_DOC_ID, AA.AA_NUMBER, AA.AA_CDR_DESTINATION, AA.AA_OG_TYPE, AA.AA_OG_BANK FROM TP_TR_ALTRI_ATTRIBUTE AA, TP_TR_OGGETTO OG WHERE AA.AA_DOC_ID = OG.OG_ID AND AA.AA_ID = ? AND OG.OG_BANK = ?");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,3l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,2,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"9010110201123");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,4,"10");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,5,9l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,6,8l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final AltriAttributeView altriAttributeView = adminTransactionDataAccess.getAltriAttributeView(Long.valueOf("12"));
		Assert.assertEquals("9010110201123",altriAttributeView.getBarCode());
	}
	@Test
	public void getOggettoStatusView_01() throws NumberFormatException, TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT OS.OS_ID,OS.OS_DOC_ID,OS.OS_STATUS_ID,OS.OS_USER,OS.OS_CDR,OS.OS_IP_ADDRESS,OS.OS_DATE_TIME,OS.OS_REF_ID FROM TP_TR_OGGETTO_STATUS_REFERENCE OS,TP_TR_OGGETTO OG  WHERE OS.OS_DOC_ID=OG.OG_ID AND OS.OS_ID=? AND OG.OG_BANK=?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,3l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,2,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,3,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,4,"BSZI212");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,5,"099231");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,6,"10.2.56");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.DATE, 1,7,new Date());
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,8,"");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final HistoryView historyView = adminTransactionDataAccess.getOggettoStatusView(Long.valueOf("12"));
		Assert.assertEquals("BSZI212",historyView.getUserId());
	}

	@Test
	public void getOggettoStatusView_02() throws NumberFormatException, TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT OS.OS_ID,OS.OS_DOC_ID,OS.OS_STATUS_ID,OS.OS_USER,OS.OS_CDR,OS.OS_IP_ADDRESS,OS.OS_DATE_TIME,OS.OS_REF_ID FROM TP_TR_OGGETTO_STATUS_REFERENCE OS,TP_TR_OGGETTO OG  WHERE OS.OS_DOC_ID=OG.OG_ID AND OS.OS_ID=? AND OG.OG_BANK=?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,3l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,2,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,3,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,4,"BSZI212");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,5,"099231");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,6,"10.2.56");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.DATE, 1,7,new Date());
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,8,"4");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final HistoryView historyView = adminTransactionDataAccess.getOggettoStatusView(Long.valueOf("12"));
		Assert.assertEquals("BSZI212",historyView.getUserId());
	}
	@Test
	public void getPBustaNeraAttributeView() throws NumberFormatException, TracciabilitaDataAccessException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT PBN_DOC_ID, PBN_DATE, PBN_DESC, PBN_IMPORTO, PBN_NOTE FROM TP_TR_BUSTANERA_ATTRIBUTE WHERE PBN_ID = ?");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 0, "PBN_DOC_ID",1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.DATE, 1, "PBN_DATE",new java.sql.Date(0));
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, "PBN_DESC","Desc");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 3, "PBN_IMPORTO","12");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 4, "PBN_NOTE","Note");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final PBustaNeraAttributeView pBNView = adminTransactionDataAccess.getPBustaNeraAttributeView(Long.valueOf("12"));
		Assert.assertEquals("Note",pBNView.getNote());
	}
	@Test
	public void isValidRefId() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT OG_ID FROM TP_TR_OGGETTO WHERE OG_ID=? AND OG_BANK = ?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,3l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final boolean isValidRefId = adminTransactionDataAccess.isValidRefId("12");
		Assert.assertTrue(isValidRefId);
	}
	@Test
	public void getBustaNeraErrorCodeView() throws NumberFormatException, TracciabilitaException{
		mockStatementProvider = new MockStatementProvider("SELECT BE_ID, BE_DOC_ID,BE_ERROR_CODE  FROM TP_TR_BUSTANERA_ERRORCODE  WHERE BE_ID =? ");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,3l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,2,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"TPRL-010");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection bustaNeraErrorCodeViewColl = adminTransactionDataAccess.getBustaNeraErrorCodeView(Long.valueOf("2"));
		Assert.assertEquals(1, bustaNeraErrorCodeViewColl.size());
	}
	@Test
	public void getBustaCinqueAttributeView() throws NumberFormatException, TracciabilitaException{
		mockStatementProvider = new MockStatementProvider("SELECT BA_ID, BA_DOC_ID,BA_ISBANKADMIN,BA_DEL_NOTE  FROM TP_TR_BUSTA_CINQUE_ATTRIBUTE  WHERE BA_ID =? " );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,3l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,2,4l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"T");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,4,"ADMIN");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection bustaCinqueAttributeViewColl = adminTransactionDataAccess.getBustaCinqueAttributeView(Long.valueOf("6"));
		Assert.assertEquals(1, bustaCinqueAttributeViewColl.size());
	}
}
