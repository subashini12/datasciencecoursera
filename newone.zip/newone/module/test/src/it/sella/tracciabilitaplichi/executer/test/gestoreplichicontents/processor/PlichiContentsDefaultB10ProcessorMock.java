package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import mockit.Mock;

public class PlichiContentsDefaultB10ProcessorMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;
	private static Boolean messageflag = false;
	private static Boolean isMapEmpty = false;

	public static void setMapEmpty() {
		isMapEmpty = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setMessage() {
		messageflag = true;
	}

	@Mock
	public static Map setRicezioneData(RequestEvent rqEvent,
			StateMachineSession session) throws TracciabilitaException,
			RemoteException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final HashMap mapRicezioneData = new HashMap();
		OggettoView oggettoView = new OggettoView();
		oggettoView.setBankDescription("abcd");
		mapRicezioneData.put("OggettoView", oggettoView);
		if (messageflag) {
			messageflag = false;
			mapRicezioneData.put("message", "abcd");
		}
		return mapRicezioneData;
	}

	@Mock
	public static Map getUserDetail() throws RemoteException,
			TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final Map usrgc = new Hashtable();
		usrgc.put("datacurr", "10/05/1985");
		usrgc.put("user", "gbs03094");
		return usrgc;
	}

	@Mock
	public static Map addControlloData(RequestEvent rqEvent,
			StateMachineSession session) throws TracciabilitaException,
			RemoteException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		BustaDeiciAttributeView bustaDeiciAttributeView = new BustaDeiciAttributeView();
		bustaDeiciAttributeView.setBarcode("1234567891234");
		ControlliView controlliView = new ControlliView();
		controlliView.setNote("note");
		Map map = new HashMap();
		map.put("message", "message");
		map.put("bustaDeiciView", bustaDeiciAttributeView);
		map.put("controlliView", controlliView);
		if (isMapEmpty) {
			map.put("message", "");
		}

		return map;
	}
}
