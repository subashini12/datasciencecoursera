package it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class HomePageProcessorMock 
{
	private static Boolean remoteException = false;
	
	public static void setRemoteException() {
		remoteException = true;
	}
	@Mock
	public static Map getUserDetails( ) throws TracciabilitaException, RemoteException
	{		
		if(remoteException){
			remoteException = false;
			throw new RemoteException();
		}
		final Map map = new HashMap();
		map.put("user","ravi");
		map.put("cdr","099231");
		map.put("CodSucc", "abc");
		map.put("idsucc", 2L);
		map.put(CONSTANTS.USER.getValue( ), "ravi");
		map.put(ITPConstants.CDR,"IT-Org"); 		
		map.put( CONSTANTS.NAME.getValue( ), "ANBARASU" );
		map.put( CONSTANTS.SUR_NAME.getValue( ), "SHANMUGHAM" );
		map.put( CONSTANTS.CDR_DESCRIPTION.getValue( ), "MIST BUSINESS UNIT" );
		map.put( CONSTANTS.ABI_BANCA.getValue( ), "03311" );
		map.put( CONSTANTS.BANK_DESCRIPTION.getValue( ), "Banca Sella Holding" );
		return map;		
	}
	
	
	
}
