package it.sella.tracciabilitaplichi.executer.test.gestorechannelelementsadmin;

import it.sella.tracciabilitaplichi.executer.gestorechannelelementsadmin.ChannelElementsAdminDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.util.Hashtable;

import org.easymock.EasyMock;

public class ChannelElementsAdminDefaultExecuterTest extends AbstractSellaExecuterMock
{

	public ChannelElementsAdminDefaultExecuterTest(String name) 
	{
		super(name);
	}
	
	ChannelElementsAdminDefaultExecuter executer = new ChannelElementsAdminDefaultExecuter();
	
	public void testExecuter_01()
	{
		setUpMockMethods( TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class , TracciabilitaPlichiCommonDataAccessMock.class );
		setUpMockMethods( TPUtil.class , TPUtilMock.class );
		expecting(getStateMachineSession().put( "ChannelElementsColl", getchannelElementsColl() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( "ChannelDefinitionColl", getchannelElementsColl() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll() ;
		executer.execute( getRequestEvent());
	}
	public void testExecuter_02()
	{
		TracciabilitaPlichiCommonDataAccessMock.setTracciabilitaException();
		setUpMockMethods( TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class , TracciabilitaPlichiCommonDataAccessMock.class );
		setUpMockMethods( TPUtil.class , TPUtilMock.class );
		expecting(getStateMachineSession().put( "ChannelElementsColl", getchannelElementsColl() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( "ChannelDefinitionColl", getchannelElementsColl() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll() ;
		executer.execute( getRequestEvent());
	}
	
	private Hashtable getchannelElementsColl()
	{
		Hashtable hashtable = new Hashtable();		
		hashtable.put(1, "abc");
		return  hashtable;
	}	

}
