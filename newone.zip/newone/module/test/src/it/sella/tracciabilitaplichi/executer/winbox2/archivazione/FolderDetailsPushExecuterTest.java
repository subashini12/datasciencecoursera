package it.sella.tracciabilitaplichi.executer.winbox2.archivazione;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.archivazione.processor.FolderChooserProcessor;

import java.io.Serializable;
import java.util.Stack;



public class FolderDetailsPushExecuterTest extends AbstractSellaExecuterMock{

	public FolderDetailsPushExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	FolderDetailsPushExecuter executer=new FolderDetailsPushExecuter();
	public void testFolderDetailsPushExecuter_01()
	{
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(FolderChooserProcessor.class, FolderChooserProcessorMock.class);
		Stack stack=new Stack();
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("1212123242").anyTimes();
		expecting(getStateMachineSession().containsKey(CONSTANTS.BARCODE_STACK.getValue( ))).andReturn(false).anyTimes();
		expecting(getStateMachineSession().get(CONSTANTS.BARCODE_STACK.getValue( ))).andReturn(stack).anyTimes();
		expecting( getStateMachineSession().put( CONSTANTS.BARCODE_STACK.getValue( ) ,(Serializable)stack ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testFolderDetailsPushExecuter_02()
	{	setUpMockMethods(FolderChooserProcessor.class, FolderChooserProcessorMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		Stack stack=new Stack();
		stack.push("Barcode");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("1212123242").anyTimes();
		expecting(getStateMachineSession().containsKey(CONSTANTS.BARCODE_STACK.getValue( ))).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get(CONSTANTS.BARCODE_STACK.getValue( ))).andReturn(stack).anyTimes();
		expecting( getStateMachineSession().put( CONSTANTS.BARCODE_STACK.getValue( ) ,(Serializable)stack ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testFolderDetailsPushExecuter_03()
	{	setUpMockMethods(FolderChooserProcessor.class, FolderChooserProcessorMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		Stack stack=new Stack();
		stack.push(null);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("1212123242").anyTimes();
		expecting(getStateMachineSession().containsKey(CONSTANTS.BARCODE_STACK.getValue( ))).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get(CONSTANTS.BARCODE_STACK.getValue( ))).andReturn(stack).anyTimes();
		expecting( getStateMachineSession().put( CONSTANTS.BARCODE_STACK.getValue( ) ,(Serializable)stack ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		
	}

}
