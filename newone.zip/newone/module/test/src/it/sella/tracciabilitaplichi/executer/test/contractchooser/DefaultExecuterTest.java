package it.sella.tracciabilitaplichi.executer.test.contractchooser;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

import it.sella.tracciabilitaplichi.contractchooser.helper.ContractListUtil;
import it.sella.tracciabilitaplichi.executer.contractchooser.DefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.contractchooser.helper.ContractListUtilMock;

public class DefaultExecuterTest extends AbstractSellaExecuterMock
{

	public DefaultExecuterTest(String name) 
	{
		super(name);		
	}
	
	DefaultExecuter executer = new DefaultExecuter();
	
	public void testDefaultExecuter_01()
	{
		setUpMockMethods(ContractListUtil.class , ContractListUtilMock.class);
		expecting( getStateMachineSession().get( "PlichiBusta10Map" )).andReturn( ( Serializable )getPlichiBusta10Map()).anyTimes();
		expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDefaultExecuter_02()
	{
		ContractListUtilMock.setTracciabilitaException();
		setUpMockMethods(ContractListUtil.class , ContractListUtilMock.class);
		expecting( getStateMachineSession().get( "PlichiBusta10Map" )).andReturn( ( Serializable )getPlichiBusta10Map()).anyTimes();
		expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	private Map getPlichiBusta10Map()
	{
		Map map = new HashMap();
		map.put("a", "value");
		return map;		
	}

}
