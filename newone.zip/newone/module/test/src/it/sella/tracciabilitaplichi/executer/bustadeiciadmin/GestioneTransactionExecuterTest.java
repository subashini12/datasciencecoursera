package it.sella.tracciabilitaplichi.executer.bustadeiciadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPControlliDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TPControlliDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.HelperMock;
import it.sella.tracciabilitaplichi.implementation.util.Helper;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;

import java.util.Map;

import org.easymock.EasyMock;



public class GestioneTransactionExecuterTest extends AbstractSellaExecuterMock{

	public GestioneTransactionExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	GestioneTransactionExecuter executer=new GestioneTransactionExecuter();
	
	public void testGestioneTransactionExecuter_01() {
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("1");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null, executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_02() {
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn(null);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail", executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_03() {
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail", executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_04() {
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("id");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail", executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_05() {
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("0112");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail", executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_06() {
		TPControlliDataAccessMock.setcontrattoIdNull();
		setUpMockMethods(GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class);
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("0112");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ControlliView) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_07() {
		TPControlliDataAccessMock.setcontrolliViewNOtNull();
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("1");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ControlliView) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null, executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_08() {
		TPControlliDataAccessMock.setcontrolliViewNOtNull();
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("0112");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null, executeResult.getTransition());
	}
	
	public void testGestioneTransactionExecuter_09() {
		HelperMock.setRemoteException();
		setUpMockMethods(Helper.class, HelperMock.class);
		expecting(getRequestEvent().getAttribute("ControlliID")).andReturn("1");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null, executeResult.getTransition());
	}
	
}
