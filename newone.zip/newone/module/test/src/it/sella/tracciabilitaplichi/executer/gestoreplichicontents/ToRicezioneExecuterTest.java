package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;


import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultB10Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents.processor.PlichiContentsDefaultB10ProcessorMock;

public class ToRicezioneExecuterTest extends AbstractSellaExecuterMock{

	public ToRicezioneExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ToRicezioneExecuter executer=new ToRicezioneExecuter();
	public void testToRicezioneExecuter_01()
	{
		setUpMockMethods(PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		executer.execute(getRequestEvent());
	}
	public void testToRicezioneExecuter_02()
	{
		PlichiContentsDefaultB10ProcessorMock.setTracciabilitaException();
		setUpMockMethods(PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		executer.execute(getRequestEvent());
	}
	public void testToRicezioneExecuter_03()
	{
		PlichiContentsDefaultB10ProcessorMock.setRemoteException();
		setUpMockMethods(PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		executer.execute(getRequestEvent());
	}
}
