package it.sella.tracciabilitaplichi.implementation;


import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiImplDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiImplDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.Before;

public class AltriBustaCinqueImplTest extends AbstractSellaMock{

	public AltriBustaCinqueImplTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	AltriBustaCinqueImpl altriBustaCinqueImpl = new AltriBustaCinqueImpl() ;

	@Override
	@Before
	public void setUp() throws Exception {
	}

	public void testAltriBustaCinqueImpl_01()
	{
		ClassificazioneWrapperMock.setPBUST5();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiImplDataAccess.class, TracciabilitaPlichiImplDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		try {
			altriBustaCinqueImpl.censitoOggetto(getProperties());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private static OggettoView getOggettoView()
	{
		final OggettoView oggettoView=new OggettoView();
		oggettoView.setUserId("2");
		oggettoView.setCdrName("01235");
		oggettoView.setStatusId(2L);
		oggettoView.setUserId("56");
		new SimpleDateFormat("dd/MM/yyyy");
		final Date date = new Date("2012,jan,9");
		final Timestamp timeStamp = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(timeStamp);
		return oggettoView;
	}
	
	private static Properties getProperties()
	{
		final Map map = new HashMap();
		final HistoryView historyView=getHistoryView();
		final OggettoView oggettoView=getOggettoView ();
		final Properties properties=new Properties();
		properties.put(ITPConstants.OGGETTO_VIEW ,oggettoView );
		properties.put(ITPConstants.HISTORY_VIEW, historyView);
		properties.put("PlichiBusta5Map",map);
		properties.put("MismatchPlichiBusta5Map",map);
		final Collection collection = new ArrayList();
		properties.put("SelBarCodeCollection",collection );
		return properties;
	}
	
	private static HistoryView getHistoryView()
	{
		final HistoryView historyView=new HistoryView();
		historyView.setDocumentId(2L);
		return historyView; 
	}
	
}
