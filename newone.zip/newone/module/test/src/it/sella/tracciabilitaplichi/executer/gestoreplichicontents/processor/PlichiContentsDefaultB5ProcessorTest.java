package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.HistoryPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Hashtable;

import org.easymock.EasyMock;


public class PlichiContentsDefaultB5ProcessorTest extends AbstractSellaExecuterMock{

	public PlichiContentsDefaultB5ProcessorTest(String name) {
		super(name);
	}
	
	PlichiContentsDefaultB5Processor processor = new PlichiContentsDefaultB5Processor () ;
	
	public void testPlichiContentsDefaultB5Processor_01()
	{
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		try {
			expecting(getStateMachineSession().get("SearchFrom")).andReturn(null).anyTimes();
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
			playAll();
			processor.processB5Records(getRequestEvent(), "1234567891458");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public void testPlichiContentsDefaultB5Processor_02()
	{
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(HistoryPlichiContentsDataAccess.class, HistoryPlichiContentsDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		try {
			expecting(getStateMachineSession().get("SearchFrom")).andReturn("History").anyTimes();
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
			playAll();
			processor.processB5Records(getRequestEvent(), "1234567891458");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	/*public void testProcessPB5Records_01()
	{
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		try {
			expecting(getStateMachineSession().get("SearchFrom")).andReturn(null).anyTimes();
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
			playAll();
			IBorsaVerdeDataAccess borsaVerdeDataAccess = EasyMock.createMock(IBorsaVerdeDataAccess.class);
			expecting(borsaVerdeDataAccess.getBorsaVerdeCode("1234567891458")).andReturn("122").anyTimes();
			EasyMock.replay(borsaVerdeDataAccess);
			processor.processPB5Records(getRequestEvent(), "1234567891458");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (TracciabilitaException e) {
			e.printStackTrace();
		}
	}*/
}
