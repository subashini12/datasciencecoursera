/*package it.sella.tracciabilitaplichi.implementation;


import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriView;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Properties;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

public class AltriPlichiImplTest extends BasicJDBCTestCaseAdapter 
{

	AltriPlichiImpl altriPlichiImpl = new AltriPlichiImpl();
	
	private static OggettoView getOggettoView()
	{
		final OggettoView oggettoView=new OggettoView();
		oggettoView.setId(1L);
		return oggettoView;
	}
	
	private static  HistoryView getHistoryView()
	{
		final HistoryView historyView= new HistoryView();
		historyView.setDocumentId(1L);
		historyView.setCdr("abc");
		return historyView;
	}
	private static  PlichiAttributeView getPlichiAttributeView()
	{
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView();
		plichiAttributeView.setBankDescription("banca sella");
		return plichiAttributeView;
	}
	private static  Collection getInvioPAltriCollection()
	{
		final Collection invioPAltriCollection = new ArrayList();
		final AltriView av1=new AltriView();
		av1.setId(2L);
		invioPAltriCollection.add(av1);
		return invioPAltriCollection;
	}
	
	private static  Collection getAltriViewCollection()
	{
		final Collection altriCollection = new ArrayList();
		final AltriView av1=new AltriView();
		av1.setId(1L);
		altriCollection.add(av1);
		return altriCollection;
	}
	
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable=new Hashtable();
		hashtable.put("AltriID", 2L);
		hashtable.put("barCode", "12");
		return hashtable;
	}
	private static Properties getProperties()
	{
		final Properties properties=new Properties();
		properties.put("OggettoView", getOggettoView());
		properties.put("HistoryView", getHistoryView());
		properties.put("PlichiAttributeView",getPlichiAttributeView() );
		properties.put("AltriCollection", getAltriViewCollection());
		properties.put("InvioPAltriCollection", getInvioPAltriCollection());
		properties.put("ModificaAltriTable",getHashtable());
		return properties;
	}
	
	public void testAltriBustaImplTestCase_01() throws SQLException  {

		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("PD_ID", new Object[] { "1" });
		result.addColumn("PD_DOC_ID", new Object[] { "1" });
		result.addColumn("PD_AW_ID", new Object[] { "1" });
		result.addColumn("PD_DA_DATE", new Object[] { new Timestamp(1L) });
		result.addColumn("PD_A_DATE", new Object[] { new Timestamp(1L) });
		statementHandler.prepareGlobalResultSet(result);
		try {
			altriPlichiImpl.censitoOggetto(getProperties());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliOggetto_01() 
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		final Properties properties=getProperties();
		try {
			altriPlichiImpl.cancelliOggetto(properties);
		} catch (final RemoteException e) {
		} catch (final TracciabilitaException e) {
		}
	}
	
}
*/