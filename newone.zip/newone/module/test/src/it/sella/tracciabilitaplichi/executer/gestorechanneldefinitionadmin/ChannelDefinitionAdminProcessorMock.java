package it.sella.tracciabilitaplichi.executer.gestorechanneldefinitionadmin;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ChannelDefinitionView;

import java.rmi.RemoteException;
import java.util.HashMap;

import mockit.Mock;

public class ChannelDefinitionAdminProcessorMock {
	
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	private static Boolean isNullDefinitionId = false;
	private static Boolean isError = false;

	public static void setNullDefinitionId() {
		isNullDefinitionId = true;
	}
	
	public static void setError() {
		isError = true;
	}

	@Mock
	public static HashMap validateEvent(final RequestEvent requestEvent)
			throws TracciabilitaException, RemoteException {
		final ChannelDefinitionView channelDefinitionView = new ChannelDefinitionView();
		channelDefinitionView.setChannelDeadline(1L);
		channelDefinitionView.setChannelDefinitionId(1L);
		channelDefinitionView.setChannelName("");
		if (isNullDefinitionId) {
			channelDefinitionView.setChannelDefinitionId(null);
		}
		HashMap hashMap = new HashMap();
		hashMap.put("View", channelDefinitionView);
		if(isError)
		{
			hashMap = new HashMap();
			hashMap.put("Error", "");
			hashMap.put("Argument", "");
			hashMap.put("MSG", "");	
		}
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		
		return hashMap;
	}
}
