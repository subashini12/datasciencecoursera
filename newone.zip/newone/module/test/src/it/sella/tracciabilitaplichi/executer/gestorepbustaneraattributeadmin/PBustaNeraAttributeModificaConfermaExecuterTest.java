package it.sella.tracciabilitaplichi.executer.gestorepbustaneraattributeadmin;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.admin.PBustaNeraAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.PBustaNeraAttributeAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

public class PBustaNeraAttributeModificaConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	public PBustaNeraAttributeModificaConfermaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PBustaNeraAttributeModificaConfermaExecuter executer = new PBustaNeraAttributeModificaConfermaExecuter();

	public void testPBustaNeraAttributeModificaConfermaExecuter_01() {
		    TracciabilitaPlichiImplMock.setBustaNera();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
			setUpMockMethods(PBustaNeraAttributeAdminImpl.class,
					PBustaNeraAttributeAdminImplMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("conferma")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("PageFrom")).andReturn(
					"Modifica").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute"))
					.andReturn((Serializable) getMap()).anyTimes();
			expecting(
					getStateMachineSession().containsKey(
							"mapPBustaNeraAttribute")).andReturn(Boolean.TRUE)
					.anyTimes();
			expecting(getStateMachineSession().remove("mapPBustaNeraAttribute"))
					.andReturn("").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}

	public void testPBustaNeraAttributeModificaConfermaExecuter_02() {
	        TracciabilitaPlichiImplMock.setBustaNera();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			final Map map = new HashMap();
			map.put("id", 1L);
			setUpMockMethods(PBustaNeraAttributeAdminImpl.class,
					PBustaNeraAttributeAdminImplMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("conferma")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("PageFrom")).andReturn(
					"Cancelli").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute"))
					.andReturn((Serializable) map).anyTimes();
			expecting(
					getStateMachineSession().containsKey(
							"mapPBustaNeraAttribute")).andReturn(Boolean.TRUE)
					.anyTimes();
			expecting(getStateMachineSession().remove("mapPBustaNeraAttribute"))
					.andReturn("").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}

	public void testPBustaNeraAttributeModificaConfermaExecuter_03() {
			TracciabilitaPlichiImplMock.setTracciabilitaException();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			final Map map = new HashMap();
			map.put("id", 1L);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(PBustaNeraAttributeAdminImpl.class,
					PBustaNeraAttributeAdminImplMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("conferma")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("PageFrom")).andReturn(
					"Cancelli").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute"))
					.andReturn((Serializable) map).anyTimes();
			expecting(
					getStateMachineSession().containsKey(
							"mapPBustaNeraAttribute")).andReturn(Boolean.TRUE)
					.anyTimes();
			expecting(getStateMachineSession().remove("mapPBustaNeraAttribute"))
					.andReturn("").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}
	
		public void testPBustaNeraAttributeModificaConfermaExecuter_05() {
				TracciabilitaPlichiImplMock.setRemoteException();
				setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
				final Map map = new HashMap();
				map.put("id", 1L);
				setUpMockMethods(PBustaNeraAttributeAdminImpl.class,
						PBustaNeraAttributeAdminImplMock.class);
				Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
				Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
				expecting(getRequestEvent().getEventName()).andReturn("conferma")
						.anyTimes();
				expecting(getRequestEvent().getAttribute("PageFrom")).andReturn(
						"Cancelli").anyTimes();
				expecting(getStateMachineSession().get("mapPBustaNeraAttribute"))
						.andReturn((Serializable) map).anyTimes();
				expecting(
						getStateMachineSession().containsKey(
								"mapPBustaNeraAttribute")).andReturn(Boolean.TRUE)
						.anyTimes();
				expecting(getStateMachineSession().remove("mapPBustaNeraAttribute"))
						.andReturn("").anyTimes();
				playAll();
				executer.execute(getRequestEvent());
		}
		
			
	public void testPBustaNeraAttributeModificaConfermaExecuter_04() {
			final Map map = new HashMap();
			map.put("id", 1L);
			setUpMockMethods(PBustaNeraAttributeAdminImpl.class,
					PBustaNeraAttributeAdminImplMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("conferma")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("PageFrom")).andReturn(
					"indietro").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute"))
					.andReturn((Serializable) map).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}
	
	public void testPBustaNeraAttributeModificaConfermaExecuter_06() {
		final Map map = new HashMap();
		map.put("id", 1L);
		setUpMockMethods(PBustaNeraAttributeAdminImpl.class,
				PBustaNeraAttributeAdminImplMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("indietro")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("PageFrom")).andReturn(
				"indietro").anyTimes();
		expecting(getStateMachineSession().get("mapPBustaNeraAttribute"))
				.andReturn((Serializable) map).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
}
	
	public static Map getMap() {
		final Map map = new HashMap();
		map.put("docId", "1");
		map.put("id", "1");
		map.put("date", "12/02/2012");
		map.put("importo", "");
		map.put("note", "");
		map.put("description", "");
		return map;
	}
}
