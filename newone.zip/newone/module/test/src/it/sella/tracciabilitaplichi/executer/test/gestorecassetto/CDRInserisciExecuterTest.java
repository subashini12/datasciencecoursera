package it.sella.tracciabilitaplichi.executer.test.gestorecassetto;

import it.sella.tracciabilitaplichi.executer.gestorecassetto.CDRInserisciExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class CDRInserisciExecuterTest extends AbstractSellaExecuterMock 
{
	public CDRInserisciExecuterTest(final String name) 
	{
		super(name);
	}

	CDRInserisciExecuter executer = new CDRInserisciExecuter();
	
	/*public void testCDRInserisciExecuter_forErrMsgNull_01()
	{
		setUpMockMethods( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "codiceCDR" )).andReturn( "ABCD" ).anyTimes();
		final Collection collLinkedCasetto = new Vector();
		final LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		final LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		final Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) collLinkedCasetto ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		final Map mapCDR4CDRDescription = new HashMap();
		expecting( getStateMachineSession().get( "mapCDR4CDRDescription" ) ).andReturn( (Serializable) mapCDR4CDRDescription ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCDRInserisciExecuter_forErrMsgNull_02()
	{
		setUpMockMethods( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "codiceCDR" )).andReturn( "ABCD" ).anyTimes();
		final Collection collLinkedCasetto = new Vector();
		final LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		final LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		final Collection collCDRInserisci = new ArrayList();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) collLinkedCasetto ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().put( "collCDRInserisci", collCDRInserisci )).andReturn( null ).anyTimes();;
		final Map mapCDR4CDRDescription = new HashMap();
		expecting( getStateMachineSession().get( "mapCDR4CDRDescription" ) ).andReturn( (Serializable) mapCDR4CDRDescription ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());	
	}*/
	public void testCDRInserisciExecuter_forErrMsg_01()
	{
		setUpMockMethods( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "codiceCDR" )).andReturn( "" ).anyTimes();
		final Collection collLinkedCasetto = new Vector();
		final LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		final LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) collLinkedCasetto ).anyTimes();
		final Collection collCDRInserisci = new ArrayList();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		final Map mapCDR4CDRDescription = new HashMap();
		expecting( getStateMachineSession().get( "mapCDR4CDRDescription" ) ).andReturn( (Serializable) mapCDR4CDRDescription ).anyTimes();	
		playAll();
		executer.execute(getRequestEvent());	
	}
	
	/*public void testCDRInserisciExecuter_forErrMsg_02()
	{
		TracciabilitaPlichiCassettoDataAccessMock.setCDRInLinkedCassetto();
		setUpMockMethods( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "codiceCDR" )).andReturn( "ABC" ).anyTimes();
		final Collection collLinkedCasetto = new Vector();
		final LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		final LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) collLinkedCasetto ).anyTimes();
		final Collection collCDRInserisci = new ArrayList();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		final Map mapCDR4CDRDescription = new HashMap();
		expecting( getStateMachineSession().get( "mapCDR4CDRDescription" ) ).andReturn( (Serializable) mapCDR4CDRDescription ).anyTimes();	
		playAll();
		executer.execute(getRequestEvent());	
	}
	
	public void testCDRInserisciExecuter_forErrMsgNull_forTracciabiltaException()
	{
		DBPersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "codiceCDR" )).andReturn( "ABCD" ).anyTimes();
		final Collection collLinkedCasetto = new Vector();
		final LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		final LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		final Collection collCDRInserisci = new ArrayList();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) collLinkedCasetto ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		final Map mapCDR4CDRDescription = new HashMap();
		expecting( getStateMachineSession().get( "mapCDR4CDRDescription" ) ).andReturn( (Serializable) mapCDR4CDRDescription ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCDRInserisciExecuter_forErrMsgNull_forRemoteException()
	{
		DBPersonaleWrapperMock.setRemoteException();
		setUpMockMethods( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "codiceCDR" )).andReturn( "ABCD" ).anyTimes();
		final Collection collLinkedCasetto = new Vector();
		final LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		final LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		final Collection collCDRInserisci = new ArrayList();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) collLinkedCasetto ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		final Map mapCDR4CDRDescription = new HashMap();
		expecting( getStateMachineSession().get( "mapCDR4CDRDescription" ) ).andReturn( (Serializable) mapCDR4CDRDescription ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());	
	}*/
}
