package it.sella.tracciabilitaplichi.executer.winbox2.mock;

import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import mockit.Mock;

public class WinBox2Mock {
	@Mock
	public Folder getFolder(final int index) {
		return new Folder();
	}
}
