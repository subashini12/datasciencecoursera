package it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor;

import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.BustaDeiciPaggingMock;
import it.sella.tracciabilitaplichi.implementation.util.BustaDeiciPagging;

import java.util.HashMap;
import java.util.Hashtable;

import mockit.Mockit;

import org.easymock.classextension.EasyMock;

public class ChangePageProcessorTest extends AbstractSellaExecuterMock {

	public ChangePageProcessorTest(final String name) {
		super(name);
	}

	ChangePageProcessor processor = new ChangePageProcessor();

	public void testChangePageProcessor_01() {
		expecting(getRequestEvent().getAttribute("pageNo")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("currentPageNo")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("plichIds")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("plichIds")).andReturn(getHashMap());
		expecting(getStateMachineSession().containsKey("plichDatas")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("plichDatas")).andReturn(getHashMap());
		expecting(getStateMachineSession().get("contrattiuc")).andReturn(new Hashtable());
		expecting(getRequestEvent().getEventName()).andReturn("PageNo").anyTimes() ;
		expecting(getRequestEvent().getAttribute("plichiAttributeId")).andReturn("1^123").anyTimes();
		final LazyFetchCollection lazyFetchCollection = EasyMock.createMock(LazyFetchCollection.class);
		expecting(getStateMachineSession().get("Pagging")).andReturn( new BustaDeiciPagging(lazyFetchCollection,1)).anyTimes();
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), ( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		Mockit.setUpMock(BustaDeiciPagging.class, BustaDeiciPaggingMock.class);
		playAll();
		assertNotNull(processor.mapChangePageData(getRequestEvent(), getStateMachineSession()));
	}	
	
	public void testgetFinalData_01() {
		processor.getFinalData(getHashMap(), getHashMap());
	}

	private HashMap getHashMap() {
		final HashMap hashMap = new HashMap();
		hashMap.put("",new HashMap());
		return hashMap ;
	}
	
}
