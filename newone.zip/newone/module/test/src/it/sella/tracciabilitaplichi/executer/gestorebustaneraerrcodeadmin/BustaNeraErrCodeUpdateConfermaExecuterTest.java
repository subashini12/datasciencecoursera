package it.sella.tracciabilitaplichi.executer.gestorebustaneraerrcodeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraErrorCodeView;

public class BustaNeraErrCodeUpdateConfermaExecuterTest extends AbstractSellaExecuterMock{

	public BustaNeraErrCodeUpdateConfermaExecuterTest(final String name) {
		super(name);
	}

	BustaNeraErrCodeUpdateConfermaExecuter executer = new BustaNeraErrCodeUpdateConfermaExecuter() ;

	/*public void testBustaNeraErrCodeUpdateConfermaExecuter_01() {
		TracciabilitaPlichiImplMock.setBustaNera();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedBustaNeraErrCodeView")).andReturn(getBustaNeraErrorCodeView()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}*/

	public void testBustaNeraErrCodeUpdateConfermaExecuter_remoteException() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedBustaNeraErrCodeView")).andReturn(getBustaNeraErrorCodeView()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testBustaNeraErrCodeUpdateConfermaExecuter_tracciabilitaException() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("UpdateConferma").anyTimes();
		expecting(getStateMachineSession().get("ModifiedBustaNeraErrCodeView")).andReturn(getBustaNeraErrorCodeView()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testBustaNeraErrCodeUpdateConfermaExecuter_02() {
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("BustaNeraErrCodeView")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("ModifiedBustaNeraErrCodeView")).andReturn(getBustaNeraErrorCodeView()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedBustaNeraErrCodeView")).andReturn(true).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("back",executeResult.getTransition());
	}

	public void testBustaNeraErrCodeUpdateConfermaExecuter_03() {
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("BustaNeraErrCodeView")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("ModifiedBustaNeraErrCodeView")).andReturn(getBustaNeraErrorCodeView()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedBustaNeraErrCodeView")).andReturn(true).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("back",executeResult.getTransition());
	}

	public void testBustaNeraErrCodeUpdateConfermaExecuter_04() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Indietro").anyTimes();
		expecting(getStateMachineSession().get("BustaNeraErrCodeView")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("ModifiedBustaNeraErrCodeView")).andReturn(getBustaNeraErrorCodeView()).anyTimes();
		expecting(getStateMachineSession().containsKey("ModifiedBustaNeraErrCodeView")).andReturn(true).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("back",executeResult.getTransition());
	}

	private static BustaNeraErrorCodeView getBustaNeraErrorCodeView() {
		final BustaNeraErrorCodeView bustaNeraErrorCodeView = new BustaNeraErrorCodeView();
		bustaNeraErrorCodeView.setSequenceId(2L);
		bustaNeraErrorCodeView.setErrorCode("");
		bustaNeraErrorCodeView.setId(2L);
		return bustaNeraErrorCodeView ;
	}

}
