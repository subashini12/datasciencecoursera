package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;


public class PlichiContentsEliminaExecuterTest extends AbstractSellaExecuterMock{

	public PlichiContentsEliminaExecuterTest(final String name) {
		super(name);
	}

	PlichiContentsEliminaExecuter executer = new PlichiContentsEliminaExecuter() ;
	
	public void testPlichiContentsEliminaExecuter_01()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ParentType")).andReturn("PBUST5").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testPlichiContentsEliminaExecuter_02()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ParentType")).andReturn("PALTRI").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testPlichiContentsEliminaExecuter_03()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ParentType")).andReturn("BUSTN").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsEliminaExecuter_04()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ParentType")).andReturn("PBUSTN").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsEliminaExecuter_05()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ParentType")).andReturn("PBUST10").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
}
