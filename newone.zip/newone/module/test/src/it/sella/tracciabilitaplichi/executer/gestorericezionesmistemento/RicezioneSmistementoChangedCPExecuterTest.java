package it.sella.tracciabilitaplichi.executer.gestorericezionesmistemento;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;



public class RicezioneSmistementoChangedCPExecuterTest extends AbstractSellaExecuterMock{

	public RicezioneSmistementoChangedCPExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezioneSmistementoChangedCPExecuter executer=new RicezioneSmistementoChangedCPExecuter();
	
	public void testRicezioneSmistementoChangedCPExecuter_01()
	{
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getRequestEvent().getAttribute("SelectedCP")).andReturn("1");
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(true);
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn((Serializable) map);
		expecting(getStateMachineSession().remove("BustaNeraBackUpCollection")).andReturn("");
		expecting(getStateMachineSession().remove("BustaNeraMainCollection")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testRicezioneSmistementoChangedCPExecuter_02()
	{
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getRequestEvent().getAttribute("SelectedCP")).andReturn("1");
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(true);
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn((Serializable) map);
		expecting(getStateMachineSession().remove("BustaNeraBackUpCollection")).andReturn("");
		expecting(getStateMachineSession().remove("BustaNeraMainCollection")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicezioneSmistementoChangedCPExecuter_03()
	{
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getRequestEvent().getAttribute("SelectedCP")).andReturn("1");
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(true);
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn((Serializable) map);
		expecting(getStateMachineSession().remove("BustaNeraBackUpCollection")).andReturn("");
		expecting(getStateMachineSession().remove("BustaNeraMainCollection")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}

	private static Map getMap()
	{
		final Map map=new HashMap();
		return map;
	}

}
