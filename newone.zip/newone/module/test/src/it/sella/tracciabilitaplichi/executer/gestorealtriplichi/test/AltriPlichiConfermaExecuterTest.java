package it.sella.tracciabilitaplichi.executer.gestorealtriplichi.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriplichi.AltriPlichiConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import mockit.Mockit;


public class AltriPlichiConfermaExecuterTest extends AbstractSellaExecuterMock{

	public AltriPlichiConfermaExecuterTest(final String name) {
		super(name);
	}

	AltriPlichiConfermaExecuter executer = new AltriPlichiConfermaExecuter() ;
	
	public void testAltriPlichiConfermaExecuter_01() {
		BarcodeValidatorMock.setInvalidBarcode();
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}
	
	public void testAltriPlichiConfermaExecuter_02() {
		DBPersonaleWrapperMock.setValidCdrFalse();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("123456789542");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("099231");
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}
	
	public void testAltriPlichiConfermaExecuter_03() {
		DBPersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("123456789542");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("099231");
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}
	
	public void testAltriPlichiConfermaExecuter_04() {
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("099231").anyTimes();
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}
	
	public void testAltriPlichiConfermaExecuter_05() {
		DBPersonaleWrapperMock.setRemoteException();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("123456789542");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("099231");
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}
	
	private static Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable();
		hashtable.put("AltriMainCollection",getAltriCollection());
		return hashtable ;
	}
	
	private static Collection getAltriCollection() {
		final Collection collection = new ArrayList();
		return collection ;
	}
	
}
