package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

import mockit.Mock;

public class ProcessorMock 
{	
  private static Boolean resultNotNull = false;	
  private static Boolean tracciabilitaException = false;
  private static Boolean remoteException = false;
  private static Boolean isPratica = false;
	
	public  static void setResultNotNull() 
	{
		resultNotNull = true;
	}
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}
	public  static void setRemoteException() 
	{
		remoteException = true;
	}
	public  static void setPratica() 
	{
		isPratica = true;
	}
    @Mock
	public Boolean isPratica( final RequestEvent requestEvent )
    {
    	Boolean flag = false;
    	if( isPratica )
    	{  
    		isPratica = false;
    		flag = true;
    	}
		return flag;
    }
    @Mock
    public String [ ] validate( final String tipoOggetto, final String abilitato, final String desc, final String cdr ) throws TracciabilitaException, RemoteException
    {
    	
    	String [ ] result = new String [ 2 ];
    	result[0]=null;
    	
    	if( resultNotNull )
    	{   
    		resultNotNull= false;
    		result[0]="abcd";
    		result[1]="defg";
    	}
    	if( tracciabilitaException )
    	{
    	   tracciabilitaException = false;
    	   throw new TracciabilitaException();
    	}
    	if( remoteException )
    	{   
    		remoteException = false;
    		throw new RemoteException( "RemoteException" );    		
    	}
    
    	return result;
    }
    @Mock
    public String [ ] validate( final String tipoOggetto, final String abilitato, final String desc ) throws TracciabilitaException, RemoteException
    {
    	String [ ] result = new String [ 2 ];
    	result[0]=null;
    	
    	if( resultNotNull )
    	{
    		resultNotNull = false;
    		result[0]="abcd";
    		result[1]="defg";
    	}
    	if( tracciabilitaException )
    	{
    	   tracciabilitaException = false;
    	   throw new TracciabilitaException();
    	}
    	if( remoteException )
    	{ 
    		remoteException = false;
    		throw new RemoteException( "RemoteException" );    		
    	}
    
    	return result;
    }
    
}
