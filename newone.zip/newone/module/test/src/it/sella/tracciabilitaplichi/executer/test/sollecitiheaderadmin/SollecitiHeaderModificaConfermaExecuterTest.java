package it.sella.tracciabilitaplichi.executer.test.sollecitiheaderadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.sollecitiheaderadmin.SollecitiHeaderModificaConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.TpTrSollecitiHeaderView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

public class SollecitiHeaderModificaConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	SollecitiHeaderModificaConfermaExecuter sollecitiHeaderModificaConfermaExecuterTest = new SollecitiHeaderModificaConfermaExecuter();

	public SollecitiHeaderModificaConfermaExecuterTest(final String name) {
		super(name);
	}

	public void testSollecitiHeaderModificaConfermaExecuter_01() {
		new HashMap(1);
		final Map sollecitiMap = new HashMap();
		final TpTrSollecitiHeaderView view = new TpTrSollecitiHeaderView();
		sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_OLD", view);
		sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_NEW", view);
		expecting(getStateMachineSession().get("SOLLECITI_HEADER_MAP"))
				.andReturn((Serializable) sollecitiMap);

		playAll();
		final ExecuteResult executeResult = sollecitiHeaderModificaConfermaExecuterTest
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("MESSAGE"), "TRPL-1540");
		assertEquals(executeResult.getAttribute("Success").toString(), "true");
	}

	/*public void testSollecitiHeaderModificaConfermaExecuter_02() {
			setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			final Map sollecitiHeaderMap = new HashMap(1);
			final Map sollecitiMap = new HashMap();
			final TpTrSollecitiHeaderView view = new TpTrSollecitiHeaderView();
			final TpTrSollecitiHeaderView view1 = new TpTrSollecitiHeaderView();
			view1.setShBankId(9L);
			view1.setShId(3L);
			view1.setShMailType(5L);
			view.setShMailType(3L);
			view.setShId(3L);
			view.setShBankId(1L);
			view1.setShBankId(2L);
			sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_OLD", view);
			sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_NEW", view1);
			expecting(getStateMachineSession().get("SOLLECITI_HEADER_MAP"))
					.andReturn((Serializable) sollecitiMap);
			playAll();
			final ExecuteResult executeResult = sollecitiHeaderModificaConfermaExecuterTest
					.execute(getRequestEvent());
	}

	public void testSollecitiHeaderModificaConfermaExecuter_03() {
			setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			final Map sollecitiHeaderMap = new HashMap(1);
			final Map sollecitiMap = new HashMap();
			final TpTrSollecitiHeaderView view = new TpTrSollecitiHeaderView();
			final TpTrSollecitiHeaderView view1 = new TpTrSollecitiHeaderView();
			view1.setShBankId(9L);
			view1.setShId(3L);
			view1.setShMailType(5L);
			view.setShMailType(3L);
			view.setShId(3L);
			view.setShBankId(1L);
			view1.setShBankId(2L);
			sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_OLD", view);
			sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_NEW", view1);
			expecting(getStateMachineSession().get("SOLLECITI_HEADER_MAP"))
					.andReturn((Serializable) sollecitiMap);
			playAll();
			final ExecuteResult executeResult = sollecitiHeaderModificaConfermaExecuterTest
					.execute(getRequestEvent());
	}

	public void testSollecitiHeaderModificaConfermaExecuter_04() {
			setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			final Map sollecitiHeaderMap = new HashMap(1);
			final Map sollecitiMap = new HashMap();
			final TpTrSollecitiHeaderView view = new TpTrSollecitiHeaderView();
			final TpTrSollecitiHeaderView view1 = new TpTrSollecitiHeaderView();
			view1.setShBankId(9L);
			view1.setShId(3L);
			view1.setShMailType(5L);
			view.setShMailType(3L);
			view.setShId(3L);
			view.setShBankId(1L);
			view1.setShBankId(2L);
			sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_OLD", view);
			sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_NEW", view1);
			expecting(getStateMachineSession().get("SOLLECITI_HEADER_MAP"))
					.andReturn((Serializable) sollecitiMap);
			playAll();
			final ExecuteResult executeResult = sollecitiHeaderModificaConfermaExecuterTest
					.execute(getRequestEvent());
	}*/

	public void testSollecitiHeaderModificaConfermaExecuter_05() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		new HashMap(1);
		final Map sollecitiMap = new HashMap();
		final TpTrSollecitiHeaderView view = new TpTrSollecitiHeaderView();
		final TpTrSollecitiHeaderView view1 = new TpTrSollecitiHeaderView();
		view1.setShBankId(9L);
		view1.setShId(3L);
		view1.setShMailType(5L);
		view.setShMailType(3L);
		view.setShId(3L);
		view.setShBankId(1L);
		view1.setShBankId(2L);
		sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_OLD", view);
		sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_NEW", view1);
		expecting(getStateMachineSession().get("SOLLECITI_HEADER_MAP"))
				.andReturn((Serializable) sollecitiMap);
		playAll();
		sollecitiHeaderModificaConfermaExecuterTest
				.execute(getRequestEvent());
}
	
	public void testSollecitiHeaderModificaConfermaExecuter_06() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		new HashMap(1);
		final Map sollecitiMap = new HashMap();
		final TpTrSollecitiHeaderView view = new TpTrSollecitiHeaderView();
		final TpTrSollecitiHeaderView view1 = new TpTrSollecitiHeaderView();
		view1.setShBankId(9L);
		view1.setShId(3L);
		view1.setShMailType(5L);
		view.setShMailType(3L);
		view.setShId(3L);
		view.setShBankId(1L);
		view1.setShBankId(2L);
		sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_OLD", view);
		sollecitiMap.put("TP_TR_SOLLECITI_HEADER_VIEW_NEW", view1);
		expecting(getStateMachineSession().get("SOLLECITI_HEADER_MAP"))
				.andReturn((Serializable) sollecitiMap);
		playAll();
		sollecitiHeaderModificaConfermaExecuterTest
				.execute(getRequestEvent());
}
	
}
