package it.sella.tracciabilitaplichi.executer.test.gestoreoggettoadmin;

import it.sella.tracciabilitaplichi.executer.gestoreoggettoadmin.OggettoConfermaModificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;

import java.util.Hashtable;

import mockit.Mockit;

public class OggettoConfermaModificaExecuterTest extends AbstractSellaExecuterMock
{
     public OggettoConfermaModificaExecuterTest( final String name )
     {
         super( name );
     }
     
     public void testOggettoConfermaModificaExecuter_01( )
     {
    	 TracciabilitaPlichiImplMock.setBustaNera();
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		 setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
         final Hashtable oggettoTable = new Hashtable( 2 );
         final OggettoView newOggettoView = new OggettoView( );
         newOggettoView.setOggettoDate( Util.getTimeStamp( "12/12/2007 10:10:10." ) );
         final OggettoView oldOggettoView = new OggettoView( );
         oldOggettoView.setOggettoDate( Util.getTimeStamp( "12/12/2007 10:10:10." ) );
         oggettoTable.put( "NewOggettoView", newOggettoView );
         oggettoTable.put( "OldOggettoView", oldOggettoView );
         expecting( getStateMachineSession( ).get(  "OggettoTable" ) ).andReturn( oggettoTable );
         playAll( );
         new OggettoConfermaModificaExecuter( ).execute( getRequestEvent( ) );
     }
     
     public void testOggettoConfermaModificaExecuter_02( )
     {
    	 TracciabilitaPlichiImplMock.setTracciabilitaException();
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
         final Hashtable oggettoTable = new Hashtable( 2 );
         final OggettoView newOggettoView = new OggettoView( );
         newOggettoView.setOggettoDate( Util.getTimeStamp( "12/12/2007 10:10:10." ) );
         final OggettoView oldOggettoView = new OggettoView( );
         oldOggettoView.setOggettoDate( Util.getTimeStamp( "12/12/2007 10:10:10." ) );
         oggettoTable.put( "NewOggettoView", newOggettoView );
         oggettoTable.put( "OldOggettoView", oldOggettoView );
         expecting( getStateMachineSession( ).get(  "OggettoTable" ) ).andReturn( oggettoTable );
         playAll( );
         new OggettoConfermaModificaExecuter( ).execute( getRequestEvent( ) );
     }
     
     public void testOggettoConfermaModificaExecuter_03( )
     {
    	 TracciabilitaPlichiImplMock.setRemoteException();
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
         final Hashtable oggettoTable = new Hashtable( 2 );
         final OggettoView newOggettoView = new OggettoView( );
         newOggettoView.setOggettoDate( Util.getTimeStamp( "12/12/2007 10:10:10." ) );
         final OggettoView oldOggettoView = new OggettoView( );
         oldOggettoView.setOggettoDate( Util.getTimeStamp( "12/12/2007 10:10:10." ) );
         oggettoTable.put( "NewOggettoView", newOggettoView );
         oggettoTable.put( "OldOggettoView", oldOggettoView );
         expecting( getStateMachineSession( ).get(  "OggettoTable" ) ).andReturn( oggettoTable );
         playAll( );
         new OggettoConfermaModificaExecuter( ).execute( getRequestEvent( ) );
     }
}
