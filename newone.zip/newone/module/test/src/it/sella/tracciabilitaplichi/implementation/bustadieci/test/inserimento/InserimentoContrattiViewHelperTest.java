package it.sella.tracciabilitaplichi.implementation.bustadieci.test.inserimento;

import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.bustadieci.inserimento.InserimentoContrattiViewHelper;
import it.sella.tracciabilitaplichi.implementation.util.TPAsserts;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciContrattiView;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;

public class InserimentoContrattiViewHelperTest extends AbstractSellaMock 
{

	private static final String anagrafica = "FRANKLIN TEMPLETON INTERNATIONAL SERVICES S.A.";
	private static final String codProd = "01";
	private static final String contrattiDescrizione = "Contrattualistica Conto Corrente";
	private static final String nprat = "#123456";
	public InserimentoContrattiViewHelperTest( final String name ) 
	{
		super( name );
	}

	@Override
	@Before
	public void setUp() throws Exception {
		TPAsserts.assertPojoGetterSetter(InserimentoContrattiViewHelper.class);
	}

	
	public void testDefaultPageValues( )
	{
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		assertEquals( "", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "-1", viewHelper.getMacroCategoria( ) );
		assertEquals( CONSTANTS.SELEZIONA.getValue( ), viewHelper.getTipologia( ) );
		assertEquals( "", viewHelper.getAnagrafica( ) );
		assertFalse( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNull( viewHelper.getMacroCategoriaColl( ) );
		assertNull( viewHelper.getMessage( ) );
		assertEquals( "#", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
	}
	
	public void testFlattenResponse_1( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( null, null, null );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "-1", viewHelper.getMacroCategoria( ) );
		assertEquals( CONSTANTS.SELEZIONA.getValue( ), viewHelper.getTipologia( ) );
		assertEquals( "", viewHelper.getAnagrafica( ) );
		assertFalse( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertNull( viewHelper.getMessage( ) );
		assertEquals( "#", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
	}
	
	public void testFlattenResponse_2( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.FALSE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "-1", viewHelper.getMacroCategoria( ) );
		assertEquals( CONSTANTS.SELEZIONA.getValue( ), viewHelper.getTipologia( ) );
		assertEquals( "", viewHelper.getAnagrafica( ) );
		assertFalse( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1683 );
		assertEquals( "#", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
	}
	
	public void testFlattenResponse_3( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "-1", viewHelper.getMacroCategoria( ) );
		assertEquals( CONSTANTS.SELEZIONA.getValue( ), viewHelper.getTipologia( ) );
		assertEquals( "", viewHelper.getAnagrafica( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1683 );
		assertEquals( "#", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
	}
	
	public void testFlattenResponse_4( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		sessionMap.put( CONSTANTS.VIEW_MAP, getViewMap( Boolean.FALSE, Boolean.FALSE ) );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "99", viewHelper.getBranchCode( ) );
		assertEquals( "H6", viewHelper.getTipoConto( ) );
		assertEquals( "87828525", viewHelper.getOttoCifre( ) );
		assertEquals( "0", viewHelper.getMilleSimo( ) );
		assertEquals( codProd, viewHelper.getMacroCategoria( ) );
		assertEquals( contrattiDescrizione, viewHelper.getTipologia( ) );
		assertEquals( anagrafica, viewHelper.getAnagrafica( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1683 );
		assertEquals( "", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
	}

	public void testFlattenResponse_5( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		sessionMap.put( CONSTANTS.VIEW_MAP, getViewMap( Boolean.TRUE, Boolean.FALSE ) );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "87828525", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( codProd, viewHelper.getMacroCategoria( ) );
		assertEquals( contrattiDescrizione, viewHelper.getTipologia( ) );
		assertEquals( anagrafica, viewHelper.getAnagrafica( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1683 );
		assertEquals( "", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
	}

	public void testFlattenResponse_6( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		sessionMap.put( CONSTANTS.B10_CONTRATTI_ATTR_VIEW, getB10ContrattiView( Boolean.TRUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE ) );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "99", viewHelper.getBranchCode( ) );
		assertEquals( "H6", viewHelper.getTipoConto( ) );
		assertEquals( "87828525", viewHelper.getOttoCifre( ) );
		assertEquals( "0", viewHelper.getMilleSimo( ) );
		assertEquals( "08", viewHelper.getMacroCategoria( ) );
		assertEquals( contrattiDescrizione, viewHelper.getTipologia( ) );
		assertEquals( anagrafica, viewHelper.getAnagrafica( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1683 );
		assertEquals( "#", viewHelper.getNumeroPrat( ) );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
	}
	
	public void testFlattenResponse_7( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		sessionMap.put( CONSTANTS.B10_CONTRATTI_ATTR_VIEW, getB10ContrattiView( Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.FALSE ) );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "87828525", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "01", viewHelper.getMacroCategoria( ) );
		assertEquals( contrattiDescrizione, viewHelper.getTipologia( ) );
		assertEquals( anagrafica, viewHelper.getAnagrafica( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1685 );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
	}
	
	public void testFlattenResponse_8( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		final BustaDeiciContrattiView b10ContrattiView = getB10ContrattiView( Boolean.FALSE, Boolean.FALSE, Boolean.TRUE, Boolean.FALSE );
		b10ContrattiView.getBustaDeiciAttributeView( ).setCodProdottoContratto( "1913" );
		sessionMap.put( CONSTANTS.B10_CONTRATTI_ATTR_VIEW, b10ContrattiView );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "87828525", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "01", viewHelper.getMacroCategoria( ) );
		assertEquals( contrattiDescrizione, viewHelper.getTipologia( ) );
		assertEquals( anagrafica, viewHelper.getAnagrafica( ) );
		assertEquals( "#", viewHelper.getNumeroPrat( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1685 );
		assertFalse( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
	}
	
	public void testFlattenResponse_9( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = getSessionMap( Boolean.TRUE, IErrorCodes.TRPL_1683, Boolean.FALSE );
		final InserimentoContrattiViewHelper viewHelper = new InserimentoContrattiViewHelper( );
		final BustaDeiciContrattiView b10ContrattiView = getB10ContrattiView( Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.TRUE );
		b10ContrattiView.getBustaDeiciAttributeView( ).setCodProdottoContratto( "1913" );
		sessionMap.put( CONSTANTS.B10_CONTRATTI_ATTR_VIEW, b10ContrattiView );
		viewHelper.flattenResponse( sessionMap );
		assertEquals( "1044032103628", viewHelper.getBarcode( ) );
		assertEquals( "", viewHelper.getBranchCode( ) );
		assertEquals( "", viewHelper.getTipoConto( ) );
		assertEquals( "87828525", viewHelper.getOttoCifre( ) );
		assertEquals( "", viewHelper.getMilleSimo( ) );
		assertEquals( "19", viewHelper.getMacroCategoria( ) );
		assertEquals( contrattiDescrizione, viewHelper.getTipologia( ) );
		assertEquals( anagrafica, viewHelper.getAnagrafica( ) );
		assertEquals( nprat, viewHelper.getNumeroPrat( ) );
		assertTrue( viewHelper.getIsValidBarcode( ) );
		assertFalse( viewHelper.getIsSuccess( ) );
		assertNotNull( viewHelper.getMacroCategoriaColl( ) );
		assertEquals( viewHelper.getMessage( ), IErrorCodes.TRPL_1685 );
		assertTrue( viewHelper.getIsManualContract( ) );
		assertEquals( viewHelper.getMacroCategoriaColl( ), getProdottiViewColl( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.CONTRATTI_FAMILY_COLLECTION ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.SUCCESS ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
	}
	
	private Map<Enum<CONSTANTS>, Object> getSessionMap( final Boolean isValidBarcode, final String msg, final Boolean isSuccess )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, "1044032103628");
		sessionMap.put( CONSTANTS.CONTRATTI_FAMILY_COLLECTION, getProdottiViewColl( ) );
		final Object dummy1 = ( isValidBarcode == null ) ? null : sessionMap.put( CONSTANTS.VALID_BARCODE, isValidBarcode );
		sessionMap.put( CONSTANTS.MSG, msg );
		final Object dummy2 = ( isSuccess == null ) ? null : sessionMap.put( CONSTANTS.SUCCESS, isSuccess );
		return sessionMap;
	}
	
	private Collection<ProdottiView> getProdottiViewColl( )
	{
		final Collection<ProdottiView> prodottiViewColl = new ArrayList<ProdottiView>( );
		final ProdottiView prodView = new ProdottiView( );
		prodView.setCodProdotto( "08" );
		prodottiViewColl.add( prodView );
		return prodottiViewColl;
	}
	
	private Map<Enum<CONSTANTS>, String> getViewMap( final Boolean isXNeeded, final Boolean isNPrat )
	{
		final Map<Enum<CONSTANTS>, String> viewMap = new HashMap<Enum<CONSTANTS>, String>( );
		viewMap.put( CONSTANTS.BRANCH_CODE, isXNeeded ? "XX" : "99" );
		viewMap.put( CONSTANTS.TIPO_CONTO, isXNeeded ? "XX" : "H6" );
		viewMap.put( CONSTANTS.OTTOCIFRE, "87828525" );
		viewMap.put( CONSTANTS.MILLESIMO, isXNeeded ? "X" : "0" );
		viewMap.put( CONSTANTS.CONTRATTI_MACRO_CATEGORIA, codProd );
		viewMap.put( CONSTANTS.TIPO_CONTRATTI, contrattiDescrizione );
		viewMap.put( CONSTANTS.ANAGRAFICA, anagrafica );
		viewMap.put( CONSTANTS.N_PRAT, isNPrat ? nprat : "" );
		return viewMap;
	}
	
	private BustaDeiciContrattiView getB10ContrattiView( final Boolean is13Digits, final Boolean isXNeeded, final Boolean isMacroDiff, final Boolean isNPrat )
	{
		final BustaDeiciContrattiView b10ContrattiView = new BustaDeiciContrattiView( );
		b10ContrattiView.setBustaDeiciAttributeView( new BustaDeiciAttributeView( ) );
		b10ContrattiView.setContrattiProdottoView( new ContrattiProdottoView( ) );
		b10ContrattiView.getBustaDeiciAttributeView( ).setAnagrafica( isNPrat ? anagrafica.concat( " " ).concat( nprat ) : anagrafica );
		b10ContrattiView.getBustaDeiciAttributeView( ).setNumeroConto( is13Digits ? ( isXNeeded ? "XXXX87828525X" : "99H6878285250" ) : "99H687828525" );
		b10ContrattiView.getBustaDeiciAttributeView( ).setOttoCifre( "87828525" );
		b10ContrattiView.getBustaDeiciAttributeView( ).setIdCanale( isNPrat ? Long.valueOf( 0L ) : Long.valueOf( -1L ) );
		b10ContrattiView.getContrattiProdottoView( ).setCodProdotto( isMacroDiff ? codProd : isNPrat ? "19" : "08" );
		b10ContrattiView.getContrattiProdottoView( ).setDescrizioneContratto( contrattiDescrizione );
		return b10ContrattiView;
	}

}
