package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.RicezionePlichiArchivioMsgConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

public class RicezionePlichiArchivioMsgConfermaExecuterTest extends AbstractSellaExecuterMock
{

	RicezionePlichiArchivioMsgConfermaExecuter executer = new RicezionePlichiArchivioMsgConfermaExecuter();
	
	public RicezionePlichiArchivioMsgConfermaExecuterTest(String name) 
	{
		super(name);		
	}

	public void testExecuter()
	{
		expecting( getStateMachineSession().containsKey( "GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION" ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession().get( "GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION" )).andReturn( ( Serializable ) getRicezionePlichiArchivioSession()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}


	private Map getRicezionePlichiArchivioSession( )
	{
		Map views = new Hashtable();	
	    views.put( "MismatchPlichiBusta5MapForDisplay", "ab");
		views.put( "MismatchPlichiBusta5MapRed", "ab");
		return views ;		
	}
}
