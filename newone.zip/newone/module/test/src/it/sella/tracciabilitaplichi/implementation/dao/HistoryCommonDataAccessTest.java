package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;

import java.util.Date;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class HistoryCommonDataAccessTest
{
	HistoryCommonDataAccess commonDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		commonDataAccess = new HistoryCommonDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		commonDataAccess = null;
	}

	@Test
	public void getHistoryOggettoView_01() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(getHistoryOggettoViewQuery());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 2,3l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 3,"ca");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.DATE, 1, 4,new Date());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 5,"BSZI212");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 6,1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 7,"456");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 8,"CDR");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final OggettoView ogView = commonDataAccess.getHistoryOggettoView(1l);
		Assert.assertEquals(ogView.getCdrName(), "CDR");
	}
	@Test
	public void getHistoryOggettoView_02() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(getHistoryOggettoViewQuery());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 2,3l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 3,"ca");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.DATE, 1, 4,new Date());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 5,"BSZI212");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 6,1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 7,null);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 8,"CDR");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final OggettoView ogView = commonDataAccess.getHistoryOggettoView(1l);
		Assert.assertEquals(ogView.getCdrName(), "CDR");
	}

	@Test
	public void getHistoryOggettoView_03() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(getHistoryOggettoViewQuery());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 2,3l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 3,"ca");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.DATE, 1, 4,new Date());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 5,"BSZI212");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 6,1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 7,"");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 8,"CDR");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final OggettoView ogView = commonDataAccess.getHistoryOggettoView(1l);
		Assert.assertEquals(ogView.getCdrName(), "CDR");
	}

	private String getHistoryOggettoViewQuery(){
		return "SELECT OG_ID,OG_TYPE,OG_LID,OG_OGGETTO_ACTUAL_DATE,OG_USER,OG_CURR_STATUS_ID,OG_CURR_REF_ID,OG_CDR  FROM TP_HS_OGGETTO  WHERE OG_ID=? AND OG_BANK IN (SELECT CB_OTHER_BANK FROM TP_MA_COMPATIBLE_BANKS WHERE CB_BANK = ?)";
	}
	@Test
	public void isExistsPlichiForBarcodeHistory() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(isExistsPlichiForBarcodeHistorySt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final boolean isPlichiBarcodeExists = commonDataAccess.isExistsPlichiForBarcodeHistory("123");
		System.out.println("isPlichiBarcodeExists: "+isPlichiBarcodeExists);
	}

	private String isExistsPlichiForBarcodeHistorySt(){
		return "SELECT 1 FROM TP_HS_PLICHI_ATTRIBUTE  PA,TP_HS_OGGETTO OG WHERE PA.PA_DOC_ID = OG.OG_ID AND PA.PA_BARCODE = ? ";
	}


}
