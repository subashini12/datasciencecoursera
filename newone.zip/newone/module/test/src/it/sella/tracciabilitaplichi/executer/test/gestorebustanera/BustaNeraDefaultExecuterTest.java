/*package it.sella.tracciabilitaplichi.executer.test.gestorebustanera;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.BustaNeraDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiHoldingDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiHoldingDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import org.easymock.classextension.EasyMock;

public class BustaNeraDefaultExecuterTest extends AbstractSellaExecuterTest
{
		
	public BustaNeraDefaultExecuterTest( final String name )
	{
		super( name );
	}
	
	
	public void testBustaNeraDefaultExecuter1( )
	{
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);		
		setUpMockMethods(TPUtil.class, TPUtilMock.class);	
		setUpMockMethods(TracciabilitaPlichiHoldingDataAccess.class,TracciabilitaPlichiHoldingDataAccessMock.class);
		expecting(getStateMachineSession().containsKey( "BustaNeraHashTable" ) ).andReturn( Boolean.FALSE );
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	    playAll();
		final ExecuteResult executeResult = new BustaNeraDefaultExecuter( ).execute( getRequestEvent() );
		assertEquals( "TrConferma", executeResult.getTransition( ) );		
	}
	
	public void testBustaNeraDefaultExecuter2( )
	{
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);		
		setUpMockMethods(TPUtil.class, TPUtilMock.class);	
		setUpMockMethods(TracciabilitaPlichiHoldingDataAccess.class,TracciabilitaPlichiHoldingDataAccessMock.class);
		expecting(getStateMachineSession().containsKey( "BustaNeraHashTable" ) ).andReturn( Boolean.TRUE );
		expecting( getStateMachineSession( ).get(  "BustaNeraHashTable" ) ).andReturn(getBustaNeraHashtable( ));
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	    playAll();
		final ExecuteResult executeResult = new BustaNeraDefaultExecuter( ).execute( getRequestEvent() );
		assertEquals( "TrConferma", executeResult.getTransition( ) );		
	}
	
	public void testBustaNeraDefaultExecuter3( )
	{
		DBPersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);		
		setUpMockMethods(TPUtil.class, TPUtilMock.class);	
		setUpMockMethods(TracciabilitaPlichiHoldingDataAccess.class,TracciabilitaPlichiHoldingDataAccessMock.class);
		expecting(getStateMachineSession().containsKey( "BustaNeraHashTable" ) ).andReturn( Boolean.FALSE );
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	    playAll();
		final ExecuteResult executeResult = new BustaNeraDefaultExecuter( ).execute( getRequestEvent() );
		assertEquals( "it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException", executeResult.getException( ).toString() );
	}
	
	public void testBustaNeraDefaultExecuter4( )
	{
		DBPersonaleWrapperMock.setRemoteException();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);		
		setUpMockMethods(TPUtil.class, TPUtilMock.class);	
		setUpMockMethods(TracciabilitaPlichiHoldingDataAccess.class,TracciabilitaPlichiHoldingDataAccessMock.class);
		expecting(getStateMachineSession().containsKey( "BustaNeraHashTable" ) ).andReturn( Boolean.FALSE );
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	    playAll();
		final ExecuteResult executeResult = new BustaNeraDefaultExecuter( ).execute( getRequestEvent() );
		assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );	
	}
	
	private Hashtable getBustaNeraHashtable( )
	{
		final Hashtable bustaNeraHashTable = new Hashtable();
		final Collection bustaNeraMainCollection = new ArrayList();
		bustaNeraHashTable.put("BustaNeraMainCollection", bustaNeraMainCollection);
		bustaNeraHashTable.put( "PageNo", "1" );
		bustaNeraHashTable.put( "DefaultCdr", "" );
		bustaNeraHashTable.put( "Dipendente", "SHANMUGHAM ANBARASU" );
		bustaNeraHashTable.put( "Succ", "IN2030/TECHNICAL" );
		bustaNeraHashTable.put( "RestoreCdr","099231");
		return bustaNeraHashTable;
	}	
}
*/