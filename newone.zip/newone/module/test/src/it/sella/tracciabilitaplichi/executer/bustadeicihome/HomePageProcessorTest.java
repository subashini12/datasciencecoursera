package it.sella.tracciabilitaplichi.executer.bustadeicihome;


import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.AnagraficiWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.IntestatazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.AnagraficiWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.IntestatazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

/**
 * @author gbs03134
 *
 */

public class HomePageProcessorTest extends AbstractSellaExecuterMock {

	public HomePageProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	HomePageProcessor processor = null ;
	
	public void test_getUserDetails01() {
		processor = new HomePageProcessor() ;
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(AnagraficiWrapper.class, AnagraficiWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(IntestatazioneWrapper.class, IntestatazioneWrapperMock.class);
		try {
			assertNotNull(processor.getUserDetails());
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}		
}
