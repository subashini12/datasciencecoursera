package it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class FrequentiDestinazioneCdrProcessorMock {
	private static Boolean isvalidateRicercaDataNotNull = false;
	private static Boolean remoteException = false;
	private static Boolean isnullData = false;

	public static void setvalidateRicercaDataNotNull() {
		isvalidateRicercaDataNotNull = true;
	}

	public static void setNullData() {
		isnullData = true;
	}
	
	public static void setRemoteException() {
		remoteException = true;
	}
	@Mock
	public static String validateInserciData(final RequestEvent requestEvent)
			throws TracciabilitaException, RemoteException {
		String data = "abc" ;
		if(isnullData)
		{
			data = null ;
		}
		return data;
	}

	@Mock
	public static Map setInserciPageData(final RequestEvent requestEvent) throws RemoteException {
		
		final Map mapFreqUsedCDRS = new HashMap(4);
		mapFreqUsedCDRS.put("banca", "1");
		mapFreqUsedCDRS.put("descrizione", "descrizione");
		mapFreqUsedCDRS.put("posizione", "1");
		mapFreqUsedCDRS.put("codiceCDR", "cdr");
		return mapFreqUsedCDRS;
	}

	@Mock
	public static String validateRicercaData(final RequestEvent requestEvent) {
		String name = null;
		if (isvalidateRicercaDataNotNull) {
			name = "banu";
		}
		return name;
	}
	
	@Mock
	public static FrequentiDestinazioneCdrView setModificaPageData( final RequestEvent requestEvent, final ExecuteResult exResult )
	{
		final FrequentiDestinazioneCdrView frequentiDestinazioneCdrView = new FrequentiDestinazioneCdrView() ;
		return frequentiDestinazioneCdrView ;
	}
}
