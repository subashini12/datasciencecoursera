package it.sella.tracciabilitaplichi.executer.gestorebustadeiciattributesadmin.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.rmi.RemoteException;

public class DeiciAttributeConfermaProcessorTest extends AbstractSellaExecuterMock{

	public DeiciAttributeConfermaProcessorTest(final String name) {
		super(name);
	}

	DeiciAttributeConfermaProcessor processor = new DeiciAttributeConfermaProcessor();
	
	
	public void testDeiciAttributeConfermaProcessor_01() throws RemoteException, TracciabilitaException {
		TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_02() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_03() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_04() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("12233");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_05() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("1223");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	
	public void testDeiciAttributeConfermaProcessor_06() throws RemoteException, TracciabilitaException {
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("1223");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("12");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("11");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("11");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("98");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_07() throws RemoteException, TracciabilitaException {
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("1223");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("12");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("11");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("11");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("98");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_08() throws RemoteException, TracciabilitaException {
		UtilMock.setCheckNullFalse();
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("1223");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("12");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("//");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("//");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("//");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		expecting(getRequestEvent().getAttribute("NumeroCon")).andReturn("");
		expecting(getRequestEvent().getAttribute("OttoCifre")).andReturn("");
		expecting(getRequestEvent().getAttribute("NumeroCodDer")).andReturn("");
		expecting(getRequestEvent().getAttribute("IdEsitoCon")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NoteControllo")).andReturn("");
		expecting(getRequestEvent().getAttribute("NumeroCodDer")).andReturn("");
		expecting(getRequestEvent().getAttribute("IdSucc")).andReturn("1");
		expecting(getRequestEvent().getAttribute("IdEsitoCon")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NoteControllo")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testDeiciAttributeConfermaProcessor_09() throws RemoteException, TracciabilitaException {
		UtilMock.setCheckNullFalse();
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("1223");
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("12");
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("//");
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("//");
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("//");
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("");
		expecting(getRequestEvent().getAttribute("NumeroCon")).andReturn("");
		expecting(getRequestEvent().getAttribute("OttoCifre")).andReturn("");
		expecting(getRequestEvent().getAttribute("NumeroCodDer")).andReturn("");
		expecting(getRequestEvent().getAttribute("IdEsitoCon")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NoteControllo")).andReturn("");
		expecting(getRequestEvent().getAttribute("NumeroCodDer")).andReturn("");
		expecting(getRequestEvent().getAttribute("IdSucc")).andReturn("1");
		expecting(getRequestEvent().getAttribute("IdEsitoCon")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NoteControllo")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
}
