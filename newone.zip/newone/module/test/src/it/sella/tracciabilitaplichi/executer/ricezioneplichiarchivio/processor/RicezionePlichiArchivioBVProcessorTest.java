package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.borsaverdearchivation.BVInputProcessor;
import it.sella.tracciabilitaplichi.borsaverdearchivation.BVInputProcessorMock;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.mock.RicezionePlichiArchivioBVProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class RicezionePlichiArchivioBVProcessorTest extends
		AbstractSellaExecuterMock {

	public RicezionePlichiArchivioBVProcessorTest(final String name) {
		super(name);
	}

	RicezionePlichiArchivioBVProcessor processor = new RicezionePlichiArchivioBVProcessor();

	public void testRicezionePlichiArchivioBVProcessor_01() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(BVInputProcessor.class, BVInputProcessorMock.class);
		setUpMockMethods(RicezionePlichiArchivioBVProcessor.class, RicezionePlichiArchivioBVProcessorMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn((Serializable) getMap()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		try {
			processor.processBVRecords(getRequestEvent());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public void testRicezionePlichiArchivioBVProcessor_02() {
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(BVInputProcessor.class, BVInputProcessorMock.class);
		setUpMockMethods(RicezionePlichiArchivioBVProcessor.class, RicezionePlichiArchivioBVProcessorMock.class);
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn((Serializable) getMap()).anyTimes();
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		try {
			processor.processBVRecords(getRequestEvent());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private static Map getMap() {
		final Map map = new HashMap();
		map.put(ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED, 1L);
		map.put(ITPConstants.TOTAL_PLICHI_RECEIVED, 1L);
		map.put(ITPConstants.SELECTED_OGGETTO_TYPE, "");
		return map;
	}
	
	public void testarchiveBorsaVerde_01()
	{
		TracciabilitaPlichiImplMock.setStatus();
		ClassificazioneWrapperMock.setPBUST5();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		final Map map = new HashMap();
		final Collection collection = new ArrayList();
		collection.add(1L);
		map.put(getBorsaVerdeAttributeView(), collection);
		try {
			processor.archiveBorsaVerde( getCollection(), map ,  getCollection());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private Collection getCollection()
	{
		final Collection collection = new ArrayList();
		collection.add(getBorsaVerdeAttributeView());
		return collection ;
	}
	
	private BorsaVerdeAttributeView getBorsaVerdeAttributeView()
	{
		final BorsaVerdeAttributeView borsaVerdeAttributeView = new BorsaVerdeAttributeView() ;
		borsaVerdeAttributeView.setDocumentId(1L);
		return borsaVerdeAttributeView ;
	}
}
