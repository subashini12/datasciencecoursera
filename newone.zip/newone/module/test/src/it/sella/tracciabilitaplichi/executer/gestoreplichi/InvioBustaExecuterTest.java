package it.sella.tracciabilitaplichi.executer.gestoreplichi;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.PreparazionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.util.PreparazionePlichiCacheUtil;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;

public class InvioBustaExecuterTest extends AbstractSellaExecuterMock {

	public InvioBustaExecuterTest(final String name) {
		super(name);
	}

	InvioBustaExecuter executer = new InvioBustaExecuter();

	public void testInvioBustaExecuter_01() {
		PreparazionePlichiCacheUtilMock.setInvioBustaExecuterDetails();
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("checkbox")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("BarCodeList")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}
}
