package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class PlichiContentsDefaultB20ProcessorMock {
	private static Boolean isMapValues = false;
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setMapValues() {
		isMapValues = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	@Mock
	public static Map<Enum, Object> validatePageNum(final String noOfPages) {
		final Map<Enum, Object> map = new HashMap<Enum, Object>();
		map.put(CONSTANTS.NUMBER_OF_PAGES, 2L);
		if (isMapValues) {
			map.put(CONSTANTS.MSG, null);
		}
		return map;

	}

	@Mock
	public static void updateBustaVentiPageCount(final String stampeId,
			final Long noOfPages, final TracciabilitaPlichiView plichiView)
			throws RemoteException, TracciabilitaException {
		if (tracciabilitaException) {
			throw new TracciabilitaException();
		}
		if (remoteException) {
			throw new RemoteException();
		}
	}

}
