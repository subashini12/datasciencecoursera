package it.sella.tracciabilitaplichi.executer.gestionesolleciti.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.IGestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;

import java.rmi.RemoteException;
import java.util.Map;

import org.easymock.EasyMock;


public class ProrogheRicercaConfermaProcessorTest  extends AbstractSellaExecuterMock{

	public ProrogheRicercaConfermaProcessorTest(final String name) {
		super(name);
	}

	ProrogheRicercaConfermaProcessor processor = new ProrogheRicercaConfermaProcessor();
	
	public void testProrogheRicercaConfermaProcessor_01() throws RemoteException, TracciabilitaException {
		UtilMock.setCheckNullFalse();
		BarcodeValidatorMock.setInvalidBarcode();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class, TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn(null);
		playAll();
		final Map map=null;
		final IGestioneSollecitiDataAccess iGestioneSollecitiDataAccess = EasyMock.createMock(IGestioneSollecitiDataAccess.class);
		EasyMock.expect(iGestioneSollecitiDataAccess.getSollecitiProrogheMap("1234567891234")).andReturn(map);
		EasyMock.replay(iGestioneSollecitiDataAccess);
		assertNotNull(processor.validateInput(getRequestEvent()));
	}
	
	public void testProrogheRicercaConfermaProcessor_02() throws RemoteException, TracciabilitaException {
		BarcodeValidatorMock.setInvalidBarcode();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class, TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		playAll();
		assertNotNull(processor.validateInput(getRequestEvent()));
	}
	
}
