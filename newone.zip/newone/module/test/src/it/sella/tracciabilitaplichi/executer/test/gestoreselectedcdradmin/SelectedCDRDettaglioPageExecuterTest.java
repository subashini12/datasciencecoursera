package it.sella.tracciabilitaplichi.executer.test.gestoreselectedcdradmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestoreselectedcdradmin.SelectedCDRDettaglioPageExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SelectedCDRDettaglioPageExecuterTest extends AbstractSellaExecuterMock {

	 SelectedCDRDettaglioPageExecuter  selectedCDRDettaglioPageExecuter = new  SelectedCDRDettaglioPageExecuter();

	public  SelectedCDRDettaglioPageExecuterTest(String name) {
		super(name);
	}

	public void testSelectedCDRDettaglioPageExecuter_01() {
		 final Map bancaMap = new HashMap();
		 ArrayList selectedCDRView = new ArrayList();
		 TpMaSelectedCdrView view = new TpMaSelectedCdrView();
		 selectedCDRView.add(view);
		 bancaMap.put("SELECTED_CDR_VIEW", selectedCDRView);
		 expecting(getRequestEvent().getAttribute("scCdr")).andReturn("scCdr").anyTimes();
		 expecting(getRequestEvent().getAttribute("scBankId")).andReturn("scBankId").anyTimes();
		 expecting(getRequestEvent().getAttribute("index")).andReturn("0").anyTimes();
		 expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn((Serializable)bancaMap).anyTimes();
		playAll();
		 		ExecuteResult executeResult = selectedCDRDettaglioPageExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("SELECTED_CDR_VIEW_MODIFY"), view);
	}
}
