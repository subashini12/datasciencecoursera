package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.ModificaDeleteGrantsExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.persistence.dao.TailoredGrantsImpl;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.dto.TailoredGrants;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ModificaDeleteGrantsExecuterTest extends AbstractSellaExecuterMock
{ 
	final ModificaDeleteGrantsExecuter modificaDeleteGrantsExecuter = new ModificaDeleteGrantsExecuter();;
	
	public ModificaDeleteGrantsExecuterTest(String name)
	{
		super(name);
	}	

	public void testDeleteGrants_forSuccessCase()
	{
		expecting(getRequestEvent().getAttribute("soggettoId")).andReturn("1517").anyTimes();
		expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn((Serializable) getAltriWinboxTable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1517").anyTimes();
		playAll();
		setUpMockMethods(TailoredGrantsImpl.class, TailoredGrantsImplMock.class);
		ExecuteResult executeResult =  modificaDeleteGrantsExecuter.execute(getRequestEvent());
	}
	
	public void testDeleteGrants_forFailureCase()
	{
		TailoredGrantsImplMock.setTracciabilitaException();
		expecting(getRequestEvent().getAttribute("soggettoId")).andReturn("1517").anyTimes();
		expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn((Serializable) getAltriWinboxTable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1517").anyTimes();
		playAll();
		setUpMockMethods(TailoredGrantsImpl.class, TailoredGrantsImplMock.class);
		ExecuteResult executeResult =  modificaDeleteGrantsExecuter.execute(getRequestEvent());
	}
		
	private Map getAltriWinboxTable()
	{
		Map altriWindowTableMap = new HashMap();
		AltriWinboxView altriWinboxView = new AltriWinboxView();
		TailoredGrants tailoredGrants = new TailoredGrants();
		Collection<Grants> collection = new ArrayList<Grants>();
		Grants grants = new Grants();
		grants.setId(Long.valueOf(12));
		collection.add(grants);
		tailoredGrants.setGrants(collection);
		altriWinboxView.setTailoredGrants(tailoredGrants);
		altriWindowTableMap.put("OldAltriWinboxView", altriWinboxView);
		return altriWindowTableMap;
	}

}


