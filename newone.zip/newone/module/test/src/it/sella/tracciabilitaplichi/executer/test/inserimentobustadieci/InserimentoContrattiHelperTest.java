package it.sella.tracciabilitaplichi.executer.test.inserimentobustadieci;

import it.sella.classificazione.ClassificazioneView;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.InserimentoContrattiHelper;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.Validator;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.ValidatorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciContrattiView;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class InserimentoContrattiHelperTest extends AbstractSellaExecuterMock 
{

	private static final String BARCODE = "1000468914313";
	private static final String NC = "8452992960051";
	private static final String OC = "99296005";
	private static final String codProdContratto = "0767";
	private static final String anagrafica = "NOVE ZERO";
	private static final String dummy = "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890";
	private static final String nprat = "#123121";
	private static ClassificazioneView classificazioneView = null;
	private BustaDeiciContrattiView contrattiView = null;
	
	public InserimentoContrattiHelperTest( final String name )
	{
		super( name );
	}
	
	@Override
	protected void setUp( ) throws Exception
	{
		super.setUp( );
		this.contrattiView = null;
		classificazioneView = getMock( ClassificazioneView.class );
		expecting( this.classificazioneView.getId( ) ).andReturn( Long.valueOf( 5900L ) ).anyTimes( );
		play( classificazioneView );
	}
	
	public void testGetSessionMap_1( )
	{
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE );
		final Map<Enum<CONSTANTS>, Object> mapToTheSession = new HashMap<Enum<CONSTANTS>, Object>( );
		mapToTheSession.put( CONSTANTS.CONTRATTI_FAMILY_COLLECTION, new ArrayList<ProdottiView>( ) );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) mapToTheSession );
		playAll( );
		final Map<Enum<CONSTANTS>, Object> sessionMap = InserimentoContrattiHelper.getInstance( ).getSessionMap( getRequestEvent( ) );
		assertEquals( mapToTheSession, sessionMap );
	}
	
	public void testGetSessionMap_2( )
	{
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.FALSE );
		final Map<Enum<CONSTANTS>, Object> mapToTheSession = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).put(CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ), mapToTheSession ) ).andReturn( mapToTheSession );
		playAll( );
		final Map<Enum<CONSTANTS>, Object> sessionMap = InserimentoContrattiHelper.getInstance( ).getSessionMap( getRequestEvent( ) );
		assertNotNull( sessionMap );
	}
	
	/*public void testSetDefaultPageDetails_1( ) throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Map<Enum<CONSTANTS>, Object> sessionMap  =new HashMap<Enum<CONSTANTS>, Object>();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection<ProdottiView>) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		InserimentoContrattiHelper.getInstance( ).setDefaultPageDetails(sessionMap);
	}*/
	
	public void testValidateBarcode_01() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(Validator.class, ValidatorMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("CONTRATTI_INSERIMENTO_MAP")).andReturn(true);
		final Map<Enum<CONSTANTS>, Object> sessionMap  =new HashMap<Enum<CONSTANTS>, Object>();
		expecting(getStateMachineSession().get("CONTRATTI_INSERIMENTO_MAP")).andReturn((Serializable) sessionMap);
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("1234567890123");
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("1234567890123");
		playAll();
		InserimentoContrattiHelper.getInstance( ).validateBarcode(getRequestEvent());
	}
	
/*	public void testvalidateContratti_01() throws  TracciabilitaException
	{
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Validator.class, ValidatorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		expecting(getStateMachineSession().containsKey("CONTRATTI_INSERIMENTO_MAP")).andReturn(true).anyTimes();
		final Map<Enum<CONSTANTS>, String> sessionMap1  =new HashMap<Enum<CONSTANTS>, String>();
		sessionMap1.put(CONSTANTS.NUMEROCONTO, "1");
		sessionMap1.put(CONSTANTS.OTTOCIFRE , "1212");
		sessionMap1.put(CONSTANTS.ANAGRAFICA, "12325");
		sessionMap1.put(CONSTANTS.N_PRAT, "12325");
		final Map<Enum<CONSTANTS>, Object> sessionMap  =new HashMap<Enum<CONSTANTS>, Object>();
		sessionMap.put(CONSTANTS.VIEW_MAP, sessionMap1);
		expecting(getStateMachineSession().get("CONTRATTI_INSERIMENTO_MAP")).andReturn((Serializable) sessionMap).anyTimes();
		expecting(getStateMachineSession().containsKey("MSG")).andReturn(true).anyTimes();
		playAll();
		try {
			InserimentoContrattiHelper.getInstance( ).validateContratti(getRequestEvent());
		} catch (final RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
}
