package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.InserisciExecuter;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.PrepareBusta10Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation.processor.PrepareBusta10ProcessorMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.dao.IGestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.test.view.Busta10PreparationPageViewMock;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;

import java.util.Hashtable;

public class InserisciExecuterTest extends AbstractSellaExecuterMock
{

	private final IGestioneSollecitiDataAccess sollecitiDataAccess = null;
	private static Busta10PreparationPageView preparationPageView = null;
	public InserisciExecuterTest( final String name )
	{
		super( name );
	}
	
	InserisciExecuter executer = new InserisciExecuter();

	/*public void testInserisciExecuter1( )
	{
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
       	setUpMockMethods( PrepareBusta10Processor.class, PrepareBusta10ProcessorMock.class );
		setUpMockMethods( Busta10PreparationPageView.class, Busta10PreparationPageViewMock.class );
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		expecting( getStateMachineSession().get( "Busta10PreparationPageView" )).andReturn(  getB10PreparationPageView()  ).anyTimes();
		expecting( getRequestEvent().getAttribute("barCode")).andReturn("21").anyTimes();
		expecting( getRequestEvent().getAttribute("bustaId")).andReturn("21").anyTimes();
        setUpMockMethods( TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class );
		playAll();
		executer.execute( getRequestEvent() );
	}*/

	public void testInserisciExecuter2( )
	{
		PrepareBusta10ProcessorMock.setTracciabilitaException();
		setUpMockMethods( PrepareBusta10Processor.class, PrepareBusta10ProcessorMock.class );
		setUpMockMethods( Busta10PreparationPageView.class, Busta10PreparationPageViewMock.class );
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		expecting( getStateMachineSession().get( "Busta10PreparationPageView" )).andReturn(  getB10PreparationPageView()  ).anyTimes();
		expecting( getRequestEvent().getAttribute("barCode")).andReturn("21").anyTimes();
		expecting( getRequestEvent().getAttribute("bustaId")).andReturn("21").anyTimes();
        setUpMockMethods( TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class );
		playAll();
		executer.execute( getRequestEvent() );
		
	}
	
	public void testInserisciExecuter3( )
	{
		PrepareBusta10ProcessorMock.setRemoteException();
		setUpMockMethods( PrepareBusta10Processor.class, PrepareBusta10ProcessorMock.class );
		setUpMockMethods( Busta10PreparationPageView.class, Busta10PreparationPageViewMock.class );
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		expecting( getStateMachineSession().get( "Busta10PreparationPageView" )).andReturn(  getB10PreparationPageView()  ).anyTimes();
		expecting( getRequestEvent().getAttribute("barCode")).andReturn("21").anyTimes();
		expecting( getRequestEvent().getAttribute("bustaId")).andReturn("21").anyTimes();
        setUpMockMethods( TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class );
		playAll();
		executer.execute( getRequestEvent() );
		
	}
	
	private Busta10PreparationPageView getB10PreparationPageView( )
	{
		final Busta10PreparationPageView pageView = new Busta10PreparationPageView( );
		pageView.setUserDetails( getUserDetail( ) );
		pageView.setCurrentPageNo( 1 );
		pageView.setTotalPages( 1 );
		return pageView;
	}
	
	private final Hashtable getUserDetail( )
    {
    	final Hashtable userDetails = new Hashtable( );
        userDetails.put( CONSTANTS.USER.getValue( ), "SBAI085" );
        userDetails.put( CONSTANTS.NAME.getValue( ), "ANBARASU" );
        userDetails.put( CONSTANTS.SUR_NAME.getValue( ), "SHANMUGHAM" );
        userDetails.put( CONSTANTS.CDR.getValue( ), "SB9I08" );
        userDetails.put( CONSTANTS.CDR_DESCRIPTION.getValue( ), "MIST BUSINESS UNIT" );
        userDetails.put( CONSTANTS.ABI_BANCA.getValue( ), "03311" );
        userDetails.put( CONSTANTS.BANK_DESCRIPTION.getValue( ), "Banca Sella Holding" );
        userDetails.put( CONSTANTS.BANK.getValue( ), Long.valueOf( 1483455L ) );
        return userDetails;
    }
	
	
}
