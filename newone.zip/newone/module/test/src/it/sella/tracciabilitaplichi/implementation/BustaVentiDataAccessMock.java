package it.sella.tracciabilitaplichi.implementation;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;

import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class BustaVentiDataAccessMock {
@Mock
public Collection<String> getBarcodesCreatedToday( final OggettoView oggettoView ) throws TracciabilitaException
{
	final Collection<String> strCollection =new ArrayList<String>();
	strCollection.add("");
	return strCollection ;
}
}
