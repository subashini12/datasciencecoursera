package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;

import java.rmi.RemoteException;
import java.util.Map;

import mockit.Mock;

public class GrantsValidatorMock 
{
	private static Boolean tracciabilitaException = false;
	
	private static Boolean remoteException = false;
	
		public  static void setTracciabilitaException() 
		{  
			tracciabilitaException = true;
		}
		public  static void setRemoteException() 
		{  
			remoteException = true;
		}
		
     @Mock
	  public static void validate( final String userOrCdr, final AltriWinboxView altriWinboxView, final Map sessionMap ) throws TracciabilitaException, RemoteException
	  {
		return ;
	  }
     @Mock
     public static void validate( final String userOrCdr, final Map<Enum,Object> sessionMap ) throws TracciabilitaException, RemoteException
     {
    	 if( tracciabilitaException )
    	 {
    		 tracciabilitaException = false; 
    		 throw new TracciabilitaException();    		 
    	 }
    	 
    	 if( remoteException )
    	 {
    		 remoteException = false; 
    		 throw new RemoteException();    		 
    	 }
    	 return ;
     }
}
