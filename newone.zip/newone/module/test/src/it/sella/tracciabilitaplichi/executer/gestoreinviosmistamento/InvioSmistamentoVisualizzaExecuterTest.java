package it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccess;
//import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCassettoDataAccessMock;
//import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class InvioSmistamentoVisualizzaExecuterTest extends AbstractSellaExecuterMock {

	public InvioSmistamentoVisualizzaExecuterTest(final String name) {
		super(name);
	}

	InvioSmistamentoVisualizzaExecuter executer = new InvioSmistamentoVisualizzaExecuter();

	public void testInvioSmistamentoVisualizzaExecuter_01() {
		final Map map = new HashMap() ;
		expecting(getRequestEvent().getAttribute("cassettoCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("smistamento")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) map).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("Visualizza").anyTimes();
		expecting(getStateMachineSession().containsKey("InviatoMsg")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove("InviatoMsg")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoVisualizzaExecuter_02() {
		//ClassificazioneWrapperMock.setConnectionPoint();
		//setUpMockMethods(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("cassettoCode")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("smistamento")).andReturn(null).anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("Visualizza").anyTimes();
		expecting(getStateMachineSession().containsKey("InviatoMsg")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("cassettoCode")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("cassettoCode")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().remove("InviatoMsg")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public Map getMap() {
		final Map map = new HashMap() ;
		map.put("smistamentoId", "1");
		map.put("mapIdBustaNeraView", getBustaNeraViewMap());
		map.put("LastSentBustaNeraView","");
		return map ;
	}
	
	private static Map getPageListaBustaNeraViewMap() {
		final Map bustaNeraViewListMap = new HashMap();
		bustaNeraViewListMap.put("1", "1");
		return bustaNeraViewListMap ;
	}
	
	private static Map getBustaNeraViewMap() {
		final Map bustaNeraViewMap = new HashMap();
		bustaNeraViewMap.put("1", getTracciabilitaPlichiView());
		return bustaNeraViewMap ;
	}
	
	private static TracciabilitaPlichiView getTracciabilitaPlichiView() {
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		tracciabilitaPlichiView.setPlichiAttributeView(getPlichiAttributeView());
		return tracciabilitaPlichiView ;
	}
	
	private static OggettoView getOggettoView() {
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setOggettoType(1L);
		oggettoView.setId(1L);
		return oggettoView ;
	}
	
	private static PlichiAttributeView getPlichiAttributeView() {
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView() ;
		plichiAttributeView.setBarCode("1234567891236");
		return plichiAttributeView ;
	}
	
	private static Collection getButaNeraCollection() {
		final Collection bustaNeraCollection = new ArrayList() ;
		bustaNeraCollection.add(getTracciabilitaPlichiView());
		return bustaNeraCollection ;
	}
	
}
