package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.HistoryPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TransactionHistoryDeciderMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.TransactionHistoryDecider;

import java.rmi.RemoteException;
import java.util.Hashtable;

import org.easymock.EasyMock;


public class PlichiContentsDefaultProcessorTest extends AbstractSellaExecuterMock{

	public PlichiContentsDefaultProcessorTest(final String name) {
		super(name);
	}

	PlichiContentsDefaultProcessor processor = new PlichiContentsDefaultProcessor() ;
	
	public void testPlichiContentsDefaultProcessor_01()
	{
			expecting(getStateMachineSession().containsKey(ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn(true);
			expecting(getStateMachineSession().get(ITPConstants.PLICHI_CONTENTS_HASH_TABLE)).andReturn(getHashtable());
			playAll();
			processor.getSessionMap(getStateMachineSession());
	}
	
	public void testPlichiContentsDefaultProcessor_02()
	{
			expecting(getStateMachineSession().containsKey(ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn(false);
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
			playAll();
			processor.getSessionMap(getStateMachineSession());
	}
	
	/*public void testPlichiContentsDefaultProcessor_03()
	{
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("");
		expecting(getStateMachineSession().containsKey( ITPConstants.BV_DOC_ID )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.BV_DOC_ID )).andReturn("123456");
		playAll();
			try {
				processor.getOggettoStatusReferenceColl(getRequestEvent(), "BV34567891235");
			} catch (RemoteException e) {
				e.printStackTrace();
			} catch (TracciabilitaException e) {
				e.printStackTrace();
			}
	}*/
	
	public void testPlichiContentsDefaultProcessor_04()
	{
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().containsKey( ITPConstants.BV_DOC_ID )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.BV_DOC_ID )).andReturn("123456");
		playAll();
			try {
				processor.getOggettoStatusReferenceColl(getRequestEvent(), "1234567891235");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			}
	}
	
	public void testPlichiContentsDefaultProcessor_05()
	{
		setUpMockMethods(HistoryPlichiContentsDataAccess.class, HistoryPlichiContentsDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("History");
		expecting(getStateMachineSession().containsKey( ITPConstants.BV_DOC_ID )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.BV_DOC_ID )).andReturn("123456");
		playAll();
			try {
				processor.getOggettoStatusReferenceColl(getRequestEvent(), "1234567891235");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			}
	}
	
	public void testPlichiContentsDefaultProcessor_06()
	{
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("BustaDeici");
		expecting(getStateMachineSession().containsKey( ITPConstants.BV_DOC_ID )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.BV_DOC_ID )).andReturn("123456");
		playAll();
			try {
				processor.getOggettoStatusReferenceColl(getRequestEvent(), "1234567891235");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			}
	}
	
	public void testPlichiContentsDefaultProcessor_07()
	{
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("B10History");
		expecting(getStateMachineSession().containsKey( ITPConstants.BV_DOC_ID )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.BV_DOC_ID )).andReturn("123456");
		playAll();
			try {
				processor.getOggettoStatusReferenceColl(getRequestEvent(), "1234567891235");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			}
	}
	
	public void testPlichiContentsDefaultProcessor_08()
	{
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("B10History");
		expecting(getStateMachineSession().containsKey( ITPConstants.BV_DOC_ID )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.BV_DOC_ID )).andReturn("FOLD56");
		playAll();
			try {
				processor.getOggettoStatusReferenceColl(getRequestEvent(), "1234567891235");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			}
	}
	
	private Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable() ;
		return hashtable;
	}
}

