package it.sella.tracciabilitaplichi.executer.test.gestorebustanera;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.ajax.bustanera.handler.BustaNeraVerificaHandler;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.BustaNeraInserisciExecuter;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraAttributeView;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import junit.framework.TestCase;
import mockit.Mock;
import mockit.Mockit;

public class BustaNeraInserisciExecuterTest extends TestCase {

	private RequestEvent requestEvent;
	private StateMachineSession session;

	@Override
	protected void setUp( ) throws Exception {
		super.setUp( );
		this.requestEvent = createMock( RequestEvent.class );
		this.session = createMock( StateMachineSession.class );
	}

	public void getGeoChallengedCdrList() {
		Mockit.setUpMock(BustaNeraVerificaHandler.class, new Object() {
			@Mock
			public List<String> getGeoChallengedCdrList(final String bankSelected ) throws TracciabilitaException, RemoteException {
				final List<String> cdrList = new ArrayList<String>();
				cdrList.add("099A02");
				cdrList.add("099A03");
				cdrList.add("099A04");
				cdrList.add("099A06");
				cdrList.add("099A40");
				return cdrList ;
			}
		});
	}

	public void testBustaNeraInserisci1( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "", "", "32/01/2010", "Sodexho coupons", "", "", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1016".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && "32/01/2010".equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "32", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2010", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "Sodexho coupons", executeResult.getAttribute( "Desc" ) );
	}

	public void testBustaNeraInserisci2( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "", "", "01/01/1889", "Sodexho coupons", "", "", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1072".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && "01/01/1889".equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "1889", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "Sodexho coupons", executeResult.getAttribute( "Desc" ) );
	}

	public void testBustaNeraInserisci3( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "", "", "01/01/2040", "Sodexho coupons", "", "", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( "TRPL-1052".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && "01/01/2040".equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2040", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "Sodexho coupons", executeResult.getAttribute( "Desc" ) );
	}


	public void testBustaNeraInserisci4( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "", "", "01/01/2010", "", "", "", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1080".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && "".equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2010", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "", executeResult.getAttribute( "Desc" ) );
		assertEquals( "", executeResult.getAttribute( "Importo" ) );
		assertEquals( "", executeResult.getAttribute( "ImportoDec" ) );
		assertEquals( "", executeResult.getAttribute( "Note" ) );
	}

	public void testBustaNeraInserisci5( ) {
		getGeoChallengedCdrList() ;
		final StringBuilder desc = new StringBuilder( "Description is very much needed. But it has to be less than 50 characters in size, otherwise we will get an error. Ok!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" );
		mockTheRequestParams( "", "", "", "01/01/2010", desc.toString( ), "", "", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1301".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && desc.toString( ).equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2010", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( desc.toString( ), executeResult.getAttribute( "Desc" ) );
		assertEquals( "", executeResult.getAttribute( "Importo" ) );
		assertEquals( "", executeResult.getAttribute( "ImportoDec" ) );
		assertEquals( "", executeResult.getAttribute( "Note" ) );
	}

	public void testBustaNeraInserisci6( ) {
		getGeoChallengedCdrList() ;
		final StringBuilder note = new StringBuilder( "Note is very much needed. But it has to be less than 100 characters in size, otherwise we will get an error. Ok!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" );
		mockTheRequestParams( "", "", "", "01/01/2010", "Sodexho coupon", "", "", note.toString( ) );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1338".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && note.toString( ).equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2010", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "Sodexho coupon", executeResult.getAttribute( "Desc" ) );
		assertEquals( "", executeResult.getAttribute( "Importo" ) );
		assertEquals( "", executeResult.getAttribute( "ImportoDec" ) );
		assertEquals( note.toString( ), executeResult.getAttribute( "Note" ) );
	}


	public void testBustaNeraInserisci7( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "", "", "01/01/2010", "Sodexho coupon", "-10", "09", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1306".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && "-10,09".equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2010", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "Sodexho coupon", executeResult.getAttribute( "Desc" ) );
		assertEquals( "-10", executeResult.getAttribute( "Importo" ) );
		assertEquals( "09", executeResult.getAttribute( "ImportoDec" ) );
		assertEquals( "", executeResult.getAttribute( "Note" ) );
	}

	public void testBustaNeraInserisci8( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "", "", "01/01/2010", "Sodexho coupon", "10", "-9", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1306".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( executeResult.getAttribute( "Argument" ) != null && "10,-9".equals( ( ( ( String[ ] )executeResult.getAttribute( "Argument" ) )[0] ) ) );
		assertEquals( "01", executeResult.getAttribute( "dateDD" ) );
		assertEquals( "01", executeResult.getAttribute( "dateMM" ) );
		assertEquals( "2010", executeResult.getAttribute( "dateYYYY" ) );
		assertEquals( "Sodexho coupon", executeResult.getAttribute( "Desc" ) );
		assertEquals( "10", executeResult.getAttribute( "Importo" ) );
		assertEquals( "-9", executeResult.getAttribute( "ImportoDec" ) );
		assertEquals( "", executeResult.getAttribute( "Note" ) );
	}


	public void testBustaNeraInserisci9( ) {
		getGeoChallengedCdrList() ;
		mockTheRequestParams( "", "AA12345342", "", "01/01/2010", "Sodexho coupon", "10", "9", "" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		Hashtable bnHashTable = new Hashtable( );
		bnHashTable.put( "DefaultCdr", "099505" );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( bnHashTable );
		replay( this.requestEvent );
		replay( this.session );

		final ExecuteResult executeResult = new BustaNeraInserisciExecuter( ).execute( this.requestEvent );

		assertTrue( "TrConferma".equals( executeResult.getTransition( ) ) );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );
		bnHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		assertTrue( bnHashTable.containsKey( "BarCode" ) );
		assertEquals( "AA12345342", bnHashTable.get( "BarCode" ).toString( ) );
		assertEquals( Long.valueOf( 2 ), bnHashTable.get( "BustaNeraSeqNo" ) );
		final Collection bnMainCollection = ( Collection ) bnHashTable.get( "BustaNeraMainCollection" );
		assertEquals( 1, bnMainCollection.size( ) );
		for( final Object obj : bnMainCollection )
		{
			final BustaNeraAttributeView view = ( BustaNeraAttributeView ) obj;
			assertEquals( Long.valueOf( 1 ), view.getId( ) );
			try
			{
				assertEquals( new Timestamp( Util.getUtilDate( "01/01/2010" ).getTime() ), view.getBnDate( ) );
			}
			catch (final TracciabilitaException tracciabilitaException )
			{
				assertTrue( "Date not valid", true );
			}
			assertEquals( "Sodexho coupon", view.getDesc( ) );
			assertEquals( "10,90", view.getImporto( ) );
		}
	}

	private void mockTheRequestParams( final String userOrCDR, final String barcode, final String noteForDest, final String ddmmyyyy, final String description, final String importo, final String importoDecimal, final String note) {
		String dd = "";
		String mm = "";
		String yyyy = "";
		if ( ddmmyyyy != null && !"".equals( ddmmyyyy ) )
		{
			dd = ddmmyyyy.split( "/" )[0];
			mm = ddmmyyyy.split( "/" )[1];
			yyyy = ddmmyyyy.split( "/" )[2];
		}

		expect( this.requestEvent.getAttribute( "UserOrCdr" ) ).andReturn( userOrCDR ).anyTimes();
		expect( this.requestEvent.getAttribute( "BarCode" ) ).andReturn( barcode ).anyTimes();
		expect( this.requestEvent.getAttribute( "NoteForDest" ) ).andReturn( noteForDest ).anyTimes();
		expect( this.requestEvent.getAttribute( "SelectedBankId" ) ).andReturn( "-1" ).anyTimes();
		expect( this.requestEvent.getAttribute( "widelyUsedCdr" ) ).andReturn( "-1" ).anyTimes();
		expect( this.requestEvent.getAttribute( "MailMe" ) ).andReturn( null ).anyTimes();
		expect( this.requestEvent.getAttribute( "dateDD" ) ).andReturn( dd ).anyTimes();
		expect( this.requestEvent.getAttribute( "dateMM" ) ).andReturn( mm ).anyTimes();
		expect( this.requestEvent.getAttribute( "dateYYYY" ) ).andReturn( yyyy ).anyTimes();
		expect( this.requestEvent.getAttribute( "Desc" ) ).andReturn( description ).anyTimes();
		expect( this.requestEvent.getAttribute( "Importo" ) ).andReturn( importo ).anyTimes();
		expect( this.requestEvent.getAttribute( "ImportoDec" ) ).andReturn( importoDecimal ).anyTimes();
		expect( this.requestEvent.getAttribute( "Note" ) ).andReturn( note ).anyTimes();
	}


}
