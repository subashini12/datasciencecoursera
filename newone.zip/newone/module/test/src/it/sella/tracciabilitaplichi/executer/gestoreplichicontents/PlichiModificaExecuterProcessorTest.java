package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.StatusModifierInfoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.util.Hashtable;

public class PlichiModificaExecuterProcessorTest extends
		AbstractSellaExecuterMock {

	public PlichiModificaExecuterProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiModificaExecuterProcessor processor = new PlichiModificaExecuterProcessor();

	public void testPlichiModificaExecuterProcessor_01() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isDateChanged(getRequestEvent(), "", "11", "12", "12");
	}

	public void testPlichiModificaExecuterProcessor_02() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isDateChanged(getRequestEvent(), "1", "11", "12", "12");
	}

	public void testPlichiModificaExecuterProcessor_03() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("Cassetto")).andReturn("")
				.anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isCassettoChanged(getRequestEvent());
	}

	public void testPlichiModificaExecuterProcessor_04() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("Cassetto")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isCassettoChanged(getRequestEvent());
	}

	public void testPlichiModificaExecuterProcessor_05() {
		expecting(getRequestEvent().getAttribute("1")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isUserChanged(getRequestEvent(), "1", "1");
	}

	public void testPlichiModificaExecuterProcessor_06() {
		expecting(getRequestEvent().getAttribute("1")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isUserChanged(getRequestEvent(), "1", "1");
	}

	public void testPlichiModificaExecuterProcessor_07() {
		expecting(getRequestEvent().getAttribute("1")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isRecievioRequired(getRequestEvent());
	}

	public void testPlichiModificaExecuterProcessor_08() {
		expecting(getRequestEvent().getAttribute("1")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable"))
				.andReturn(getHashtable()).anyTimes();
		playAll();
		processor.isInvioRequired(getRequestEvent());
	}

	private Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable();
		hashtable.put("", getStatusModifierInfoView());
		hashtable.put("TracciabilitaPlichiView", getTracciabilitaPlichiView());
		hashtable.put("Cassetto", "1");
		hashtable.put("1", getStatusModifierInfoView());
		return hashtable;
	}

	private TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		return tracciabilitaPlichiView ;
	}
	
	private OggettoView getOggettoView()
	{
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setUserId("");
		return oggettoView ;
	}
	
	/*public void testvalidateRequest_01() {
		//setUpMockMethods(PlichiContentsDefaultB20Processor.class, PlichiContentsDefaultB20ProcessorMock.class);
		//setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("destinationCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationUser")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ownerOfPlichi")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("userSent")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Causale")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("userRicieved")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bvCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ownerCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("b10Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("NoOfPages")).andReturn("5").anyTimes();
		expecting(getRequestEvent().getAttribute("Cassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ownerBank")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destBank")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationBank")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("codProdCont")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("CreatedDay")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("CreatedMonth")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("CreatedYear")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(getHashtable()).anyTimes();
		playAll();
		try {
			processor.validateRequest(getRequestEvent());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}*/

	public StatusModifierInfoView getStatusModifierInfoView() {
		final StatusModifierInfoView statusModifierInfoView = new StatusModifierInfoView();
		statusModifierInfoView.setUserId("");
		return statusModifierInfoView;
	}
}
