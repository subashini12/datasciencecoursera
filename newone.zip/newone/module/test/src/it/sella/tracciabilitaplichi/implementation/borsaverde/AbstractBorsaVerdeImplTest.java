/*package it.sella.tracciabilitaplichi.implementation.borsaverde;


import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.TracciabilitaImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Properties;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

public class AbstractBorsaVerdeImplTest extends BasicJDBCTestCaseAdapter{

	@Override
	@Before
	public void setUp() throws Exception {
	}

	@Override
	@After
	public void tearDown() throws Exception {
	}
	
	BorsaVerdeImpl borsaVerdeImpl = new BorsaVerdeImpl() ;

		public void testBorsaVerdeImpl_01()
		{	
			Mockit.setUpMock(BorsaVerdeImpl.class, BorsaVerdeImplMock.class);
			Mockit.setUpMock(Util.class, UtilMock.class);
			Mockit.setUpMock(TracciabilitaImpl.class, TracciabilitaImplMock.class);
			Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
			Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
			final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
			final PreparedStatementResultSetHandler  statementHandler = 
	            connection.getPreparedStatementResultSetHandler();
			final MockResultSet result = statementHandler.createResultSet();
			MockRunnerConnection.setConnection(connection);
			result.addColumn("BV_ID",new Object[]{"1"});
			result.addColumn("BV_DOC_ID",new Object[]{"1"});
			result.addColumn("BV_CODE_ID",new Object[]{"1"});
			result.addColumn("BV_CURR_STATUS_ID",new Object[]{"1"});
			result.addColumn("BV_CREATION_DATE",new Object[]{"1"});
			result.addColumn("BV_ID_SUCC",new Object[]{"1"});
			result.addColumn("BV_CDR_DESTINATION",new Object[]{"1"});
			statementHandler.prepareGlobalResultSet(result);
			final Properties properties = new Properties() ;
			properties.put(ITPConstants.OGGETTO_VIEW, getOggettoView());
			properties.put(ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW ,getBorsaVerdeAttributeView() );
			try {
				borsaVerdeImpl.censitoOggetto(properties);
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			} catch (final RemoteException e) {
				e.printStackTrace();
			}                 
		}
		
		public void testModificaOggetto_01()
		{	
			UtilMock.setCheckNullFalse() ;
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(BorsaVerdeImpl.class, BorsaVerdeImplMock.class);
			Mockit.setUpMock(Util.class, UtilMock.class);
			Mockit.setUpMock(TracciabilitaImpl.class, TracciabilitaImplMock.class);
			Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
			Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
			Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
			final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
			final PreparedStatementResultSetHandler  statementHandler = 
	            connection.getPreparedStatementResultSetHandler();
			final MockResultSet result = statementHandler.createResultSet();
			MockRunnerConnection.setConnection(connection);
			result.addColumn("BV_ID",new Object[]{"1"});
			result.addColumn("BV_DOC_ID",new Object[]{"1"});
			result.addColumn("BV_CODE_ID",new Object[]{"1"});
			result.addColumn("BV_CURR_STATUS_ID",new Object[]{"1"});
			result.addColumn("BV_CREATION_DATE",new Object[]{"1"});
			result.addColumn("BV_ID_SUCC",new Object[]{"1"});
			result.addColumn("BV_CDR_DESTINATION",new Object[]{"1"});
			statementHandler.prepareGlobalResultSet(result);
			final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
			tracciabilitaPlichiView.setBorsaVerdeAttributeView(getBorsaVerdeAttributeView());
			final Properties properties = new Properties() ;
			properties.put(ITPConstants.STATUS,"");
			properties.put(ITPConstants.OGGETTO_VIEW,getOggettoView());
			properties.put(ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW,getBorsaVerdeAttributeView() );
			properties.put(ITPConstants.BORSA_VERDE_MODIFICA_TPVIEW,tracciabilitaPlichiView);
			properties.put(ITPConstants.HISTORY_VIEW,getHistoryView());
			try {
				borsaVerdeImpl.modificaOggetto(properties);
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		}
		
		public void testModificaOggetto_02()
		{	
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(BorsaVerdeImpl.class, BorsaVerdeImplMock.class);
			Mockit.setUpMock(Util.class, UtilMock.class);
			Mockit.setUpMock(TracciabilitaImpl.class, TracciabilitaImplMock.class);
			Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
			Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
			Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
			final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
			final PreparedStatementResultSetHandler  statementHandler = 
	            connection.getPreparedStatementResultSetHandler();
			final MockResultSet result = statementHandler.createResultSet();
			MockRunnerConnection.setConnection(connection);
			result.addColumn("BV_ID",new Object[]{"1"});
			result.addColumn("BV_DOC_ID",new Object[]{"1"});
			result.addColumn("BV_CODE_ID",new Object[]{"1"});
			result.addColumn("BV_CURR_STATUS_ID",new Object[]{"1"});
			result.addColumn("BV_CREATION_DATE",new Object[]{"1"});
			result.addColumn("BV_ID_SUCC",new Object[]{"1"});
			result.addColumn("BV_CDR_DESTINATION",new Object[]{"1"});
			statementHandler.prepareGlobalResultSet(result);
			final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
			tracciabilitaPlichiView.setBorsaVerdeAttributeView(getBorsaVerdeAttributeView());
			final Properties properties = new Properties() ;
			properties.put(ITPConstants.OGGETTO_VIEW,getOggettoView());
			properties.put(ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW,getBorsaVerdeAttributeView() );
			properties.put(ITPConstants.BORSA_VERDE_MODIFICA_TPVIEW,tracciabilitaPlichiView);
			properties.put(ITPConstants.HISTORY_VIEW,getHistoryView());
			try {
				borsaVerdeImpl.modificaOggetto(properties);
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		}
		
		public void testModificaOggetto_03()
		{	
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(BorsaVerdeImpl.class, BorsaVerdeImplMock.class);
			Mockit.setUpMock(Util.class, UtilMock.class);
			Mockit.setUpMock(TracciabilitaImpl.class, TracciabilitaImplMock.class);
			Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
			Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
			Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
			final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
			final PreparedStatementResultSetHandler  statementHandler = 
	            connection.getPreparedStatementResultSetHandler();
			final MockResultSet result = statementHandler.createResultSet();
			MockRunnerConnection.setConnection(connection);
			result.addColumn("BV_ID",new Object[]{"1"});
			result.addColumn("BV_DOC_ID",new Object[]{"1"});
			result.addColumn("BV_CODE_ID",new Object[]{"1"});
			result.addColumn("BV_CURR_STATUS_ID",new Object[]{"1"});
			result.addColumn("BV_CREATION_DATE",new Object[]{"1"});
			result.addColumn("BV_ID_SUCC",new Object[]{"1"});
			result.addColumn("BV_CDR_DESTINATION",new Object[]{"1"});
			statementHandler.prepareGlobalResultSet(result);
			final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
			tracciabilitaPlichiView.setBorsaVerdeAttributeView(getBorsaVerdeAttributeView());
			final Collection collection = new ArrayList() ;
			collection.add("1");
			collection.add("2");
			final Properties properties = new Properties() ;
			properties.put(ITPConstants.OGGETTO_VIEW,getOggettoView());
			properties.put(ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW,getBorsaVerdeAttributeView() );
			properties.put(ITPConstants.HISTORY_VIEW,getHistoryView());
			properties.put(ITPConstants.BV_DOC_ID_COLLECTION,collection);
			try {
				borsaVerdeImpl.modificaOggetto(properties);
			} catch (final TracciabilitaException e) {
				e.printStackTrace();
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		}
		
		public OggettoView getOggettoView()
		{
			final OggettoView oggettoView = new OggettoView() ;
			oggettoView.setStatusId(1L);
			return oggettoView ;
		}
		
		public HistoryView getHistoryView()
		{
		final HistoryView historyView = new HistoryView() ;
		historyView.setDocumentId(1L);
		return historyView ;
		}
		
		public BorsaVerdeAttributeView getBorsaVerdeAttributeView()
		{
			final BorsaVerdeAttributeView borsaVerdeAttributeView = new BorsaVerdeAttributeView() ;
			borsaVerdeAttributeView.setDocumentId(1L);
			borsaVerdeAttributeView.setStatusId(1L);
			borsaVerdeAttributeView.setIdSucc(1L);
			borsaVerdeAttributeView.setDataCreato(new Date(2012, 02, 01, 12, 12));
			return borsaVerdeAttributeView ;
		}
	}
*/