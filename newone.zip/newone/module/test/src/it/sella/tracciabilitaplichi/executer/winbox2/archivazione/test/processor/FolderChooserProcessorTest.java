package it.sella.tracciabilitaplichi.executer.winbox2.archivazione.test.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.archivazione.processor.FolderChooserProcessor;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.winbox2.archivazione.WinBox2ArchivazioneHelper;
import it.sella.tracciabilitaplichi.winbox2.test.mock.WinBox2ArchivazioneHelperMock;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;


public class FolderChooserProcessorTest extends AbstractSellaExecuterMock{

	public FolderChooserProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	FolderChooserProcessor processor = new FolderChooserProcessor() ;
	
	public void testFolderChooserProcessor_01()
	{
		setUpMockMethods(WinBox2ArchivazioneHelper.class, WinBox2ArchivazioneHelperMock.class);
		processor.getSelectedFoldersPerWinBox2(getRequestEvent(),getMap() );
	}
	
	public void testFolderChooserProcessor_02()
	{
		processor.getSelectedFoldersFromPage(null);
	}
	
	public void testFolderChooserProcessor_03()
	{
		final String[] strArr = new String[2];
		strArr[0] = "069778" ;
		strArr[1] = "123546" ;
		processor.getSelectedFoldersFromPage(strArr);
	}
	
	public void testFolderChooserProcessor_04()
	{
		final String barcode = "123546" ;
		processor.getSelectedFoldersFromPage(barcode);
	}
	
	private static Map getMap()
	{
		final Map<String, Collection<Folder>> map = new HashMap<String, Collection<Folder>>();
		map.put("123456-7891234", getFolderCollection());
		return map ;
	}
	
	private static Collection getFolderCollection()
	{
		final Collection<Folder> folderCollection = new ArrayList<Folder>();
		folderCollection.add(getFolder ());
		return folderCollection ;
	}
	
	private static Folder getFolder()
	{
		final Folder folder = new Folder() ;
		final OggettoView oggettoView =new OggettoView() ;
		oggettoView.setBankId(2L);
		folder.setOggettoView(oggettoView);
		return folder ;
	}
	
	public void testFolderChooserProcessor_05()
	{
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getAttribute("7891234_123456-7894568")).andReturn("4554545").anyTimes();
		EasyMock.replay(requestEvent);
		setUpMockMethods(WinBox2ArchivazioneHelper.class, WinBox2ArchivazioneHelperMock.class);
		processor.getSelectedFoldersPerWinBox2(requestEvent,getMap() );
	}
}
