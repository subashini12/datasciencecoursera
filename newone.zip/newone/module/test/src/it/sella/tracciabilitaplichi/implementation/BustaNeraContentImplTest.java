/*package it.sella.tracciabilitaplichi.implementation;


import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraAttributeView;

import java.util.Properties;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BustaNeraContentImplTest  {

	BustaNeraContentImpl bustaNeraContentImpl=new BustaNeraContentImpl();
	
	@Before
	public void setUp() throws Exception {
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_TR_BUSTANERA_ATTRIBUTE (PBN_ID numeric(6))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_TR_BUSTANERA_ATTRIBUTE values(3)");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_TR_BUSTANERA_ATTRIBUTE values(2)");
	}
	
	@Test
	public void cancelliOggetto_01()
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final Properties properties=getProperties();
		try {
			bustaNeraContentImpl.cancelliOggetto(properties);
		} catch (final TracciabilitaException e) {
		}
	}

	@Test
	public void cancelliOggetto_02()
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final Properties properties=getProperties();
		try {
			bustaNeraContentImpl.censitoOggetto(properties);
		} catch (final TracciabilitaException e) {
		}
	}
	
	private static BustaNeraAttributeView getBustaNeraAttributeView()
	{
		final BustaNeraAttributeView bustaNeraAttributeView=new BustaNeraAttributeView();
		bustaNeraAttributeView.setId(2L);
		return bustaNeraAttributeView;
	}
	
	private static Properties getProperties()
	{
		final BustaNeraAttributeView bustaNeraAttributeView=getBustaNeraAttributeView();
		final Properties properties=new Properties();
		properties.put("BustaNeraAttributeView",bustaNeraAttributeView);
		return properties;
	}
	
	@After
	public void tearDown() throws Exception {
		SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_TR_BUSTANERA_ATTRIBUTE");
	}

}
*/