package it.sella.tracciabilitaplichi.executer.test.gestoreplichialtriattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestoreplichialtriattributeadmin.PlichiAltriAttributeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;

public class PlichiAltriAttributeCercaExecuterTest extends AbstractSellaExecuterMock
{

	public PlichiAltriAttributeCercaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	PlichiAltriAttributeCercaExecuter executer = new PlichiAltriAttributeCercaExecuter();
	
	public void testExecuter_01()
	{
		expecting( getStateMachineSession().containsKey( "PlichiAltriAttributeTable" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
	    playAll();
		executer.execute( getRequestEvent());		
	}
	
	public void testExecuter_02()	
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getStateMachineSession().containsKey( "PlichiAltriAttributeTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	public void testExecuter_03()	
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setViewSizeZero();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getStateMachineSession().containsKey( "PlichiAltriAttributeTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_04()	
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getStateMachineSession().containsKey( "PlichiAltriAttributeTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_05()	
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getStateMachineSession().containsKey( "PlichiAltriAttributeTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("abc").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	
	
	
	private  Map getPlichiAltriAttributeTable()
	{
		 Map plichiAltriAttributeTable = new Hashtable();
		 plichiAltriAttributeTable.put(1, "abc");
		 return plichiAltriAttributeTable;
	}

}
