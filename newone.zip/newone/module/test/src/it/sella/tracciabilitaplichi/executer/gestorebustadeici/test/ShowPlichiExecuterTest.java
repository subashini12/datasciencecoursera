package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.ShowPlichiExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Stack;

import org.easymock.EasyMock;

public class ShowPlichiExecuterTest extends  AbstractSellaExecuterMock {

	ShowPlichiExecuter executer = new ShowPlichiExecuter();
	
	public ShowPlichiExecuterTest(final String name) {
		super(name);
	}
	
	public void testShowPlichiExecuter_01() {
		expecting( getStateMachineSession().containsKey( "BarCodeStack" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "SearchFrom" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getRequestEvent().getAttribute( "PageNo" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), ( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "BarCodeStack" )).andReturn(  getBarCode()  ).anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn( "DetaglioEvent" ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testShowPlichiExecuter_02() {
		expecting( getStateMachineSession().containsKey( "BarCodeStack" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "SearchFrom" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getRequestEvent().getAttribute( "PageNo" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( null ).anyTimes();		
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "1234354363" ).anyTimes();
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), ( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "BarCodeStack" )).andReturn(  getBarCode()  ).anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn( "DetaglioEvent" ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testShowPlichiExecuter_03() {
		expecting( getStateMachineSession().containsKey( "BarCodeStack" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "SearchFrom" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getRequestEvent().getAttribute( "PageNo" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( null ).anyTimes();		
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "1234354363" ).anyTimes();
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), ( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "BarCodeStack" )).andReturn(  getBarCode()  ).anyTimes();
		expecting( getStateMachineSession().remove( "SearchFrom" )).andReturn(  null  ).anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn( "ABC" ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}

	private Stack getBarCode() {
		final Stack stack = new Stack( );
		stack.add("barCode");
		return stack ;
	}
	
}
