/*package it.sella.tracciabilitaplichi.executer.test.gestionesolleciti;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.ISDefaultEsitiMailExecuter;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import org.easymock.EasyMock;


public class ISDefaultEsitiMailExecuterTest  extends AbstractSellaExecuterTest {

	public ISDefaultEsitiMailExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	ISDefaultEsitiMailExecuter executer = new ISDefaultEsitiMailExecuter();
	
	
	public void testISDefaultEsitiMailExecuter_01()
	{
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		expecting( getStateMachineSession().containsKey( "GESTIONE_SOLLECITI_MAP" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	
	public void testISDefaultEsitiMailExecuter_02()
	{
		SecurityWrapperMock.setTracciabilitaException();
		setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		expecting( getStateMachineSession().containsKey( "GESTIONE_SOLLECITI_MAP" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		ExecuteResult executeResult = executer.execute( getRequestEvent());
		assertEquals("it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException" ,executeResult.getException().toString());
	}
	
}
*/