package it.sella.tracciabilitaplichi.executer.gestorebustacinque;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiBustasDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiStatusDataAccessMock;

import java.util.Collection;

import org.easymock.EasyMock;



public class BustaExecuterTest extends AbstractSellaExecuterMock{

	public BustaExecuterTest(final String name) {
		super(name);
	}
	
	BustaExecuter executer=new BustaExecuter();
	
	public void testBustaExecuter_01() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
	}
	
	public void testBustaExecuter_03() {
		TracciabilitaPlichiBustasDataAccessMock.setExistOggettoForUser();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testBustaExecuter_04() {
		TracciabilitaPlichiBustasDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public void testBustaExecuter_05() {
		TracciabilitaPlichiBustasDataAccessMock.setExistOggettoForUserNotnull();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma" );
	}
	
	public void testBustaExecuter_06() {
		TracciabilitaPlichiBustasDataAccessMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testBustaExecuter_02() {
		TracciabilitaPlichiBustasDataAccessMock.setTracciabilitaException();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public void testBustaExecuter_07() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
}