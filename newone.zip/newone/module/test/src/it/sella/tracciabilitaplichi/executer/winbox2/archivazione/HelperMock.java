package it.sella.tracciabilitaplichi.executer.winbox2.archivazione;

import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.winbox2.archivazione.Winbox2InputProcessor;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class HelperMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	/*
	 * @Mock public static Map getMapControlloFromCache() throws
	 * TracciabilitaException, RemoteException { if(tracciabilitaException) {
	 * tracciabilitaException=false; throw new TracciabilitaException(); }
	 * if(remoteException) { remoteException=false; throw new RemoteException();
	 * } Map map=new HashMap();
	 * 
	 * return map; }
	 */
	@Mock
	public static Map getArchivioSessionMap(final StateMachineSession session) {
		final Winbox2InputProcessor winbox2InputProcessor = new Winbox2InputProcessor(
				"", 1L);
		final Map map = new HashMap();
		final Map<String, Collection<Folder>> confirmationNeededMap = new HashMap<String, Collection<Folder>>();
		final Collection cln = new ArrayList();
		final Folder f1 = new Folder();
		f1.setSTATO("stato");
		cln.add(f1);
		confirmationNeededMap.put("1", cln);
		map.put(CONSTANTS.CONFIRMATION_NEEDED_MAP.toString(),
				confirmationNeededMap);
		map.put(CONSTANTS.WINBOX2_INPUT_PROCESSOR.toString(),
				winbox2InputProcessor);
		map.put(CONSTANTS.STAMPE_ID.getValue(), "");
		return map;
	}

	@Mock
	public static void setWinBox2ArchivioPageDetails(
			final Map<String, Object> sessionMap,
			final Winbox2InputProcessor winbox2InputProcessor)
			throws TracciabilitaException, RemoteException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		return;
	}	
}
