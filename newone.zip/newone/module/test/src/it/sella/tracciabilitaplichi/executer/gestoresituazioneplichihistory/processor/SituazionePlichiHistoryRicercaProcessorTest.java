package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichihistory.processor;

import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

public class SituazionePlichiHistoryRicercaProcessorTest extends
		AbstractSellaExecuterMock {

	public SituazionePlichiHistoryRicercaProcessorTest(final String name) {
		super(name);
	}

	SituazionePlichiHistoryRicercaProcessor processor = new SituazionePlichiHistoryRicercaProcessor();

	public void testSituazionePlichiHistoryRicercaProcessor_01() {
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderBank")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationBank")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiBarCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descritioneArticoli")).andReturn("").anyTimes();
		playAll();
		processor.validateHistoryInputs(getRequestEvent());
	}
}
