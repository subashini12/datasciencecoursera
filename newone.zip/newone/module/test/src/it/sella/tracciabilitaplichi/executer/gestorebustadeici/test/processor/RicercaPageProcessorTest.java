package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor;

import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.RicercaPageProcessor;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.rmi.RemoteException;

public class RicercaPageProcessorTest extends AbstractSellaMock {
	
	public RicercaPageProcessorTest( final String name ) {
		super( name );
	}
	
	public void testRicercaPageProcessor_01() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		try {
			assertNotNull(RicercaPageProcessor.getInstance().getResponsibleIdSuccAndCdrMap(""));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
}
