package it.sella.tracciabilitaplichi.executer.test.gestorecdrgroupadmin;

import it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin.CdrGroupOperationsDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

import java.util.Collection;

import org.easymock.EasyMock;

public class CdrGroupOperationsDefaultExecuterTest extends AbstractSellaExecuterMock {

	public CdrGroupOperationsDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	CdrGroupOperationsDefaultExecuter executer = new CdrGroupOperationsDefaultExecuter() ;
	
	public void testCdrGroupOperationsDefaultExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("Cdr")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("ID")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("Cdr")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("ID")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("Group")).andReturn("").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCdrGroupOperationsDefaultExecuter_02()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("Cdr")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("ID")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("Cdr")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("ID")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("Group")).andReturn("").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
}
