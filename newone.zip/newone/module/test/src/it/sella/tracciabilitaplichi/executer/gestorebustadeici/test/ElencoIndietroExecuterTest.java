package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.ElencoIndietroExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.ArrayList;

public class ElencoIndietroExecuterTest extends AbstractSellaExecuterMock {
	
	ElencoIndietroExecuter executer = new ElencoIndietroExecuter();
	
	public ElencoIndietroExecuterTest(final String name) {
		super(name);		
	}
	
	public void testElencoIndietroExecuter_01() {
		expecting( getStateMachineSession().containsKey( CONSTANTS.SEARCH_FILTER.toString( ) ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "StatusCollection" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "ESITO_COLLECTION" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "COD_CONTRATTO_COLL" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "UnifiedCdrsList" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "IsUserCapoORViceCapo" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "CodCDR" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.DATA_RICERCA.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "ESITO_COLLECTION" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting( getStateMachineSession().get( "StatusCollection" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting( getStateMachineSession().put( "collStatusDetail" , new ArrayList() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "UnifiedCdrsList" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting( getStateMachineSession().get( "IsUserCapoORViceCapo" )).andReturn( Boolean.TRUE  ).anyTimes();		
		expecting( getStateMachineSession().get( "CodCDR" )).andReturn(  "09923"  ).anyTimes();
		expecting( getStateMachineSession().remove( "StatusCollection" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().put( "UltimoEsito", new ArrayList() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove( "ESITO_COLLECTION" ) ).andReturn(null).anyTimes();		
		expecting( getStateMachineSession().remove( "COD_CONTRATTO_COLL" ) ).andReturn(null).anyTimes();		
		expecting( getStateMachineSession().remove( "SEARCH_FILTER" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( CONSTANTS.DATA_RICERCA.toString( ))).andReturn(null).anyTimes();
		playAll();		
		final ExecuteResult executeResult = executer.execute( getRequestEvent() );
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testElencoIndietroExecuter_02() {
		expecting( getStateMachineSession().containsKey( CONSTANTS.SEARCH_FILTER.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "StatusCollection" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "ESITO_COLLECTION" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "COD_CONTRATTO_COLL" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "UnifiedCdrsList" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "IsUserCapoORViceCapo" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "CodCDR" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.DATA_RICERCA.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "ESITO_COLLECTION" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting( getStateMachineSession().get( "StatusCollection" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting( getStateMachineSession().put( "collStatusDetail" , new ArrayList() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "UnifiedCdrsList" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting( getStateMachineSession().get( "IsUserCapoORViceCapo" )).andReturn( Boolean.TRUE  ).anyTimes();		
		expecting( getStateMachineSession().get( "CodCDR" )).andReturn(  "09923"  ).anyTimes();
		expecting( getStateMachineSession().remove( "StatusCollection" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().put( "UltimoEsito", new ArrayList() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove( "ESITO_COLLECTION" ) ).andReturn(null).anyTimes();		
		expecting( getStateMachineSession().remove( "COD_CONTRATTO_COLL" ) ).andReturn(null).anyTimes();		
		expecting( getStateMachineSession().remove( "SEARCH_FILTER" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( CONSTANTS.DATA_RICERCA.toString( ))).andReturn(null).anyTimes();
		playAll();		
		final ExecuteResult executeResult = executer.execute( getRequestEvent() );
		assertEquals(executeResult.getTransition(), "TrIndietro");
	}

}
