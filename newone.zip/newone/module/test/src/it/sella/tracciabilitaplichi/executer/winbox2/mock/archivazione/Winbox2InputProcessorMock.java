package it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione;

import it.sella.tracciabilitaplichi.persistence.dto.Cassetto;
import mockit.Mock;

public class Winbox2InputProcessorMock {
	@Mock
	public Cassetto getCassetto() {
		final Cassetto cassetto = new Cassetto();
		cassetto.setSTATO("stato");
		return cassetto;
	}

	/*@Mock
	public List<Long> getNoOfWinBox2ToBeArchivedColl( ) throws RemoteException, TracciabilitaException
	{
		final List<Long> list = new ArrayList<Long>();
		list.add(1L);
		list.add(1L);
		return list ;
	}*/
	
	@Mock
	public Long getTotalNoOfWinBox2ToBeArchived() {
		return Long.valueOf(1);
	}
	@Mock
	public Long getTotalWinBox2InInviataToBeArchived() {
		return Long.valueOf(1);
	}
}
