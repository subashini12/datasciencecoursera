package it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class InvioSmistamentoIndietroExecuterTest extends
		AbstractSellaExecuterMock {

	public InvioSmistamentoIndietroExecuterTest(final String name) {
		super(name);
	}

	InvioSmistamentoIndietroExecuter executer = new InvioSmistamentoIndietroExecuter();

	public void testInvioSmistamentoIndietroExecuter_01() {
	    TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting(getStateMachineSession().remove("smistamentoId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("cassettoCode")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public void testInvioSmistamentoIndietroExecuter_02() {
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting(getStateMachineSession().remove("smistamentoId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("cassettoCode")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public void testInvioSmistamentoIndietroExecuter_03() {
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		TracciabilitaPlichiManagerBeanMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting(getStateMachineSession().remove("smistamentoId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("cassettoCode")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoIndietroExecuter_04() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting(getStateMachineSession().remove("smistamentoId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn("").anyTimes();
		expecting(getStateMachineSession().remove("cassettoCode")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public Map getMap() {
		final Map map = new HashMap();
		map.put("SelectedBustaNeraViewCollection", new ArrayList());
		map.put("LastSentBustaNeraView", "");
		map.put("smistamentoId", "");
		map.put("ArrayListBustaNeraView", "");
		return map;
	}

}
