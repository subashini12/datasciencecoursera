package it.sella.tracciabilitaplichi.contractchooser.test.helper;

import it.sella.tracciabilitaplichi.contractchooser.helper.ContractListUtil;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class ContractListUtilTest extends BasicJDBCTestCaseAdapter{

	ContractListUtil contractListUtil = new ContractListUtil() ; 
	
	public void testGetBustaDeiciAttributeViews() throws SQLException {
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_ID", new Object[] { "27" });
		result.addColumn("BD_NC", new Object[] { "T1A9679837670" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_COD_PRODCONT", new Object[] { "30" });
		result.addColumn("BD_OGGETTO_ID", new Object[] { "4979086" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			assertNotNull(contractListUtil.getContractForPlicoNumero(getB10Map()));
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetBustaDeiciAttributeViews_exception() throws SQLException {
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_ID", new Object[] { "27" });
		result.addColumn("BD_NC", new Object[] { "T1A9679837670" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			assertNotNull(contractListUtil.getContractForPlicoNumero(getB10Map()));
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public Map getB10Map() {
		final Collection b10Collection = new ArrayList() ;
		b10Collection.add("1360017276508");
		final Map b10Map = new HashMap() ;
		b10Map.put("1360020163444", b10Collection);
		return b10Map ;
	}
	
}
