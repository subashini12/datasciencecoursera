/*package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.msg.MsgManager;
import it.sella.tracciabilitaplichi.implementation.admin.AltriAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriAttributeView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

public class AltriAttributeAdminImplTest extends BasicJDBCTestCaseAdapter {

	AltriAttributeAdminImpl altriAttributeAdminImpl = new AltriAttributeAdminImpl();

	public void testModificaOggetto_01() throws SQLException {
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
	    Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("AA_DOC_ID", new Object[] { "1" });
		result.addColumn("AA_NUMBER", new Object[] { "1" });
		result.addColumn("AA_CDR_DESTINATION", new Object[] { "1" });
		result.addColumn("AA_OG_TYPE", new Object[] { "1" });
		result.addColumn("AA_ID", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			altriAttributeAdminImpl.modificaOggetto(getAltriAttributeView());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}

	private static AltriAttributeView getAltriAttributeView() {
		final AltriAttributeView altriAttributeView = new AltriAttributeView();
		altriAttributeView.setDocumentId(3L);
		altriAttributeView.setBarCode("1234567887");
		altriAttributeView.setCdrDestination("");
		altriAttributeView.setAltriType(3L);
		altriAttributeView.setId(4L);
		return altriAttributeView;
	}
}*/