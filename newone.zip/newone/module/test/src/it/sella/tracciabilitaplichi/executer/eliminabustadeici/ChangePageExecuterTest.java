package it.sella.tracciabilitaplichi.executer.eliminabustadeici;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.ChangePageProcessor;
import it.sella.tracciabilitaplichi.implementation.util.BustaDeiciPagging;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ChangePageProcessor.class})
public class ChangePageExecuterTest {

	ChangePageExecuter changePageExecuter = new ChangePageExecuter() ;
	
	@Test
	public void execute() {
		
		BustaDeiciPagging bustaDeiciPagging = EasyMock.createMock(BustaDeiciPagging.class);
		try {
			EasyMock.expect(bustaDeiciPagging.getPageData(Integer.parseInt( "1" ))).andReturn(new Hashtable()).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isPreviousSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isNextSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.getCurrentSection()).andReturn(new ArrayList()).anyTimes();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		EasyMock.replay(bustaDeiciPagging);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.get("Pagging")).andReturn(bustaDeiciPagging).anyTimes();
		EasyMock.expect(session.containsKey(ITPConstants.COD_CONTRATTO_COLL)).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( new ArrayList()).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( "").anyTimes();
		EasyMock.expect(session.get( EasyMock.anyObject() )).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(requestEvent);
		
		Map mapChangepageprocessor = new HashMap();
		mapChangepageprocessor.put("pageNo","1");
		
		PowerMock.mockStatic(ChangePageProcessor.class);
		ChangePageProcessor changePageProcessor = EasyMock.createMock(ChangePageProcessor.class);
		EasyMock.expect(ChangePageProcessor.mapChangePageData(requestEvent, session)).andReturn(mapChangepageprocessor).anyTimes();
		PowerMock.replay(ChangePageProcessor.class);
		
		changePageExecuter.execute(requestEvent);
	}
	
	@Test
	public void execute_02() {
		
		BustaDeiciPagging bustaDeiciPagging = EasyMock.createMock(BustaDeiciPagging.class);
		try {
			EasyMock.expect(bustaDeiciPagging.getPageData(Integer.parseInt( "1" ))).andReturn(new Hashtable()).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isPreviousSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isNextSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.getCurrentSection()).andReturn(new ArrayList()).anyTimes();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		EasyMock.replay(bustaDeiciPagging);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.get("Pagging")).andReturn(bustaDeiciPagging).anyTimes();
		EasyMock.expect(session.containsKey(ITPConstants.COD_CONTRATTO_COLL)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.get( ITPConstants.COD_CONTRATTO_COLL )).andReturn("").anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( new ArrayList()).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( "").anyTimes();
		EasyMock.expect(session.get( EasyMock.anyObject() )).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(requestEvent);
		
		Map mapChangepageprocessor = new HashMap();
		mapChangepageprocessor.put("pageNo","1");
		
		PowerMock.mockStatic(ChangePageProcessor.class);
		ChangePageProcessor changePageProcessor = EasyMock.createMock(ChangePageProcessor.class);
		EasyMock.expect(ChangePageProcessor.mapChangePageData(requestEvent, session)).andReturn(mapChangepageprocessor).anyTimes();
		PowerMock.replay(ChangePageProcessor.class);
		
		ExecuteResult executeResult = changePageExecuter.execute(requestEvent);
		Assert.assertFalse((Boolean) executeResult.getAttribute("prevLink"));
		
	}
}
