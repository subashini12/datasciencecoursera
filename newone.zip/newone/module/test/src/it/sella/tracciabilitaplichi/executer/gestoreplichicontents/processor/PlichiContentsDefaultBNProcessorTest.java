/*package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

public class PlichiContentsDefaultBNProcessorTest extends
		AbstractSellaExecuterTest {

	public PlichiContentsDefaultBNProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiContentsDefaultBNProcessor processor = new PlichiContentsDefaultBNProcessor();

	public void testPlichiContentsDefaultBNProcessor_01() {
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("").anyTimes();
		playAll();
		try {
			processor.processBNRecords(getRequestEvent(), null);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
}
*/