package it.sella.tracciabilitaplichi.executer.test.gestorebustacinqueattributesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.gestorebustacinqueattributesadmin.BustaCinqueAttributeUpdateConfermaExecuter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.view.BustaCinqueAttributeView;
import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;

public class BustaCinqueAttributeUpdateConfermaExecuterTest {

    BustaCinqueAttributeUpdateConfermaExecuter BustaCinqueAttributeUpdateConfermaExecuter = new BustaCinqueAttributeUpdateConfermaExecuter();

    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_01() {
    	Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(new BustaCinqueAttributeView()).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getEventName( )).andReturn("UpdateConferma").anyTimes( );
        EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
        final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent);
        Assert.assertEquals("TRPL-1055", executeResult.getAttribute( "MSG"));
        Assert.assertEquals("yes", executeResult.getAttribute( "Success"));
        Assert.assertEquals(null, executeResult.getAttribute("BustaCinqueAttributeViews"));
    } 

    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_02() {
    	Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
    	final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect( stateMachineSession.get( "BustaCinqueAttributeViews" )).andReturn(null);
		EasyMock.expect( stateMachineSession.containsKey(  "ModifiedBustaCinqueAttributeView" )).andReturn(true);
		EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(new BustaCinqueAttributeView()).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getEventName( )).andReturn("Indietro").anyTimes( );
		EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent);
		Assert.assertEquals(null, executeResult.getAttribute( "MSG"));
        Assert.assertEquals(null, executeResult.getAttribute( "Success"));
        Assert.assertEquals(null, executeResult.getAttribute("BustaCinqueAttributeViews"));
    } 
     
    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_03() {
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
         final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
	 	 EasyMock.expect( stateMachineSession.get( "BustaCinqueAttributeViews" )).andReturn(null);
	 	 EasyMock.expect( stateMachineSession.containsKey(  "ModifiedBustaCinqueAttributeView" )).andReturn(false);
	 	 EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(null).anyTimes();
	 	 EasyMock.replay(stateMachineSession);
         final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
 		 EasyMock.expect( requestEvent.getEventName( )).andReturn("Indietro").anyTimes( );
 		 EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();		EasyMock.replay(requestEvent);
 		 final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent);
         Assert.assertEquals(null, executeResult.getAttribute( "MSG"));
         Assert.assertEquals(null, executeResult.getAttribute( "Success"));
         Assert.assertEquals(null, executeResult.getAttribute("BustaCinqueAttributeViews"));
     } 
     
    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_04() {
    	 Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
    	 Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
         final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
	 	 EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(new BustaCinqueAttributeView()).anyTimes();
	 	 EasyMock.replay(stateMachineSession);
         final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
 		 EasyMock.expect( requestEvent.getEventName( )).andReturn("UpdateConferma").anyTimes( );
 		 EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();		
 		 EasyMock.replay(requestEvent);
 		 final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent);
 		 Assert.assertEquals("TRPL-1055", executeResult.getAttribute( "MSG"));
         Assert.assertEquals("yes", executeResult.getAttribute( "Success"));
         Assert.assertEquals(null, executeResult.getAttribute("BustaCinqueAttributeViews"));
    }
     
    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_remoteException() {
    	 TracciabilitaPlichiImplMock.setRemoteException();
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
    	 Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
         final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
	 	 EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(new BustaCinqueAttributeView()).anyTimes();
	 	 EasyMock.replay(stateMachineSession);
         final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
 		 EasyMock.expect( requestEvent.getEventName( )).andReturn("UpdateConferma").anyTimes( );
 		 EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();		
 		 EasyMock.replay(requestEvent);
 		 final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent);
 		 Assert.assertEquals(null, executeResult.getAttribute( "MSG"));
 		 Assert.assertEquals(null, executeResult.getAttribute( "Success"));
     } 

    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_tracciabilitaException() {
    	 TracciabilitaPlichiImplMock.setTracciabilitaException();
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
    	 Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
         final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
	 	 EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(new BustaCinqueAttributeView()).anyTimes();
	 	 EasyMock.replay(stateMachineSession);
         final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
 		 EasyMock.expect( requestEvent.getEventName( )).andReturn("UpdateConferma").anyTimes( );
 		 EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();		
 		 EasyMock.replay(requestEvent);
 		 final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent); 
         Assert.assertEquals(null, executeResult.getAttribute( "MSG"));
 		 Assert.assertEquals(null, executeResult.getAttribute( "Success"));
     } 
     
    @Test
     public void bustaCinqueAttributeUpdateConfermaExecuter_05() {
    	 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
    	 Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
         final BustaCinqueAttributeView view = new BustaCinqueAttributeView() ;
         view.setId( 34L );
         view.setDocId(  33L );
         view.setFlag( "flage" );
         view.setBankAdmin( "admin" );
         final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
	 	 EasyMock.expect( stateMachineSession.get( "BustaCinqueAttributeViews" )).andReturn(null);
	 	 EasyMock.expect( stateMachineSession.containsKey(  "ModifiedBustaCinqueAttributeView" )).andReturn(true);
	 	 EasyMock.expect( stateMachineSession.get( "ModifiedBustaCinqueAttributeView" )).andReturn(view).anyTimes();
	 	 EasyMock.replay(stateMachineSession);
         final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
 		 EasyMock.expect( requestEvent.getEventName( )).andReturn("Indietro").anyTimes( );
 		 EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();		
 		 EasyMock.replay(requestEvent);
 		 final ExecuteResult executeResult = BustaCinqueAttributeUpdateConfermaExecuter.execute(requestEvent); 
         Assert.assertEquals(null, executeResult.getAttribute( "MSG"));
 		 Assert.assertEquals(null, executeResult.getAttribute( "Success"));
 		 Assert.assertEquals(null, executeResult.getAttribute("BustaCinqueAttributeViews"));
     } 
     
}
