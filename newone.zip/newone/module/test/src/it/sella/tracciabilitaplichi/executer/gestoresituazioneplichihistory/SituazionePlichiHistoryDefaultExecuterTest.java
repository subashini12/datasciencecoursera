package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichihistory;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Hashtable;

import org.easymock.EasyMock;

public class SituazionePlichiHistoryDefaultExecuterTest extends
		AbstractSellaExecuterMock {

	public SituazionePlichiHistoryDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SituazionePlichiHistoryDefaultExecuter executer = new SituazionePlichiHistoryDefaultExecuter();

	public void testSituazionePlichiHistoryDefaultExecuter_01() {
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testSituazionePlichiHistoryDefaultExecuter_02() {
		TracciabilitaPlichiStatusDataAccessMock.setTracciabilitaException();
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryDefaultExecuter_03() {
		TracciabilitaPlichiStatusDataAccessMock.setRemoteException();
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryDefaultExecuter_04() {
		ClassificazioneWrapperMock.setTracciabilitaExternalServicesException();
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
}
