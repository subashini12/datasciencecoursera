package it.sella.tracciabilitaplichi.implementation;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Properties;

import mockit.Mock;

public class BustaDeiciContrattiImplMock {
	
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}
	
@Mock
public void modificaOggetto( final Properties properties ) throws TracciabilitaException, RemoteException
{
	if (remoteException) {
		throw new RemoteException();
	}
	
	if (tracciabilitaException) {
		tracciabilitaException = false;
		throw new TracciabilitaException();
	}
	
	return ;
}
}
