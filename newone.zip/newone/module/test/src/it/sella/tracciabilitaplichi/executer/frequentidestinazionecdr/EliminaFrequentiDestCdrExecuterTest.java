package it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessorMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccessMock;

public class EliminaFrequentiDestCdrExecuterTest extends
AbstractSellaExecuterMock {

	public EliminaFrequentiDestCdrExecuterTest(final String name) {
		super(name);
	}

	EliminaFrequentiDestCdrExecuter executer = new EliminaFrequentiDestCdrExecuter();

	/*public void testEliminaFrequentiDestCdrExecuter_01() {
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrError");
	}

	public void testEliminaFrequentiDestCdrExecuter_02() {
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn(null).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrError");
	}*/

	public void testEliminaFrequentiDestCdrExecuter_03() {
		TPFrequentiDestinazioneCdrDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}

	public void testEliminaFrequentiDestCdrExecuter_04() {
		TPFrequentiDestinazioneCdrDataAccessMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class,TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class,FrequentiDestinazioneCdrProcessorMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
}
