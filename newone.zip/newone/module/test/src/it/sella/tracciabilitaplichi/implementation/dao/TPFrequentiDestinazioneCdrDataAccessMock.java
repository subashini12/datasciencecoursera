package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import mockit.Mock;

public class TPFrequentiDestinazioneCdrDataAccessMock
{
	private static Boolean tracciabilitaException = false;
	private static Boolean isfrequentiDestinazioneCdrExist = false;
	private static Boolean isCollFrequentiDestinazioneCdrViewNotNull = false;
	private static Boolean remoteException = false;

	public static void setCollFrequentiDestinazioneCdrViewNotNull() {
		isCollFrequentiDestinazioneCdrViewNotNull = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setfrequentiDestinazioneCdrExist() {
		isfrequentiDestinazioneCdrExist = true;
	}

	@Mock
	public boolean isfrequentiDestinazioneCdrExist(final String cdrId)
	throws TracciabilitaException {
		boolean flag = false;
		if (isfrequentiDestinazioneCdrExist) {
			isfrequentiDestinazioneCdrExist = false;
			flag = true;
		}
		if (tracciabilitaException) {
			throw new TracciabilitaException();
		}
		return flag;
	}

	@Mock
	public FrequentiDestinazioneCdrView getfrequentiDestinazioneCdr(final String cdrId)
	throws TracciabilitaException {
		final FrequentiDestinazioneCdrView view = new FrequentiDestinazioneCdrView();
		view.setBankId(1L);
		view.setBankDescription("abc");
		return view;
	}

	@Mock
	public Collection collFrequentiDestinazioneCdrView(final Map mapFreqUsedCDRS)
	throws TracciabilitaException {
		Collection collection = null;

		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (isCollFrequentiDestinazioneCdrViewNotNull) {
			collection = new ArrayList();
		}

		return collection;
	}


	@Mock
	public boolean isfrequentiDestinazioneCdrExist4bank( final String bankId , final String codiceCdr ) throws TracciabilitaException
	{
		return true ;
	}
}
