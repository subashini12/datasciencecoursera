package it.sella.tracciabilitaplichi.executer.test.gestorebustanera;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.BustaNeraVerificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiHoldingDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiHoldingDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import junit.framework.TestCase;
import mockit.Mockit;

public class BustaNeraVerificaExecuterTest extends TestCase
{
	private RequestEvent requestEvent;
	private StateMachineSession session;
	
	public BustaNeraVerificaExecuterTest( final String name )
	{
		super( name );
	}
	
	@Override
	public void setUp( ) throws Exception
	{
		super.setUp( );
		this.requestEvent = createMock( RequestEvent.class );
		this.session = createMock( StateMachineSession.class );
	}
	
	@Override
	public void tearDown( )
	{
		requestEvent = null;
		session = null;
	}
	
	public void testBNCDRVerifica1( )
	{
		mockTheRequestParams( "", "-1", "-1", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) != null && "TRPL-1078".equals( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ).toString( ) ) );
		
	}
	
	public void testBNCDRVerifica2( )
	{
		mockTheRequestParams( "IN2030", "1", "3", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) != null && "TRPL-1089".equals( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ).toString( ) ) );
		
	}
	
	public void testBNCDRVerifica3( )
	{
		mockTheRequestParams( "IN2030", "-1", "-1", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) != null && "TRPL-1345".equals( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ).toString( ) ) );
		
	}
	
	public void testBNCDRVerifica4( )
	{
		mockTheRequestParams( "", "1", "-1", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) != null && "TRPL-1078".equals( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ).toString( ) ) );
		
	}
	
	public void testBNCDRVerifica5( )
	{
		/*mockTheRequestParams( "IN2000", "1", "-1", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		mockDBPersonaleWrapper( Boolean.FALSE );
		mockSecurityWrapper( Boolean.FALSE );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) != null && "TRPL-1078".equals( executeResult.getAttribute( CONSTANTS.MSG.toString( ) ).toString( ) ) );*/
		
	}
	
	public void testBNCDRVerifica6( )
	{
	/*	mockTheRequestParams( "099505", "1483455", "-1", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		mockDBPersonaleWrapper( Boolean.TRUE );
		mockSecurityWrapper( Boolean.FALSE );
		mockPlichiBustasDataAccess( Boolean.TRUE );
		mockHoldingDataAccess( );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );
		final Hashtable bustaNeraHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		assertTrue( bustaNeraHashTable.containsKey( "CdrDesc" ) && "ARCHIVIO / DOCUMENTI".equals( bustaNeraHashTable.get( "CdrDesc" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CassettoOfCdr" ) && "SHB099505".equals( bustaNeraHashTable.get( "CassettoOfCdr" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CassettoOfCdrDesc" ) && "ARCHIVIO / DOCUMENTI MAGLIOLEO".equals( bustaNeraHashTable.get( "CassettoOfCdrDesc" ) ) );*/
		
	}
	
	/*public void testBNCDRVerifica7( )
	{
		mockTheRequestParams( "GBS02096", "1483455", "-1", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		
		mockDBPersonaleWrapper( Boolean.FALSE );
		mockSecurityWrapper( Boolean.TRUE );
		mockSecurityDBPersonaleWrapper( );
		mockPlichiBustasDataAccess( Boolean.TRUE );
		mockHoldingDataAccess( );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );
		final Hashtable bustaNeraHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		assertTrue( bustaNeraHashTable.containsKey( "CdrDesc" ) && "BALAJI RANGANATHAN/ARCHIVIO".equals( bustaNeraHashTable.get( "CdrDesc" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CassettoOfCdr" ) && "SHB099505".equals( bustaNeraHashTable.get( "CassettoOfCdr" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CassettoOfCdrDesc" ) && "ARCHIVIO / DOCUMENTI MAGLIOLEO".equals( bustaNeraHashTable.get( "CassettoOfCdrDesc" ) ) );
		
	}
	
	public void testBNCDRVerifica8( )
	{
		mockTheRequestParams( "", "-1", "3", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		final Hashtable bnHashTable = new Hashtable( );
		bnHashTable.put( "WidelyUsedCdr", getAllWidelyUsedCdrs( "1" ) );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( bnHashTable );
		replay( this.requestEvent );
		replay( this.session );
		
		mockDBPersonaleWrapper( Boolean.TRUE );
		mockPlichiBustasDataAccess( Boolean.TRUE );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "WidelyCdr" ) != null );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );
		final Hashtable bustaNeraHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		
		assertTrue( bustaNeraHashTable.containsKey( "CdrDesc" ) && "ARCHIVIO / DOCUMENTI".equals( bustaNeraHashTable.get( "CdrDesc" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CassettoOfCdr" ) && "SHB099505".equals( bustaNeraHashTable.get( "CassettoOfCdr" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CassettoOfCdrDesc" ) && "ARCHIVIO / DOCUMENTI MAGLIOLEO".equals( bustaNeraHashTable.get( "CassettoOfCdrDesc" ) ) );
	}
	
	public void testBNCDRVerifica9( )
	{
		mockTheRequestParams( "", "-1", "3", null, null, null, null );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		final Hashtable bnHashTable = new Hashtable( );
		bnHashTable.put( "WidelyUsedCdr", getAllWidelyUsedCdrs( "1" ) );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( bnHashTable );
		replay( this.requestEvent );
		replay( this.session );
		
		mockDBPersonaleWrapper( Boolean.TRUE );
		mockPlichiBustasDataAccess( Boolean.FALSE );
		
		final ExecuteResult executeResult = new BustaNeraVerificaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "WidelyCdr" ) != null );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );
		final Hashtable bustaNeraHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1307".equals( executeResult.getAttribute( "MSG" ) ) );
		assertTrue( bustaNeraHashTable.containsKey( "CdrDesc" ) && "ARCHIVIO / DOCUMENTI".equals( bustaNeraHashTable.get( "CdrDesc" ) ) );
		assertFalse( bustaNeraHashTable.containsKey( "CassettoOfCdr" ) );
		assertFalse( bustaNeraHashTable.containsKey( "CassettoOfCdrDesc" ) );
	}*/
	
	private void mockTheRequestParams( final String userOrCDR, final String selectedBankId, final String widelyUsedCDR, final String reqFrom, final String barcode, final String noteForDest, final String mailMe )
	{
		expect( this.requestEvent.getAttribute( "UserOrCdr" ) ).andReturn( userOrCDR ).times( 2 );
		expect( this.requestEvent.getAttribute( "SelectedBankId" ) ).andReturn( selectedBankId ).times( 2 );
		expect( this.requestEvent.getAttribute( "widelyUsedCdr" ) ).andReturn( widelyUsedCDR ).times( 2 );
		expect( this.requestEvent.getAttribute( "requestFrom" ) ).andReturn( reqFrom );
		expect( this.requestEvent.getAttribute( "BarCode" ) ).andReturn( barcode );
		expect( this.requestEvent.getAttribute( "NoteForDest" ) ).andReturn( noteForDest );
		expect( this.requestEvent.getAttribute( "MailMe" ) ).andReturn( mailMe );
	}
	
	private void mockSecurityDBPersonaleWrapper( )
	{
		Mockit.setUpMock( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class );		
	}
	
	private void mockSecurityWrapper( final Boolean isValidUser )
	{
		Mockit.setUpMock( SecurityWrapper.class, SecurityWrapperMock.class);
		
	}
	
	private void mockDBPersonaleWrapper( final Boolean isValidCdrHoldingBank )
	{
		Mockit.setUpMock( DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
	}
	
	private void mockPlichiBustasDataAccess( final Boolean isNeededToCassetto )
	{
		Mockit.setUpMock( TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class );
	}
	
	private void mockHoldingDataAccess( )
	{
		Mockit.setUpMock( TracciabilitaPlichiHoldingDataAccess.class, TracciabilitaPlichiHoldingDataAccessMock.class);
	}
	
	private Collection getAllWidelyUsedCdrs( final String bankIDStr )
	{
		final Collection widelyUsedCdrs = new ArrayList( 10 );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 1L ), Long.valueOf( 1483455L ), "Banca Sella Holding", "099320", "NUOVI SIST. PAG. (ASSEGNI VERSATI SALVO BUON FINE)", Long.valueOf( 1L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 2L ),	Long.valueOf( 1483455L ), "Banca Sella Holding", "099278", "RISPARMIO ASSICURATIVO", Long.valueOf( 2L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 3L ), Long.valueOf( 1483455L ), "Banca Sella Holding", "099505", "ARCHIVIO", Long.valueOf( 3L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 4L ),	Long.valueOf( 1483455L ), "Banca Sella Holding", "099318", "SIST. PAG. TRADIZIONALI (ASSEGNI CIRCOLARI,BOLLETTINI,PAGHE,SCHEDINE,EFFETTI)",	Long.valueOf( 4L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 5L ),	Long.valueOf( 1L ), "Banca Sella S.p.A.", "099006",	"SELLA CONSULT", Long.valueOf( 5L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 6L ),	Long.valueOf( 1L ), "Banca Sella S.p.A.", "350005", "ESTERO MERCI", Long.valueOf( 6L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 7L ),	Long.valueOf( 1L ), "Banca Sella S.p.A.", "099008",	"FIDUCIARIA SELLA", Long.valueOf( 7L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 8L ),	Long.valueOf( 1483455L ), "Banca Sella Holding", "099303", "CONTENZIOSO", Long.valueOf( 8L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 9L ), Long.valueOf( 1483455L ), "Banca Sella Holding", "099326", "TITOLI - FIDEIUSSIONI A CAVEAU", Long.valueOf( 9L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 10L ),Long.valueOf( 1483455L ), "Banca Sella Holding", "099300", "DISPUTE CARTA DI CREDITO", Long.valueOf( 10L ) ) );
		return widelyUsedCdrs;
	}
	
	private FrequentiDestinazioneCdrView getFrequentlyUserCdr( final Long id, final Long bankId, final String bankDesc, final String cdr, final String cdrDesc, final Long position )
	{
		final FrequentiDestinazioneCdrView freqCdrView = new FrequentiDestinazioneCdrView();
		freqCdrView.setId( id );
		freqCdrView.setBankId( bankId );
		freqCdrView.setBankDescription( bankDesc );
		freqCdrView.setCdr( cdr );
		freqCdrView.setDescription( cdrDesc );
		freqCdrView.setPosizione( position );
		return freqCdrView;
	}

}
