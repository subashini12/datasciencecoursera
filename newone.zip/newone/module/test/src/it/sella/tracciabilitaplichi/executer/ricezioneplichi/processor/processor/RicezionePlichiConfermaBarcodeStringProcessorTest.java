package it.sella.tracciabilitaplichi.executer.ricezioneplichi.processor.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.executer.ricezioneplichi.processor.RicezionePlichiConfermaBarcodeStringProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RicezionePlichiConfermaBarcodeStringProcessorTest extends AbstractSellaExecuterMock{

	public RicezionePlichiConfermaBarcodeStringProcessorTest(final String name) {
		super(name);
	}

	RicezionePlichiConfermaBarcodeStringProcessor processor = new RicezionePlichiConfermaBarcodeStringProcessor() ;

	public void testRicezionePlichiConfermaBarcodeStringProcessor_03() throws RemoteException, TracciabilitaException
	{
		TracciabilitaPlichiCommonDataAccessMock.setInValidBarcode();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult();
		processor.processBarcodeString(getRequestEvent(), getPALTRIMap(), "1234567895487", executeResult, (ArrayList) getlist(), getMap(), "");
	}

	public void testRicezionePlichiConfermaBarcodeStringProcessor_04() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult();
		processor.processBarcodeString(getRequestEvent(), getPALTRIMap(), "1234567895487", executeResult, (ArrayList) getlist(), getMap(), "");
	}

	public void testRicezionePlichiConfermaBarcodeStringProcessor_05() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult();
		processor.processBarcodeString(getRequestEvent(), getPBUST10Map(), "1234567895487", executeResult, (ArrayList) getlist(), getMap(), "");
	}

	public void testRicezionePlichiConfermaBarcodeStringProcessor_06() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult();
		processor.processBarcodeString(getRequestEvent(), getPBUST10Map(), "ADDONE", executeResult, (ArrayList) getlist(), getMap(), "");
	}

	private static List getlist()
	{
		final List list = new ArrayList();
		return list ;
	}

	private static Map getPALTRIMap()
	{
		final Map map = new HashMap() ;
		map.put("IsArchivoDept","Yes");
		map.put("IsBarCodeReaderAvailable","");
		map.put("TypesOfOggettos","");
		map.put("PlichiType","PALTRI");
		map.put("SelBarCodeColl","");
		return map ;
	}

	private static Map getPBUST10Map()
	{
		final Map map = new HashMap() ;
		map.put("IsArchivoDept","Yes");
		map.put("IsBarCodeReaderAvailable","");
		map.put("TypesOfOggettos","");
		map.put("PlichiType","PBUST10");
		map.put("SelBarCodeColl","");
		map.put("PageNoRP",1);
		return map ;
	}

	private static Map getMap()
	{
		final Map map = new HashMap() ;
		return map ;
	}


}
