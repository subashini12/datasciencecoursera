package it.sella.tracciabilitaplichi.executer.winbox2.preparazione;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.persistence.dto.WinBox2;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mockit.Mock;

public class HelperMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	@Mock
	public static void setFolderArchiveFlowInSession(
			final RequestEvent requestEvent, final Map<Enum, Object> sessionMap) {
		return;
	}
	@Mock
	public static Map<Enum, Object> getSessionMap( final StateMachineSession session ) throws TracciabilitaException, RemoteException
	{
		final List<Folder> folderColl = new ArrayList<Folder>() ;
		final Folder folder = new Folder() ;
		folderColl.add(folder);
		final Map<Enum,Object> map = new HashMap<Enum,Object>();
		map.put( CONSTANTS.FOLDER_INDEX ,"1");
		map.put(CONSTANTS.LOCALAZZITO_PRATICA, folderColl);
		map.put( CONSTANTS.FOLDER_FLOW , "11");
		map.put( CONSTANTS.WINBOX2 , new WinBox2());
		return map;
	}
}
