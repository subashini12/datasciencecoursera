package it.sella.tracciabilitaplichi.executer.gestoreinvioplichi;

import static org.easymock.EasyMock.expect;
import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Stack;

import org.easymock.EasyMock;



public class ShowPlichiExecuterTest extends AbstractSellaExecuterMock{

	public ShowPlichiExecuterTest(final String name) {
		super(name);
	}

	ShowPlichiExecuter executer = new ShowPlichiExecuter();
	
	public void testShowPlichiExecuter_01() {
		expecting( getStateMachineSession().containsKey( "BarCodeStack" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("2");
		expect( getStateMachineSession().put( CONSTANTS.BARCODE_STACK.getValue( ), new Stack( ) ) ).andReturn( new Stack( ) );
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testShowPlichiExecuter_02() {
		final Stack stack=getStack();
		expecting( getStateMachineSession().containsKey( "BarCodeStack" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("2");
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	private static Stack getStack() {
		final Stack stack=new Stack();
		stack.push("1");
		return stack;
	}
	
}
