package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.RicezionePlichiArchivioIndietroExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

public class RicezionePlichiArchivioIndietroExecuterTest extends AbstractSellaExecuterMock
{

	RicezionePlichiArchivioIndietroExecuter executer = new RicezionePlichiArchivioIndietroExecuter();
	
	public RicezionePlichiArchivioIndietroExecuterTest(String name) 
	{
		super(name);		
	}
	
	public void testExecuter_01()
	{
		expecting( getStateMachineSession().get( "GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION" )).andReturn( ( Serializable ) getRicezionePlichiArchivioSession()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_02()
	{
		Hashtable views = (Hashtable) getRicezionePlichiArchivioSession();	
		
		if( views.containsKey( CONSTANTS.LastBoxCode.toString( ) ) )
		{
			views.remove( CONSTANTS.LastBoxCode.toString( ));
		}
		expecting( getStateMachineSession().get( "GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION" )).andReturn( ( Serializable ) views  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	private Map getRicezionePlichiArchivioSession( )
	{
		Map views = new Hashtable();	
	    views.put( CONSTANTS.PlichiToBeReceived.toString( ), "ab");
		views.put( CONSTANTS.PlichiReceived.toString( ), "ab");
		views.put( CONSTANTS.OggettoType.toString( ), "ab");
		views.put( CONSTANTS.IsBarCodeReaderAvailable.toString( ), "ab");
		views.put( CONSTANTS.BarCodeStr.toString( ), "ab");
		views.put( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ), "ab");
		views.put( CONSTANTS.TypesOfOggettos.toString( ), "ab");
		views.put( CONSTANTS.LastBoxCode.toString( ), 2L);
		views.put( CONSTANTS.CASSETTO_BOX_ID.getValue( ), 1L);	
		return views ;		
	}
}
