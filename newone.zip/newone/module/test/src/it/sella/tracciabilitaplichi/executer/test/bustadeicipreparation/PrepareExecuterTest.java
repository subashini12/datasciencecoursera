package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.PrepareExecuter;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.PrepareBusta10Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation.processor.PrepareBusta10ProcessorMock;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;

public class PrepareExecuterTest extends AbstractSellaExecuterMock
{

	public PrepareExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	PrepareExecuter executer = new PrepareExecuter();
	public void  testPrepareExecuter_01( )
	{
		expecting( getStateMachineSession().get( "Busta10PreparationPageView" )).andReturn( getBusta10PreparationPageView()   ).anyTimes();
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("1231231231").anyTimes();
		setUpMockMethods( PrepareBusta10Processor.class, PrepareBusta10ProcessorMock.class);
		playAll();
		executer.execute( getRequestEvent() );
	}
	
	public void  testPrepareExecuter_02( )
	{
		PrepareBusta10ProcessorMock.setTracciabilitaException();
		expecting( getStateMachineSession().get( "Busta10PreparationPageView" )).andReturn( getBusta10PreparationPageView()   ).anyTimes();
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("1231231231").anyTimes();
		setUpMockMethods( PrepareBusta10Processor.class, PrepareBusta10ProcessorMock.class);
		playAll();
		executer.execute( getRequestEvent() );
	}

	public void  testPrepareExecuter_03( )
	{
		PrepareBusta10ProcessorMock.setRemoteException();
		expecting( getStateMachineSession().get( "Busta10PreparationPageView" )).andReturn( getBusta10PreparationPageView()   ).anyTimes();
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("1231231231").anyTimes();
		setUpMockMethods( PrepareBusta10Processor.class, PrepareBusta10ProcessorMock.class);
		playAll();
		executer.execute( getRequestEvent() );
	}
	private Busta10PreparationPageView getBusta10PreparationPageView()
	{
		Busta10PreparationPageView busta10PreparationPageView = new Busta10PreparationPageView();
		busta10PreparationPageView.setBarCode("1231241241");
		return busta10PreparationPageView;
	}
   
}
