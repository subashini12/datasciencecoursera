package it.sella.tracciabilitaplichi.executer.test.contractchooser;

import it.sella.tracciabilitaplichi.contractchooser.helper.ContractChooserHelper;
import it.sella.tracciabilitaplichi.executer.contractchooser.PlichiContentsPushExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.contractchooser.helper.ContractChooserHelperMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class PlichiContentsPushExecuterTest extends AbstractSellaExecuterMock
{

	public PlichiContentsPushExecuterTest(final String name) 
	{
		super(name);		
	}
	
	PlichiContentsPushExecuter executer = new PlichiContentsPushExecuter();
	

	public void testPlichiContentsPushExecuter()
	{
		setUpMockMethods(ContractChooserHelper.class, ContractChooserHelperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "PlichiBusta10Map" )).andReturn((Serializable) getMap() ).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bustaIdFor1")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	private Map getMap()
	{
		final Map map = new HashMap();
		map.put("1", "");
		return map ;
	}
}
