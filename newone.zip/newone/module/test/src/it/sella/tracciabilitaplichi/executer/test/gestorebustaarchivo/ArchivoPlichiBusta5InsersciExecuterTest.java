package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoPlichiBusta5InsersciExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Hashtable;

public class ArchivoPlichiBusta5InsersciExecuterTest  extends AbstractSellaExecuterMock {

    ArchivoPlichiBusta5InsersciExecuter  archivoPlichiBusta5InsersciExecuter = new  ArchivoPlichiBusta5InsersciExecuter();

   public  ArchivoPlichiBusta5InsersciExecuterTest(final String name) {
       super(name);
   }

   public void testArchivoPlichiBusta5InsersciExecuter_01() {
 
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "") ; 
       playAll();
       final ExecuteResult executeResult =  archivoPlichiBusta5InsersciExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrFail"));
       assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1110" );
        
   }
   /*public void testArchivoPlichiBusta5InsersciExecuter_02() {
       
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ;
       redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
    	   @Mock
           public boolean isExistPlichi( String barCode ) throws TracciabilitaException{
                   return true;
               }
           });
       playAll();
       ExecuteResult executeResult =  archivoPlichiBusta5InsersciExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrFail"));
       assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1024" );
        
   }
   
   public void testArchivoPlichiBusta5InsersciExecuter_03() {
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ;
       redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
    	   @Mock
           public boolean isExistPlichi( String barCode ) throws TracciabilitaException{
                   return false;
               }
           });
       playAll();
       ExecuteResult executeResult =  archivoPlichiBusta5InsersciExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrConferma"));       
   }
   
   public void testArchivoPlichiBusta5InsersciExecuter_04() {
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ;
       redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
    	   @Mock
           public boolean isExistPlichi( String barCode ) throws TracciabilitaException{
                   throw new TracciabilitaException();
               }
           });
       playAll();
       ExecuteResult executeResult =  archivoPlichiBusta5InsersciExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getException( ).toString( ), ("it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException"));
   }
   
   public void testArchivoPlichiBusta5InsersciExecuter_05() {
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ;
       redefineMethod(TracciabilitaPlichiFactory.class, new Object(){
    	   @Mock
           public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException{
               throw new RemoteException();
           }
       });
       playAll();
       ExecuteResult executeResult =  archivoPlichiBusta5InsersciExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getException( ).toString( ), ("java.rmi.RemoteException"));
   }*/
}
