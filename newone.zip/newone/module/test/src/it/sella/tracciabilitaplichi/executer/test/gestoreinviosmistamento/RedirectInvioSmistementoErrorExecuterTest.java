package it.sella.tracciabilitaplichi.executer.test.gestoreinviosmistamento;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento.RedirectInvioSmistementoErrorExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

public class RedirectInvioSmistementoErrorExecuterTest extends AbstractSellaExecuterMock
{

	RedirectInvioSmistementoErrorExecuter executer = new RedirectInvioSmistementoErrorExecuter();
	
	public RedirectInvioSmistementoErrorExecuterTest(String name) 
	{
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	public void testExecuter()
	{
		expecting( getStateMachineSession().get( "GESTORE_INVIO_SMISTAMENTO_SESSION" )).andReturn( (Serializable) getMap()  ).anyTimes();
		playAll();
		executer.execute( getRequestEvent());
	}

	private Map getMap()
	{
		Map map = new Hashtable();		
		map.put("ValidBarCodeButNotInRequiredState","a");
		map.put("StateOfPlichi","b");
		map.put("PBarcode","c");
		map.put("ERRMSG","d");
		return map;
	}

}
