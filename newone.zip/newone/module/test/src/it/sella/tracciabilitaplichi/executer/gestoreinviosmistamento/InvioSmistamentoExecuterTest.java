package it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento;


import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
//import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.io.Serializable;
import java.util.Hashtable;

import org.easymock.classextension.EasyMock;

public class InvioSmistamentoExecuterTest extends AbstractSellaExecuterMock{

	public InvioSmistamentoExecuterTest(final String name) {
		super(name);
	}
	
	InvioSmistamentoExecuter executer=new InvioSmistamentoExecuter();
	
	public void testInvioSmistamentoExecuter_01() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		//setUpMockMethods(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		final Hashtable altriAttributeHashtable = new Hashtable();
		altriAttributeHashtable.put( "SmistamentoCollection", "" );
		altriAttributeHashtable.put( "UserName", "" );
		altriAttributeHashtable.put( "CurrDate", "" );
		expecting(getStateMachineSession().containsKey("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn(altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoExecuter_02() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	//	setUpMockMethods(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		final Hashtable altriAttributeHashtable = new Hashtable();
		altriAttributeHashtable.put( "SmistamentoCollection", "" );
		altriAttributeHashtable.put( "UserName", "" );
		altriAttributeHashtable.put( "CurrDate", "" );
		expecting(getStateMachineSession().containsKey("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoExecuter_tracciabilitaException() {
		SecurityWrapperMock.setTracciabilitaException();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		//setUpMockMethods(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		final Hashtable altriAttributeHashtable = new Hashtable();
		altriAttributeHashtable.put( "SmistamentoCollection", "" );
		altriAttributeHashtable.put( "UserName", "" );
		altriAttributeHashtable.put( "CurrDate", "" );
		expecting(getStateMachineSession().containsKey("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public void testInvioSmistamentoExecuter_remoteException() {
		SecurityDBpersonaleWrapperMock.setRemoteException();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	//	setUpMockMethods(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		final Hashtable altriAttributeHashtable = new Hashtable();
		altriAttributeHashtable.put( "SmistamentoCollection", "" );
		altriAttributeHashtable.put( "UserName", "" );
		altriAttributeHashtable.put( "CurrDate", "" );
		expecting(getStateMachineSession().containsKey("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

}
