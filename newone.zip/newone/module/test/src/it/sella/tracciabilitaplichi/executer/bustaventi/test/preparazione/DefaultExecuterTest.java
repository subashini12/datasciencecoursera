package it.sella.tracciabilitaplichi.executer.bustaventi.test.preparazione;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.bustaventi.preparazione.DefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor.HomePageProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.BustaVentiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.BustaVentiDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.classextension.EasyMock;

public class DefaultExecuterTest extends AbstractSellaExecuterMock
{
	
    public DefaultExecuterTest( final String name ) {
        super( name );
    }

    DefaultExecuter defaultExecuter = new DefaultExecuter() ;
    
    public void testDefaultExecuter_01( ) {
    	setUpMockMethods(TPUtil.class,TPUtilMock.class);
    	setUpMockMethods(BustaVentiDataAccess.class, BustaVentiDataAccessMock.class);
    	setUpMockMethods(Util.class,UtilMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.SUCCESS)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.MESSAGE)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	playAll();
    	final ExecuteResult executeResult = defaultExecuter.execute(getRequestEvent());
    	assertEquals(executeResult.getTransition(),null);
    }
    
    public void testDefaultExecuter_02( ) {
    	setUpMockMethods(TPUtil.class,TPUtilMock.class);
    	setUpMockMethods(BustaVentiDataAccess.class, BustaVentiDataAccessMock.class);
    	setUpMockMethods(Util.class,UtilMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn(Boolean.FALSE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.SUCCESS)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.MESSAGE)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
    	playAll();
    	final ExecuteResult executeResult = defaultExecuter.execute(getRequestEvent());
    	assertEquals(executeResult.getTransition(),null);
    }
    
    public void testDefaultExecuter_03( ) {
    	SecurityDBpersonaleWrapperMock.setTracciabilitaException();
    	setUpMockMethods(TPUtil.class,TPUtilMock.class);
    	setUpMockMethods(BustaVentiDataAccess.class, BustaVentiDataAccessMock.class);
    	setUpMockMethods(Util.class,UtilMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn(Boolean.FALSE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.SUCCESS)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.MESSAGE)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
    	playAll();
    	final ExecuteResult executeResult = defaultExecuter.execute(getRequestEvent());
    	assertEquals(executeResult.getTransition(),null);
    }
    
    public void testDefaultExecuter_04( ) {
    	SecurityDBpersonaleWrapperMock.setRemoteException();
    	setUpMockMethods(TPUtil.class,TPUtilMock.class);
    	setUpMockMethods(BustaVentiDataAccess.class, BustaVentiDataAccessMock.class);
    	setUpMockMethods(Util.class,UtilMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn(Boolean.FALSE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.SUCCESS)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().containsKey(ITPConstants.MESSAGE)).andReturn(Boolean.TRUE).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().get(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getMap()).anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.SUCCESS)).andReturn("").anyTimes();
    	expecting(getStateMachineSession().remove(ITPConstants.MESSAGE)).andReturn("").anyTimes();
    	expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
    	playAll();
        final ExecuteResult executeResult = defaultExecuter.execute(getRequestEvent());
        assertEquals(executeResult.getTransition(),null);
    }

    public Map getMap() {
    	final Map map = new HashMap();
    	return map ;
    }
}
