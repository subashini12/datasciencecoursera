package it.sella.tracciabilitaplichi.executer.test.gestorebustacinqueattributesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustacinqueattributesadmin.BustaCinqueAttributeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;

import java.io.Serializable;

import org.easymock.EasyMock;

public class BustaCinqueAttributeConfermaExecuterTest  extends AbstractSellaExecuterMock {

    BustaCinqueAttributeConfermaExecuter bustaCinqueAttributeConfermaExecuter = new BustaCinqueAttributeConfermaExecuter();

    public BustaCinqueAttributeConfermaExecuterTest(final String name) {
        super(name);
    }

     public void testBustaCinqueAttributeConfermaExecuter_01() {

        expecting( getRequestEvent( ).getAttribute( "ID" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "documentId" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "isBankAdmin" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "Note" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getEventName( )).andReturn("Conferma").anyTimes();
        expecting( getStateMachineSession( ).get( "BustaCinqueAttributeViews" )).andReturn("").anyTimes();
        playAll(); 
        final ExecuteResult executeResult = bustaCinqueAttributeConfermaExecuter
                .execute(getRequestEvent());
      assertEquals(executeResult.getAttribute("MSG"), "TRPL-1081");
      assertEquals(executeResult.getTransition( ), "TrFail");
    } 
    
    public void testBustaCinqueAttributeConfermaExecuter_02() {
        expecting( getRequestEvent( ).getEventName( )).andReturn("NonConferma").anyTimes();
        playAll();        
        final ExecuteResult executeResult = bustaCinqueAttributeConfermaExecuter
                .execute(getRequestEvent());
      assertEquals(executeResult, null);
    } 
    
    public void testBustaCinqueAttributeConfermaExecuter_03() {

		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getRequestEvent( ).getAttribute( "ID" )).andReturn("12").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "documentId" )).andReturn("343").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "isBankAdmin" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "Note" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getEventName( )).andReturn("Conferma").anyTimes();
        expecting( getStateMachineSession( ).get( "BustaCinqueAttributeViews" )).andReturn("").anyTimes();
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Serializable) EasyMock.anyObject())).andReturn(null);
        playAll();
        final ExecuteResult executeResult = bustaCinqueAttributeConfermaExecuter
                .execute(getRequestEvent());
        assertEquals(executeResult.getAttribute("ISEDITABLE"), "NO");
        assertEquals(executeResult.getTransition( ), "TrConferma");
    } 
    
    public void testBustaCinqueAttributeConfermaExecuter_04() {

    	TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getRequestEvent( ).getAttribute( "ID" )).andReturn("12").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "documentId" )).andReturn("343").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "isBankAdmin" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "Note" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getEventName( )).andReturn("Conferma").anyTimes();
        expecting( getStateMachineSession( ).get( "BustaCinqueAttributeViews" )).andReturn("").anyTimes();
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Serializable) EasyMock.anyObject())).andReturn(null);
        playAll();
        final ExecuteResult executeResult = bustaCinqueAttributeConfermaExecuter
                .execute(getRequestEvent());
        assertEquals(executeResult.getAttribute("MSG"), "TRPL-1062");
        assertEquals(executeResult.getTransition( ), "TrFail");
        
      } 
 
 
    
    
    public void testBustaCinqueAttributeConfermaExecuter_05() {

    	TracciabilitaPlichiAdminTransactionDataAccessMock.setTracciabilitaException();
    	setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getRequestEvent( ).getAttribute( "ID" )).andReturn("12").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "documentId" )).andReturn("343").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "isBankAdmin" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getAttribute( "Note" )).andReturn("").anyTimes();
        expecting( getRequestEvent( ).getEventName( )).andReturn("Conferma").anyTimes();
        expecting( getStateMachineSession( ).get( "BustaCinqueAttributeViews" )).andReturn("").anyTimes();
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Serializable) EasyMock.anyObject())).andReturn(null);
        playAll();
        final ExecuteResult executeResult = bustaCinqueAttributeConfermaExecuter
                .execute(getRequestEvent());
        assertEquals(executeResult.getException( ).toString( ), "it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException");
    }      
}
