package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import mockit.Mock;

public class PlichiAttributeAdminImplMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	@Mock
	public void modificaOggetto(final TPView adminView)
			throws TracciabilitaException {

		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		return;
	}
}
