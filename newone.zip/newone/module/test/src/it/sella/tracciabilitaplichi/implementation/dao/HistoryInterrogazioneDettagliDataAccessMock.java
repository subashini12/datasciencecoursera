package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.RicercaView;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Vector;

import mockit.Mock;

public class HistoryInterrogazioneDettagliDataAccessMock {
	
	private static Boolean isRicercaViewCollNull = false; 
	private static Boolean remoteException = false;
	
	public static void setRicercaViewCollNull(){
		isRicercaViewCollNull = true;
	}
	
	public static void setRemoteException() {
		remoteException = true;
	}

	@Mock
	public Collection getRicercaView( final java.sql.Date datacomp, final String searchKey, final String searchType ) throws TracciabilitaException, RemoteException {
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		Vector ricercaViewColl = new Vector();
		final RicercaView ricercaView1 = new RicercaView();
		ricercaView1.setId( 1L );
		final Calendar calendar = Calendar.getInstance();
		final java.util.Date now = calendar.getTime();
		final java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());
		ricercaView1.setActualDate( currentTimestamp);		
		ricercaView1.setUserId( "gbs03094" );		
		ricercaView1.setCdr( "099231" );
		ricercaView1.setCdrDesc( "BaseSystems" );
		ricercaView1.setStatusDesc( "invio");
		ricercaView1.setBarCode( "132456789097" );		
		ricercaView1.setLid( "AZ01" );
		ricercaView1.setBarCodePlico( "987654321");		
		ricercaView1.setBoxNumber( 2L );		
		final RicercaView ricercaView2  = new RicercaView();
		ricercaView2.setId( 2L );		
		ricercaView2.setActualDate( currentTimestamp );		
		ricercaView2.setUserId( "gbs03095" );		
		ricercaView2.setCdr( "099232" );
		ricercaView2.setCdrDesc( "DASystems" );
		ricercaView2.setStatusDesc( "invio");
		ricercaView2.setBarCode( "13245672347" );		
		ricercaView2.setLid( "AZ02" );
		ricercaView2.setBarCodePlico( "987651231");		
		ricercaView2.setBoxNumber( 5L );
		ricercaViewColl.add(ricercaView1);
		ricercaViewColl.add(ricercaView2);	
		if(isRicercaViewCollNull){
			isRicercaViewCollNull = false;
			ricercaViewColl = null;
		}
		return ricercaViewColl;
     }

}
