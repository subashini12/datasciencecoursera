/*package it.sella.tracciabilitaplichi.executer.winbox2.test;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.Validator;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.easymock.MockControl;


public class ValidatorTest extends TestCase
{
    private RequestEvent        requestEvent        = null;
    private MockControl         requestEventControl = null;
   
    public ValidatorTest( final String name )
    {
        super( name );
    }

    @Override
	protected void setUp( ) throws Exception
    {
        super.setUp( );

        this.requestEventControl = MockControl.createControl( RequestEvent.class );
        this.requestEvent = ( RequestEvent ) this.requestEventControl.getMock( );
    }
    @Override
	protected void tearDown( )
    {
    }
    public void testValidate1( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1570, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate2( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.IMPORTO, "#" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate3( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.IMPORTO, "1" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( false, ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getImporto( ) == null );
    }
    public void testValidate4( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.IMPORTO_CENTS, "1" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( false, ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getImporto( ) == null );
    }
    public void testValidate5( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.NAME, "MANI" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate6( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.SUR_NAME, "MANI" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate7( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.NAME, "ANBU" );
         inputMap.put( CONSTANTS.SUR_NAME, "SHANMUGAM" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( "ANBU", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getNome( ) );
         assertEquals( "SHANMUGAM", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getCogNome( ) );
    }
    public void testValidate8( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.OTTOCIFRE, "123" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         Mockit.redefineMethods( AnagraficiWrapper.class, new Object( ) {
        	 public Long getSoggettoId(final String ottoCifre ) throws RemoteException
        	 {
        		 return null;
        	 }
         } );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1561, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate9( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.MESE, "1" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( resultMap.get( CONSTANTS.ERROR_MESSAGE ), IErrorCodes.TRPL_1572 );
    }
    public void testValidate10( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.ANNO, "2000" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate11( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.MESE, "13" );
         inputMap.put( CONSTANTS.ANNO, "2000" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate12( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.MESE, "12" );
         inputMap.put( CONSTANTS.ANNO, "1899" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate13( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.MESE, "21" );
         inputMap.put( CONSTANTS.ANNO, "3000" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate14( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.MESE, "12" );
         inputMap.put( CONSTANTS.ANNO, "2999" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( "12/2999", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getMeseAnno( ) );
    }
    public void testValidate15( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.TIPO_PRATICA, "" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, false, true );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1572, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate16( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.TIPO_PRATICA, "" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
    }
    public void testValidate17( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.NAME, "CHITRA" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( "CHITRA", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getNome( ) );
    }
    public void testValidate18( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.SUR_NAME, "SHANKAR" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( "SHANKAR", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getCogNome( ) );
    }
    public void testValidate19( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.TIPO_CONTO, "1" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         Mockit.redefineMethods( Validator.class, new Object( ) { 
        	 public Boolean isValidNumeroConto( final Map<Enum, String> inputMap ) throws RemoteException
        	 {
        		 return Boolean.FALSE;
        	 }
         } );
         
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1396, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate20( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.BRANCH_CODE, "2" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         Mockit.redefineMethods( Validator.class, new Object( ) { 
        	 public Boolean isValidNumeroConto( final Map<Enum, String> inputMap ) throws RemoteException
        	 {
        		 return Boolean.FALSE;
        	 }
         } );

         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1396, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate21( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.MILLESIMO, "3" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         Mockit.redefineMethods( Validator.class, new Object( ) { 
        	 public Boolean isValidNumeroConto( final Map<Enum, String> inputMap ) throws RemoteException
        	 {
        		 return Boolean.FALSE;
        	 }
         } );

         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1396, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate22( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.BRANCH_CODE, "1" );
         inputMap.put( CONSTANTS.TIPO_CONTO, "2" );
         inputMap.put( CONSTANTS.MILLESIMO, "3" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         Mockit.redefineMethods( Validator.class, new Object( ) { 
        	 public Boolean isValidNumeroConto( final Map<Enum, String> inputMap ) throws RemoteException
        	 {
        		 return Boolean.FALSE;
        	 }
         } );

         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( true, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( false, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( IErrorCodes.TRPL_1396, resultMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
    public void testValidate23( ) throws TracciabilitaException, RemoteException
    {
         final Map<CONSTANTS,String> inputMap = getInputMap( );
         inputMap.put( CONSTANTS.TIPO_PRATICA, "1" );
         inputMap.put( CONSTANTS.MESE, "12" );
         inputMap.put( CONSTANTS.ANNO, "2999" );
         inputMap.put( CONSTANTS.BRANCH_CODE, "" );
         inputMap.put( CONSTANTS.TIPO_CONTO, "" );
         inputMap.put( CONSTANTS.OTTOCIFRE, "" );
         inputMap.put( CONSTANTS.MILLESIMO, "" );
         inputMap.put( CONSTANTS.IMPORTO, "20" );
         inputMap.put( CONSTANTS.IMPORTO_CENTS, "20" );
         inputMap.put( CONSTANTS.NOTE, "TEST" );
         inputMap.put( CONSTANTS.NAME, "NARESH" );
         inputMap.put( CONSTANTS.SUR_NAME, "KUMAR" );
         inputMap.put( CONSTANTS.PROTOCOL, "&&" );
         inputMap.put( CONSTANTS.SOCIETA_GBS, "1" );
         inputMap.put( CONSTANTS.ALTRA_SOCIETA, "NEW SELLA COMPANY" );
         for ( final CONSTANTS key : inputMap.keySet( ) )
         {
             this.requestEvent.getAttribute( key.getValue( ) );
             this.requestEventControl.setReturnValue( inputMap.get( key ) );
         }
         this.requestEventControl.replay( );
         final Map<Enum, Object> resultMap = Validator.validate( this.requestEvent, true, false );
         assertEquals( false, resultMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
         assertEquals( true, resultMap.containsKey( CONSTANTS.FOLDER_ATTRIBUTES ) );
         assertEquals( Long.valueOf( "1" ), ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getTipoPratica( ) );
         assertEquals( "12/2999", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getMeseAnno( ) );
         assertEquals( null, ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getCifre( ) );
         assertEquals( new BigDecimal( "20.20" ), ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getImporto( ) );
         assertEquals( "TEST", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getNote( ) );
         assertEquals( "NARESH", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getNome( ) );
         assertEquals( "&&", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getProtocollo( ) );
         assertEquals( Long.valueOf( 1 ), ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getSocietaGBS( ) );
         assertEquals( "NEW SELLA COMPANY", ( ( FolderAttributes ) resultMap.get( CONSTANTS.FOLDER_ATTRIBUTES ) ).getSocieta( ) );
    }
    
    private Map<CONSTANTS,String> getInputMap( )
    {
       final Map<CONSTANTS,String> inputMap = new HashMap<CONSTANTS,String>( 1 );
       inputMap.put( CONSTANTS.BARCODE, "" );
       inputMap.put( CONSTANTS.TIPO_PRATICA, "1" );
       inputMap.put( CONSTANTS.MESE, "" );
       inputMap.put( CONSTANTS.ANNO, "" );
       inputMap.put( CONSTANTS.BRANCH_CODE, "" );
       inputMap.put( CONSTANTS.TIPO_CONTO, "" );
       inputMap.put( CONSTANTS.OTTOCIFRE, "" );
       inputMap.put( CONSTANTS.MILLESIMO, "" );
       inputMap.put( CONSTANTS.IMPORTO, "" );
       inputMap.put( CONSTANTS.IMPORTO_CENTS, "" );
       inputMap.put( CONSTANTS.NOTE, "" );
       inputMap.put( CONSTANTS.NAME, "" );
       inputMap.put( CONSTANTS.SUR_NAME, "" );
       inputMap.put( CONSTANTS.PROTOCOL, "" );
       inputMap.put( CONSTANTS.SOCIETA_GBS, "-1" );
       inputMap.put( CONSTANTS.ALTRA_SOCIETA, "" );
       inputMap.put( CONSTANTS.FOLDER_FLOW, "0" );
       inputMap.put( CONSTANTS.CODICE_FISCALE, "" );
       return inputMap;
    }
}
*/