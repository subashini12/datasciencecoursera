package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlichiContentsDefaultWinbox2ProcessorTest extends
		AbstractSellaExecuterMock {

	public PlichiContentsDefaultWinbox2ProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiContentsDefaultWinbox2Processor processor = new PlichiContentsDefaultWinbox2Processor();

	public void testPlichiContentsDefaultWinbox2Processor_01() {
		try {
			processor.removeArchivioStatus(getList(), 1L);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	/*public void testPlichiContentsDefaultWinbox2Processor_02() {
		setUpMockMethods(AbstractDAOFactory.class, AbstractDAOFactoryMock.class);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		setUpMockMethods(PlichiContentsDefaultProcessor.class, PlichiContentsDefaultProcessorMock.class);
		try {
			processor.processWinbox2Records(getRequestEvent(), "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	*/
	private  Map getMap()
	{
		final Map map = new HashMap() ;
		map.put("TracciabilitaPlichiView", getTracciabilitaPlichiView());
		return map ;
	}
	
	private TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView();
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		return tracciabilitaPlichiView;
		
	}
	
	private OggettoView getOggettoView() {
		final OggettoView oggettoView = new OggettoView();
		oggettoView.setId(1L);
		return oggettoView;
	}

	private List getList() {
		final List list = new ArrayList();
		list.add("1");
		list.add("1");
		return list;
	}
}
