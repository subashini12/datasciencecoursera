package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.AbstractExecuter;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.ChangeFolderArchiveFlowAction;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.ChangeFolderTypeAction;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.HashMap;
import java.util.Map;

public class ChangeFolderTypeActionTest extends AbstractSellaExecuterMock {
        
	    ChangeFolderTypeAction changeFolderTypeAction = new ChangeFolderTypeAction() ;
	    
        public ChangeFolderTypeActionTest( final String message )
        {
            super( message );
        }
        
        public void testGetLogger( )
        {
            final Log4Debug expected = Log4DebugFactory.getLog4Debug( ChangeFolderArchiveFlowAction.class );
            final AbstractExecuter abstractExecuter = new ChangeFolderTypeAction( );
            assertEquals( expected.getClass( ), abstractExecuter.getLogger( ).getClass( ) );
        }
        
        public void testGetLoggerMap( )
        {
            final AbstractExecuter abstractExecuter = new ChangeFolderTypeAction( );
            final Map<CONSTANTS,String> actual = abstractExecuter.getLoggerMap( new HashMap<Enum, Object>( 1 ) );
            assertEquals( null, actual );
        }
        
    }
