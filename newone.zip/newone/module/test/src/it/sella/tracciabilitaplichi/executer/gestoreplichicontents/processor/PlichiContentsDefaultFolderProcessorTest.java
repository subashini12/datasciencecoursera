package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsDefaultProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;



public class PlichiContentsDefaultFolderProcessorTest extends AbstractSellaExecuterMock{

	
	public PlichiContentsDefaultFolderProcessorTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	PlichiContentsDefaultFolderProcessor processor=new PlichiContentsDefaultFolderProcessor();
	
	public void testRemoveNotAllowedStatuses_01()
	{
		List statusList=getStatusList();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		TracciabilitaPlichiView tracciabilitaPlichiView=getTracciabilitaPlichiView();
		try {
			PlichiContentsDefaultFolderProcessor.removeNotAllowedStatuses(statusList, tracciabilitaPlichiView);
		} catch (RemoteException e) {
			e.getMessage();
		} catch (TracciabilitaException e) {
			e.getMessage();
		}
	}
	
	public void testRemoveNotAllowedStatuses_02()
	{
		TracciabilitaPlichiStatusDataAccessMock.setStatusViewNotEqual();
		List statusList=getStatusList();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		TracciabilitaPlichiView tracciabilitaPlichiView=getTracciabilitaPlichiView();
		try {
			PlichiContentsDefaultFolderProcessor.removeNotAllowedStatuses(statusList, tracciabilitaPlichiView);
		} catch (RemoteException e) {
			e.getMessage();
		} catch (TracciabilitaException e) {
			e.getMessage();
		}
	}
	
	public void testRemoveNotAllowedStatuses_03()
	{
		setUpMockMethods(PlichiContentsDefaultProcessor.class, PlichiContentsDefaultProcessorMock.class);
		try {
			processor.processFolderRecord(getRequestEvent(), "12321379856587");
		} catch (RemoteException e) {
			e.getMessage();
		} catch (TracciabilitaException e) {
			e.getMessage();
		}
	}
	private static TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		OggettoView oggettoView=new OggettoView();
		oggettoView.setStatusId(Long.valueOf(1));
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		return tracciabilitaPlichiView;
	}
	private static List getStatusList()
	{
		List statusList=new ArrayList();
		statusList.add("1");
		statusList.add("A");
		statusList.add("2");
		statusList.add("B");
		return statusList;
	}
}
