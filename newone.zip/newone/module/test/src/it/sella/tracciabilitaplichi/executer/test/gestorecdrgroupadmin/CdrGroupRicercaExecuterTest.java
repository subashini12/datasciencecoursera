package it.sella.tracciabilitaplichi.executer.test.gestorecdrgroupadmin;

import it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin.CdrGroupRicercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

import org.easymock.EasyMock;

public class CdrGroupRicercaExecuterTest extends AbstractSellaExecuterMock
{

	public CdrGroupRicercaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	CdrGroupRicercaExecuter executer = new CdrGroupRicercaExecuter();
	
	public void testCdrGroupRicercaExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupRicercaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn("Ricerci").anyTimes();
		expecting( getStateMachineSession().get("Cdr" )).andReturn("IT").anyTimes();
		expecting( getStateMachineSession().get("Group" )).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupRicercaExecuter_03()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupRicercaExecuter_04()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setGrouplistNotNull();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupRicercaExecuter_forTracciabilitaException()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting( getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}

}
