package it.sella.tracciabilitaplichi.executer.gestorealtriplichi.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriplichi.AltriPlichiEliminaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


public class AltriPlichiEliminaExecuterTest extends AbstractSellaExecuterMock {

	public AltriPlichiEliminaExecuterTest(final String name) {
		super(name);
	}

	AltriPlichiEliminaExecuter executer=new AltriPlichiEliminaExecuter();
	
	public void testAltriPlichiEliminaExecuter_01() {
		final AltriView altriView=new AltriView();
		altriView.setId(1L);
		final Collection collection = new ArrayList() ;
		collection.add(altriView);
		final Map altriPlichiHashtable = new HashMap();
		altriPlichiHashtable.put("AltriMainCollection",collection );
		expecting(getRequestEvent().getAttribute("checkbox")).andReturn("");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting( getStateMachineSession().get("AltriPlichiHashTable")).andReturn((Serializable) altriPlichiHashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}

	public void testAltriPlichiEliminaExecuter_02() {
		final AltriView altriView=new AltriView();
		altriView.setId(1L);
		final Collection collection = new ArrayList() ;
		collection.add(altriView);
		final Map altriPlichiHashtable = new HashMap();
		altriPlichiHashtable.put("AltriMainCollection",collection );
		expecting(getRequestEvent().getAttribute("checkbox")).andReturn(null);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting( getStateMachineSession().get("AltriPlichiHashTable")).andReturn((Serializable) altriPlichiHashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testAltriPlichiEliminaExecuter_03() {
		final AltriView altriView=new AltriView();
		altriView.setId(1L);
		final Collection collection = new ArrayList() ;
		collection.add(altriView);
		final Map altriPlichiHashtable = new HashMap();
		final String stringArray[]=new String[1]; 
		stringArray[0]="";
		altriPlichiHashtable.put("AltriMainCollection",collection );
		expecting(getRequestEvent().getAttribute("checkbox")).andReturn(stringArray);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting( getStateMachineSession().get("AltriPlichiHashTable")).andReturn((Serializable) altriPlichiHashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
}
