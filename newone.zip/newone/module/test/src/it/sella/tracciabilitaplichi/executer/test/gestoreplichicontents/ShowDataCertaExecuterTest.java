package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.ShowDataCertaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ImageStorageSystemWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ImageStorageSystemWrapperMock;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

public class ShowDataCertaExecuterTest extends  AbstractSellaExecuterMock 
{

	public ShowDataCertaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	ShowDataCertaExecuter executer = new ShowDataCertaExecuter();
	
	public void testShowDataCertaExecuter_01()
	{
		setUpMockMethods( ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);		
		expecting( getStateMachineSession().get( "PlichiContentsHashTable" )).andReturn(  (Serializable) gettracciabilitaPlichiHashtable()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowDataCertaExecuter_02()
	{
		ImageStorageSystemWrapperMock.setTracciabilitaException();
		setUpMockMethods( ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);		
		expecting( getStateMachineSession().get( "PlichiContentsHashTable" )).andReturn(  (Serializable) gettracciabilitaPlichiHashtable()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testShowDataCertaExecuter_03()
	{
		ImageStorageSystemWrapperMock.setRemoteException();
		setUpMockMethods( ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);		
		expecting( getStateMachineSession().get( "PlichiContentsHashTable" )).andReturn(  (Serializable) gettracciabilitaPlichiHashtable()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	
	private Map gettracciabilitaPlichiHashtable()
	{
		final Map tracciabilitaPlichiHashtable = new Hashtable();
		tracciabilitaPlichiHashtable.put(CONSTANTS.ISS_ID,1L);
		return tracciabilitaPlichiHashtable;
	}

}
