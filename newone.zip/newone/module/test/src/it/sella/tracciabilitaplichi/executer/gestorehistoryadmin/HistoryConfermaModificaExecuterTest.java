package it.sella.tracciabilitaplichi.executer.gestorehistoryadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.HistoryAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.HistoryAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;

import java.util.Hashtable;

import mockit.Mockit;

public class HistoryConfermaModificaExecuterTest extends AbstractSellaExecuterMock {

	public HistoryConfermaModificaExecuterTest(final String name) {
		super(name);
	}

	HistoryConfermaModificaExecuter executer = new HistoryConfermaModificaExecuter() ;
	
	public void testHistoryConfermaModificaExecuter_1() {
		TracciabilitaPlichiImplMock.setStatus();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(HistoryAdminImpl.class, HistoryAdminImplMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(gethHashtable()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testHistoryConfermaModificaExecuter_2() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(HistoryAdminImpl.class, HistoryAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(gethHashtable()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public void testHistoryConfermaModificaExecuter_3() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(HistoryAdminImpl.class, HistoryAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(gethHashtable()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public Hashtable gethHashtable() {
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NewHistoryView", getHistoryView());
		hashtable.put("OldHistoryView", getHistoryView());
		return hashtable ;
	}
	
	public HistoryView getHistoryView() {
		final HistoryView historyView = new HistoryView()  ;
		return historyView ;
	}
	
}
