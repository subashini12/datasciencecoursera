package it.sella.tracciabilitaplichi.executer.gestorericezionesmistemento;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import org.easymock.EasyMock;



public class ShowPlichiExecuterTest extends AbstractSellaExecuterMock{

	public ShowPlichiExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ShowPlichiExecuter executer=new ShowPlichiExecuter();
	public void testShowPlichiExecuter_01()
	{
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("2");
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().remove("BustaNeraBackUpCollection")).andReturn("");
		expecting(getStateMachineSession().remove("BustaNeraMainCollection")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}

}
