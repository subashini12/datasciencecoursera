/*package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoPlichiBusta5RicercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Hashtable;

public class ArchivoPlichiBusta5RicercaExecuterTest  extends AbstractSellaExecuterTest {

     ArchivoPlichiBusta5RicercaExecuter   archivoPlichiBusta5RicercaExecuter = new   ArchivoPlichiBusta5RicercaExecuter();

   public   ArchivoPlichiBusta5RicercaExecuterTest(final String name) {
       super(name);
   }

   public void testArchivoPlichiBusta5RicercaExecuter_01() {
	   setUpMockMethods(LogEvent.class,LogEventMock.class );
	   setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
	   setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	   setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "") ; 
       playAll();
       final ExecuteResult executeResult =   archivoPlichiBusta5RicercaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrFail"));
       assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1110" );
        
   }
   public void testArchivoPlichiBusta5RicercaExecuter_02() {
	   setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
	   setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	   setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
	   setUpMockMethods(LogEvent.class,LogEventMock.class );
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ; 
       playAll();
       final ExecuteResult executeResult =   archivoPlichiBusta5RicercaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrFail"));
       assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1311" );
        
   }
   public void testArchivoPlichiBusta5RicercaExecuter_03() {
	   setUpMockMethods(LogEvent.class,LogEventMock.class );
	   setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	   setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
	   setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ; 
       playAll();
       final ExecuteResult executeResult =   archivoPlichiBusta5RicercaExecuter
               .execute(getRequestEvent());
   }
   
   public void testArchivoPlichiBusta5RicercaExecuter_04() {
	   setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
	   setUpMockMethods(LogEvent.class,LogEventMock.class );
	   setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	   setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ; 
       playAll();
       final ExecuteResult executeResult =   archivoPlichiBusta5RicercaExecuter
               .execute(getRequestEvent());
   }
   
   public void testArchivoPlichiBusta5RicercaExecuter_05() {
	   setUpMockMethods(LogEvent.class,LogEventMock.class );
	   setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
	   setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
	   setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
               archivoBustaCinqueSession) ;
       expecting(getRequestEvent( ).getAttribute( "BarCodePlico"  )).andReturn(
               "9010000000390") ; 
       playAll();
       final ExecuteResult executeResult =   archivoPlichiBusta5RicercaExecuter
               .execute(getRequestEvent());
   }
}
*/