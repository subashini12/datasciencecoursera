package it.sella.tracciabilitaplichi.executer.ricercabustacinque;


import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.ArrayList;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class RicercaBustaCinqueExecuterTest extends AbstractSellaExecuterMock{

	public RicercaBustaCinqueExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicercaBustaCinqueExecuter executer=new RicercaBustaCinqueExecuter();
	
	public void testRicercaBustaCinqueExecuterTest_01()
	{	
		Hashtable hashtable=getHashTable();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("1");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testRicercaBustaCinqueExecuterTest_02()
	{	
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("TrDefault");
		expecting(getStateMachineSession().containsKey("PageNo")).andReturn(true);
		expecting(getStateMachineSession().get("PageNo")).andReturn("1");
		expecting(getStateMachineSession().remove("PageNo")).andReturn(null);
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(false);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testRicercaBustaCinqueExecuterTest_03()
	{	
		Hashtable hashtable=getHashTable();
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("TrDefault");
		expecting(getStateMachineSession().containsKey("PageNo")).andReturn(false);
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicercaBustaCinqueExecuterTest_04()
	{	
		Hashtable hashtable=getEmptyHashTable();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Hashtable getHashTable()
	{
		ArrayList arrayList=new ArrayList();
		arrayList.add("1");
		Hashtable hashtable=new Hashtable();
		hashtable.put("FiltraCollRicercaView", arrayList);
		return hashtable;
	}
	
	private static Hashtable getEmptyHashTable()
	{
		ArrayList arrayList=new ArrayList();
		Hashtable hashtable=new Hashtable();
		hashtable.put("FiltraCollRicercaView", arrayList);
		return hashtable;
	}
}
