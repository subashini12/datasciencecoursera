package it.sella.tracciabilitaplichi.executer.test.gestorecdrgroupadmin;

import it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin.CdrGroupCancelliCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

import org.easymock.EasyMock;

public class CdrGroupCancelliCercaExecuterTest extends AbstractSellaExecuterMock
{

	public CdrGroupCancelliCercaExecuterTest(String name) 
	{
		super(name);
	}
	
	CdrGroupCancelliCercaExecuter executer = new CdrGroupCancelliCercaExecuter();
	
	public void testCdrGroupCancelliCercaExecuter_01()
	{
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupCancelliCercaExecuter_02()
	{
		expecting( getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupCancelliCercaExecuter_03()
	{
		expecting( getRequestEvent().getAttribute("ID")).andReturn("ab").anyTimes();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupCancelliCercaExecuter_04()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setAsInValidCdrGroupId();
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupCancelliCercaExecuter_for()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException();
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}

}
