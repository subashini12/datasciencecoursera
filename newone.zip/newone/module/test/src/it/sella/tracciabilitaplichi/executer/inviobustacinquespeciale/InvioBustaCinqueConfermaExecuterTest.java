/*package it.sella.tracciabilitaplichi.executer.inviobustacinquespeciale;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;


public class InvioBustaCinqueConfermaExecuterTest {

	InvioBustaCinqueConfermaExecuter executer = new InvioBustaCinqueConfermaExecuter();

	@Test
	public void invioBustaCinqueConfermaExecutertest_01()
	{
		ExternalServicesFactoryMock.setOperationAllowed();
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getAttribute( "NumeroTerminalo" )).andReturn("").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Day" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Month" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Year" )).andReturn("2012").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "barcode" )).andReturn("1044020563441").anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult  executeResult = executer.execute(requestEvent);
		Assert.assertNotNull(executeResult);
		Assert.assertEquals("",executeResult.getAttribute("dipendente"));
		Assert.assertEquals("1044020563441",executeResult.getAttribute("BarCode"));
	}

	@Test
	public void invioBustaCinqueConfermaExecutertest_02()
	{
		TracciabilitaPlichiCommonDataAccessMock.setCdrForLidAsNull();
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getAttribute( "NumeroTerminalo" )).andReturn("").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Day" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Month" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Year" )).andReturn("2012").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "barcode" )).andReturn("1044020563441").anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult  executeResult = executer.execute(requestEvent);
		Assert.assertNotNull(executeResult);
		Assert.assertEquals("",executeResult.getAttribute("dipendente"));
		Assert.assertEquals("-",executeResult.getAttribute("succ"));
		Assert.assertEquals("1044020563441",executeResult.getAttribute("BarCode"));
	}

	@Test
	public void invioBustaCinqueConfermaExecutertest_tracciabilitaException()
	{
		SecurityDBpersonaleWrapperMock.setTracciabilitaException();
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getAttribute( "NumeroTerminalo" )).andReturn("").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Day" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Month" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Year" )).andReturn("2012").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "barcode" )).andReturn("1044020563441").anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult  executeResult = executer.execute(requestEvent);
		Assert.assertNotNull(executeResult);
		Assert.assertEquals("",executeResult.getAttribute("dipendente"));
		Assert.assertEquals("-",executeResult.getAttribute("succ"));
		Assert.assertEquals("1044020563441",executeResult.getAttribute("BarCode"));
	}

	@Test
	public void invioBustaCinqueConfermaExecutertest_remoteException()
	{
		SecurityDBpersonaleWrapperMock.setRemoteException();
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getAttribute( "NumeroTerminalo" )).andReturn("").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Day" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Month" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Year" )).andReturn("2012").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "barcode" )).andReturn("1044020563441").anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult  executeResult = executer.execute(requestEvent);
		Assert.assertNotNull(executeResult);
	}

	// This test will throw exception

	@Test
	public void invioBustaCinqueConfermaExecutertest_03()
	{
		TPUtilMock.setValidateDate(2);
		Mockit.setUpMock(TPUtil.class, TPUtilMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		Mockit.setUpMock(ExternalSecurityWrapper.class, ExternalSecurityWrapperMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect( requestEvent.getAttribute( "NumeroTerminalo" )).andReturn("G42").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Day" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Month" )).andReturn("12").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "Year" )).andReturn("2012").anyTimes();
		EasyMock.expect( requestEvent.getAttribute( "barcode" )).andReturn("1044020563441").anyTimes();
		EasyMock.replay(requestEvent);
		executer.execute(requestEvent);
	}

}
 */