package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;

import mockit.Mockit;

import org.junit.Test;


public class HistoryPlichiContentsDataAccessTest 
{
	HistoryPlichiContentsDataAccess historyPlichiContentsDataAccess=new HistoryPlichiContentsDataAccess();

	@Test
	public void getPlichiType_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getPlichiType("1234567891234");
		} catch (final TracciabilitaException e) {
		}
	}
	
	/*@Test
	public void getPlichiType_02()
	{
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_OGGETTO (OG_ID numeric(12),OG_TYPE numeric(12),OG_LID varchar(12),OG_OGGETTO_ACTUAL_DATE date,OG_USER varchar(12),OG_CURR_STATUS_ID numeric(12),OG_CURR_REF_ID numeric(12),OG_CDR varchar(12),OG_BANK numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_OGGETTO (OG_ID,OG_TYPE,OG_LID,OG_OGGETTO_ACTUAL_DATE,OG_USER,OG_CURR_STATUS_ID,OG_CURR_REF_ID,OG_CDR,OG_BANK) values(1,'1','SE12','2011-10-10','1',1,1,'1',1)");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_MA_COMPATIBLE_BANKS(CB_BANK numeric(12),CB_OTHER_BANK numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_MA_COMPATIBLE_BANKS(CB_BANK,CB_OTHER_BANK) values(1,1)");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_PLICHI_ATTRIBUTE(PA_DOC_ID numeric(12),PA_BARCODE varchar(12),PA_CDR_DESTINATION varchar(12),PA_USER_DESTINATION varchar(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_PLICHI_ATTRIBUTE values(1,'1234567891234','abc','cde')");
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getPlichiType("1234567891234");
		} catch (final TracciabilitaException e) {
		}finally
		{
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_MA_COMPATIBLE_BANKS");
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_HS_OGGETTO");
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_HS_PLICHI_ATTRIBUTE");
		}
	}*/
	
	@Test
	public void getCassetto_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getCassetto(1L);
		} catch (final TracciabilitaException e) {
		}
	}
	
	/*@Test
	public void getCassetto_02()
	{
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_TR_ALTRI_ATTRIBUTE (AA_NUMBER varchar(12),AA_DOC_ID numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_TR_ALTRI_ATTRIBUTE values('1',1)");
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getCassetto(1L);
		} catch (final TracciabilitaException e) {
		}
		finally
		{
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_HS_OGGETTO");
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_TR_ALTRI_ATTRIBUTE");
		}
	}*/
	
	@Test
	public void getHistory_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getHistory("1234567891234");
		} catch (final TracciabilitaException e) {
		} catch (final RemoteException e) {
		}
	}
	
	/*@Test
	public void getHistory_03()
	{
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_OGGETTO_STATUS_REFERENCE (OS_ID numeric(12),OS_DATE_TIME date,OS_USER varchar(12),OS_CDR varchar(12),OS_REF_ID numeric(12),OS_STATUS_ID numeric(12),OS_DOC_ID numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_OGGETTO_STATUS_REFERENCE values(1,'2011-10-10','SE12','099231',1,1,1)");
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_HS_OGGETTO_STATUS_REFERENCE");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_OGGETTO_STATUS_REFERENCE values(1,'2011-10-10','SE12',null,1,1,1)");
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getHistory("1234567891234");
		} catch (final TracciabilitaException e) {
		} catch (final RemoteException e) {
		}finally
		{
			SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_OGGETTO_STATUS_REFERENCE");
		}
	}*/
	
	@Test
	public void getTracciabilitaPlichiView_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.gettracciabilitaPlichiView("1234567891234");
		} catch (final TracciabilitaException e) {
		} catch (final RemoteException e) {
		}
	}
	
	/*@Test
	public void getHistory_02()
	{
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_MA_STATUS (ST_ID numeric(12),ST_TYPE varchar(12),ST_DIS_DESC varchar(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_MA_STATUS values(1,'ST_15','Busta10')");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_OGGETTO_STATUS_REFERENCE (OS_ID numeric(12),OS_DATE_TIME date,OS_USER varchar(12),OS_CDR varchar(12),OS_REF_ID numeric(12),OS_STATUS_ID numeric(12),OS_DOC_ID numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_OGGETTO_STATUS_REFERENCE values(1,'2011-10-10','SE12','099231',1,1,1)");
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getHistory("1234567891234");
		} catch (final TracciabilitaException e) {
		} catch (final RemoteException e) {
		}finally
		{
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_HS_PLICHI_ATTRIBUTE");
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_MA_STATUS");
			SqlScriptExecuter.executeCommandInHsqlDB("delete from TP_HS_OGGETTO_STATUS_REFERENCE");
		}
	}*/
	
	@Test
	public void listPlicoBustaNera_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.listPlicoBustaNera("1234567891234");
		} catch (final TracciabilitaException e) {
	}
	}
	
	
	@Test
	public void listPlicoBustaDeice_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.listPlicoBustaDeice("1234567891234");
		} catch (final TracciabilitaException e) {
	}
	}
	
	@Test
	public void getOggettoIdForBarCode_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getOggettoIdForBarCode("1234567891234");
		} catch (final TracciabilitaException e) {
	}
	}
	
	@Test
	public void getPlichiAttributeViewForBarcode_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getPlichiAttributeViewForBarcode("1234567891234");
		} catch (final TracciabilitaException e) {
	} catch (final RemoteException e) {
		}
	}
	
	@Test
	public void listAltriPlichi_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.listAltriPlichi("1234567891234");
		} catch (final TracciabilitaException e) {
	} catch (final RemoteException e) {
		}
	}
	
	@Test
	public void listPlichi_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.listPlichi("1234567891234");
		} catch (final TracciabilitaException e) {
	} catch (final RemoteException e) {
		}
	}
	
	@Test
	public void getOperationHappendInfo_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.getOperationHappendInfo("1234567891234",1L);
		} catch (final TracciabilitaException e) {
	} catch (final RemoteException e) {
		}
	}
	
	@Test
	public void listBustaNera_01()
	{
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		try {
			historyPlichiContentsDataAccess.listBustaNera("1234567891234");
		} catch (final TracciabilitaException e) {
	} catch (final RemoteException e) {
		}
	}
	
}
