package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.LogHelper;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.dto.WinBox2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

public class LogHelperTest extends TestCase {
	
    public LogHelperTest( final String name ) {
        super( name );
    }

    public void testGetWbx2PreparazioneXML1( )  {
        final WinBox2 winBox2 = new WinBox2( null, null, new PlichiAttributeView( ) );
        final List<WinBox2> winboxList =  new ArrayList<WinBox2>( 1 );
        winboxList.add( winBox2 );
        winBox2.setOggettoView(  getOggettoView( ) );
        winBox2.getPlichiAttributeView( ).setBarCode( "1234567890123" );
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setBarcode( "3210987654321" );
        folderAttributes.setTipoPratica( 1L );
        folderAttributes.setSocieta( "SELLA COMPANY" );
        winBox2.add( new Folder( null, null, folderAttributes ) );
        final Map<Enum,Object> sessionMap = getSessionMap( );
        sessionMap.put( CONSTANTS.WINBOX2_COLLECTION, winboxList );
        final String expected = "<TRPL-WBX2-CREAZIONE><OBJECT_TYPE>TEST TYPE</OBJECT_TYPE><USER>SSILQ74</USER><CDR>IN2030</CDR><BANK_ID>1</BANK_ID><WINBOX2_BARCODE>1234567890123</WINBOX2_BARCODE><FOLDER><BARCODE>3210987654321</BARCODE><DESC>NEW FOLDER TYPE</DESC><MONTH_YEAR></MONTH_YEAR><OTTO_TREDICI_CIFRE></OTTO_TREDICI_CIFRE><AMOUNT></AMOUNT><FIRST_NAME></FIRST_NAME><LAST_NAME></LAST_NAME><REF_NUM></REF_NUM><GBS_COMPANY></GBS_COMPANY><EXT_COMPANY>SELLA COMPANY</EXT_COMPANY><NOTES></NOTES><ARCHIVE_FLOW>CENTRALIZZATO</ARCHIVE_FLOW><CODFIS_PIVA></CODFIS_PIVA></FOLDER></TRPL-WBX2-CREAZIONE>";
        String actual = LogHelper.getInstance( ).getWbx2PreparazioneXML( sessionMap ) ;
        actual = new StringBuilder( actual ).replace( actual.indexOf( "<TIMESTAMP>" ), actual.indexOf( "<USER>" ), "" ).toString( );
        assertEquals( expected, actual );
    }
    
    public void testGetWbx2PreparazioneXML2( ) {
        final WinBox2 winBox2 = new WinBox2( null, null, new PlichiAttributeView( ) );
        final List<WinBox2> winboxList =  new ArrayList<WinBox2>( 1 );
        winboxList.add( winBox2 );
        winBox2.setOggettoView( getOggettoView( ) );
        winBox2.getPlichiAttributeView( ).setBarCode( "1234567890123" );
        winBox2.add( new Folder( null, null, getFolderAttributes( ) ) );
        final Map<Enum,Object> sessionMap = getSessionMap( );
        sessionMap.put( CONSTANTS.WINBOX2_COLLECTION, winboxList );
        final String expected = "<TRPL-WBX2-CREAZIONE><OBJECT_TYPE>TEST TYPE</OBJECT_TYPE><USER>SSILQ74</USER><CDR>IN2030</CDR><BANK_ID>1</BANK_ID><WINBOX2_BARCODE>1234567890123</WINBOX2_BARCODE><FOLDER><BARCODE>3210987654321</BARCODE><DESC>NEW FOLDER TYPE</DESC><MONTH_YEAR></MONTH_YEAR><OTTO_TREDICI_CIFRE></OTTO_TREDICI_CIFRE><AMOUNT></AMOUNT><FIRST_NAME></FIRST_NAME><LAST_NAME></LAST_NAME><REF_NUM></REF_NUM><GBS_COMPANY>BANCA SELLA</GBS_COMPANY><EXT_COMPANY>SELLA COMPANY</EXT_COMPANY><NOTES></NOTES><ARCHIVE_FLOW>CENTRALIZZATO</ARCHIVE_FLOW><CODFIS_PIVA></CODFIS_PIVA></FOLDER></TRPL-WBX2-CREAZIONE>";
        String actual = LogHelper.getInstance( ).getWbx2PreparazioneXML( sessionMap ) ;
        actual = new StringBuilder( actual ).replace( actual.indexOf( "<TIMESTAMP>" ), actual.indexOf( "<USER>" ), "" ).toString( );
        assertEquals( expected, actual );
    }
    
    public void testGetFolderPreparazioneXML( ) {
        final WinBox2 winBox2 = new WinBox2( );
        final Folder folder = new Folder( );
        folder.setOggettoView( getOggettoView( ) );
        folder.setFolderAttributes( getFolderAttributes( ) );
        folder.setGrants( new ArrayList<Grants>( 1 ) );
        winBox2.add( folder );
        final Map<Enum,Object> sessionMap = getSessionMap( );
        sessionMap.put( CONSTANTS.WINBOX2, winBox2 );
        sessionMap.put( CONSTANTS.FOLDER_FLOW, CONSTANTS.ONE.getValue( ) );
        final String expected = "<TRPL-NEW-FOLDER><OBJECT_TYPE>TEST TYPE</OBJECT_TYPE><USER>SSILQ74</USER><CDR>IN2030</CDR><BANK_ID>1</BANK_ID><BARCODE>3210987654321</BARCODE><DESC>NEW FOLDER TYPE</DESC><MONTH_YEAR></MONTH_YEAR><OTTO_TREDICI_CIFRE></OTTO_TREDICI_CIFRE><AMOUNT></AMOUNT><FIRST_NAME></FIRST_NAME><LAST_NAME></LAST_NAME><REF_NUM></REF_NUM><GBS_COMPANY>BANCA SELLA</GBS_COMPANY><EXT_COMPANY>SELLA COMPANY</EXT_COMPANY><NOTES></NOTES><ARCHIVE_FLOW>CENTRALIZZATO</ARCHIVE_FLOW><CODFIS_PIVA></CODFIS_PIVA><ADD_GRANTS></ADD_GRANTS></TRPL-NEW-FOLDER>";
        String actual = LogHelper.getInstance( ).getFolderPreparazioneXML( sessionMap ) ;
        actual = new StringBuilder( actual ).replace( actual.indexOf( "<TIMESTAMP>" ), actual.indexOf( "<USER>" ), "" ).toString( );
        assertEquals( expected, actual );
    }
    
    public void testGetWbx2CancellazioneXML( ) {
        final WinBox2 winBox2 = new WinBox2( getOggettoView( ), new HistoryView( ), null );
        final Map<Enum,Object> sessionMap = getSessionMap( );
        sessionMap.put( CONSTANTS.DELETED_WINBOX2, winBox2 );
        final String expected = "<OBJECT><OGGETTO><OG_TYPE></OG_TYPE><OG_LID></OG_LID><OG_OGGETTO_ACTUAL_DATE></OG_OGGETTO_ACTUAL_DATE><OG_USER>SSILQ74</OG_USER><OG_CDR>IN2030</OG_CDR><OG_CURR_STATUS_ID></OG_CURR_STATUS_ID><OG_CURR_REF_ID></OG_CURR_REF_ID><OG_BANK>1</OG_BANK></OGGETTO><OG_ST_REF><OS_STATUS_ID></OS_STATUS_ID><OS_USER></OS_USER><OS_CDR></OS_CDR><OS_IP_ADDRESS></OS_IP_ADDRESS><OS_DATE_TIME></OS_DATE_TIME><OS_REF_ID></OS_REF_ID></OG_ST_REF></OBJECT>";
        final String actual = LogHelper.getInstance( ).getWbx2CancellazioneXML( sessionMap );
        assertEquals( expected, actual );
    }
    
    public void testGetFolderCancellazioneXML( ) {
        final Folder folder = new Folder( null, null, getFolderAttributes( ) );
        final Map<Enum,Object> sessionMap = getSessionMap( );
        sessionMap.put( CONSTANTS.DELETED_FOLDER, folder );
        final String expected = "<TRPL-FOLDER-CANCELL><FOLDER><BARCODE>3210987654321</BARCODE><DESC>NEW FOLDER TYPE</DESC><MONTH_YEAR></MONTH_YEAR><OTTO_TREDICI_CIFRE></OTTO_TREDICI_CIFRE><AMOUNT></AMOUNT><FIRST_NAME></FIRST_NAME><LAST_NAME></LAST_NAME><REF_NUM></REF_NUM><GBS_COMPANY>BANCA SELLA</GBS_COMPANY><EXT_COMPANY>SELLA COMPANY</EXT_COMPANY><NOTES></NOTES><ARCHIVE_FLOW>CENTRALIZZATO</ARCHIVE_FLOW><CODFIS_PIVA></CODFIS_PIVA></FOLDER></TRPL-FOLDER-CANCELL>";
        final String actual = LogHelper.getInstance( ).getFolderCancellazioneXML( sessionMap );
        assertEquals( expected, actual );
    }
    
    private FolderAttributes getFolderAttributes( ) {
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setBarcode( "3210987654321" );
        folderAttributes.setTipoPratica( 1L );
        folderAttributes.setSocieta( "SELLA COMPANY" );
        folderAttributes.setSocietaGBS( 1L );
        return folderAttributes;
    }
    
    private OggettoView getOggettoView( ) {
        final OggettoView oggettoView = new OggettoView( );
        oggettoView.setOggettoTypeDesc( "TEST TYPE" );
        oggettoView.setUserId( "SSILQ74" );
        oggettoView.setBankId( 1L );
        oggettoView.setCdrName( "IN2030" );
        return oggettoView;
    }
    
    private Map<Enum,Object> getSessionMap( ) {
        final Map<Enum,Object> sessionMap = new HashMap<Enum, Object>( 3 );
        final Map<Long,String> folderTypesMap = new HashMap<Long, String>( 1 );
        folderTypesMap.put( 1L, "NEW FOLDER TYPE" );
        final Map<Long,String> societaGBSMap = new HashMap<Long, String>( 1 );
        societaGBSMap.put( 1L, "BANCA SELLA" );
        sessionMap.put( CONSTANTS.FOLDER_TYPES_MAP, folderTypesMap );
        sessionMap.put( CONSTANTS.GBS_COMPANY, societaGBSMap );
        return sessionMap;
    }
}
