package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import mockit.Mock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.interfaces.dao.ITailoredGrantsImpl;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;

public class TailoredGrantsImplMock implements ITailoredGrantsImpl{

private static Boolean tracciabilitaException = false;	
	
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}
	@Mock
	public void insert( final Long altriWinboxId, final Grants grants ) throws TracciabilitaException
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
	  return ;
	}

	@Mock
	public void delete( final Long typoPraticaId, final Long soggettoId  ) throws TracciabilitaException 
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
	  return ;		
	}

}
