package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CodiceHostView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;
import java.util.Date;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class CodiceHostAdminImplTest extends BasicJDBCTestCaseAdapter {
	
	CodiceHostAdminImpl codiceHostAdminImpl = new CodiceHostAdminImpl() ;
	
	public void testModificaOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CH_ID", new Object[] { 2L });
		result.addColumn("CH_BANK_ID", new Object[] { 1L });
		result.addColumn("CH_8CIFRE", new Object[] { "90269103" });
		result.addColumn("CH_FROM_DATE", new Object[] { new Date("02/02/2005") });
		result.addColumn("CH_TO_DATE", new Object[] { new Date() });
		statementHandler.prepareGlobalResultSet(result);
		try {
			codiceHostAdminImpl.modificaOggetto(getCodiceHostView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}

	public void testModificaOggetto_02() throws SQLException
	{
		final CodiceHostView codiceHostView = new CodiceHostView() ;
		codiceHostView.setCifreNo("90269103");
		codiceHostView.setBankId(1L);
		codiceHostView.setCodiceId(2L);
		codiceHostView.setFromDate(new Date("02/02/2005"));
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CH_ID", new Object[] { 2L });
		result.addColumn("CH_BANK_ID", new Object[] { 1L });
		result.addColumn("CH_8CIFRE", new Object[] { "90269103" });
		result.addColumn("CH_FROM_DATE", new Object[] { new Date("02/02/2005") });
		result.addColumn("CH_TO_DATE", new Object[] { new Date() });
		statementHandler.prepareGlobalResultSet(result);
		try {
			codiceHostAdminImpl.modificaOggetto(codiceHostView);
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	
	public void testCensitoOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CH_ID", new Object[] { 2L });
		result.addColumn("CH_BANK_ID", new Object[] { 1L });
		result.addColumn("CH_8CIFRE", new Object[] { "90269103" });
		result.addColumn("CH_FROM_DATE", new Object[] { new Date("02/02/2005") });
		result.addColumn("CH_TO_DATE", new Object[] { new Date() });
		statementHandler.prepareGlobalResultSet(result);
		try {
			codiceHostAdminImpl.censitoOggetto(getCodiceHostView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testCensitoOggetto_02() throws SQLException
	{
		final CodiceHostView codiceHostView = new CodiceHostView() ;
		codiceHostView.setCifreNo("90269103");
		codiceHostView.setBankId(1L);
		codiceHostView.setCodiceId(2L);
		codiceHostView.setFromDate(new Date("02/02/2005"));
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CH_ID", new Object[] { 2L });
		result.addColumn("CH_BANK_ID", new Object[] { 1L });
		result.addColumn("CH_8CIFRE", new Object[] { "90269103" });
		result.addColumn("CH_FROM_DATE", new Object[] { new Date("02/02/2005") });
		result.addColumn("CH_TO_DATE", new Object[] { new Date() });
		statementHandler.prepareGlobalResultSet(result);
		try {
			codiceHostAdminImpl.censitoOggetto(codiceHostView);
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testCancelliOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CH_ID", new Object[] { 2L });
		result.addColumn("CH_BANK_ID", new Object[] { 1L });
		result.addColumn("CH_8CIFRE", new Object[] { "90269103" });
		result.addColumn("CH_FROM_DATE", new Object[] { new Date("02/02/2005") });
		result.addColumn("CH_TO_DATE", new Object[] { new Date() });
		statementHandler.prepareGlobalResultSet(result);
		try {
			codiceHostAdminImpl.cancelliOggetto(getCodiceHostView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	private static CodiceHostView getCodiceHostView()
	{
		final CodiceHostView codiceHostView = new CodiceHostView() ;
		codiceHostView.setCifreNo("90269103");
		codiceHostView.setBankId(1L);
		codiceHostView.setCodiceId(2L);
		codiceHostView.setFromDate(new Date("02/02/2005"));
		codiceHostView.setToDate(new Date("02/02/2005"));
		return codiceHostView ;
	}
	
}
