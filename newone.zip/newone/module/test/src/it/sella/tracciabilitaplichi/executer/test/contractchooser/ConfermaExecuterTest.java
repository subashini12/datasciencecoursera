package it.sella.tracciabilitaplichi.executer.test.contractchooser;

import it.sella.tracciabilitaplichi.contractchooser.helper.ContractChooserHelper;
import it.sella.tracciabilitaplichi.executer.contractchooser.ConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.contractchooser.helper.ContractChooserHelperMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class ConfermaExecuterTest extends AbstractSellaExecuterMock
{

	public ConfermaExecuterTest(String name) 
	{
		super(name);		
	}
	
	ConfermaExecuter executer = new ConfermaExecuter();
	
	
	public void testConfermaExecuter_01()
	{
		setUpMockMethods( ContractChooserHelper.class , ContractChooserHelperMock.class );
		expecting( getStateMachineSession().get( "PlichiBusta10Map" )).andReturn( ( Serializable )getPlichiBusta10Map()).anyTimes();
		expecting( getStateMachineSession().get( "plichiMap" )).andReturn(  new HashMap()  ).anyTimes();
		expecting( getRequestEvent().getAttribute("bustaIdFora")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove( "PlichiBusta10Map" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "plichiMap" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "SelectedContracts" ) ).andReturn(null).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testConfermaExecuter_02()
	{
		ContractChooserHelperMock.setSelectedBustaDeiciNull();
		setUpMockMethods( ContractChooserHelper.class , ContractChooserHelperMock.class );
		expecting( getStateMachineSession().get( "PlichiBusta10Map" )).andReturn( ( Serializable )getPlichiBusta10Map()).anyTimes();
		expecting( getStateMachineSession().get( "plichiMap" )).andReturn(  new HashMap()  ).anyTimes();
		expecting( getRequestEvent().getAttribute("bustaIdFora")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove( "PlichiBusta10Map" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "plichiMap" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "SelectedContracts" ) ).andReturn(null).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private Map getPlichiBusta10Map()
	{
		Map map = new HashMap();
		map.put("a", "value");
		return map;		
	}
	

}
