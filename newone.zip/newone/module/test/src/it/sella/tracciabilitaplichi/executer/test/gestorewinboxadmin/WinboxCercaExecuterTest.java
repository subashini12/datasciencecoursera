package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.util.Hashtable;

import org.easymock.EasyMock;

public class WinboxCercaExecuterTest  extends AbstractSellaExecuterMock {

	WinboxCercaExecuter winboxCercaExecuter =  new WinboxCercaExecuter(); 
	
	public WinboxCercaExecuterTest(final String name) {
		super(name);
	}
	

	public void testWinboxCercaExecuter_1() {
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	 
	public void testWinboxCercaExecuter_2() {
		WinboxAdminHelperMock.setRemoteException();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	
	public void testWinboxCercaExecuter_3() {
		WinboxAdminHelperMock.setTracciabilitaException();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	public void testWinboxCercaExecuter_4() {
		final Hashtable hashtable =new Hashtable();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(true);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get("AltriWinboxTable")).andReturn(hashtable);
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	public void testWinboxCercaExecuter_5() {
		TracciabilitaPlichiAdminMasterDataAccessMock.setAltriWinboxViewIsNull();
		final Hashtable hashtable =new Hashtable();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(true);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get("AltriWinboxTable")).andReturn(hashtable);
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	
	public void testWinboxCercaExecuter_6() {
		WinboxAdminHelperMock.setRemoteException();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	
	public void testWinboxCercaExecuter_7() {
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn(null)
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	
	public void testWinboxCercaExecuter_8() {
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	
	public void testWinboxCercaExecuter_9() {
		UtilMock.setNumericFalse();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
	
	public void testWinboxCercaExecuter_11() {
		TracciabilitaPlichiAdminMasterDataAccessMock.setInValidWinboxId();
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class,
				TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1")
				.anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22")
				.anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList"))
				.andReturn(true);
		expecting(getStateMachineSession().containsKey("AltriWinboxTable"))
				.andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = winboxCercaExecuter
				.execute(getRequestEvent());
	}
}
