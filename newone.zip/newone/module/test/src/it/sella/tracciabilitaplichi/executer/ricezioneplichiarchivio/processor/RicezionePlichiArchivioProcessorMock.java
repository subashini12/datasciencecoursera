package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Map;

import mockit.Mock;

public class RicezionePlichiArchivioProcessorMock {
	@Mock
	public static void processPlichiType(final Map views,
			final ExecuteResult executeResult, final long noOfPlrecieved,
			final String msg) throws TracciabilitaException, RemoteException {
		return;
	}
}
