package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.ejb.collections.ResultSetRow2BusinessObjectTransformer;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciRicercaView;

import java.rmi.RemoteException;

import mockit.Mock;

import org.easymock.classextension.EasyMock;

public class GestoreBustaDeiciDataAccessMock {

	private static Boolean isPB10InRequiredStatus = false;

	public static void setisPB10InRequiredStatus() {
		isPB10InRequiredStatus = true;
	}

	@Mock
	public LazyFetchCollection findContrattiUC(
			final BustaDeiciRicercaView ricercaQuery,
			final ResultSetRow2BusinessObjectTransformer businessObjectTransformer)
			throws TracciabilitaException, RemoteException {
		final LazyFetchCollection lazyFetchCollection = EasyMock
				.createMock(LazyFetchCollection.class);

		return lazyFetchCollection;

	}

	@Mock
	public String getEsitoDescription(final Long idEsito)
			throws TracciabilitaException {
		return "EsitoDescription";

	}

	@Mock
	public Long getSFId(final String printingId, final String imageType)
			throws TracciabilitaException {
		return 1L;
	}

	@Mock

public boolean isPB10InRequiredStatus( final String barcode, final String statuType ) throws TracciabilitaException
{
	boolean flag= true ;
	if(isPB10InRequiredStatus)
	{
		isPB10InRequiredStatus= false;
		flag = false ;
	}
	return flag ;
}
}
