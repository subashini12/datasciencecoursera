package it.sella.tracciabilitaplichi.executer.gestorehistoryadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;

import java.util.Hashtable;

import org.easymock.EasyMock;



public class HistoryCercaExecuterTest extends AbstractSellaExecuterMock{

	public HistoryCercaExecuterTest(final String name) {
		super(name);
	}

	 HistoryCercaExecuter executer=new  HistoryCercaExecuter();
	 
	 public void testHistoryCercaExecuter_01() {
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(true);
		 expecting(getStateMachineSession().get("HistoryTable")).andReturn("");
		 playAll();
		 final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		 assertEquals("TrConferma",executeResult.getTransition());
	 }
	 
	 public void testHistoryCercaExecuter_02() {
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		 playAll();
		 final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		 assertEquals("TrFail",executeResult.getTransition());
	 }
	 
	  public void testHistoryCercaExecuter_03() {
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("id");
		 playAll();
		 final ExecuteResult executeResult =   executer.execute(getRequestEvent());
		 assertEquals("TrFail",executeResult.getTransition());
	 }
	  
	  public void testHistoryCercaExecuter_04() {
		 setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("1234");
		 expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		 playAll();
		 final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		 assertEquals("TrFail",executeResult.getTransition());
	  }
	  
	  public void testHistoryCercaExecuter_06() {
		 TracciabilitaPlichiAdminTransactionDataAccessMock.setHistoryViewNotNull();
		 setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("1234");
		 expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		 playAll();
		 final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		 assertEquals("TrConferma",executeResult.getTransition());
	  }
	  
	  public void testHistoryCercaExecuter_05() {
	  	 TracciabilitaPlichiAdminTransactionDataAccessMock.setTracciabilitaException();
		 setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("1234");
		 expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		 playAll();
		 final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		 assertEquals(null,executeResult.getTransition());
	  }
	  
	  public void testHistoryCercaExecuter_07() {
		 final Hashtable hashtable=new Hashtable();
		 setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);     
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(true);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("1234");
		 expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		 expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		 playAll();
		 final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		 assertEquals("TrConferma",executeResult.getTransition());
	  }
	  
	  public void testHistoryCercaExecuter_08() {
	  	 TracciabilitaPlichiAdminTransactionDataAccessMock.setRemoteException();
		 setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getStateMachineSession().containsKey("HistoryTable")).andReturn(false);
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("1234");
		 expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		 playAll();
		 final ExecuteResult executeResult =   executer.execute(getRequestEvent());
		 assertEquals(null,executeResult.getTransition());
	 }
}
