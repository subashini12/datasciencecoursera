package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsDefaultProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Collection;
import java.util.Stack;

import org.easymock.EasyMock;



public class CronistoriaPlichiExecuterTest extends AbstractSellaExecuterMock{

	public CronistoriaPlichiExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	CronistoriaPlichiExecuter executer=new CronistoriaPlichiExecuter();
	
	public void testCronistoriaPlichiExecuter_01()
	{
		setUpMockMethods(PlichiContentsDefaultProcessor.class, PlichiContentsDefaultProcessorMock.class);
		final Stack stack=new Stack();
		stack.push("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("Cronistoria");
		expecting(getRequestEvent().getAttribute("visibilita")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCronistoriaPlichiExecuter_02()
	{
		PlichiContentsDefaultProcessorMock.setRemoteException();
		setUpMockMethods(PlichiContentsDefaultProcessor.class, PlichiContentsDefaultProcessorMock.class);
		final Stack stack=new Stack();
		stack.push("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("Cronistoria");
		expecting(getRequestEvent().getAttribute("visibilita")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCronistoriaPlichiExecuter_03()
	{
		PlichiContentsDefaultProcessorMock.setTracciabilitaException();
		setUpMockMethods(PlichiContentsDefaultProcessor.class, PlichiContentsDefaultProcessorMock.class);
		final Stack stack=new Stack();
		stack.push("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("Cronistoria");
		expecting(getRequestEvent().getAttribute("visibilita")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCronistoriaPlichiExecuter_04()
	{
		setUpMockMethods(PlichiContentsDefaultProcessor.class, PlichiContentsDefaultProcessorMock.class);
		final Stack stack=new Stack();
		stack.push("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("RefreshHistory");
		expecting(getStateMachineSession().containsKey("barCode")).andReturn(true);
		expecting(getRequestEvent().getEventName()).andReturn("Cronistoria");
		expecting(getRequestEvent().getAttribute("visibilita")).andReturn("a");
		playAll();
		executer.execute(getRequestEvent());
	}

}
