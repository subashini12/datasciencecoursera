/*package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxOperationsDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.classextension.EasyMock;


public class WinboxOperationsDefaultExecuterTest extends AbstractSellaExecuterTest
{

	final WinboxOperationsDefaultExecuter executer = new WinboxOperationsDefaultExecuter();
	public WinboxOperationsDefaultExecuterTest(final String name) 
	{
		super(name);
	}
	public void testDefaultExecuter_forSuccessCaseWithCLASSIFICAZIONE_MAP()
	{
		final Map<Long,String> map = new HashMap<Long, String>();
		map.put(Long.valueOf(1), "ravi");
		TracciabilitaPlichiAdminMasterDataAccessMock.setWinBoxListNull();
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class ) ;
		setUpMockMethods( TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class,TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().get( CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ) ) ).andReturn( getAltriWinboxView() ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.ALTRI_WINBOX_VIEW.getValue( )) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.CLASSIFICAZIONE_MAP.getValue( )) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put(  CONSTANTS.CLASSIFICAZIONE_MAP.getValue( ), map) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )(Long)  EasyMock.anyObject() ) ).andReturn( null );
		playAll();		
		executer.execute( getRequestEvent());
	}

	public void testDefaultExecuter_forTracciabiltaException()
	{
		WinboxAdminHelperMock.setTracciabilitaException();
		TracciabilitaPlichiAdminMasterDataAccessMock.setWinBoxListNull();
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class ) ;
		setUpMockMethods( TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class,TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().get( CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ) ) ).andReturn( getAltriWinboxView() ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.ALTRI_WINBOX_VIEW.getValue( )) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.CLASSIFICAZIONE_MAP.getValue( )) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();		
		executer.execute( getRequestEvent());
	}
	public void testDefaultExecuter_forRemoteException()
	{
		WinboxAdminHelperMock.setRemoteException();
		TracciabilitaPlichiAdminMasterDataAccessMock.setWinBoxListNull();
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class ) ;
		setUpMockMethods( TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class,TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getStateMachineSession().get( CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ) ) ).andReturn( getAltriWinboxView() ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.ALTRI_WINBOX_VIEW.getValue( )) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.CLASSIFICAZIONE_MAP.getValue( )) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	
	private AltriWinboxView getAltriWinboxView() 
	{
		final AltriWinboxView altriWinboxView = new AltriWinboxView();
		altriWinboxView.setDesc("ravi");		
		return altriWinboxView;
	}
}
*/