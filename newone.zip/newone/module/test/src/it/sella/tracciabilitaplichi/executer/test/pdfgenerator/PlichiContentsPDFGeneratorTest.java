package it.sella.tracciabilitaplichi.executer.test.pdfgenerator;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;



public class PlichiContentsPDFGeneratorTest extends AbstractSellaExecuterMock 
{
	
	public PlichiContentsPDFGeneratorTest(final String name) {
		super(name);
	}
	 @Override
	protected void setUp( ) throws Exception
	    {
	        super.setUp( );
	    }

	
	@Override
	public void tearDown() throws Exception {
	}
	
	public void testGetDataXMLPlichiContents() throws Exception {
		/*String actual ="";
		TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView();
		OggettoView ogetto = new OggettoView();
		ogetto.setUserId("BSA81");
		ogetto.setCdrName("09909");
		tracciabilitaPlichiView.setOggettoView(ogetto);
		PlichiAttributeView pilichAttributeView = new PlichiAttributeView();
		pilichAttributeView.setCdrDestination("BSAAl");
		pilichAttributeView.setBarCode("00998800000999");
		tracciabilitaPlichiView.setPlichiAttributeView(pilichAttributeView);
		StatusModifierInfoView inviaInfo= new StatusModifierInfoView();
		
		inviaInfo.setUserId("BSA099");
		StatusModifierInfoView ricievaInfo = new StatusModifierInfoView();
		ricievaInfo.setUserId("BSA099");
		Long cassetto = Long.valueOf(2);
		Collection plichiViewList = new ArrayList();
		redefineMethod(TPUtil.class, new Object(){
		public  Collection getCollComboView( String keyValueStr ) throws TracciabilitaException
		{
			Collection<ComboView> bankNames = new ArrayList<ComboView>();
			ComboView comboView = new ComboView();
			comboView.setKey("Banca");
			comboView.setValue("Banca Sella");
			bankNames.add(comboView);
		 return bankNames;	
		}
		});
		
			
		 redefineMethod(SecurityDBPersonaleWrapper.class, new Object(){
			 public String getDipendente( final String userId ) throws TracciabilitaException, RemoteException
				{
				   	return "Devi" ;
				}
		 });

			
		 redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
			 public String listBankIds() throws TracciabilitaException
				{
				 String banks = "00";
				 return banks;
				}
		 });
		// @suppressConstructor(ExternalServicesFactory.class);
		 //mockStatic(ExternalServicesFactory.class);
		 ExternalServicesFactory mockSingleton = getMock(ExternalServicesFactory.class);
		 expecting(ExternalServicesFactory.getInstance()).andReturn(mockSingleton).anyTimes();

		
		// suppressConstructor(SecurityDBPersonaleWrapper.class);
		// mockStatic(SecurityDBPersonaleWrapper.class);
		 SecurityDBPersonaleWrapper mockSingleton1 = getMock(SecurityDBPersonaleWrapper.class);
		// expecting(SecurityDBPersonaleWrapper.getInstance()).andReturn(mockSingleton1).anyTimes();

		// expecting(mockSingleton1.getDipendente("")).andReturn("Devi");
		redefineMethod(Util.class, new Object(){
		public String getItalianDateWithoutTime( Timestamp timestamp )
		{
			return "12:09:00";
		}
		});
		// crackSingleton(ExternalServicesFactory.class,securityDBPersonaleWrapper) ;
		
		playAll();
		String xmlPlici = PlichiContentsPDFGenerator.getDataXMLPlichiContents(tracciabilitaPlichiView, inviaInfo, ricievaInfo, cassetto, plichiViewList);
		assertNotNull(xmlPlici);
				*/
		
	}
	
}
