package it.sella.tracciabilitaplichi.executer.test.gestoreselectedcdradmin;

import it.sella.tracciabilitaplichi.executer.gestoreselectedcdradmin.SelectedCDRInseriscaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.admin.SelectedCDRAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.admin.SelectedCDRAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.view.TpMaSelectedCdrViewMock;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

public class SelectedCDRInseriscaExecuterTest extends AbstractSellaExecuterMock {

	SelectedCDRInseriscaExecuter selectedCDRInseriscaExecuter = new SelectedCDRInseriscaExecuter();

	public SelectedCDRInseriscaExecuterTest(final String name) {
		super(name);
	}

	
	public void testSelectedCDRInseriscaExecuter_01() {
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		setUpMockMethods(TpMaSelectedCdrView.class, TpMaSelectedCdrViewMock.class);
		final TpMaSelectedCdrView tpMaSelectedCdrView = new TpMaSelectedCdrView();
		final Map map = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("scCdr")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) map).anyTimes();
		playAll();
		selectedCDRInseriscaExecuter.execute(getRequestEvent());
	}
	
	public void testSelectedCDRInseriscaExecuter_02() {
		TpMaSelectedCdrViewMock.setNonEmptyMap();
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		setUpMockMethods(TpMaSelectedCdrView.class, TpMaSelectedCdrViewMock.class);
		final TpMaSelectedCdrView tpMaSelectedCdrView = new TpMaSelectedCdrView();
		final Map map = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("scCdr")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) map).anyTimes();
		playAll();
		selectedCDRInseriscaExecuter.execute(getRequestEvent());
	}
}
