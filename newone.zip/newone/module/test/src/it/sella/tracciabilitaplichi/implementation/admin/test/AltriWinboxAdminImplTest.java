/*
package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.msg.MsgManager;
import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.admin.AltriWinboxAdminImpl;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.ConnectionLifeCycleMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

import org.junit.Test;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.CallableStatementResultSetHandler;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

*//**
 *
 * @author GBS02360
 *//*
public class AltriWinboxAdminImplTest  extends BasicJDBCTestCaseAdapter {

	 public AltriWinboxAdminImplTest( final String name )
	    {
	        super( name );
	    }

	    AltriWinboxAdminImpl altriWinboxAdminImpl = new AltriWinboxAdminImpl() ;
	    
    *//**
     * Test of censitoOggetto method, of class AltriWinboxAdminImpl.
     * @throws TracciabilitaException 
     *//*
    @Test
    public void testCensitoOggetto() throws TracciabilitaException {
    	Mockit.setUpMock(LogEvent.class,LogEventMock.class);
    	Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final CallableStatementResultSetHandler statementHandler = 
            connection.getCallableStatementResultSetHandler();
		MockRunnerConnection.setConnection(connection);
		final Map outParam = new HashMap();
		outParam.put(1, "OK");
		statementHandler.prepareOutParameter("BEGIN INSERT INTO TP_MA_ALTRI_WINBOX(AW_ID,AW_DESC,AW_NO_YEARS,AW_CDR,AW_BANK,AW_OBJECT_TYPE,AW_ENABLED,AW_CUSTOM_ACCESS) VALUES(TP_SQ_ALTRI_WINBOX.nextval,?,?,?,?,?,?,?) RETURNING AW_ID INTO ?; END;", outParam);
    	final TPView tpView = new AltriWinboxView() ;
    	altriWinboxAdminImpl.censitoOggetto(tpView);
    }

    
    *//**
     * Test of modificaOggetto method, of class AltriWinboxAdminImpl.
     * @throws TracciabilitaException 
     *//*
    @Test
    public void testModificaOggetto() throws TracciabilitaException {
        Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
        Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("AW_ID", new Object[] { "1" });
		result.addColumn("AW_DESC", new Object[] { "1" });
		result.addColumn("AW_NO_YEARS", new Object[] { "1" });
		result.addColumn("AW_CDR", new Object[] { "1" });
		result.addColumn("AW_OBJECT_TYPE", new Object[] { "1" });
		result.addColumn("AW_ENABLED", new Object[] { "1" });
		result.addColumn("AW_CUSTOM_ACCESS", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
    	final TPView tpView = new AltriWinboxView() ;
    	altriWinboxAdminImpl.modificaOggetto(tpView);
    }
    *//**
     * Test of cancelliOggetto method, of class AltriWinboxAdminImpl.
     * @throws TracciabilitaException 
     *//*
    @Test
    public void testCancelliOggetto() throws TracciabilitaException {
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("AW_ID", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
    	final TPView tpView = new AltriWinboxView() ;
    	altriWinboxAdminImpl.cancelliOggetto(tpView);
    }


}*/