package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import mockit.Mock;

public class TPProdottiDataAccessMock 
{
	
	private static Boolean tracciabilitaException = false;	
	
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}
		
	@Mock
	public Map<Long, ProdottiView> gestoreAllprodotti() throws TracciabilitaException
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
		final Map map = new HashMap();
		final ProdottiView prodottiView = new ProdottiView( );
        prodottiView.setCodProdotto( "abc" );
		map.put(Long.valueOf(1),prodottiView);		
		return map;
	}
	@Mock
	public String getDescForProdConto( final String prodCode ) throws TracciabilitaException
    {
        return "IT - Organizatione Generali";
    }
	
	@Mock
	public ProdottiView getProdottiViewById( final long prodottiId ) throws TracciabilitaException
    {
		final ProdottiView pView = new ProdottiView();
        pView.setCodProdotto("222");
        return pView;
    }
	
	@Mock
	public Hashtable getAllProdottiView() throws TracciabilitaException
	{
		final Hashtable hashTable=new Hashtable();
		return hashTable;
		
	}
	
	@Mock
	
	public List getDispCollForInserimentopage( final String abiBanca, final String flagObbl, final Boolean isSeleziona  ) throws TracciabilitaException
	{
		final List list=new ArrayList();
		list.add("");
		return list;
	}
	
	@Mock
	
	public Collection<ProdottiView> getAllContractFamilies( final String abiBanca, final String flagObbl ) throws TracciabilitaException
	{
		final ProdottiView prodottiView = new ProdottiView();
		final Collection<ProdottiView> prodottiViewColl = new ArrayList<ProdottiView>();
		prodottiViewColl.add(prodottiView);
		return prodottiViewColl;
	}
}
