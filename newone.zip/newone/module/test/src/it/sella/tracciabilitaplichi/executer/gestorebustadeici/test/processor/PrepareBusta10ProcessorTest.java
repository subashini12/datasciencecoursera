package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor;

import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.PrepareBusta10Processor;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.dao.ArchivationBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalSecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalSecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.ArchivationBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

public class PrepareBusta10ProcessorTest extends AbstractSellaExecuterMock {

	public PrepareBusta10ProcessorTest(final String name) {
		super(name);
	}

	PrepareBusta10Processor processor = new PrepareBusta10Processor();

	public void testPrepareBusta10Processor_01() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		setUpMockMethods(ArchivationBustaDeiciDataAccess.class,ArchivationBustaDeiciDataAccessMock.class);
		setUpMockMethods(GestioneSollecitiDataAccess.class,GestioneSollecitiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		try {
			assertNotNull(processor.getContractList(getBusta10PreparationPageView()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testPrepareBusta10Processor_02() {
		ArchivationBustaDeiciDataAccessMock.setEmptyContractList();
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		setUpMockMethods(ArchivationBustaDeiciDataAccess.class,ArchivationBustaDeiciDataAccessMock.class);
		setUpMockMethods(GestioneSollecitiDataAccess.class,GestioneSollecitiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		try {
			processor.getContractList(getBusta10PreparationPageView());
			assertTrue(true);
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testPrepareBusta10_01() {
		UtilMock.setCheckNullFalse();
		TPBustaDeiciDataAccessMock.setPreparataStatus();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(ExternalSecurityWrapper.class,ExternalSecurityWrapperMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		setUpMockMethods(ArchivationBustaDeiciDataAccess.class,ArchivationBustaDeiciDataAccessMock.class);
		setUpMockMethods(GestioneSollecitiDataAccess.class,GestioneSollecitiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		final Busta10PreparationPageView busta10PreparationPageView = null;
		try {
			processor.prepareBusta10(busta10PreparationPageView);
			assertTrue(true);
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testPrepareBusta10_02() {
		UtilMock.setCheckNullFalse();
		TPBustaDeiciDataAccessMock.setPreparataStatus();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(ExternalSecurityWrapper.class,ExternalSecurityWrapperMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		setUpMockMethods(ArchivationBustaDeiciDataAccess.class,ArchivationBustaDeiciDataAccessMock.class);
		setUpMockMethods(GestioneSollecitiDataAccess.class,GestioneSollecitiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		final Busta10PreparationPageView busta10PreparationPageView = new Busta10PreparationPageView();
		busta10PreparationPageView.setBarCode("1234567891235");
		try {
			processor.prepareBusta10(busta10PreparationPageView);
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	private static Busta10PreparationPageView getBusta10PreparationPageView() {
		final Busta10PreparationPageView busta10PreparationPageView = new Busta10PreparationPageView();
		busta10PreparationPageView.setBarCode("12345678912354");
		busta10PreparationPageView.isAlreadyExist("12345678912354");
		busta10PreparationPageView.setArgument("");
		busta10PreparationPageView.setUserDetails(getMap());
		return busta10PreparationPageView;
	}

	private static Map getMap() {
		final Map map = new HashMap();
		map.put("bank", 1L);
		return map;
	}
}
