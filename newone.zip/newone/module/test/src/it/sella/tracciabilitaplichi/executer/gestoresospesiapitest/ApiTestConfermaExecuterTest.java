package it.sella.tracciabilitaplichi.executer.gestoresospesiapitest;

import it.sella.tracciabilitaplichi.SospesiService;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.persistence.mock.tracciabilitaplichi.SospesiServiceMock;

public class ApiTestConfermaExecuterTest extends AbstractSellaExecuterMock {

	public ApiTestConfermaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ApiTestConfermaExecuter apiTestConfermaExecuter = new ApiTestConfermaExecuter();
	public void testApiTestConfermaExecuter_13() {
		SospesiServiceMock.setIllegalAccessException();
		setUpMockMethods(SospesiService.class, SospesiServiceMock.class);
		expecting(getRequestEvent().getAttribute("ParamList"))
				.andReturn("099505,").anyTimes();
		expecting(getRequestEvent().getAttribute("parameter"))
				.andReturn("yes").anyTimes();
		expecting(getRequestEvent().getAttribute("MethodName"))
				.andReturn("getCountPlichiToReceive").anyTimes();
		playAll();
		apiTestConfermaExecuter.execute(getRequestEvent());
	}

	public void testApiTestConfermaExecuter_12() {
		
		setUpMockMethods(SospesiService.class, SospesiServiceMock.class);
		expecting(getRequestEvent().getAttribute("ParamList"))
				.andReturn("099505,").anyTimes();
		expecting(getRequestEvent().getAttribute("parameter"))
				.andReturn("yes").anyTimes();
		expecting(getRequestEvent().getAttribute("MethodName"))
				.andReturn("getCountPlichiToReceive").anyTimes();
		playAll();
		apiTestConfermaExecuter.execute(getRequestEvent());
	}
	public void testApiTestConfermaExecuter_11() {
		expecting(getRequestEvent().getAttribute("ParamList"))
				.andReturn("099505").anyTimes();
		expecting(getRequestEvent().getAttribute("parameter"))
				.andReturn("yes").anyTimes();
		expecting(getRequestEvent().getAttribute("MethodName"))
				.andReturn("isExistsBustaNera").anyTimes();
		playAll();
		apiTestConfermaExecuter.execute(getRequestEvent());
	}
	
		public void testApiTestConfermaExecuter_10() {
			expecting(getRequestEvent().getAttribute("ParamList"))
					.andReturn("ParamList").anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName"))
					.andReturn("isExistsOggetto()").anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}
		
		public void testApiTestConfermaExecuter_01() {
			expecting(getRequestEvent().getAttribute("ParamList")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("parameter")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
			assertEquals("", getRequestEvent().getAttribute("MethodName"));
			assertEquals("", getRequestEvent().getAttribute("ParamList"));
			assertEquals("", getRequestEvent().getAttribute("parameter"));
		}

		public void testApiTestConfermaExecuter_02() {
			expecting(getRequestEvent().getAttribute("ParamList"))
					.andReturn("Param,List").anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName"))
					.andReturn("methodName").anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_03() {
			expecting(getRequestEvent().getAttribute("ParamList")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName"))
					.andReturn("methodName").anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_04() {
			expecting(getRequestEvent().getAttribute("ParamList")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_05() {
			expecting(getRequestEvent().getAttribute("ParamList"))
					.andReturn("ParamList").anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_06() {
			expecting(getRequestEvent().getAttribute("ParamList")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("parameter")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_07() {
			expecting(getRequestEvent().getAttribute("ParamList")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("parameter")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_08() {
			expecting(getRequestEvent().getAttribute("ParamList"))
					.andReturn("Param").anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}

		public void testApiTestConfermaExecuter_09() {
			expecting(getRequestEvent().getAttribute("ParamList")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("parameter"))
					.andReturn("yes").anyTimes();
			expecting(getRequestEvent().getAttribute("MethodName")).andReturn("")
					.anyTimes();
			playAll();
			apiTestConfermaExecuter.execute(getRequestEvent());
		}
	}




