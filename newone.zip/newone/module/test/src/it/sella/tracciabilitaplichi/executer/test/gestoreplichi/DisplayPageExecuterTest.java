package it.sella.tracciabilitaplichi.executer.test.gestoreplichi;

import it.sella.tracciabilitaplichi.executer.gestoreplichi.DisplayPageExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.PreparazionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.PreparazionePlichiCacheUtil;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class DisplayPageExecuterTest extends AbstractSellaExecuterMock
{

	DisplayPageExecuter executer = new DisplayPageExecuter();
	
	public DisplayPageExecuterTest(String name) 
	{
		super(name);		
	}

	public void testExecuter_01()
	{
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();		
		expecting(getRequestEvent().getStateName()).andReturn("PreparazionePlichi").anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_02()
	{
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn("a:b:c:").anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();		
		expecting(getRequestEvent().getStateName()).andReturn("PreparazionePlichii").anyTimes();
		expecting( getStateMachineSession().get( "InvioPlichiHashTable" )).andReturn( ( Serializable ) getInvioPlichiHashTable() ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_03()
	{
		PreparazionePlichiCacheUtilMock.setTracciabilitaException();
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();		
		expecting(getRequestEvent().getStateName()).andReturn("PreparazionePlichi").anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}

	private Map getInvioPlichiHashTable() 
	{
		Map map= new HashMap();
		Map submap=new HashMap();
		submap.put(1,"abc");
		map.put("pageInfo",submap);		
		return map;
	}

}
