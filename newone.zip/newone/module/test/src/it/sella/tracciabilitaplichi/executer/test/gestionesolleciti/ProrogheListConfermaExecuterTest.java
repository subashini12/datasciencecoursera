package it.sella.tracciabilitaplichi.executer.test.gestionesolleciti;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.ProrogheListConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.dao.IGestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProrogheListConfermaExecuterTest   extends AbstractSellaExecuterMock {
private IGestioneSollecitiDataAccess igestioneSollecitiDataAccess = null ;
    
    @Override
	public void setUp( ) throws Exception
    {
        super.setUp( );
        igestioneSollecitiDataAccess = getMock( IGestioneSollecitiDataAccess.class );
        redefineMethod( TracciabilitaPlichiImpl.class, new Object( ) {
            public IGestioneSollecitiDataAccess getGestioneSollecitiDataAccess( )
            {
                return igestioneSollecitiDataAccess;
            }
        });
    }
    
    final ProrogheListConfermaExecuter ProrogheListConfermaExecuterTest =  new ProrogheListConfermaExecuter(); 
    
    
    public ProrogheListConfermaExecuterTest(final String name) {
        super(name);
    }

   
 
     public void testProrogheListConfermaExecuter_01() throws TracciabilitaException{
    	 setUpMockMethods(LogEvent.class,LogEventMock.class );
        final Map sollecitoProrogheSessionMap = new HashMap( 1 );
        sollecitoProrogheSessionMap.put( ITPConstants.BARCODE  , "901");
        expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(( Serializable ) sollecitoProrogheSessionMap).anyTimes();
        expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
        playAll();
        play( igestioneSollecitiDataAccess );
      
        final ExecuteResult executeResult = ProrogheListConfermaExecuterTest.execute(getRequestEvent());
        assertEquals("TrConferma" ,executeResult.getTransition( ));
    }
     
     /*public void testProrogheListConfermaExecuter_02() throws TracciabilitaException{
    	UtilMock.setCheckNullFalse();
    	setUpMockMethods(Util.class,UtilMock.class);
    	setUpMockMethods(ProrogheListConfermaProcessor.class,ProrogheListConfermaProcessorMock.class);
    	setUpMockMethods(LogEvent.class,LogEventMock.class );
        expecting(getRequestEvent( ).getAttribute( "prGG1")).andReturn("").anyTimes();
        expecting(getRequestEvent( ).getAttribute( "prMM1")).andReturn("").anyTimes();
        expecting(getRequestEvent( ).getAttribute( "prAAAA1")).andReturn("").anyTimes();
        expecting(getRequestEvent( ).getAttribute( "prNote1")).andReturn("").anyTimes();
        expecting(getRequestEvent( ).getAttribute( "sdDisabled1")).andReturn("").anyTimes();
        final Map sollecitoProrogheSessionMap = new HashMap( 1 );
        final SollecitiProrogheListView view = new SollecitiProrogheListView();
        sollecitoProrogheSessionMap.put( 1L, view );
        sollecitoProrogheSessionMap.put( ITPConstants.PROROGHE_MAP  , sollecitoProrogheSessionMap);
        sollecitoProrogheSessionMap.put( ITPConstants.BARCODE  , "901");
        expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITO_PROROGHE_MAP)).andReturn(( Serializable ) sollecitoProrogheSessionMap).anyTimes();
        expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
        playAll();
        play( igestioneSollecitiDataAccess );
        final ExecuteResult executeResult = ProrogheListConfermaExecuterTest.execute(getRequestEvent());
        assertEquals("TrFail" ,executeResult.getTransition( ));
    }*/
}
