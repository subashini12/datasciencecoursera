package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import mockit.Mock;

public class TPContrattiProdottoDataAccessMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;
	private static Boolean isCodeProdConExistsTrue = false;

	public static void setCodeProdConExistsToTrue() {
		isCodeProdConExistsTrue = true;;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	@Mock
	public String getDescConByCodeProdCon(final String codProCon)
			throws TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		return "LIC";
	}

	@Mock
	public Collection<ContrattiProdottoView> getContractsCollection(
			final String familyCode, final String abibanca)
			throws TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		final Collection<ContrattiProdottoView> contrattiProdottoHt = new ArrayList<ContrattiProdottoView>();
		final ContrattiProdottoView contrattiProdottoView = new ContrattiProdottoView();
		contrattiProdottoView.setCodContratto("abc");
		contrattiProdottoHt.add(contrattiProdottoView);
		return contrattiProdottoHt;
	}

	@Mock
	public Hashtable gestoreAllContratti() throws TracciabilitaException {
		final Hashtable hashtable = new Hashtable();
		hashtable.put(1, "abc");
		return hashtable;
	}

	@Mock
	public Hashtable gestoreContrattiForAbiCode(final String abiBanca)
			throws TracciabilitaException {
		final Hashtable hashtable = new Hashtable();
		hashtable.put(1, "abc");
		return hashtable;
	}

	@Mock
	public Hashtable findAllContrattiProdottiView(final String abiBanca)
			throws TracciabilitaException, RemoteException {
		if (remoteException) {
			throw new RemoteException();
		}
		final Hashtable hashtable = new Hashtable();
		return hashtable;
	}
	
	@Mock
	public boolean isCodeProdConExists( final String codProCon, final Long id ) throws TracciabilitaException
	{
		boolean isCodeProdConExists = false;
		if(isCodeProdConExistsTrue){
			isCodeProdConExistsTrue = false;
			isCodeProdConExists = true;
		}
		return isCodeProdConExists ;
	}
	
	@Mock
	
	public String getCPViewByCodProdottoContratto( final String codProdottoContratto ) throws TracciabilitaException
	{
		return "" ;
	}
	
	@Mock
	public Collection<ContrattiProdottoView> getCPViewByAbiBanca( final String abiBanca, final String flag, final String codProd, final String descrizione, final Boolean isNeededToAvoidDummy ) throws TracciabilitaException
	{
		final Collection<ContrattiProdottoView> contrattiProdottoViewColl = new ArrayList<ContrattiProdottoView>() ;
		final ContrattiProdottoView contrattiProdottoView = new ContrattiProdottoView() ;
		contrattiProdottoView.setAbiBanca("03268");
		contrattiProdottoViewColl.add(contrattiProdottoView);
		return contrattiProdottoViewColl ;
	}
}
