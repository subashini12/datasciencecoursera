package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;


import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestProdottiAdminDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccessMock;

import org.easymock.EasyMock;

public class GestProdottiAdminDefaultExecuterTest extends AbstractSellaExecuterMock {

    public GestProdottiAdminDefaultExecuterTest( String name )
    {
        super( name );
        // TODO Auto-generated constructor stub
    }
    GestProdottiAdminDefaultExecuter gestProdottiAdminDefaultExecuter =  new GestProdottiAdminDefaultExecuter(); 
 
    public void testGestProdottiAdminDefaultExecuterTest_01(){
   
        setUpMockMethods( TPProdottiDataAccess.class, TPProdottiDataAccessMock.class );
        expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null );
        playAll();
        ExecuteResult executeResult = gestProdottiAdminDefaultExecuter.execute( getRequestEvent() );
        assertEquals( "ListProdotti", executeResult.getTransition( ) );
    }

    public void testGestProdottiAdminDefaultExecuterTest_02(){
    	TPProdottiDataAccessMock.setTracciabilitaException();
    	setUpMockMethods( TPProdottiDataAccess.class, TPProdottiDataAccessMock.class );
         expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null );
         playAll();
         ExecuteResult executeResult = gestProdottiAdminDefaultExecuter.execute( getRequestEvent()
     );
              
    }
}
