package it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;


public class InvioSmistamentoPageLinkExecuterTest extends AbstractSellaExecuterMock{

	public InvioSmistamentoPageLinkExecuterTest(final String name) {
		super(name);
	}

	InvioSmistamentoPageLinkExecuter executer = new InvioSmistamentoPageLinkExecuter();
	
	public void testInvioSmistamentoPageLinkExecuter_01() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("plichiAttributeId")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("pageNo")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	private static Map getMap() {
		final Map map = new HashMap();
		map.put("filteredMapIdBustaNeraView",new ArrayList() );
		map.put("mapIdBustaNeraView",getBustaNeraViewMap() );
		map.put("lastSeenPage", "1");
		map.put("mapPageListaBustaNeraView",getBustaNeraViewMap() );
		return map ;
	}
	
	private static Map getBustaNeraViewMap() {
		final Map map = new HashMap();
		map.put("1",new ArrayList());
		map.put("lastSeenPage", "1");
		return map ;
	}
	
}
