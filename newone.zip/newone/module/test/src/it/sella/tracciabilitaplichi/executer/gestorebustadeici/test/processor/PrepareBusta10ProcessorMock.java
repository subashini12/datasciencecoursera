package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;

import java.rmi.RemoteException;

import mockit.Mock;

public class PrepareBusta10ProcessorMock 
{
	@Mock
	public static void prepareBusta10(Busta10PreparationPageView pageView) throws TracciabilitaException, RemoteException 
	{
		return ;
	}

}
