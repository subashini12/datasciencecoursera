package it.sella.tracciabilitaplichi.executer.test.gestionepropertiesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.PropertyShowIndietroExecuter;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;

public class PropertyShowIndietroExecuterTest  {

	PropertyShowIndietroExecuter PropertyShowIndietroExecuterTest = new PropertyShowIndietroExecuter();
	
	@Test
	public void propertyShowIndietroExecuter_01(){
		final Map sesssionMap = new HashMap();
		sesssionMap.put("Inserisci", "Inserisci");
		sesssionMap.put("Elimina", "Elimina");
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey("GESTIONE_PROPERTIES_ADMIN_MAP")).andReturn(Boolean.TRUE);
		EasyMock.expect(stateMachineSession.get("GESTIONE_PROPERTIES_ADMIN_MAP")).andReturn((Serializable)sesssionMap);
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = PropertyShowIndietroExecuterTest.execute(requestEvent);
		Assert.assertEquals("TrEliminaIndietro" ,executeResult.getTransition() );
	}

}
