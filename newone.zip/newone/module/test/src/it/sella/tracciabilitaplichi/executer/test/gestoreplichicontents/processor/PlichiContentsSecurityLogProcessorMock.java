package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents.processor;

import mockit.Mock;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.statemachine.RequestEvent;

public class PlichiContentsSecurityLogProcessorMock 
{
	@Mock
	 public static ExecuteResult logIfContract( RequestEvent requestEvent ) 
    {
		ExecuteResult execureResult = ExecuteResultFactory.getInstance().getExecuteResult( "TrConferma" );	
		return execureResult;
    }

}
