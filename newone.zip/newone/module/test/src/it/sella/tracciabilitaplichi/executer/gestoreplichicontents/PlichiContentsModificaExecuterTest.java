package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;


import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsModificaBNProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsModificaPB5ProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsModificaPBNProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsModificaPBustasProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsModificaBNProcessor;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsModificaPB5Processor;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsModificaPBNProcessor;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsModificaPBustasProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Stack;

import junit.framework.Assert;
import mockit.Mockit;

public class PlichiContentsModificaExecuterTest extends AbstractSellaExecuterMock{

	public PlichiContentsModificaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiContentsModificaExecuter executer=new PlichiContentsModificaExecuter();

	public void testPlichiContentsModificaExecuter_01()
	{
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaPBustasProcessor.class, PlichiContentsModificaPBustasProcessorMock.class);
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaCinqueID1")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}

	public void testPlichiContentsModificaExecuter_02()
	{
		ClassificazioneWrapperMock.setBUSTN();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaBNProcessor.class, PlichiContentsModificaBNProcessorMock.class);
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getStateMachineSession().get("ContralisticaId1")).andReturn("");
		expecting(getRequestEvent().getAttribute("BustaCinqueID1")).andReturn("");
		expecting(getRequestEvent().getAttribute("BustaCinqueID")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}
	public void testPlichiContentsModificaExecuter_03()
	{
		ClassificazioneWrapperMock.setPBUST5();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaPB5Processor.class, PlichiContentsModificaPB5ProcessorMock.class);
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getStateMachineSession().get("ContralisticaId1")).andReturn("");
		expecting(getRequestEvent().getAttribute("BustaCinqueID1")).andReturn("");
		expecting(getRequestEvent().getAttribute("BustaCinqueID")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}


	public void testPlichiContentsModificaExecuter_04()
	{
		ClassificazioneWrapperMock.setPBUSTN();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaBNProcessor.class, PlichiContentsModificaBNProcessorMock.class);
		setUpMockMethods(PlichiContentsModificaPBNProcessor.class,PlichiContentsModificaPBNProcessorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}
	public void testPlichiContentsModificaExecuter_05()
	{
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaPB5Processor.class, PlichiContentsModificaPB5ProcessorMock.class);
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("ContralisticaId1")).andReturn("");
		expecting(getStateMachineSession().get("ContralisticaId")).andReturn("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}
	public void testPlichiContentsModificaExecuter_06()
	{
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaPB5Processor.class, PlichiContentsModificaPB5ProcessorMock.class);
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("ContralisticaId1")).andReturn("");
		expecting(getStateMachineSession().get("ContralisticaId")).andReturn("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}
	public void testPlichiContentsModificaExecuter_07()
	{
		ClassificazioneWrapperMock.setTracciabilitaExternalServicesException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(PlichiContentsModificaPB5Processor.class, PlichiContentsModificaPB5ProcessorMock.class);
		final Stack stack=getStack();
		expecting(getStateMachineSession().get("ContralisticaId1")).andReturn("");
		expecting(getStateMachineSession().get("ContralisticaId")).andReturn("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567891234");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1234567891234");
		playAll();
		executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}

	private static Stack getStack()
	{
		final Stack stack=new Stack();
		stack.push("1");
		return stack;
	}
}
