package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TpTrSollecitiHeaderView;
import mockit.Mock;

public class SollecitiHeaderDataAccessMock 
{
	private static Boolean isTpTrSollecitiHeaderViewNull= false;

	public  static void setTpTrSollecitiHeaderViewNull() 
	{
		isTpTrSollecitiHeaderViewNull = true;
	}
	
	@Mock	
	public TpTrSollecitiHeaderView getViewById( final Long keyId ) throws TracciabilitaException 
	{
		TpTrSollecitiHeaderView tpTrSollecitiHeaderView = null;
		tpTrSollecitiHeaderView = new TpTrSollecitiHeaderView();
		if( isTpTrSollecitiHeaderViewNull )
		{
			isTpTrSollecitiHeaderViewNull = false;
			tpTrSollecitiHeaderView = null;
		}
		
		return tpTrSollecitiHeaderView;

	}

}
