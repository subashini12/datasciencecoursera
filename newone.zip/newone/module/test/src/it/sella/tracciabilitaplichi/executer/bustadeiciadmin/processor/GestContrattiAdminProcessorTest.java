package it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;


public class GestContrattiAdminProcessorTest extends AbstractSellaExecuterMock{

	GestContrattiAdminProcessor processor = null;
	RequestEvent requestEvent = null;
    
	public GestContrattiAdminProcessorTest(final String name) {
		super(name);
	}

	@Override
	@Before
	public void setUp() throws Exception {
		processor = new GestContrattiAdminProcessor() ;
	    this.requestEvent = createMock( RequestEvent.class );
	    Mockit.setUpMock(TPContrattiProdottoDataAccess.class,TPContrattiProdottoDataAccessMock.class);
	}
	
	@Override
	@After
	public void tearDown() throws Exception {
		processor = null;
		requestEvent = null;
	}
	
	public void testGestContrattiAdminProcessor_01() {
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("2");
		replay( this.requestEvent );
	    try {
			assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_02() {
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn("abc");
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_03() {
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("12a");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn("abc");
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_04() {
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn("abc");
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_05() {
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn("");
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_06() {
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("-1");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn("abc");
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_07() {
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("11");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn("abc");
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_08() {
		final String contrattiDesc ="abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_09() {
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("-1");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_10() {
		TPContrattiProdottoDataAccessMock.setCodeProdConExistsToTrue();
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_11() {
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_12() {
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("4");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("123");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	public void testGestContrattiAdminProcessor_13() {
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("abc");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testGestContrattiAdminProcessor_14() {
		final String contrattiDesc ="abcd";
		expect(this.requestEvent.getAttribute("ContrattiProdCont")).andReturn("1234");
		expect(this.requestEvent.getAttribute("ContrattiCod")).andReturn("34");
		expect(this.requestEvent.getAttribute("ProdottiId")).andReturn("12");
		expect(this.requestEvent.getAttribute("ContrattiDesc")).andReturn(contrattiDesc);
		expect(this.requestEvent.getAttribute("ContrattiFlagObbl")).andReturn("T");
		expect(this.requestEvent.getAttribute("contrattoDaControllare")).andReturn("2");
		expect(this.requestEvent.getAttribute("ContrattiId")).andReturn("1");
		expect(this.requestEvent.getAttribute("Imagini")).andReturn("0");
		expect(this.requestEvent.getAttribute("startingId")).andReturn("-2");
		replay( this.requestEvent );
	    try {
	    	assertNotNull(processor.validateEvent(this.requestEvent , "03268"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}	
}
