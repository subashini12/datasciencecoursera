package it.sella.tracciabilitaplichi.executer.test.gestoreplichi;

import it.sella.tracciabilitaplichi.executer.gestoreplichi.RiepilogoPlichiDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.PreparazionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.PreparazionePlichiCacheUtil;

public class RiepilogoPlichiDefaultExecuterTest extends AbstractSellaExecuterMock
{

	RiepilogoPlichiDefaultExecuter executer = new RiepilogoPlichiDefaultExecuter();
	
	public RiepilogoPlichiDefaultExecuterTest(final String name) 
	{
		super(name);		
	}
	
	public void testRiepilogoPlichiDefaultExecuter_01()
	{
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class , SecurityDBpersonaleWrapperMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class , TracciabilitaPlichiPlichiDataAccessMock.class );
		expecting( getStateMachineSession().get( "ConPageNumber" )).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testRiepilogoPlichiDefaultExecuter_02()
	{
		SecurityDBpersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class , SecurityDBpersonaleWrapperMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class , TracciabilitaPlichiPlichiDataAccessMock.class );
		expecting( getStateMachineSession().get( "ConPageNumber" )).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testRiepilogoPlichiDefaultExecuter_03()
	{
		SecurityDBpersonaleWrapperMock.setRemoteException();
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class , SecurityDBpersonaleWrapperMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class , TracciabilitaPlichiPlichiDataAccessMock.class );
		expecting( getStateMachineSession().get( "ConPageNumber" )).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}


}
