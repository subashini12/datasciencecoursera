package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.RicezioneExecuter;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultB10Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents.processor.PlichiContentsDefaultB10ProcessorMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Stack;

import mockit.Mockit;

public class RicezioneExecuterTest extends AbstractSellaExecuterMock
{
	public RicezioneExecuterTest(final String name) 
	{
		super(name);	
	}

	RicezioneExecuter executer = new RicezioneExecuter();
	
	public void testRicezioneExecuter_01()
	{
		setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting( getStateMachineSession().put( "PlichiContentsModified", Boolean.TRUE ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collControlliView" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().remove( "collControlliView" ) ).andReturn(null).anyTimes();	
		expecting( getStateMachineSession().containsKey( "Pagging" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().remove( "Pagging" ) ).andReturn(null).anyTimes();	
		expecting( getStateMachineSession().containsKey( "BarCodeStack" ) ).andReturn( Boolean.TRUE ).anyTimes();
		final Stack stack = new Stack( );
		stack.add("barCode");
		expecting( getStateMachineSession().get( "BarCodeStack" )).andReturn(  stack  ).anyTimes();
		expecting( getStateMachineSession().remove( "barCode" ) ).andReturn(null).anyTimes();	
		expecting( getRequestEvent().getAttribute( "Barcode" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drgg" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drmm" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "draa" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "user" )).andReturn( "01" ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testRicezioneExecuter_02()
	{
		PlichiContentsDefaultB10ProcessorMock.setMessage();
		setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting( getRequestEvent().getAttribute( "Barcode" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drgg" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drmm" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "draa" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "user" )).andReturn( "01" ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneExecuter_03()
	{
		PlichiContentsDefaultB10ProcessorMock.setTracciabilitaException();
		PlichiContentsDefaultB10ProcessorMock.setMessage();
		setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting( getRequestEvent().getAttribute( "Barcode" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drgg" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drmm" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "draa" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "user" )).andReturn( "01" ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneExecuter_04()
	{
		PlichiContentsDefaultB10ProcessorMock.setRemoteException();
		PlichiContentsDefaultB10ProcessorMock.setMessage();
		setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting( getRequestEvent().getAttribute( "Barcode" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drgg" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "drmm" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "draa" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "user" )).andReturn( "01" ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
}
