package it.sella.tracciabilitaplichi.executer.inserimentobustadieci;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;

import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class InputHandlerMock {

	@Mock
	public String getBarcode(final RequestEvent requestEvent) {
		return "1234567890123";
	}

	@Mock
	public Map<Enum<CONSTANTS>, String> getInserimentoContrattiInputParams( final RequestEvent requestEvent )
	{
		return new HashMap<Enum<CONSTANTS>, String>();
	}
}
