package it.sella.tracciabilitaplichi.implementation.borsaverde;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;

import java.sql.SQLException;

import mockit.Mock;

public class BorsaVerdeImplMock {

	@Mock
	public void censitoBorsaVerde(
			final BorsaVerdeAttributeView borsaVerdeAttributeView)
			throws SQLException, TracciabilitaException {
		return;
	}

	@Mock
	public void modifcaBorsaVerde(
			final BorsaVerdeAttributeView borsaVerdeAttributeView)
			throws SQLException, TracciabilitaException {
		return;
	}
}
