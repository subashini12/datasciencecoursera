package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPControlliDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TPControlliDataAccessMock;

import java.util.ArrayList;
import java.util.Stack;

import org.easymock.EasyMock;



public class CronistoriaEsitiExecuterTest extends AbstractSellaExecuterMock{

	public CronistoriaEsitiExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	
	CronistoriaEsitiExecuter executer=new CronistoriaEsitiExecuter();
	
	public void testCronistoriaEsitiExecuter_01()
	{
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		final Stack stack=getNullStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCronistoriaEsitiExecuter_02()
	{
		TPControlliDataAccessMock.setControlliViewByContrattoIdNotNull();
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		final Stack stack=getNotNullStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCronistoriaEsitiExecuter_03()
	{
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		final Stack stack=getNullStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCronistoriaEsitiExecuter_04()
	{
		TPControlliDataAccessMock.setRemoteException();
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		final Stack stack=getNotNullStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCronistoriaEsitiExecuter_05()
	{
		TPControlliDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TPControlliDataAccess.class, TPControlliDataAccessMock.class);
		final Stack stack=getNotNullStack();
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Stack getNullStack()
	{
		final Stack stack=new Stack();
		stack.push(null);
		return stack;
	}
	private static Stack getNotNullStack()
	{
		final Stack stack=new Stack();
		stack.push("1234567890123");
		return stack;
	}
	
}
