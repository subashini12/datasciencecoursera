package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestoreCodiceHostCancelliExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.admin.CodiceHostAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.CodiceHostAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPCodiceHostDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPCodiceHostDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import mockit.Mockit;

public class GestoreCodiceHostCancelliExecuterTestCase extends
		AbstractSellaExecuterMock {

	public GestoreCodiceHostCancelliExecuterTestCase(final String name) {
		super(name);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	GestoreCodiceHostCancelliExecuter gestoreCodiceHostCancelliExecuter = new GestoreCodiceHostCancelliExecuter();

	public void testGestoreCodiceHostCancelliExecuterTest_03() {
		TPCodiceHostDataAccessMock.setCodiceHostExists();
		setUpMockMethods(TPCodiceHostDataAccess.class,TPCodiceHostDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getAttribute("codiceHost")).andReturn("12345678");
		playAll();
		gestoreCodiceHostCancelliExecuter.execute(getRequestEvent());
	}

	public void testGestoreCodiceHostCancelliExecuterTest_04() {
		TPCodiceHostDataAccessMock.setCodiceHostExists();
		setUpMockMethods(TPCodiceHostDataAccess.class,TPCodiceHostDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("codiceHost")).andReturn("12");
		playAll();
		gestoreCodiceHostCancelliExecuter.execute(getRequestEvent());
	}

	public void testGestoreCodiceHostCancelliExecuterTest_05() {
			TPCodiceHostDataAccessMock.setTracciabilitaException();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(CodiceHostAdminImpl.class,CodiceHostAdminImplMock.class);
			setUpMockMethods(TPCodiceHostDataAccess.class,TPCodiceHostDataAccessMock.class);
			expecting(getRequestEvent().getAttribute("codiceHost")).andReturn(
					"12345678");
			playAll();
			gestoreCodiceHostCancelliExecuter
					.execute(getRequestEvent());
	}
	
	public void testGestoreCodiceHostCancelliExecuterTest_06() {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(CodiceHostAdminImpl.class,
				CodiceHostAdminImplMock.class);
		setUpMockMethods(TPCodiceHostDataAccess.class,
				TPCodiceHostDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("codiceHost")).andReturn(
				"12345678");
		playAll();
		gestoreCodiceHostCancelliExecuter
				.execute(getRequestEvent());
}
}
