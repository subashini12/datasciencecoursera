package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class FrequentiDestinazioneCdrAdminImplTest extends BasicJDBCTestCaseAdapter {

	FrequentiDestinazioneCdrAdminImpl frequentiDestinazioneCdrAdminImpl = new FrequentiDestinazioneCdrAdminImpl() ;
	
	public void testCensitoOggetto_exception2() throws SQLException {
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn(addColumn());
		result.addRow(addRow());
		statementHandler.prepareGlobalResultSet(result);
		try {
			frequentiDestinazioneCdrAdminImpl.censitoOggetto(null);
			assertTrue(true);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testModificaOggetto_exception2() throws SQLException {
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn(addColumn());
		result.addRow(addRow());
		statementHandler.prepareGlobalResultSet(result);
		try {
			frequentiDestinazioneCdrAdminImpl.modificaOggetto(null);
			assertTrue(true);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testCancelliOggetto_exception2() throws SQLException {
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn(addColumn());
		result.addRow(addRow());
		statementHandler.prepareGlobalResultSet(result);
		try {
			frequentiDestinazioneCdrAdminImpl.cancelliOggetto(null);
			assertTrue(true);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	private List addRow() {
		final List row= new ArrayList() ;
		row.add(21L);
		row.add(1L);
		row.add("099505");
		row.add("BSE ARCHIVIO DOCUMENTI");
		row.add(1L);
		return row;
	}

	private FrequentiDestinazioneCdrView getFrequentiDestinazioneCdrView() {
		final FrequentiDestinazioneCdrView frequentiDestinazioneCdrView = new FrequentiDestinazioneCdrView() ;
		frequentiDestinazioneCdrView.setBankId(1L);
		frequentiDestinazioneCdrView.setBankDescription("BSE ARCHIVIO DOCUMENTI");
		frequentiDestinazioneCdrView.setCdr("099505");
		frequentiDestinazioneCdrView.setPosizione(1L);
		frequentiDestinazioneCdrView.setId(21L);
		return frequentiDestinazioneCdrView ;
	}
	
	private List addColumn() {
		final List column= new ArrayList() ;
		column.add("WU_ID");
		column.add("WU_BANK");
		column.add("WU_CDR");
		column.add("WU_DESC");
		column.add("WU_ORDER_DISPLAY");
		return column ;
	}
	
}
