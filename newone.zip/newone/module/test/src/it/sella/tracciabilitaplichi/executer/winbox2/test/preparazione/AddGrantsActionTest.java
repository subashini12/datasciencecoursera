package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.AddGrantsAction;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsValidator;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.HelperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

public class AddGrantsActionTest extends AbstractSellaExecuterMock
{
    public AddGrantsActionTest( final String message )
    {
        super( message );
    }
    AddGrantsAction addGrantsAction = new AddGrantsAction();
    public void testExecuteAction( ) throws TracciabilitaException, RemoteException
    {
    	setUpMockMethods( Helper.class, HelperMock.class);         
        setUpMockMethods( GrantsValidator.class, GrantsValidatorMock.class );
        expecting( getRequestEvent().getAttribute( "cdr" ) ).andReturn("1").anyTimes();
        playAll();
        final Enum abc = addGrantsAction.executeAction(getRequestEvent());       
        assertNotNull(abc);
    }   
}
