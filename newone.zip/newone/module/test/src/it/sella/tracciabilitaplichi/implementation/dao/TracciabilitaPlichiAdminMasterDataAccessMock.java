package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.implementation.view.CdrGroupView;
import it.sella.tracciabilitaplichi.implementation.view.CompatibleBanksView;
import it.sella.tracciabilitaplichi.implementation.view.HostlIdAttributeView;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;

import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class TracciabilitaPlichiAdminMasterDataAccessMock {
	
	private static Boolean isInValidWinboxId = false;
	private static Boolean winBoxList = false;
	private static Boolean tracciabilitaException = false;
	private static Boolean isGroupListNotNull  = false;
	private static Boolean iscdrGroupViewTestNull = false;
	private static Boolean isCdrAdded2Group = false ;
	private static Boolean isValidCdrGroupId = false ;
	private static Boolean isHostlIdAttributeViewNull= false ;
	private static Boolean iscompatibleBanksViewNull= false ;
	private static Boolean isAltriWinboxViewNull= false ;

	public  static void setAltriWinboxViewIsNull()
	{
		isAltriWinboxViewNull = true;
	}
	public  static void setInValidWinboxId()
	{
		isInValidWinboxId = true;
	}

	public  static void setTracciabilitaException()
	{
		tracciabilitaException = true;
	}
	public  static void setWinBoxListNull()
	{
		winBoxList = true;
	}
	public static void setGrouplistNotNull()
	{
		isGroupListNotNull = true ;
	}
	public static void setcdrGroupViewTestNull()
	{
		iscdrGroupViewTestNull = true ;
	}
	public static void setisCdrAdded2Group()
	{
		isCdrAdded2Group = true ;
	}
	public static void setAsInValidCdrGroupId()
	{
		isValidCdrGroupId = true ;
	}
	public static void setHostlIdAttributeViewNull()
	{
		isHostlIdAttributeViewNull = true ;
	}

	public static void setcompatibleBanksViewNull()
	{
		iscompatibleBanksViewNull = true ;
	}

	@Mock
	public Collection getRicercaWinboxList( final AltriWinboxView altriWinboxSearchView ) throws TracciabilitaException
	{

		Collection winList = new ArrayList();
		if(!winBoxList)
		{
			winBoxList = false ;
			winList.add("abc");
		}
		else
			winList = null;
		return winList;
	}

	@Mock
	public Collection getRicercaCdrGroupList( final String cdr, final String group ) throws TracciabilitaException
	{
		final Collection ricercaCdrGroupList = new ArrayList();
		if( tracciabilitaException )
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if(isGroupListNotNull)
		{
			isGroupListNotNull = false;
			ricercaCdrGroupList.add("abcv");
		}
		return ricercaCdrGroupList ;
	}
	@Mock
	public boolean isCdrAdded2Group( final String group ) throws TracciabilitaException
	{
		Boolean flag = false;
		if(isCdrAdded2Group)
		{
			isCdrAdded2Group = false;
			flag = true ;
		}
		return flag ;
	}
	@Mock
	public CdrGroupView isCdrExists( final String cdr ) throws TracciabilitaException
	{
		CdrGroupView cdrView = new CdrGroupView();
		cdrView.setCdr("cdr");
		cdrView.setId(1L);
		if( iscdrGroupViewTestNull )
		{
			iscdrGroupViewTestNull = false ;
			cdrView = null ;
		}
		return cdrView;

	}
	@Mock
	public boolean isValidCdrGroupId( final String id ) throws TracciabilitaException
	{
		Boolean flag = true;
		if( isValidCdrGroupId )
		{
			isValidCdrGroupId = false ;
			flag = false ;
		}
		return flag ;
	}
	@Mock
	public CdrGroupView getCdrGroupView( final String id ) throws TracciabilitaException
	{
		if( tracciabilitaException )
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		final CdrGroupView cdrView = new CdrGroupView();
		cdrView.setCdr("cdr");
		cdrView.setId(1L);
		return cdrView;

	}
	@Mock
	public HostlIdAttributeView getHostlIdAttributeView( final String id ) throws TracciabilitaException
	{
		if( tracciabilitaException )
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		HostlIdAttributeView view = new HostlIdAttributeView();
		view.setHaId("1");
		view.setHaLid("02");
		if(isHostlIdAttributeViewNull)
		{
			isHostlIdAttributeViewNull = false ;
			view = null ;
		}
		return view ;
	}


	@Mock
	public boolean isValidWinboxId( final String id ) throws TracciabilitaException
	{
		Boolean flag = true;
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		if(isInValidWinboxId)
		{
			flag = false ;
		}
		return flag;
	}
	@Mock
	public CompatibleBanksView getCompatibleBanksView( final String id ) throws TracciabilitaException
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		CompatibleBanksView compBanks = new CompatibleBanksView();
		compBanks.setBankId(1L);
		compBanks.setId(1L);
		compBanks.setOtherBankId(1L);
		if( iscompatibleBanksViewNull )
		{
			iscompatibleBanksViewNull = false;
			compBanks = null;
		}
		return compBanks;
	}

	@Mock
	public AltriWinboxView getAltriWinboxView( final String id ) throws TracciabilitaException
	{
		AltriWinboxView altriWinboxView=new AltriWinboxView();
		if(isAltriWinboxViewNull)
		{
			altriWinboxView = null ;
		}
		return altriWinboxView ;
	}

	@Mock
	public Collection<Grants> getTailoredGrants( final Long praticaId ) throws TracciabilitaException {
		final Collection<Grants> grantsColl = new ArrayList<Grants>();
		final Grants grant1 = new Grants();
		grant1.setBarcode("12345");
		grant1.setCdrCode("BSSC6");
		grant1.setDescription("abcd");
		grant1.setId(1L);
		grant1.setIdSoggetto(-1L);
		grant1.setIsEnabled(true);
		final Grants grant2 = new Grants();
		grant1.setBarcode("123456");
		grant1.setCdrCode("BSSC7");
		grant1.setDescription("cdr");
		grant1.setId(1L);
		grant1.setIdSoggetto(2L);
		grant1.setIsEnabled(true);
		grantsColl.add(grant1);
		grantsColl.add(grant2);
		return grantsColl;
	}
}
