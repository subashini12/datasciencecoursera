package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichihistory;


import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class SituazionePlichiHistoryFiltraExecuterTest extends AbstractSellaExecuterMock{

	public SituazionePlichiHistoryFiltraExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SituazionePlichiHistoryFiltraExecuter executer=new SituazionePlichiHistoryFiltraExecuter();

	public void testSituazionePlichiHistoryFiltraExecuter_01()
	{
		final Map map=getMap();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryFiltraExecuter_02()
	{
		final Map map=getMapWithTypesOfOggettos();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiHistoryFiltraExecuter_03()
	{
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("A");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("C");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("F");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryFiltraExecuter_04()
	{
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("A");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("C");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("F");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiHistoryFiltraExecuter_07()
	{
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("A");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryFiltraExecuter_05()
	{
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final Map map=getMap();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("status");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("1");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("CDR");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("senderCdrDescription");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567897412");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("1");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	

	public void testSituazionePlichiHistoryFiltraExecuter_06()
	{
		final Map map=getMap();
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map);
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("");
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderCdrDescription")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Map getMap()
	{
		final OggettoView oggettoView=new OggettoView();
		oggettoView.setStatusId(Long.valueOf(1));
		oggettoView.setUserId("2");
		oggettoView.setLid("CS11");
		oggettoView.setOggettoTypeDesc(null);
		final PlichiAttributeView plichiAttributeView=new PlichiAttributeView();
		plichiAttributeView.setCdrDestination("CDR Destination");
		plichiAttributeView.setCdrDestDesc("CdrDestDesc");
		plichiAttributeView.setBarCode("1234567890123");
		final ArrayList arrayList=new ArrayList();
		final TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		tracciabilitaPlichiView.setPlichiAttributeView(plichiAttributeView);
		arrayList.add(tracciabilitaPlichiView);
		final Map map=new HashMap();
		map.put("RicercaCollPlichiView", arrayList);
		map.put("FilteredTypesOfOggettos", "");
		map.put("StatusViewList", "");
		return map;
	}
	
	private static Map getMapWithTypesOfOggettos()
	{
		final OggettoView oggettoView=new OggettoView();
		oggettoView.setStatusId(Long.valueOf(1));
		oggettoView.setOggettoTypeDesc("oggettoTypeDesc");
		final PlichiAttributeView plichiAttributeView=new PlichiAttributeView();
		plichiAttributeView.setCdrDestination("CDR Destination");
		final ArrayList arrayList=new ArrayList();
		final TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		tracciabilitaPlichiView.setPlichiAttributeView(plichiAttributeView);
		arrayList.add(tracciabilitaPlichiView);
		final Map map=new HashMap();
		map.put("RicercaCollPlichiView", arrayList);
		map.put("TypesOfOggettos", "");
		map.put("StatusViewList", "");
		return map;
	}
	
	}
