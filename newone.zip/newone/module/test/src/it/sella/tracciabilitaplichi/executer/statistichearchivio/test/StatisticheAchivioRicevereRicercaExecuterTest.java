package it.sella.tracciabilitaplichi.executer.statistichearchivio.test;

import it.sella.tracciabilitaplichi.executer.statistichearchivio.StatisticheAchivioRicevereRicercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;

public class StatisticheAchivioRicevereRicercaExecuterTest extends AbstractSellaExecuterMock
{

	public StatisticheAchivioRicevereRicercaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	
	StatisticheAchivioRicevereRicercaExecuter executer = new StatisticheAchivioRicevereRicercaExecuter();
	
	
	public void testExecuter_01()
	{
		
		TPUtilMock.setValidateDate(2);
		setUpMockMethods( TPUtil.class, TPUtilMock.class );
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("creazioneFromDay")).andReturn("21");
		expecting(getRequestEvent().getAttribute("creazioneFromMonth")).andReturn("10");
		expecting(getRequestEvent().getAttribute("creazioneFromYear")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("creazioneToDay")).andReturn("21");
		expecting(getRequestEvent().getAttribute("creazioneToMonth")).andReturn("10");
		expecting(getRequestEvent().getAttribute("creazioneToYear")).andReturn("2011");		
		expecting(getRequestEvent().getAttribute("ricezioneFromDay")).andReturn("21");
		expecting(getRequestEvent().getAttribute("ricezioneFromMonth")).andReturn("10");
		expecting(getRequestEvent().getAttribute("ricezioneFromYear")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("ricezioneToDay")).andReturn("10");
		expecting(getRequestEvent().getAttribute("ricezioneToMonth")).andReturn("21");
		expecting(getRequestEvent().getAttribute("ricezioneToYear")).andReturn("2011");
		playAll();
		executer.execute( getRequestEvent() );
	}
	
	public void testExecuter_02()
	{
		
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("creazioneFromDay")).andReturn("");
		expecting(getRequestEvent().getAttribute("creazioneFromMonth")).andReturn("10");
		expecting(getRequestEvent().getAttribute("creazioneFromYear")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("creazioneToDay")).andReturn("21");
		expecting(getRequestEvent().getAttribute("creazioneToMonth")).andReturn("10");
		expecting(getRequestEvent().getAttribute("creazioneToYear")).andReturn("2011");		
		expecting(getRequestEvent().getAttribute("ricezioneFromDay")).andReturn("21");
		expecting(getRequestEvent().getAttribute("ricezioneFromMonth")).andReturn("10");
		expecting(getRequestEvent().getAttribute("ricezioneFromYear")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("ricezioneToDay")).andReturn("10");
		expecting(getRequestEvent().getAttribute("ricezioneToMonth")).andReturn("21");
		expecting(getRequestEvent().getAttribute("ricezioneToYear")).andReturn("2011");
		playAll();
		executer.execute( getRequestEvent() );
	}
	
}
