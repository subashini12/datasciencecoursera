package it.sella.tracciabilitaplichi.executer.winbox2.preparazione;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class GrantsHelperMock {
@Mock
public static Collection<Grants> getGrants( final Long praticaId ) throws TracciabilitaException, RemoteException
{
	final Collection<Grants> grantsCollection = new ArrayList<Grants>() ;
	final Grants grants = new Grants() ;
	grants.setBarcode("1234567891234");
	grantsCollection.add(grants);
	return grantsCollection ;
}
@Mock
public static String getCDR( final Long idSoggetto ) throws TracciabilitaException, RemoteException {
	return "GBS03094";
}
}
