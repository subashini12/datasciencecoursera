package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalSecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalSecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CompatibleBanksView;

import java.rmi.RemoteException;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TracciabilitaPlichiBustasDataAccessTest {

	TracciabilitaPlichiBustasDataAccess dataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		dataAccess = new TracciabilitaPlichiBustasDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		dataAccess = null;
	}

	@Test
	public void isCompatibleBanksExist() throws TracciabilitaException{
		final CompatibleBanksView compatibleBanksView= new CompatibleBanksView();
		compatibleBanksView.setBankId(Long.valueOf("1"));
		compatibleBanksView.setId(Long.valueOf("2"));
		compatibleBanksView.setOtherBankId(Long.valueOf("3"));
		mockStatementProvider = new MockStatementProvider("SELECT 1 FROM TP_MA_COMPATIBLE_BANKS WHERE CB_BANK  =? AND CB_OTHER_BANK=?");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 1,"ST_01");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertTrue(dataAccess.isCompatibleBanksExist(compatibleBanksView));
	}
	@Test
	public void isValidLid() throws RemoteException, TracciabilitaException{
		Mockit.setUpMock(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(ExternalSecurityWrapper.class,ExternalSecurityWrapperMock.class);
		Assert.assertTrue(dataAccess.isValidLid("I56"));
	}

}
