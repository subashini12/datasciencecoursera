/*package it.sella.tracciabilitaplichi.executer.test.gestionepropertiesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.PropertyShowConfermaExecuter;
import it.sella.tracciabilitaplichi.implementation.InvioSollecitiPropertiesImpl;
import it.sella.tracciabilitaplichi.implementation.InvioSollecitiPropertiesImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.TpMaPropertiesView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;

public class PropertyShowConfermaExecuterTest {

	PropertyShowConfermaExecuter propertyShowConfermaExecuter = new PropertyShowConfermaExecuter();

	@Test
	public void propertyShowConfermaExecuter_01()
	{
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(InvioSollecitiPropertiesImpl.class, InvioSollecitiPropertiesImplMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(stateMachineSession.get(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn((Serializable) getHashMap()).anyTimes();
		EasyMock.expect(stateMachineSession.containsKey( ITPConstants.INSERISCI)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = propertyShowConfermaExecuter.execute( requestEvent );
		Assert.assertEquals(executeResult.getTransition(), null );
	}

	@Test
	public void propertyShowConfermaExecuter_02()
	{
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(InvioSollecitiPropertiesImpl.class, InvioSollecitiPropertiesImplMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(stateMachineSession.get(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn((Serializable) getHashMap()).anyTimes();
		EasyMock.expect(stateMachineSession.containsKey( ITPConstants.INSERISCI)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = propertyShowConfermaExecuter.execute( requestEvent );
		Assert.assertEquals(executeResult.getTransition(), null );
	}
	
	@Test
	public void propertyShowConfermaExecuter_03()
	{
		Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(InvioSollecitiPropertiesImpl.class, InvioSollecitiPropertiesImplMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(stateMachineSession.get(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn((Serializable) getHashMap()).anyTimes();
		EasyMock.expect(stateMachineSession.containsKey( ITPConstants.INSERISCI)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		propertyShowConfermaExecuter.execute( requestEvent );
	}
	
	
	private static Map getHashMap()
	{
		final TpMaPropertiesView tpMaPropertiesView = new TpMaPropertiesView("","");
		final Map map= new HashMap();
		map.put(ITPConstants.TP_MA_PROPERTIES_VIEW, tpMaPropertiesView);
		map.put(ITPConstants.ELIMINA, "");
		return map ;
	}
}
*/