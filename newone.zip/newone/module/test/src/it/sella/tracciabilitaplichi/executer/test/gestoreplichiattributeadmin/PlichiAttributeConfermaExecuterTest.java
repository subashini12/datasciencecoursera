package it.sella.tracciabilitaplichi.executer.test.gestoreplichiattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestoreplichiattributeadmin.PlichiAttributeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;

import java.util.Hashtable;

public class PlichiAttributeConfermaExecuterTest extends AbstractSellaExecuterMock
{
	PlichiAttributeConfermaExecuter executer = new PlichiAttributeConfermaExecuter();
	
	public PlichiAttributeConfermaExecuterTest(final String name) 
	{
		super(name);
	}
	
	public void testPlichiAttributeConfermaExecuter_01()
	{
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods( DBPersonaleWrapper.class , DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	
	public void testPlichiAttributeConfermaExecuter_02()
	{
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	public void testPlichiAttributeConfermaExecuter_03()
	{   
		TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	public void testPlichiAttributeConfermaExecuter_04()
	{
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	
	public void testPlichiAttributeConfermaExecuter_05()
	{
		DBPersonaleWrapperMock.setValidCdrFalse();
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class );
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	
	public void testPlichiAttributeConfermaExecuter_06()
	{
		SecurityWrapperMock.setValidCdrFalse();
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class );
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	
	public void testPlichiAttributeConfermaExecuter_07()
	{
		SecurityWrapperMock.setValidCdrFalse();
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class );
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	
	public void testPlichiAttributeConfermaExecuter_08()
	{
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods( DBPersonaleWrapper.class , DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	public void testPlichiAttributeConfermaExecuter_09()
	{
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods( DBPersonaleWrapper.class , DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	public void testPlichiAttributeConfermaExecuter_forTracciabilitaException()
	{
		DBPersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods( DBPersonaleWrapper.class , DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	public void testPlichiAttributeConfermaExecuter_forRemoteException()
	{
		DBPersonaleWrapperMock.setRemoteException();
		setUpMockMethods( TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods( DBPersonaleWrapper.class , DBPersonaleWrapperMock.class);
		setUpMockMethods( SecurityWrapper.class , SecurityWrapperMock.class);
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "DocId" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "Barcode" ) ).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute( "CdrDest" ) ).andReturn("0676").anyTimes();
		expecting( getRequestEvent().getAttribute( "ControllerUser" ) ).andReturn("BS123").anyTimes();
		expecting( getRequestEvent().getAttribute( "NoteForDest" ) ).andReturn("Hi").anyTimes();
		expecting( getRequestEvent().getAttribute( "UserDest" ) ).andReturn("Hye").anyTimes();
		expecting( getRequestEvent().getAttribute( "BankDest" ) ).andReturn("01").anyTimes();
		expecting( getStateMachineSession().get("PlichiTable")).andReturn( getplichiHashTable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent()); 
	}
	private Hashtable getplichiHashTable()
	{
		
		final Hashtable plichiAttributeHashtable = new Hashtable ();
		plichiAttributeHashtable.put( "OldPlichiAttributeView", getplichiAttributeView());
		plichiAttributeHashtable.put( "OldPlichiAttributeView", getplichiAttributeView());
		return plichiAttributeHashtable ;
	}
	
	private PlichiAttributeView getplichiAttributeView()
	{
		final PlichiAttributeView plView = new PlichiAttributeView();
		plView.setBankDescription("bankDescription");
		return plView ;
	}

}
