package it.sella.tracciabilitaplichi.executer.gestorericezionesmistemento;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Hashtable;

public class RedirectRicezioneSmistementoErrorExecuterTest extends AbstractSellaExecuterMock {

	public RedirectRicezioneSmistementoErrorExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RedirectRicezioneSmistementoErrorExecuter executer = new RedirectRicezioneSmistementoErrorExecuter();

	public void testRedirectRicezioneSmistementoErrorExecuter_01() {
		expecting( getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(true);
		expecting( getStateMachineSession().get( "RicezioneSmistementoHashTable" )).andReturn(  getricezioneSmistementoHashtable()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private Hashtable getricezioneSmistementoHashtable()
	{
		Hashtable RicezioneSmistementoHashTable = new Hashtable();
		RicezioneSmistementoHashTable.put("ValidBarCodeButNotInRequiredState","abc");
		RicezioneSmistementoHashTable.put("PBarcode","abc");
		RicezioneSmistementoHashTable.put("StateOfPlichi","abc");
		return RicezioneSmistementoHashTable;		
	}
}
