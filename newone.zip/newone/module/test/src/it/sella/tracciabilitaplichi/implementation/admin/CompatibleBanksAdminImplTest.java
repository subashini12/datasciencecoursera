package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CompatibleBanksView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;

import mockit.Mockit;

import org.junit.Assert;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class CompatibleBanksAdminImplTest extends BasicJDBCTestCaseAdapter {

	CompatibleBanksAdminImpl compatibleBanksAdminImpl = new CompatibleBanksAdminImpl();
	
	private CompatibleBanksView getCompatibleBanksView()
	{
		final CompatibleBanksView compatibleBanksView = new CompatibleBanksView() ;
		compatibleBanksView.setOtherBankId(1L);
		compatibleBanksView.setBankId(57992L);
		compatibleBanksView.setId(162L);
		return compatibleBanksView ;
	}
	
	public void testCancelliOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CB_ID", new Object[] { 162L });
		statementHandler.prepareGlobalResultSet(result);
		try {
			compatibleBanksAdminImpl.cancelliOggetto(getCompatibleBanksView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testCancelliOggetto_02() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CB_ID", new Object[] { 162L });
		statementHandler.prepareGlobalResultSet(result);
		try {
			compatibleBanksAdminImpl.cancelliOggetto(null);
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	
	public void testCensitoOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CB_ID", new Object[] { 162L });
		statementHandler.prepareGlobalResultSet(result);
		try {
			compatibleBanksAdminImpl.censitoOggetto(getCompatibleBanksView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}

	public void testCensitoOggetto_02() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);		
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CB_ID", new Object[] { 162L });
		statementHandler.prepareGlobalResultSet(result);
		try {
			compatibleBanksAdminImpl.censitoOggetto(null);
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testModificaOggetto()
	{
		try {
			compatibleBanksAdminImpl.modificaOggetto(null);
		} catch (final TracciabilitaException e) {
			Assert.assertNotNull(e);
		}
	}
}
