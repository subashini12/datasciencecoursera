/*package it.sella.tracciabilitaplichi.implementation.borsaverde;

import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;

import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class BorsaVerdeImplTest extends BasicJDBCTestCaseAdapter{

	public BorsaVerdeImplTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	BorsaVerdeImpl borsaVerdeImpl = new BorsaVerdeImpl() ;
	
	public void testCensitoBorsaVerde_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(AbstractBorsaVerdeImpl.class,AbstractBorsaVerdeImplMock.class);
		final MockConnection connection= getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BV_ID",new Object[]{"1"});
		result.addColumn("BV_DOC_ID",new Object[]{"1"});
		result.addColumn("BV_CODE_ID",new Object[]{"1"});
		result.addColumn("BV_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BV_CREATION_DATE",new Object[]{"1"});
		result.addColumn("BV_ID_SUCC",new Object[]{"1"});
		result.addColumn("BV_CDR_DESTINATION",new Object[]{"1"});
		try {
			borsaVerdeImpl.censitoBorsaVerde(getBorsaVerdeAttributeView());
		} catch (final SQLException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}

	public BorsaVerdeAttributeView getBorsaVerdeAttributeView()
	{
		final BorsaVerdeAttributeView borsaVerdeAttributeView = new BorsaVerdeAttributeView() ;
		borsaVerdeAttributeView.setStatusId(1L);
		borsaVerdeAttributeView.setDocumentId(1L);
		borsaVerdeAttributeView.setCode("");
		borsaVerdeAttributeView.setIdSucc(1L);
		return borsaVerdeAttributeView ;
	}
}
*/