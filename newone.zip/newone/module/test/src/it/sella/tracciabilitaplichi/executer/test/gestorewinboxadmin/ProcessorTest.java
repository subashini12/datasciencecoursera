package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

public class ProcessorTest extends AbstractSellaExecuterMock
{
    public ProcessorTest( final String name )
    {
        super( name );
    }

    @Override
	protected void setUp( ) throws Exception
    {
        super.setUp( );
    }
    @Override
	protected void tearDown( )
    {
    }
   
    public void testValidate1( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "-1";
        final String abilitato = "1";
        final String desc = "TEST" ;
        assertEquals( IErrorCodes.TRPL_1566, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc, null )[ 0 ] );
    }
    public void testValidate2( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "1";
        final String abilitato = "-1";
        final String desc = "TEST" ;
        assertEquals( IErrorCodes.TRPL_1566, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc, null )[ 0 ] );
    }
    public void testValidate3( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "1";
        final String abilitato = "1";
        final String desc = null;
        assertEquals( IErrorCodes.TRPL_1566, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc, null )[ 0 ] );
    }
    public void testValidate4( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "-1";
        final String abilitato = "1";
        final String desc = "TEST";
        assertEquals( null, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc )[ 0 ] );
    }
    public void testValidate5( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "1";
        final String abilitato = "-1";
        final String desc = "TEST";
        assertEquals( null, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc )[ 0 ] );
    }
    public void testValidate6( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "1";
        final String abilitato = "1";
        final String desc = null;
        assertEquals( null, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc )[ 0 ] );
    }
    public void testValidate7( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "-1";
        final String abilitato = "-1";
        final String desc = null;
        assertEquals( IErrorCodes.TRPL_1059, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc )[ 0 ] );
    }
    public void testValidate8( ) throws TracciabilitaException, RemoteException
    {
        final String tipoOggetto = "1";
        final String abilitato = "1";
        final String desc = "TEST";
        assertEquals( null, Processor.getInstance( ).validate( tipoOggetto, abilitato, desc )[ 0 ] );
    }
    
    public void testIsPratica_01()
    {
    	expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("1").anyTimes();
    	expecting(getStateMachineSession().get(CONSTANTS.CLASSIFICAZIONE_MAP.getValue( ))).andReturn((Serializable) getMap());
    	playAll();
    	Processor.getInstance().isPratica(getRequestEvent());
    }
    
    public void testValidate_01()
    {
    	UtilMock.setCheckNullFalse();
    	DBPersonaleWrapperMock.setValidCdrFalse();
    	setUpMockMethods(Util.class, UtilMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
    	try {
			Processor.getInstance().validate("", "", "", "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
    }
    
    private Map<Long,String> getMap()
    {
    	final Map<Long,String> map = new HashMap<Long, String>();
    	map.put(1L, "Pratica");
    	return map ;
    }
}
