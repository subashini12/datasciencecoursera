package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.mock.DBHelperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ChannelDefinitionView;
import it.sella.tracciabilitaplichi.implementation.view.ChannelElementsView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Hashtable;
import java.util.Map.Entry;

import junit.framework.Assert;
import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TPMultiChannelDataAccessTest {

	TPMultiChannelDataAccess tpMultiChannelDataAccess=new TPMultiChannelDataAccess();

	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private DBHelperMock dbHelperMock;

	@Before
	public void setUp() throws Exception {
		tpMultiChannelDataAccess = new TPMultiChannelDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		dbHelperMock = new DBHelperMock();
		dbHelperMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(DBConnector.class, dbHelperMock);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
	}

	@After
	public void tearDown() throws Exception {
		tpMultiChannelDataAccess = null;
	}

	@Test
	public void getAllChannelDefinition() throws TracciabilitaException
	{
		Long key = null;
		ChannelDefinitionView channelDefinitionView = null;
		final String query = "SELECT CD_ID, CD_NAME, CD_DEADLINE FROM TP_MA_CHANNEL_DEFINITION";
		mockStatementProvider = new MockStatementProvider(query);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, "CD_ID",Long.valueOf("2"));
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, "CD_NAME","ravi");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 3, "CD_DEADLINE",Long.valueOf("5"));
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Hashtable<Long,ChannelDefinitionView> channelCollection = tpMultiChannelDataAccess.getAllChannelDefinition();
		for(final Entry<Long, ChannelDefinitionView> entry : channelCollection.entrySet()) {
			key = entry.getKey();
			channelDefinitionView = entry.getValue();
		}
		Assert.assertEquals("ravi", channelDefinitionView.getChannelName());
		Assert.assertEquals(Long.valueOf("5"), channelDefinitionView.getChannelDeadline());
	}

	@Test
	public void getAllChannelElements() throws TracciabilitaException
	{
		Long key = null;
		ChannelElementsView channelElementsView = null;
		final String query = "SELECT CE_ID, CE_ID_CHANNEL, CE_ELEMENT_VALUE, CE_BANK FROM TP_MA_CHANNEL_ELEMENTS";
		mockStatementProvider = new MockStatementProvider(query);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, "CE_ID",Long.valueOf("2"));
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 2, "CE_ID_CHANNEL",Long.valueOf("3"));
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 3, "CE_ELEMENT_VALUE","ravi");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 4, "CE_BANK",Long.valueOf("5"));
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Hashtable<Long,ChannelElementsView> channelCollection = tpMultiChannelDataAccess.getAllChannelElements();
		for(final Entry<Long, ChannelElementsView> entry : channelCollection.entrySet()) {
			key = entry.getKey();
			channelElementsView = entry.getValue();
		}
		Assert.assertEquals("ravi", channelElementsView.getChannelElementValue());
		Assert.assertEquals(Long.valueOf("5"), channelElementsView.getIdBanca());
	}
}
