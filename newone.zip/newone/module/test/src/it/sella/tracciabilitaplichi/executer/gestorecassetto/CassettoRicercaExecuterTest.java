package it.sella.tracciabilitaplichi.executer.gestorecassetto;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCassettoDataAccessMock;

import java.util.Collection;

import org.easymock.EasyMock;

public class CassettoRicercaExecuterTest extends AbstractSellaExecuterMock {
	public CassettoRicercaExecuterTest(final String name) {
		super(name);
	}

	CassettoRicercaExecuter executer = new CassettoRicercaExecuter();

	public void testCassettoRicercaExecuter_01() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testCassettoRicercaExecuter_02() {
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testCassettoRicercaExecuter_03() {
		TracciabilitaPlichiCassettoDataAccessMock.setTracciabilitaDataAccessException();
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
}
