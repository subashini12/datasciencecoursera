package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;
import java.util.Hashtable;


public class PlichiContentsModificaPBNProcessorTest extends AbstractSellaExecuterMock{

	public PlichiContentsModificaPBNProcessorTest(final String name) {
		super(name);
	}

	PlichiContentsModificaPBNProcessor processor = new PlichiContentsModificaPBNProcessor() ;
	
	public void testPlichiContentsModificaPBNProcessor_01()
	{
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("cdrName1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyPBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaPBNProcessor_02()
	{
		TracciabilitaPlichiPlichiContentsDataAccessMock.setExistNonDeletedPlichi();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("cdrName1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyPBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable () ;
		return hashtable;
	}
	
}
