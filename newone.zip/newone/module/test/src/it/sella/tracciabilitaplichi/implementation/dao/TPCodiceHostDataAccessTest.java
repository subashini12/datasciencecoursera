package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CodiceHostView;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class TPCodiceHostDataAccessTest  {

	TPCodiceHostDataAccess tpCodiceHostDataAccess=new TPCodiceHostDataAccess();
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		tpCodiceHostDataAccess = new TPCodiceHostDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		tpCodiceHostDataAccess = null;
	}

	@Test
	public void isCodiceHostExists() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getIsCodiceHostExistsSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1,1,"12");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertEquals(Boolean.TRUE, tpCodiceHostDataAccess.isCodiceHostExists("8cifre"));
	}

	@Test
	public void isCodiceExists()throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getIsCodiceExistsQuery());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1,1,"11");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertEquals(Boolean.TRUE, tpCodiceHostDataAccess.isCodiceExists(1l,"8cifre"));
	}

	@Test
	public void getCodiceHostDetail() throws TracciabilitaException{
		//Mockit.setUpMock(Util.class,UtilMock.class);
		mockStatementProvider = new MockStatementProvider(getCodiceHostDetailSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 0, "CH_ID","2");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "CH_BANK_ID","3");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, "CH_8CIFRE","12121212");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 4,"10/04/1985");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 5,"10/05/1985");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final CodiceHostView codiceHostView = tpCodiceHostDataAccess.getCodiceHostDetail("12121212");
		Assert.assertEquals(Long.valueOf(3l),codiceHostView.getBankId());
	}

	private String getCodiceHostDetailSt(){
		return "SELECT CH_ID, CH_BANK_ID, CH_8CIFRE, to_char(CH_FROM_DATE,'dd/MM/yyyy'), to_char(CH_TO_DATE,'dd/MM/yyyy') FROM TP_MA_B10_CODICEHOST WHERE CH_8CIFRE  = ?";
	}

	private String getIsCodiceExistsQuery(){
		return "SELECT CH_ID FROM TP_MA_B10_CODICEHOST WHERE CH_BANK_ID = ? AND CH_8CIFRE = ? AND (CH_FROM_DATE < sysdate AND CH_TO_DATE > sysdate OR CH_TO_DATE is null)";
	}

	private String getIsCodiceHostExistsSt(){
		return "SELECT CH_ID FROM TP_MA_B10_CODICEHOST WHERE CH_8CIFRE = ?";
	}
}
