/*package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoPlichiBusta5InsersciConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Hashtable;

import mockit.Mockit;

public class ArchivoPlichiBusta5InsersciConfermaExecuterTest extends
		AbstractSellaExecuterTest {

	ArchivoPlichiBusta5InsersciConfermaExecuter archivoPlichiBusta5InsersciConfermaExecuter = new ArchivoPlichiBusta5InsersciConfermaExecuter();

	public ArchivoPlichiBusta5InsersciConfermaExecuterTest(final String name) {
		super(name);
	}

	public void testArchivoPlichiBusta5InsersciConfermaExecuter_01() {
		TracciabilitaPlichiCommonDataAccessMock.setValidBoxId();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		archivoBustaCinqueSession.put("TracciabilitaPlichiView",
				new TracciabilitaPlichiView());
		archivoBustaCinqueSession.put("BarCodePlico", "");
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		expecting(getRequestEvent().getAttribute("casetto")).andReturn("1234");
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5InsersciConfermaExecuter
				.execute(getRequestEvent());
	}

	public void testArchivoPlichiBusta5InsersciConfermaExecuter_02() {
		UtilMock.setNumericFalse();
		TracciabilitaPlichiCommonDataAccessMock.setValidBoxId();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		archivoBustaCinqueSession.put("TracciabilitaPlichiView",
				new TracciabilitaPlichiView());
		archivoBustaCinqueSession.put("BarCodePlico", "");
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		expecting(getRequestEvent().getAttribute("casetto")).andReturn("");
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5InsersciConfermaExecuter
				.execute(getRequestEvent());
	}
	
	public void testArchivoPlichiBusta5InsersciConfermaExecuter_03() {
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		archivoBustaCinqueSession.put("TracciabilitaPlichiView",
				new TracciabilitaPlichiView());
		archivoBustaCinqueSession.put("BarCodePlico", "");
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		expecting(getRequestEvent().getAttribute("casetto")).andReturn("124");
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5InsersciConfermaExecuter
				.execute(getRequestEvent());
		}
	
	public void testArchivoPlichiBusta5InsersciConfermaExecuter_04() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		archivoBustaCinqueSession.put("TracciabilitaPlichiView",
				new TracciabilitaPlichiView());
		archivoBustaCinqueSession.put("BarCodePlico", "");
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		expecting(getRequestEvent().getAttribute("casetto")).andReturn("124");
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5InsersciConfermaExecuter
				.execute(getRequestEvent());
	}
	
	public void testArchivoPlichiBusta5InsersciConfermaExecuter_05() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,
				ClassificazioneWrapperMock.class);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		archivoBustaCinqueSession.put("TracciabilitaPlichiView",
				new TracciabilitaPlichiView());
		archivoBustaCinqueSession.put("BarCodePlico", "");
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		expecting(getRequestEvent().getAttribute("casetto")).andReturn("124");
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5InsersciConfermaExecuter
				.execute(getRequestEvent());
	}
}
*/