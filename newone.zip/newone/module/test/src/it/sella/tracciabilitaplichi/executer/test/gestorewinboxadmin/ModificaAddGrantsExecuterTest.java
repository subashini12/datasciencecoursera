package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;


import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.ModificaAddGrantsExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsValidator;
import it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione.GrantsValidatorMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.persistence.dao.TailoredGrantsImpl;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.dto.TailoredGrants;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ModificaAddGrantsExecuterTest extends AbstractSellaExecuterMock
{
	final ModificaAddGrantsExecuter modificaAddGrantsExecuter = new ModificaAddGrantsExecuter();
	
	public ModificaAddGrantsExecuterTest(final String name) 
	{
		super(name);
	}	

	public void testAddGrants_withoutErrorMessage()
	{   		
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("082882").anyTimes();		
		expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn((Serializable) getAltriWinboxTable()).anyTimes();
		playAll();
		setUpMockMethods(TailoredGrantsImpl.class, TailoredGrantsImplMock.class);
		setUpMockMethods(GrantsValidator.class, GrantsValidatorMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		modificaAddGrantsExecuter.execute(getRequestEvent());
	}
		
	public void testAddGrants_withErrorMessage()
	{   		
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("082882").anyTimes();	
		final Map map = getAltriWinboxTable();
		map.put(CONSTANTS.ERROR_MESSAGE, "ErrorMessage");
		expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn((Serializable) map).anyTimes();
		playAll();
		setUpMockMethods(TailoredGrantsImpl.class, TailoredGrantsImplMock.class);
		setUpMockMethods(GrantsValidator.class, GrantsValidatorMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		modificaAddGrantsExecuter.execute(getRequestEvent());
	}
	public void testAddGrants_ForTracciabilitaException()
	{   		
		TailoredGrantsImplMock.setTracciabilitaException();
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("082882").anyTimes();		
		expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn((Serializable) getAltriWinboxTable()).anyTimes();
		playAll();
		setUpMockMethods(TailoredGrantsImpl.class, TailoredGrantsImplMock.class);
		setUpMockMethods(GrantsValidator.class, GrantsValidatorMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		modificaAddGrantsExecuter.execute(getRequestEvent());
	}
	
    private Map getAltriWinboxTable()
	{
		final Map altriWindowTableMap = new HashMap();
		final AltriWinboxView altriWinboxView = new AltriWinboxView();
		final TailoredGrants tailoredGrants = new TailoredGrants();
		final Collection<Grants> collection = new ArrayList<Grants>();
		final Grants grants = new Grants();
		grants.setId(Long.valueOf(12));
		grants.setIdSoggetto(Long.valueOf(13));
		collection.add(grants);
		tailoredGrants.setGrants(collection);
		altriWinboxView.setCustomAccess(Byte.valueOf("0"));
		altriWinboxView.setId(Long.valueOf(12));
		altriWinboxView.setTailoredGrants(tailoredGrants);
		altriWindowTableMap.put("OldAltriWinboxView", altriWinboxView);
		return altriWindowTableMap;
	}

   
}




