/*package it.sella.tracciabilitaplichi.implementation;


import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import mockit.Mockit;

import org.junit.Before;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.StatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

public class BustaDeiciControlliImplTest extends BasicJDBCTestCaseAdapter{
	
	BustaDeiciControlliImpl bustaDeiciControlliImpl=new BustaDeiciControlliImpl();

	@Override
	@Before
	public void setUp() throws Exception {
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, MockRunnerConnection.class);
	}

	public void testCensitoOggetto_01()
	{
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final StatementResultSetHandler statementHandler = 
            connection.getStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID ");
		result.addColumn("CL_DATA");
		result.addColumn("CL_COD_DIP");
		result.addColumn("CL_CONTRATTO_ID");
		result.addColumn("CL_ID_ESITO");
		result.addColumn("CL_NOTE");
		final List controlliList=new ArrayList();
		controlliList.add(0, 1);
		controlliList.add(1, "2011-10-10");
		controlliList.add(2, "");
		controlliList.add(3, 1L);
		controlliList.add(4, "");
		controlliList.add(5, "NOTE FILED");
		result.addRow(controlliList);
		final ControlliView controlliView=getControlliView();
		final Properties properties=getProperties(controlliView);
		statementHandler.prepareResultSet("INSERT INTO TP_TR_B10_CONTROLLI(CL_ID,CL_DATA,CL_COD_DIP,CL_CONTRATTO_ID,CL_ID_ESITO,CL_NOTE) VALUES(TP_SQ_B10_CONTROLLI_ID.NEXTVAL,?,?,?,?,?)", result);
		try {
			bustaDeiciControlliImpl.censitoOggetto(properties);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		} catch (final RemoteException e) {
			e.printStackTrace();
		}
	}
	
	
	public void testModificaOggetto_01()
	{
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final StatementResultSetHandler statementHandler = 
            connection.getStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID_ESITO");
		result.addColumn("CL_NOTE");
		result.addColumn("CL_DATA");
		result.addColumn("CL_COD_DIP");
		result.addColumn("CL_CONTRATTO_ID");
		result.addColumn("CL_ID");
		final ControlliView controlliView=getNullValuesControlliView();
		final Properties properties=getProperties(controlliView);
		statementHandler.prepareResultSet("UPDATE TP_TR_B10_CONTROLLI SET CL_ID_ESITO = ?,CL_NOTE = ?,CL_DATA = ?, CL_COD_DIP = ?, CL_CONTRATTO_ID = ? WHERE CL_ID = ?", result );
		try {
			bustaDeiciControlliImpl.modificaOggetto(properties);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private static ControlliView getNullValuesControlliView()
	{
		final Date date=new Date(2012, 12, 10);
		final Timestamp dataControllo=new Timestamp(date.getDate());
		final ControlliView controlliView=new ControlliView();
		controlliView.setNote(null);
		controlliView.setIdEsito(null);
		controlliView.setContrattoId(null);
		controlliView.setDataControllo(dataControllo);
		controlliView.setControlliId(2L);
		controlliView.setCodDipControllo("");
		return controlliView;
	}
	
	public void testModificaOggetto_02()
	{
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final StatementResultSetHandler statementHandler = 
            connection.getStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID_ESITO");
		result.addColumn("CL_NOTE");
		result.addColumn("CL_DATA");
		result.addColumn("CL_COD_DIP");
		result.addColumn("CL_CONTRATTO_ID");
		result.addColumn("CL_ID");
		final ControlliView controlliView=getControlliView();
		final Properties properties=getProperties(controlliView);
		statementHandler.prepareResultSet("UPDATE TP_TR_B10_CONTROLLI SET CL_ID_ESITO = ?,CL_NOTE = ?,CL_DATA = ?, CL_COD_DIP = ?, CL_CONTRATTO_ID = ? WHERE CL_ID = ?", result );
		try {
			bustaDeiciControlliImpl.modificaOggetto(properties);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private static Properties getProperties(final ControlliView controlliView) {
		final Properties properties=new Properties();
		properties.put("ControlliView", controlliView);
		return properties;
	}
	
	private static ControlliView getControlliView()
	{
		final Date date=new Date(2012, 12, 10);
		final Timestamp dataControllo=new Timestamp(date.getDate());
		final ControlliView controlliView=new ControlliView();
		controlliView.setNote("");
		controlliView.setIdEsito(1L);
		controlliView.setContrattoId(2L);
		controlliView.setDataControllo(dataControllo);
		controlliView.setControlliId(2L);
		controlliView.setCodDipControllo("");
		return controlliView;
	}
	
}
*/