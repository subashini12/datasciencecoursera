package it.sella.tracciabilitaplichi.executer.test.gestorebustanera;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.BustaNeraConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import mockit.Mockit;

public class BustaNeraConfermaExecuterTest extends AbstractSellaExecuterMock
{
	private RequestEvent requestEvent = null;
	private StateMachineSession session = null;

	public BustaNeraConfermaExecuterTest( final String name )
	{
		super( name );
	}
	
	@Override
	public void setUp( ) throws Exception
	{
		super.setUp( );
		this.requestEvent = createMock( RequestEvent.class );
		this.session = createMock( StateMachineSession.class );
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	}

	@Override
	public void tearDown( )
	{
		requestEvent = null;
		session = null;
		
	}
	
	public void testBNConfermaExecuter1( )
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		//mockRequestParams( "AA11234567", "SBAI08", "Note for Destination", "yes", "-1", "-1" );
		mockRequestParams( "AA11234567", "", "Note for Destination", "yes", "-1", "-1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1078".equals( executeResult.getAttribute( "MSG" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "".equals( executeResult.getAttribute( "UserOrCdr" ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".toUpperCase( ).equals( executeResult.getAttribute( "NoteForDest" ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ) ) );
	}

	public void testBNConfermaExecuter2( )
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		mockRequestParams( "AA11234567", "SBAI08", "Note for Destination", "yes", "1", "1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1089".equals( executeResult.getAttribute( "MSG" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "SBAI08".equals( executeResult.getAttribute( "UserOrCdr" ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".toUpperCase( ).equals( executeResult.getAttribute( "NoteForDest" ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ) ) );
		assertTrue( executeResult.getAttribute( "widelyUsedCdr" ) != null && "1".equals( executeResult.getAttribute( "widelyUsedCdr" ) ) );
		assertTrue( executeResult.getAttribute( "UserSelectedBankId" ) != null && "1".equals( executeResult.getAttribute( "UserSelectedBankId" ) ) );
	}

	public void testBNConfermaExecuter3( )
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		mockRequestParams( "AA11234567", "SBAI08", "Note for Destination", "yes", "-1", "-1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1345".equals( executeResult.getAttribute( "MSG" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "SBAI08".equals( executeResult.getAttribute( "UserOrCdr" ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".toUpperCase( ).equals( executeResult.getAttribute( "NoteForDest" ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ) ) );
	}
	
	public void testBNConfermaExecuter4( )
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		mockRequestParams( "AA11234567", "", "Note for Destination", "yes", "1", "-1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "MSG" ) != null && "TRPL-1078".equals( executeResult.getAttribute( "MSG" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "".equals( executeResult.getAttribute( "UserOrCdr" ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".toUpperCase( ).equals( executeResult.getAttribute( "NoteForDest" ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ) ) );
		assertTrue( executeResult.getAttribute( "UserSelectedBankId" ) != null && "1".equals( executeResult.getAttribute( "UserSelectedBankId" ) ) );
	}

	/*public void testBNConfermaExecuter5( )
	{
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		mockRequestParams( "AA11234567", "IN2030", "Note for Destination", "yes", "1", "-1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
	}

	public void testBNConfermaExecuter7( )
	{
		DBPersonaleWrapperMock.setAbiCode();
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiHoldingDataAccess.class, TracciabilitaPlichiHoldingDataAccessMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		mockRequestParams( "AA11234567", "IN2030", "Note for Destination", "yes", "1", "-1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
	}

	
	public void testBNConfermaExecuter6( )
	{
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		mockRequestParams( "AA1123456", "IN2030", "Note for Destination", "yes", "1", "-1" );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraConfermaExecuter( ).execute( this.requestEvent );
		assertEquals( "TrConferma", executeResult.getTransition( ) );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA1123456".equals( executeResult.getAttribute( "BarCode" ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "IN2030".equals( executeResult.getAttribute( "UserOrCdr" ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".toUpperCase( ).equals( executeResult.getAttribute( "NoteForDest" ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ) ) );
		assertTrue( executeResult.getAttribute( "UserSelectedBankId" ) != null && "1".equals( executeResult.getAttribute( "UserSelectedBankId" ) ) );
	}
*/
	
	private void mockRequestParams( final String barCode , final String userOrCdr, final String noteForDest, final String mailMe, final String bank, final String widelyCdr )
	{
		mockRequestParam( "BarCode", barCode, 3 );
		mockRequestParam( "UserOrCdr", userOrCdr, 3 );
		mockRequestParam( "NoteForDest", noteForDest, 3 );
		mockRequestParam( "MailMe", mailMe, 3 );
		mockRequestParam( "SelectedBankId", bank, 3 );
		mockRequestParam( "widelyUsedCdr", widelyCdr, 3 );
	}
	
	private void mockRequestParam( final String attributeName, final Object value, final int noOfTimes )
	{
		expect( this.requestEvent.getAttribute( attributeName ) ).andReturn( value ).times( noOfTimes );
	}
	
	
	private void mockPlichiBustasDataAccess( final Boolean isNeededToCassetto, final Boolean isCdrBelongToSameCassetto )
	{
		Mockit.setUpMock(TracciabilitaPlichiBustasDataAccess.class,TracciabilitaPlichiBustasDataAccessMock.class);
	}
	
	private Collection getAllWidelyUsedCdrs( )
	{
		final Collection widelyUsedCdrs = new ArrayList( 10 );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 1L ), Long.valueOf( 1483455L ), "Banca Sella Holding", "099320", "NUOVI SIST. PAG. (ASSEGNI VERSATI SALVO BUON FINE)", Long.valueOf( 1L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 2L ),	Long.valueOf( 1483455L ), "Banca Sella Holding", "099278", "RISPARMIO ASSICURATIVO", Long.valueOf( 2L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 3L ), Long.valueOf( 1483455L ), "Banca Sella Holding", "099505", "ARCHIVIO", Long.valueOf( 3L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 4L ),	Long.valueOf( 1483455L ), "Banca Sella Holding", "099318", "SIST. PAG. TRADIZIONALI (ASSEGNI CIRCOLARI,BOLLETTINI,PAGHE,SCHEDINE,EFFETTI)",	Long.valueOf( 4L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 5L ),	Long.valueOf( 1L ), "Banca Sella S.p.A.", "099006",	"SELLA CONSULT", Long.valueOf( 5L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 6L ),	Long.valueOf( 1L ), "Banca Sella S.p.A.", "350005", "ESTERO MERCI", Long.valueOf( 6L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 7L ),	Long.valueOf( 1L ), "Banca Sella S.p.A.", "099008",	"FIDUCIARIA SELLA", Long.valueOf( 7L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 8L ),	Long.valueOf( 1483455L ), "Banca Sella Holding", "099303", "CONTENZIOSO", Long.valueOf( 8L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 9L ), Long.valueOf( 1483455L ), "Banca Sella Holding", "099326", "TITOLI - FIDEIUSSIONI A CAVEAU", Long.valueOf( 9L ) ) );
		widelyUsedCdrs.add( getFrequentlyUserCdr( Long.valueOf( 10L ),Long.valueOf( 1483455L ), "Banca Sella Holding", "099300", "DISPUTE CARTA DI CREDITO", Long.valueOf( 10L ) ) );
		return widelyUsedCdrs;
	}
	
	private FrequentiDestinazioneCdrView getFrequentlyUserCdr( final Long id, final Long bankId, final String bankDesc, final String cdr, final String cdrDesc, final Long position )
	{
		final FrequentiDestinazioneCdrView freqCdrView = new FrequentiDestinazioneCdrView();
		freqCdrView.setId( id );
		freqCdrView.setBankId( bankId );
		freqCdrView.setBankDescription( bankDesc );
		freqCdrView.setCdr( cdr );
		freqCdrView.setDescription( cdrDesc );
		freqCdrView.setPosizione( position );
		return freqCdrView;
	}
	
	private Collection getBNMainCollection( )
	{
		final BustaNeraAttributeView attributeView = new BustaNeraAttributeView( );
		attributeView.setId( 1L );
		final BustaNeraAttributeView attributeView1 = new BustaNeraAttributeView( );
		attributeView1.setId( 2L );
		final BustaNeraAttributeView attributeView2 = new BustaNeraAttributeView( );
		attributeView2.setId( 3L );
		final Collection bnMainColl = new ArrayList( 2 );
		bnMainColl.add( attributeView );
		bnMainColl.add( attributeView1 );
		bnMainColl.add( attributeView2 );
		return bnMainColl;
	}
}
