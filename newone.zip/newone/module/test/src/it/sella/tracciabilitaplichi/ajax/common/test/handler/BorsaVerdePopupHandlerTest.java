package it.sella.tracciabilitaplichi.ajax.common.test.handler;

import it.sella.tracciabilitaplichi.ajax.common.handler.BorsaVerdePopupHandler;
import it.sella.webutil.ajax.returntypes.AjaxStringBuffer;
import junit.framework.TestCase;

public class BorsaVerdePopupHandlerTest extends TestCase
{
    public void testGetPopupContent( ) {
        final String key = "GestoreInvioPlichi.InvioPlichi.SixDCPopup.text";
        final String expected = "<table><tr><td>Nel campo di testo contrassegnato dall'etichetta \"Borsa Corrispondenza Interna\" e' necessario inserire il codice a barre di 13 cifre apposto sulla lettera di vettura.</td></tr></table>";
        final BorsaVerdePopupHandler borsaVerdePopupHandler = new BorsaVerdePopupHandler( );
        final AjaxStringBuffer actual = borsaVerdePopupHandler.getPopupContent( key );
        assertEquals( expected, actual.toString( ) );
    }
}
