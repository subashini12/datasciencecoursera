package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class WinboxConfermaExecuterTest extends AbstractSellaExecuterMock {

	WinboxConfermaExecuter winboxConfermaExecuter =  new WinboxConfermaExecuter(); 
	
	public WinboxConfermaExecuterTest(final String name) {
		super(name);
	}
	
	 public void testWinboxConfermaExecuter_01(){
		 setUpMockMethods(Util.class, UtilMock.class);
		 setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
		 expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("Desc")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("Cdr")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		 final Map<Long,String> clasificazioneMap = new HashMap<Long, String>();
		 clasificazioneMap.put(22L, "test");
		 expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP")).andReturn((Serializable)clasificazioneMap).anyTimes();
		 final Hashtable altriWinboxTable = new Hashtable();
		 altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
		 expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn(altriWinboxTable).anyTimes();
		 expecting(getStateMachineSession().containsKey("AltriWinboxTable")).andReturn(true).anyTimes();
		playAll();
		final ExecuteResult executeResult =  winboxConfermaExecuter.execute(getRequestEvent())	 ;
		assertEquals(executeResult.getAttribute("AltriWinboxTable"),altriWinboxTable);
	}
	 
	 public void testWinboxConfermaExecuter_02(){
		 DBPersonaleWrapperMock.setValidCdrFalse();
		 setUpMockMethods(Util.class, UtilMock.class);
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("Desc")).andReturn("33").anyTimes();
		 expecting(getRequestEvent().getAttribute("Cdr")).andReturn("sss").anyTimes();
		 expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		 final Map<Long,String> clasificazioneMap = new HashMap<Long, String>();
		 clasificazioneMap.put(22L, "test");
		 final Hashtable altriWinboxTable = new Hashtable();
		 altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
		 expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP")).andReturn((Serializable)clasificazioneMap).anyTimes();
		 expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn(altriWinboxTable).anyTimes();
		 expecting(getStateMachineSession().containsKey("AltriWinboxTable")).andReturn(true).anyTimes();
		playAll();
		final ExecuteResult executeResult =  winboxConfermaExecuter.execute(getRequestEvent())	 ;
		
		assertEquals(executeResult.getAttribute("AltriWinboxTable"),altriWinboxTable);
	}
	 
	/* public void testWinboxConfermaExecuter_04(){
		 DBPersonaleWrapperMock.setTracciabilitaException();
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("Desc")).andReturn("33").anyTimes();
		 expecting(getRequestEvent().getAttribute("Cdr")).andReturn("dss").anyTimes();
		 expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		 final Map<Long,String> clasificazioneMap = new HashMap<Long, String>();
		 clasificazioneMap.put(22L, "test");
		 final Hashtable altriWinboxTable = new Hashtable();
		 altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
		 expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP")).andReturn((Serializable)clasificazioneMap).anyTimes();
		 expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn(altriWinboxTable).anyTimes();
		 expecting(getStateMachineSession().containsKey("AltriWinboxTable")).andReturn(true).anyTimes();
		playAll();
		final ExecuteResult executeResult =  winboxConfermaExecuter.execute(getRequestEvent())	 ;
		
		assertEquals(executeResult.getException().toString(),"it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException");
	}
	 public void testWinboxConfermaExecuter_03(){
		 DBPersonaleWrapperMock.setRemoteException();
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("Desc")).andReturn("33").anyTimes();
		 expecting(getRequestEvent().getAttribute("Cdr")).andReturn("ddf").anyTimes();
		 expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		 expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		 final Map<Long,String> clasificazioneMap = new HashMap<Long, String>();
		 clasificazioneMap.put(22L, "test");
		 final Hashtable altriWinboxTable = new Hashtable();
		 altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
		 expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP")).andReturn((Serializable)clasificazioneMap).anyTimes();
		 expecting(getStateMachineSession().get("AltriWinboxTable")).andReturn(altriWinboxTable).anyTimes();
		 expecting(getStateMachineSession().containsKey("AltriWinboxTable")).andReturn(true).anyTimes();
		 playAll();
		final ExecuteResult executeResult =  winboxConfermaExecuter.execute(getRequestEvent())	 ;
		
		assertEquals(executeResult.getException().toString(),"java.rmi.RemoteException");
	}*/

}
