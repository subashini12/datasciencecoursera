package it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessorMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.FrequentiDestinazioneCdrAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.FrequentiDestinazioneCdrAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import mockit.Mockit;


public class ModificaFrequentiDestCdrExecuterTest extends AbstractSellaExecuterMock{

	public ModificaFrequentiDestCdrExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ModificaFrequentiDestCdrExecuter executer = new ModificaFrequentiDestCdrExecuter() ;
	
	public void testModificaFrequentiDestCdrExecuter_01() {
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		FrequentiDestinazioneCdrProcessorMock.setNullData();
		TracciabilitaPlichiImplMock.setHost();
		TPFrequentiDestinazioneCdrDataAccessMock.setfrequentiDestinazioneCdrExist();
		setUpMockMethods(FrequentiDestinazioneCdrAdminImpl.class, FrequentiDestinazioneCdrAdminImplMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class, TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testModificaFrequentiDestCdrExecuter_02() {
		TPFrequentiDestinazioneCdrDataAccessMock.setTracciabilitaException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class, TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}
	
	public void testModificaFrequentiDestCdrExecuter_03() {
		TPFrequentiDestinazioneCdrDataAccessMock.setRemoteException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class, TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}
}
