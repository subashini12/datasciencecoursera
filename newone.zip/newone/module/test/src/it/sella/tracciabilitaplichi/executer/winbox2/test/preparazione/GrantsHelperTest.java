package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsHelper;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.IntestatazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.IntestatazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GrantsHelperTest extends AbstractSellaMock
{
    public GrantsHelperTest( final String name )
    {
        super( name );
    }

    @Override
	protected void setUp( ) throws Exception
    {
        super.setUp( );
    }

    public void testAddToGrantsCollection( )
    {
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 1 );
        final Collection<Grants> grantsCollection = new ArrayList<Grants>( 1 );
        final Grants grants = new Grants( );
        sessionMap.put( CONSTANTS.GRANTS_COLLECTION, grantsCollection );
        GrantsHelper.addToGrantsCollection( sessionMap, grants );
        final Collection<Grants> actualGrantsCollection = ( Collection<Grants> ) sessionMap.get( CONSTANTS.GRANTS_COLLECTION );
        assertEquals( 1, actualGrantsCollection.size( ) );
        assertEquals( grants, ( ( List<Grants> ) actualGrantsCollection ).get( 0 ) );
    }

    public void testSetGrantsCollection_01( ) throws TracciabilitaException, RemoteException
    {
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 1 );
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setIsCustomAccess( Boolean.FALSE );
        sessionMap.put( CONSTANTS.ACCODA_PRATICA, folderAttributes );
        final Collection<Grants> grantsCollection = new ArrayList<Grants>( 1 );
        sessionMap.put( CONSTANTS.GRANTS_COLLECTION, grantsCollection );
        GrantsHelper.setGrantsCollection( sessionMap );
        final Collection<Grants> actualCollection = ( Collection<Grants> ) sessionMap.get( CONSTANTS.GRANTS_COLLECTION );
        assertEquals( 0, actualCollection.size( ) );
    }
    
    public void testGetDefaultCDRGrantsCollection(){
    	setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class);
    	setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	setUpMockMethods( IntestatazioneWrapper.class,IntestatazioneWrapperMock.class);
    	try {
			GrantsHelper.getDefaultCDRGrantsCollection();
		} catch (final Exception e) {
		}
    }
    
    public void testGetDefaultUserGrants(){
    	setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class);
    	setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	setUpMockMethods( IntestatazioneWrapper.class,IntestatazioneWrapperMock.class);
    	try {
			GrantsHelper.getDefaultCDRGrant();
		} catch (final Exception e) {
		}
    }
    
    public void testGetCdrOrUserCode_01(){
    	setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class);
    	setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	try {
			GrantsHelper.getCDR(1L);
		} catch (final Exception e) {
		}
    }
    
    public void testGetCdrOrUserCode_02(){
    	DBPersonaleWrapperMock.setSoggettoAsSemplice();
    	setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class);
    	setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	try {
			GrantsHelper.getCDR(1L);
		} catch (final Exception e) {
		}
    }
    
    public void testGetGrants(){
    	
    	setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class,TracciabilitaPlichiAdminMasterDataAccessMock.class);
    	setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
    	try {
			GrantsHelper.getGrants(1L);
		} catch (final Exception e) {
			// TODO Auto-generated catch block
		}
    }


}
