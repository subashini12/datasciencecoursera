package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CodiceHostView;

import java.util.Date;

import mockit.Mock;

public class TPCodiceHostDataAccessMock 
{
	private static Boolean tracciabilitaException = false;
	private static Boolean isCodiceHostExists = false;
	
	public static void setCodiceHostExists() {
		isCodiceHostExists = true;
	}
	
	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}
	
	@Mock
	public boolean isCodiceHostExists(final String cifre)	throws TracciabilitaException 
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		boolean flag = true ;
		if(isCodiceHostExists)
		{
			flag = false;
		}
		return flag;
	}
	@Mock
	public CodiceHostView getCodiceHostDetail(final String cifre) throws TracciabilitaException 
	{
		final CodiceHostView codiceHostView = new CodiceHostView();
		codiceHostView.setBankId(Long.valueOf("00"));
		codiceHostView.setCifreNo("1111");
		codiceHostView.setCodiceId(2L);
		codiceHostView.setFromDate(new Date());
		codiceHostView.setToDate(new Date());
		return codiceHostView;
	}


}
