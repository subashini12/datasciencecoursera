/*package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import static it.sella.tracciabilitaplichi.implementation.mock.TracciabilitaPlichiManagerMock.mockEJB;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.enumaration.CAUSALE;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.AbstractExecuter;
import it.sella.tracciabilitaplichi.executer.winbox2.Validator;
import it.sella.tracciabilitaplichi.executer.winbox2.WB2Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsHelper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.InserisciPraticaAction;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.interfaces.dao.IGrantsImpl;
import it.sella.tracciabilitaplichi.persistence.dao.GrantsImpl;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.dto.WinBox2;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;
import mockit.Mockit;

public class InserisciPraticaActionTest extends TestCase
{
        RequestEvent requestEvent = null;
        StateMachineSession smSession = null;
        IGrantsImpl grantsImpl = null;
        Map<Enum, Object> sessionMap = null; 
        public InserisciPraticaActionTest( final String message )
        {
            super( message );
        }
        @Override
		protected void setUp( ) throws Exception
        {
            super.setUp( );
            this.requestEvent = createMock( RequestEvent.class );
            this.smSession = createMock( StateMachineSession.class );
            this.grantsImpl = createMock( IGrantsImpl.class );
            expect( this.requestEvent.getAttribute( CONSTANTS.FOLDER_FLOW.getValue( ) ) ).andReturn( "0" );
            expect( this.smSession.put( CONSTANTS.STAMPE_ID.getValue( ), 123456789012L ) ).andReturn( Boolean.TRUE );     
            expect( this.requestEvent.getAttribute( CONSTANTS.APPEND_OR_INSERT.getValue( ) ) ).andReturn( CONSTANTS.ONE.getValue( ) );
            Mockit.redefineMethods( TracciabilitaPlichiImpl.class, new Object( ){
                public IGrantsImpl getGrantsImpl( )
                {
                    return grantsImpl;
                }
            });
            Mockit.redefineMethods( GrantsImpl.class, new Object( ){
                public void disableRemainingGrants( final String barcode, final Long idSoggetto ) throws TracciabilitaException
                {
                    return;
                }
            });
            expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.smSession );
            final Enum[ ]  enumArray = { CONSTANTS.FOLDER,CONSTANTS.IS_CDR_VISIBILITY,CONSTANTS.ACCODA_PRATICA,CONSTANTS.CUSTOM_ACCESS };
            for( final Enum constant : Arrays.asList( enumArray ) )
            {
                expect( this.smSession.remove( constant.toString( ) ) ).andReturn( null );
            }
            replay( this.requestEvent );
            replay( this.smSession );
        }
        private void mockObjects( final Boolean isLocalArchive, final Boolean isVisibilita )
        {
            
            Mockit.redefineMethods( Helper.class, new Object( ){
                public Map<Enum, Object> getSessionMap( final StateMachineSession session ) throws TracciabilitaException, RemoteException
                {
                   sessionMap = new HashMap<Enum,Object>( 1 );
                   final  Map<Long, String> folderTypesMap = new HashMap<Long, String>( 1 );
                   folderTypesMap.put( 1L, "DOCUMENTO GENERICO" );
                   sessionMap.put( CONSTANTS.FOLDER_TYPES_MAP, folderTypesMap );
                   final Map<String, Object> userDetails = new HashMap<String, Object>( 1 );
                   sessionMap.put( CONSTANTS.USER_DETAILS, userDetails );
                   final Map<Long,String> societaGBSmap = new HashMap<Long,String>( 1 );
                   sessionMap.put( CONSTANTS.GBS_COMPANY, societaGBSmap );
                   
                   final Map<Long,AltriWinboxView> folderViewsMap = new HashMap<Long,AltriWinboxView>( 1 );
                   final AltriWinboxView altriWinboxView = new AltriWinboxView( );
                   altriWinboxView.setCustomAccess( isVisibilita ? Byte.valueOf( "1" ) : Byte.valueOf( "0" ) );
                   folderViewsMap.put( 1L, altriWinboxView );
                   
                   sessionMap.put( CONSTANTS.FOLDER_VIEWS_MAP, folderViewsMap );
                   final Folder folder = new Folder( );
                   final FolderAttributes folderAttributes =  new FolderAttributes( );
                   folderAttributes.setIsCustomAccess( Boolean.FALSE );
                   folder.setFolderAttributes( folderAttributes );
                   final Grants grants = new Grants( );
                   grants.setIdSoggetto( 12345678L );
                   final Collection<Grants> grantsCollection = new ArrayList<Grants>( 1 );
                   grantsCollection.add( grants );
                   folder.setGrants( grantsCollection );
                   
                   
                   if( isLocalArchive )
                   {
                       //folder.getFolderAttributes( ).setFolderArchiveFlow( Short.valueOf( "0"  ) );
                       sessionMap.put( CONSTANTS.LOCALAZZITO_PRATICA, new ArrayList<Folder>( 1 ) );   
                   }
                   else
                   {
                       //folder.getFolderAttributes( ).setFolderArchiveFlow( Short.valueOf( "1"  ) );
                       sessionMap.put( CONSTANTS.WINBOX2, new WinBox2( ) );    
                   }
                   sessionMap.put( CONSTANTS.FOLDER, folder );
                   if( isVisibilita )
                   {
                       sessionMap.put( CONSTANTS.GRANTS_COLLECTION , new ArrayList<Grants>( 1 ) );
                   }
                   sessionMap.put( CONSTANTS.ACCODA_PRATICA, Boolean.TRUE );
                   
                   return sessionMap;
                }
                
                public Map<Enum,Object> getFolderBarcode( final Map<Enum,Object> sessionMap, final FolderAttributes folderAttributes, final String documentCode ) throws RemoteException, TracciabilitaException
                {
                    final Map<Enum,Object> resultMap = new HashMap<Enum, Object>( 1 );
                    resultMap.put( CONSTANTS.BARCODE, "1234567890123" );
                    resultMap.put( CONSTANTS.STAMPE_ID, 123456789012L );
                    return resultMap;
                }
                public Collection<String> getFolderOggettoIdColl( final WinBox2 winBox2 )
                {
                    return new ArrayList<String>( 1 );
                }
            });
            Mockit.redefineMethods( WB2Helper.class, new Object( ) { 
            	public OggettoView getBasicOggettoView( final Map userDetails, final CAUSALE causale, final String statusType ) throws TracciabilitaException, RemoteException
                {
                    return new OggettoView( );
                }} );
            if( !isVisibilita )
            {
                Mockit.redefineMethods( GrantsHelper.class, new Object( ) {
                    public Collection<Grants> getDefaultCDRGrantsCollection( ) throws TracciabilitaException, RemoteException
                    {
                         final Collection<Grants> grantsCollection = new ArrayList<Grants>( 1 );
                         grantsCollection.add( new Grants( ) );
                         return grantsCollection;
                    }  
                    public Grants getDefaultUserGrants( ) throws TracciabilitaException, RemoteException
                    {
                        return new Grants(  );
                    }  
                } );
            }
            else
            {
                Mockit.redefineMethods( GrantsHelper.class, new Object( ) {
                    public Grants getDefaultUserGrants( ) throws TracciabilitaException, RemoteException
                    {
                        return new Grants(  );
                    }  
                } );
            }    
            mockEJB( );
            Mockit.redefineMethods( TracciabilitaPlichiManagerBean.class, new Object( ) {
                public Long censitoOggetto( final Properties properties ) throws TracciabilitaException, RemoteException
                {
                    return 1L;
                }  
            } );
        }
        private void redefineValidator( final Boolean isValidateFail, final Boolean isLocalArchive )
        {
            Mockit.redefineMethods( Validator.class, new Object( ){
                public Map<Enum, Object> validate( final RequestEvent requestEvent, final Boolean isSearch, final Boolean isFromPraticaModifica ) throws RemoteException
                {
                    final Map<Enum, Object> resultMap = new HashMap<Enum, Object>( 1 );
                    if( isValidateFail )
                    {
                        resultMap.put( CONSTANTS.ERROR_MESSAGE, IErrorCodes.TRPL_1572 ); 
                    }
                    else
                    {
                        final FolderAttributes folderAttributes = new FolderAttributes( );
                        folderAttributes.setTipoPratica( 1L );
                        folderAttributes.setIsCustomAccess( Boolean.FALSE );
                        if( isLocalArchive )
                        {
                            folderAttributes.setFolderArchiveFlow( Short.valueOf( "0"  ) );
                        }
                        else
                        {
                            folderAttributes.setFolderArchiveFlow( Short.valueOf( "1"  ) );
                        }
                        resultMap.put( CONSTANTS.FOLDER_ATTRIBUTES, folderAttributes );
                    }
                    return resultMap;
                }
            });
        }
        public void testExecuteAction_01( ) throws TracciabilitaException, RemoteException
        {
            redefineValidator( Boolean.TRUE, Boolean.FALSE );
            Mockit.redefineMethods( Helper.class, new Object( ) {
                public Map<Enum, Object> getSessionMap( final StateMachineSession session ) throws TracciabilitaException, RemoteException
                {
                    return new HashMap<Enum,Object>( 1 );
                }  
            } );
            final AbstractExecuter abstractExecuter = new InserisciPraticaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_ERROR, actual ); 
        }
        public void testExecuteAction_02( ) throws TracciabilitaException, RemoteException
        {
            redefineValidator( Boolean.FALSE, Boolean.TRUE );
            mockObjects( true, true );
            final AbstractExecuter abstractExecuter = new InserisciPraticaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_CONFERMA, actual ); 
        }
        public void testExecuteAction_03( ) throws TracciabilitaException, RemoteException
        {
            redefineValidator( Boolean.FALSE, Boolean.FALSE );
            mockObjects( false, false );
            final AbstractExecuter abstractExecuter = new InserisciPraticaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_CONFERMA, actual ); 
        }
       
        public void testGetLoggerMap( )
        {
            Mockit.redefineMethods( LogHelper.class, new Object( ) {
                public String getFolderPreparazioneXML( final Map<Enum,Object> sessionMap )
                {
                    return "</xml>";
                }  
            } );
            final AbstractExecuter abstractExecuter = new InserisciPraticaAction( );
            final Map<CONSTANTS,String> actual = abstractExecuter.getLoggerMap( new HashMap<Enum, Object>( 1 ) );
            assertEquals( LOGGER.FOLDER.PREPARAZIONE.getValue( ), actual.get( CONSTANTS.OPERATION_CODE ) );
            assertEquals( "</xml>", actual.get( CONSTANTS.LOG_XML ) );
        }
        public void testGetLogger( )
        {
            final Log4Debug expected = Log4DebugFactory.getLog4Debug( InserisciPraticaAction.class );
            final AbstractExecuter abstractExecuter = new InserisciPraticaAction( );
            assertEquals(  expected.getClass( ), abstractExecuter.getLogger( ).getClass( ) );
        }
        @Override
		protected void tearDown( )
        {
            Mockit.restoreAllOriginalDefinitions( );
        }
}*/