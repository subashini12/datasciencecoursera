package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichi.processor;

import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.rmi.RemoteException;

public class SituazionePlichiRicercaProcessorTest extends
		AbstractSellaExecuterMock {

	public SituazionePlichiRicercaProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SituazionePlichiRicercaProcessor processor = new SituazionePlichiRicercaProcessor();

	public void testSituazionePlichiRicercaProcessor_01() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderBank")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("destinationBank")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiBarCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descritioneArticoli")).andReturn("").anyTimes();
		playAll();
		try {
			processor.validateInputs(getRequestEvent(), "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testSituazionePlichiRicercaProcessor_02() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("fromdd")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("frommm")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("fromyyyy")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("tilldd")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("tillmm")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("tillyyyy")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFromdd")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFrommm")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFromyyyy")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTilldd")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTillmm")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTillyyyy")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderBank")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("destinationBank")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiBarCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descritioneArticoli")).andReturn("").anyTimes();
		playAll();
		try {
			processor.validateInputs(getRequestEvent(), "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	
	public void testgetSoggettoIdCollection_01()
	{
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		try {
			processor.getSoggettoIdCollection("1");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
}
