package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Map;

import mockit.Mock;

public class PlichiContentsModificaPB5ProcessorMock {
	@Mock
	public static ExecuteResult modifyPB5Records(RequestEvent rqEvent,
			String barCode, Map restoreMap, ExecuteResult executeResult)
			throws TracciabilitaException, RemoteException {
		return executeResult;
	}
}
