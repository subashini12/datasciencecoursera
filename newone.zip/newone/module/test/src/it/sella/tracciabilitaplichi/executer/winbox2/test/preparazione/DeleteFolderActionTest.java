package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.enumaration.LOGGER;
import it.sella.tracciabilitaplichi.executer.winbox2.mock.WinBox2Mock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.DeleteFolderAction;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.HelperMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.LogHelper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.LogHelperMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.persistence.dto.WinBox2;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;
import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Test;

public class DeleteFolderActionTest 
{
	 final DeleteFolderAction deleteFolderAction = new DeleteFolderAction( );
	
	@Test
    public void getLoggerMap( )
    {
        Mockit.setUpMock(LogHelper.class, LogHelperMock.class);
        final Map<CONSTANTS,String> actual = deleteFolderAction.getLoggerMap( new HashMap<Enum, Object>( 1 ) );
        Assert.assertEquals( LOGGER.FOLDER.CANCELLAZIONE.getValue( ), actual.get( CONSTANTS.OPERATION_CODE ) );
        Assert.assertEquals( "</XML>", actual.get( CONSTANTS.LOG_XML ) );
    }
    
    @Test
    public void getLogger( )
    {
        final Log4Debug expected = Log4DebugFactory.getLog4Debug( DeleteFolderAction.class );
        Assert.assertEquals(  expected.getClass( ), deleteFolderAction.getLogger( ).getClass( ) );
    }
    
    @Test
    public void executeAction_01()
    {
    	TracciabilitaPlichiImplMock.setCassetto();
    	Mockit.setUpMock(Helper.class, HelperMock.class);
    	Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
    	Mockit.setUpMock(WinBox2.class, WinBox2Mock.class);
    	final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
    	EasyMock.replay(stateMachineSession);
    	final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
    	EasyMock.expect( requestEvent.getAttribute("folderIndex") ).andReturn("0").anyTimes();
    	EasyMock.expect( requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
    	EasyMock.replay( requestEvent );
    	try {
    		final Enum result = deleteFolderAction.executeAction(requestEvent);
    		Assert.assertEquals(CONSTANTS.TR_CONFERMA, result);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
    }
}
