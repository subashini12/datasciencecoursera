package it.sella.tracciabilitaplichi.executer.test.pdfgenerator;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

import mockit.Mock;

public class SecurityDBpersonaleWrapperMock 
{
	
   private static Boolean tracciabilitaException = false;
   private static Boolean remoteException = false;
   
   public  static void setTracciabilitaException() 
   {  
		tracciabilitaException = true;
	}
	public  static void setRemoteException() 
	{  
		remoteException = true;
	}
	
	@Mock
	public String getDipendente( final String userId ) throws TracciabilitaException, RemoteException
	{
		if( tracciabilitaException )
   	 {
   		 tracciabilitaException = false; 
   		 throw new TracciabilitaException();    		 
   	 }
   	 
   	 if( remoteException )
   	 {
   		 remoteException = false; 
   		 throw new RemoteException();    		 
   	 }
	   	return "Devi" ;
	}
	
	@Mock
	
	public boolean isLoggedInArchivoCdr() throws TracciabilitaException
	{
		return true ;
	}
	
	@Mock
	
	public String getDipendenteForPlichiCont( final String userId, final long bankId ) throws TracciabilitaException, RemoteException
	{
		return "" ;
	}

}
