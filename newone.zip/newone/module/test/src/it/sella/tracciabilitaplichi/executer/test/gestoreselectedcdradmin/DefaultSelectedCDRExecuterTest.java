package it.sella.tracciabilitaplichi.executer.test.gestoreselectedcdradmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestoreselectedcdradmin.DefaultSelectedCDRExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import org.easymock.EasyMock;

public class DefaultSelectedCDRExecuterTest  extends AbstractSellaExecuterMock {

	 DefaultSelectedCDRExecuter  defaultSelectedCDRExecuter = new  DefaultSelectedCDRExecuter();

	public  DefaultSelectedCDRExecuterTest(String name) {
		super(name);
	}

	public void testDefaultSelectedCDRExecuter_01() {

		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		ExecuteResult executeResult = defaultSelectedCDRExecuter.execute(getRequestEvent());
	}

}
