/*package it.sella.tracciabilitaplichi.executer.bustaventi.preparazione;


import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.test.view.PlichiAttributeViewMock;
import it.sella.tracciabilitaplichi.implementation.view.BustaVentiPreparazioneView;
import it.sella.tracciabilitaplichi.implementation.view.BustaVentiPreparazioneViewMock;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Test;

public class PreparazioneExecuterTest {

	PreparazioneExecuter preparazioneExecuter = new PreparazioneExecuter() ;

	@Test
	public void preparazioneExecuter_remoteException()
	{
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		Mockit.setUpMock(BustaVentiPreparazioneView.class, BustaVentiPreparazioneViewMock.class);
		Mockit.setUpMock(ExecutersHelper.class, ExecutersHelperMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP )).andReturn((Serializable) getHasMap()).anyTimes();
		EasyMock.expect(stateMachineSession.put( (String)EasyMock.anyObject(),( Boolean) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getAttribute(ITPConstants.BARCODE)).andReturn("1").anyTimes();
		EasyMock.expect(requestEvent.getAttribute(ITPConstants.NO_OF_PAGES)).andReturn("1").anyTimes();
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = preparazioneExecuter.execute(requestEvent);
		Assert.assertEquals(executeResult, executeResult.getTransition());
	}

	@Test
	public void preparazioneExecuter_tracciabilitaException()
	{
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		Mockit.setUpMock(BustaVentiPreparazioneView.class, BustaVentiPreparazioneViewMock.class);
		Mockit.setUpMock(ExecutersHelper.class, ExecutersHelperMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP )).andReturn((Serializable) getHasMap()).anyTimes();
		EasyMock.expect(stateMachineSession.put( (String)EasyMock.anyObject(),( Boolean) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getAttribute(ITPConstants.BARCODE)).andReturn("1").anyTimes();
		EasyMock.expect(requestEvent.getAttribute(ITPConstants.NO_OF_PAGES)).andReturn("1").anyTimes();
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = preparazioneExecuter.execute(requestEvent);
		Assert.assertEquals(executeResult, executeResult.getTransition());
	}

	@Test
	public void preparazioneExecuter_01()
	{
		ExternalServicesFactoryMock.setOperationAllowed();
		Mockit.setUpMock(PlichiAttributeView.class, PlichiAttributeViewMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(ExecutersHelper.class, ExecutersHelperMock.class);
		Mockit.setUpMock(BustaVentiPreparazioneView.class, BustaVentiPreparazioneViewMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.get(ITPConstants.BUSTA_VENTI_PREPARAZIONE_MAP)).andReturn((Serializable) getHasMap()).anyTimes();
		EasyMock.expect(stateMachineSession.put(ITPConstants.SUCCESS,Boolean.TRUE)).andReturn("").anyTimes();
		EasyMock.expect(stateMachineSession.put(ITPConstants.MESSAGE, IErrorCodes.TRPL_1056)).andReturn("").anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getAttribute(ITPConstants.BARCODE)).andReturn("1044820097234").anyTimes();
		EasyMock.expect(requestEvent.getAttribute(ITPConstants.NO_OF_PAGES)).andReturn("1").anyTimes();
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		preparazioneExecuter.execute(requestEvent);
	}

	private Map getHasMap() {
		final Set<String> barcodeSet = new HashSet<String>() ;
		barcodeSet.add("123456789123");
		final Map map = new HashMap();
		map.put(CONSTANTS.B20_BARCODE_COLLECTION, barcodeSet);
		return map ;
	}

}
 */