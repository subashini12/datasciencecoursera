package it.sella.tracciabilitaplichi.executer.test.gestorehostlidattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestorehostlidattributeadmin.HostlIdAttributeCancelliCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

public class HostlIdAttributeCancelliCercaExecuterTest extends AbstractSellaExecuterMock
{

	public HostlIdAttributeCancelliCercaExecuterTest(String name) 
	{
		super(name);
	}
	
	HostlIdAttributeCancelliCercaExecuter executer = new HostlIdAttributeCancelliCercaExecuter();
	
	public void testExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_02()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setHostlIdAttributeViewNull() ;
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_03()
	{
		expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testExecuter_04()
	{
		expecting(getRequestEvent().getAttribute("ID")).andReturn("abc").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_05()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException() ;
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
}
