package it.sella.tracciabilitaplichi.executer.gestorechanneldefinitionadmin.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.rmi.RemoteException;


public class ChannelDefinitionAdminProcessorTest extends AbstractSellaExecuterMock{

	public ChannelDefinitionAdminProcessorTest(final String name) {
		super(name);
	}

	ChannelDefinitionAdminProcessor processor = new ChannelDefinitionAdminProcessor() ;
	
	public void testChannelDefinitionAdminProcessor_01() throws RemoteException, TracciabilitaException {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("BSINDIA");
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("0");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelDefinitionAdminProcessor_02() throws RemoteException, TracciabilitaException {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("BSINDIA");
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("-1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelDefinitionAdminProcessor_03() throws RemoteException, TracciabilitaException {
		UtilMock.setNumericFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("BSINDIA");
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelDefinitionAdminProcessor_04() throws RemoteException, TracciabilitaException {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("BSINDIA");
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelDefinitionAdminProcessor_05() throws RemoteException, TracciabilitaException {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelDefinitionId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelName")).andReturn("");
		expecting(getRequestEvent().getAttribute("ChannelDeadline")).andReturn("1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
}
