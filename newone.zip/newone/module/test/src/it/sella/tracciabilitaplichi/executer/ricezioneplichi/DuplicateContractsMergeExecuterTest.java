package it.sella.tracciabilitaplichi.executer.ricezioneplichi;

import it.sella.tracciabilitaplichi.b10archivation.B10InputPutProcessor;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.DuplicateContractsMergeExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.B10InputPutProcessorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import org.easymock.EasyMock;


public class DuplicateContractsMergeExecuterTest extends AbstractSellaExecuterMock{

	public DuplicateContractsMergeExecuterTest(final String name) {
		super(name);
	}

	DuplicateContractsMergeExecuter executer = new DuplicateContractsMergeExecuter() ;
	
	public void testDuplicateContractsMergeExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().get("ChoosenContracts")).andReturn(null).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testDuplicateContractsMergeExecuter_02()
	{
		setUpMockMethods(B10InputPutProcessor.class, B10InputPutProcessorMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove("ChoosenContracts")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().get("ChoosenContracts")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testDuplicateContractsMergeExecuter_03()
	{
		TPUtilMock.setTracciabilitaException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove("ChoosenContracts")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().get("ChoosenContracts")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testDuplicateContractsMergeExecuter_04()
	{
		TPUtilMock.setRemoteException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove("ChoosenContracts")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().get("ChoosenContracts")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
//	Manager call
	
	public void testDuplicateContractsMergeExecuter_05()
	{
		B10InputPutProcessorMock.setInvalidBarcodeEntered();
		setUpMockMethods(B10InputPutProcessor.class, B10InputPutProcessorMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().remove("ChoosenContracts")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().get("ChoosenContracts")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable();
		hashtable.put("TextAreaValue", "Note");
		hashtable.put("IsBarCodeReaderAvailable", "");
		hashtable.put("TypesOfOggettos", "");
		hashtable.put("PlichiToBeReceived", "");
		hashtable.put("PlichiReceived", "");
		hashtable.put("OggettoType", "");
		hashtable.put("IS_ENDORSER_VISIBLE", "");
		hashtable.put("FinalB10ValuesToUpdate", getB10InputPutProcessor() );
		hashtable.put("Properties", getProperties());
		return hashtable ;
	}
	
	private static Map getMap()
	{
		final Map map = new HashMap() ;
		return map ;
	}
	
	private static B10InputPutProcessor getB10InputPutProcessor()
	{
		final B10InputPutProcessor b10InputPutProcessor = new B10InputPutProcessor("", "");
		return b10InputPutProcessor ;
	}
	
	private static Properties getProperties()
	{
		final Properties properties = new Properties(); 
		return properties ;
	}
}
