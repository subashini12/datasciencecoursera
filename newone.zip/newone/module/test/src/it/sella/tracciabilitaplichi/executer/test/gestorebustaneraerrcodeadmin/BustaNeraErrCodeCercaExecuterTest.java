package it.sella.tracciabilitaplichi.executer.test.gestorebustaneraerrcodeadmin;

import it.sella.tracciabilitaplichi.executer.gestorebustaneraerrcodeadmin.BustaNeraErrCodeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;

import java.io.Serializable;
import java.util.Collection;
import java.util.Vector;

public class BustaNeraErrCodeCercaExecuterTest extends AbstractSellaExecuterMock
{
	
	BustaNeraErrCodeCercaExecuter executer = new BustaNeraErrCodeCercaExecuter();

	public BustaNeraErrCodeCercaExecuterTest(String name) 
	{
		super(name);
	}
	
	public void testBustaNeraErrCodeCercaExecuter_witherrorMsgNullNViewSizeNotZero()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class ,TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().put( "BustaNeraErrCodeView",( Serializable ) collection ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeCercaExecuter_witherrorMsgNullNViewSizeZero()
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setViewSizeZero();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class ,TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().put( "BustaNeraErrCodeView",( Serializable ) collection ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeCercaExecuter_witherrorMsgNotNull_01()
	{
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "abc" ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testBustaNeraErrCodeCercaExecuter_witherrorMsgNotNull_02()
	{
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "" ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeCercaExecuter_forTracciabilitaException()
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class ,TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().put( "BustaNeraErrCodeView",( Serializable ) collection ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
}
