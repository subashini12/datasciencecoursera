package it.sella.tracciabilitaplichi.executer.test.gestorebustanera.processor;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import mockit.Mock;

public class FileReaderHelperMock
{
	
	private static Boolean fileExists = false; 
	private static Boolean tracciabilitaException = false;
	
	public static void setFileOccurence() {
		fileExists = true;
	}
	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}
	@Mock
	 public Boolean isFileExists( final String fileName, final String filePath, final String ftpPoolName ) throws TracciabilitaException{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		return fileExists;
	 }
}
