package it.sella.tracciabilitaplichi.executer.ricercabustacinque;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.util.ArrayList;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class RicercaBustaCinqueConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	public RicercaBustaCinqueConfermaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicercaBustaCinqueConfermaExecuter executer = new RicercaBustaCinqueConfermaExecuter();

	public void testRicercaBustaCinqueConfermaExecuter_01() {
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn("");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicercaBustaCinqueConfermaExecuter_02() {
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(false);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn("");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicercaBustaCinqueConfermaExecuter_03() {
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(false);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn("");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("1998");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicercaBustaCinqueConfermaExecuter_04() {
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(false);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn(
				"CodiceContratto");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicercaBustaCinqueConfermaExecuter_05() {
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn("");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("1998");
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Hashtable) EasyMock.anyObject())).andReturn(null)
				.anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicercaBustaCinqueConfermaExecuter_06() {
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn(
				"CodiceContratto");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("2");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("1998");
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Hashtable) EasyMock.anyObject())).andReturn(null)
				.anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testRicercaBustaCinqueConfermaExecuter_07() {
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().containsKey(
						"RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION"))
				.andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("SearchType")).andReturn("");
		expecting(getRequestEvent().getAttribute("NrTerminale")).andReturn("2");
		expecting(getRequestEvent().getAttribute("Day")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Month")).andReturn("01");
		expecting(getRequestEvent().getAttribute("Year")).andReturn("1998");
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Hashtable) EasyMock.anyObject())).andReturn(null)
				.anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	private static Hashtable getHashtable() {
		ArrayList arrayList = new ArrayList();
		arrayList.add("1");
		arrayList.add("2");
		Hashtable hashtable = new Hashtable();
		hashtable.put("CollRicercaList", arrayList);
		return hashtable;
	}
}
