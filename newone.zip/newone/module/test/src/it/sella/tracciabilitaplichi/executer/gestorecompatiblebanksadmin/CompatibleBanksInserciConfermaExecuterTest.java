package it.sella.tracciabilitaplichi.executer.gestorecompatiblebanksadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import junit.framework.Assert;

public class CompatibleBanksInserciConfermaExecuterTest extends
AbstractSellaExecuterMock {

	public CompatibleBanksInserciConfermaExecuterTest(final String name) {
		super(name);
	}

	CompatibleBanksInserciConfermaExecuter executer = new CompatibleBanksInserciConfermaExecuter();

	public void testCompatibleBanksInserciConfermaExecuter_01() {
		TracciabilitaPlichiImplMock.setCassetto();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21122355").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("123").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		Assert.assertTrue(true);
	}

	public void testCompatibleBanksInserciConfermaExecuter_02() {
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		TracciabilitaPlichiManagerBeanMock.setTracciabilitaException();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21122355").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("123").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public void testCompatibleBanksInserciConfermaExecuter_03() {
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		TracciabilitaPlichiManagerBeanMock.setRemoteException();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21122355").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("123").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public void testCompatibleBanksInserciConfermaExecuter_04() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		TracciabilitaPlichiManagerBeanMock.setTracciabilitaException();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21122355").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("123").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

	public void testCompatibleBanksInserciConfermaExecuter_05() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		TracciabilitaPlichiManagerBeanMock.setTracciabilitaException();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21122355").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("123").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

}
