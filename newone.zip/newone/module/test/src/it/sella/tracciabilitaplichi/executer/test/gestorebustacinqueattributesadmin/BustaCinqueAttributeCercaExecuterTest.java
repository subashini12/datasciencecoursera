package it.sella.tracciabilitaplichi.executer.test.gestorebustacinqueattributesadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustacinqueattributesadmin.BustaCinqueAttributeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;

import java.io.Serializable;

import org.easymock.EasyMock;

public class BustaCinqueAttributeCercaExecuterTest extends AbstractSellaExecuterMock {

    BustaCinqueAttributeCercaExecuter BustaCinqueAttributeCercaExecuter = new BustaCinqueAttributeCercaExecuter();

    public BustaCinqueAttributeCercaExecuterTest(String name) {
        super(name);
    }

	public void testBustaCinqueAttributeCercaExecuter_01() {

		expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		playAll();

		ExecuteResult executeResult = BustaCinqueAttributeCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("MSG"), "TRPL-1059");
		assertEquals(executeResult.getAttribute("ID"), "");
	}

	public void testBustaCinqueAttributeCercaExecuter_02() {

		expecting(getRequestEvent().getAttribute("ID")).andReturn("test");
		playAll();

		ExecuteResult executeResult = BustaCinqueAttributeCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("MSG"), "TRPL-1060");
		assertEquals(executeResult.getAttribute("ID"), "test");
	}

	public void testBustaCinqueAttributeCercaExecuter_03() {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("698");
		playAll();

		ExecuteResult executeResult = BustaCinqueAttributeCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("MSG"), "TRPL-1059");
		assertEquals(executeResult.getAttribute("ID"), "698");
	}

	public void testBustaCinqueAttributeCercaExecuter_04() {

		TracciabilitaPlichiAdminTransactionDataAccessMock
				.setBustaCinqueAttributeViewNotNull();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("698");
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Serializable) EasyMock.anyObject())).andReturn(null);
		playAll();

		ExecuteResult executeResult = BustaCinqueAttributeCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}

	public void testBustaCinqueAttributeCercaExecuter_05() {
		TracciabilitaPlichiAdminTransactionDataAccessMock
				.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("698");
		playAll();

		ExecuteResult executeResult = BustaCinqueAttributeCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getException().toString(),
				"it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException");
	}
      
  }
