package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.ToControlloExecuter;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultB10Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents.processor.PlichiContentsDefaultB10ProcessorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.B10UltimoEsitoHandlerMock;
import it.sella.tracciabilitaplichi.implementation.util.B10UltimoEsitoHandler;

import org.easymock.EasyMock;

public class ToControlloExecuterTest extends AbstractSellaExecuterMock
{

	public ToControlloExecuterTest(final String name) 
	{
		super(name);	
	}
	
	ToControlloExecuter executer = new ToControlloExecuter();

	
	public void testToControlloExecuter_forSuccessCase()
	{
		setUpMockMethods( B10UltimoEsitoHandler.class, B10UltimoEsitoHandlerMock.class);
	    setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
	    expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	public void testToControlloExecuter_forTracciabilitaException()
	{
		B10UltimoEsitoHandlerMock.setTracciabilitaException() ;
		setUpMockMethods( B10UltimoEsitoHandler.class, B10UltimoEsitoHandlerMock.class);
	    setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
	    expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testToControlloExecuter_forRemoteException()
	{
		B10UltimoEsitoHandlerMock.setRemoteException() ;
		setUpMockMethods( B10UltimoEsitoHandler.class, B10UltimoEsitoHandlerMock.class);
	    setUpMockMethods( PlichiContentsDefaultB10Processor.class, PlichiContentsDefaultB10ProcessorMock.class);
	    expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
}
