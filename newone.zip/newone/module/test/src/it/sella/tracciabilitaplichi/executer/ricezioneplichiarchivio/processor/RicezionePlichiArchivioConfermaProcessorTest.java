package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author gbs03134
 * 
 */

public class RicezionePlichiArchivioConfermaProcessorTest extends
		AbstractSellaExecuterMock {

	public RicezionePlichiArchivioConfermaProcessorTest(final String name) {
		super(name);
	}

	RicezionePlichiArchivioConfermaProcessor processor = new RicezionePlichiArchivioConfermaProcessor();

	/**
	 * check getValidatedToken method
	 * 
	 */

	public void testRicezionePlichiArchivioConfermaProcessor_01() {
		processor.getValidatedToken("PBusta10");
	}

	/**
	 * check updateInvalidBarcodes method
	 * 
	 */

	public void testRicezionePlichiArchivioConfermaProcessor_02() {
		processor.updateInvalidBarcodes(getBarcodeList());
	}

	/**
	 * check processB5Records method In this testcase we can check boxId is Not
	 * a numeric one .
	 */

	public void testRicezionePlichiArchivioConfermaProcessor_03() {
		try {
			expecting(getRequestEvent().getAttribute("boxId")).andReturn("A").anyTimes();
			playAll();
			processor.processB5Records(null, getRequestEvent(),getBarcodeList(), getBarcodeList(), getBarcodeList(),getBarcodeMap(), getBarcodeMap(), "", "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	/**
	 * In processB5Records() method  we can check boxId is a
	 * numeric one .
	 */

	/*public void testRicezionePlichiArchivioConfermaProcessor_04() {
		setUpMockMethods(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		try {
			expecting(getRequestEvent().getAttribute("boxId")).andReturn("2").anyTimes();
			expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("BARCODE").anyTimes();
			playAll();
			processor.processB5Records(null, getRequestEvent(),getList(), getList(), getList(),getBarcodeMap(), getBarcodeMap(), "", "");
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	*/
	public void testRicezionePlichiArchivioConfermaProcessor_05()
	{
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		try {
			processor.updatePB5Collection(getBarcodeList(), getBarcodeMap(), getBarcodeMap(), getBarcodeMap());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private List getList() {
		final List barcodeList = new ArrayList();
		barcodeList.add("1234567891234");
		barcodeList.add("ADDONE");
		return barcodeList;
	}

	private List getBarcodeList() {
		final List barcodeList = new ArrayList();
		barcodeList.add("1234567891234");
		return barcodeList;
	}
	
	private Map getBarcodeMap() {
		final List barcodeList = getBarcodeList();
		final Map barcodeMap = new HashMap();
		barcodeMap.put("1234567891234",barcodeList);
		return barcodeMap;
	}
}
