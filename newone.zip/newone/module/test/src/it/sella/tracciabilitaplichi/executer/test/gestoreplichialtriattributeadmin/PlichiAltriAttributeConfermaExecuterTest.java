package it.sella.tracciabilitaplichi.executer.test.gestoreplichialtriattributeadmin;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import it.sella.tracciabilitaplichi.executer.gestoreplichialtriattributeadmin.PlichiAltriAttributeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;

public class PlichiAltriAttributeConfermaExecuterTest extends AbstractSellaExecuterMock
{

	public PlichiAltriAttributeConfermaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	PlichiAltriAttributeConfermaExecuter executer = new PlichiAltriAttributeConfermaExecuter();

	public void testConfermaExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	public void testConfermaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testConfermaExecuter_03()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}

	public void testConfermaExecuter_04()
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testConfermaExecuter_05()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testConfermaExecuter_06()
	{
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testConfermaExecuter_07()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods( ExecutersHelper.class, ExecutersHelperMock.class );
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("WinboxId")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().get( "PlichiAltriAttributeTable" )).andReturn( (Serializable) getPlichiAltriAttributeTable()  ).anyTimes();
        playAll();
		executer.execute(getRequestEvent());
	}
	
	private  Map getPlichiAltriAttributeTable()
	{
		 Map plichiAltriAttributeTable = new Hashtable();
		 plichiAltriAttributeTable.put(1, "abc");
		 return plichiAltriAttributeTable;
	}
}
