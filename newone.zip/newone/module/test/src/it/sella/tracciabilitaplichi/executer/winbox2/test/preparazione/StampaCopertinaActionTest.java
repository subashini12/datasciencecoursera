/*package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import static it.sella.tracciabilitaplichi.implementation.mock.TracciabilitaPlichiManagerMock.mockEJB;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CAUSALE;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.AbstractExecuter;
import it.sella.tracciabilitaplichi.executer.winbox2.WB2Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsHelper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.StampaCopertinaAction;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.dto.WinBox2;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;
import mockit.Mockit;


public class StampaCopertinaActionTest extends TestCase
{
        RequestEvent requestEvent = null;
        StateMachineSession smSession = null;
        Map<Enum, Object> sessionMap = null; 
        public StampaCopertinaActionTest( final String message )
        {
            super( message );
        }
        @Override
		protected void setUp( ) throws Exception
        {
            super.setUp( );
            this.requestEvent = createMock( RequestEvent.class );
            this.smSession = createMock( StateMachineSession.class );
            expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.smSession );
            
            Mockit.redefineMethods( Helper.class, new Object( ){
                public Map<Enum, Object> getSessionMap( final StateMachineSession session ) throws TracciabilitaException, RemoteException
                {
                   sessionMap = new HashMap<Enum,Object>( 1 );
                   sessionMap.put( CONSTANTS.USER_DETAILS, new HashMap<String, Object>( 1) );
                   sessionMap.put( CONSTANTS.FOLDER_TYPES_MAP, new HashMap<Long,String>( 1 ) );
                   sessionMap.put( CONSTANTS.WINBOX2, new WinBox2( ) );
                   sessionMap.put( CONSTANTS.WINBOX2_COLLECTION, new ArrayList<WinBox2>( ) );
                   return sessionMap;
                }
                public Collection<String> getFolderOggettoIdColl( final WinBox2 winBox2 )
                {
                    return new ArrayList<String>( 1 );
                }
            });

            Mockit.redefineMethods( WB2Helper.class, new Object( ) { 
            	public OggettoView getBasicOggettoView( final Map userDetails, final CAUSALE causale, final String statusType ) throws TracciabilitaException, RemoteException
                {
                    return new OggettoView( );
                }
                public String getWinbox2Barcode( final Map<Enum,Object> sessionMap, final WinBox2 winBox2, final String documentCode, final String winbox2Barcode ) throws RemoteException, TracciabilitaException
                {
                	sessionMap.put( CONSTANTS.STAMPE_ID, 123456789012L );
                    return "1234567890123";
                }
            } );
            mockEJB( );
            Mockit.redefineMethods( TracciabilitaPlichiManagerBean.class, new Object( ) {
                public Long censitoOggetto(final Properties properties) throws TracciabilitaException, RemoteException
                {
                    return 1L;
                }  
            } );
            Mockit.redefineMethods( GrantsHelper.class, new Object( ) {
                public  Grants getDefaultUserGrants( ) throws TracciabilitaException, RemoteException
                {
                    return new Grants( );
                }  
            } );
            
        }
        public void testExecuteAction_01( ) throws TracciabilitaException, RemoteException
        {
            expect( this.requestEvent.getAttribute( CONSTANTS.WINBOX2_BARCODE.getValue( ) ) ).andReturn( "" );
            mockNeccessary( );
            replay( this.smSession );
            replay( this.requestEvent );
            final AbstractExecuter abstractExecuter = new StampaCopertinaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_CONFERMA, actual ); 
            assertEquals( IErrorCodes.TRPL_1056, sessionMap.get( CONSTANTS.SUCCESS ) );
        }
        public void testExecuteAction_02( ) throws TracciabilitaException, RemoteException
        {
            expect( this.requestEvent.getAttribute( CONSTANTS.WINBOX2_BARCODE.getValue( ) ) ).andReturn( "123" );    
            replay( this.smSession );
            replay( this.requestEvent );
            final AbstractExecuter abstractExecuter = new StampaCopertinaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_ERROR, actual ); 
        }
        public void testExecuteAction_03( ) throws TracciabilitaException, RemoteException
        {
            Mockit.redefineMethods( TracciabilitaPlichiCommonDataAccess.class, new Object( ) {
                public boolean isExistPlichi( String barCode ) throws TracciabilitaException
                {
                    return Boolean.FALSE;
                }  
            } );
            expect( this.requestEvent.getAttribute( CONSTANTS.WINBOX2_BARCODE.getValue( ) ) ).andReturn( "1000000766721" );
            mockNeccessary( );
            replay( this.smSession );
            replay( this.requestEvent );
            final AbstractExecuter abstractExecuter = new StampaCopertinaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_CONFERMA, actual ); 
        }
        public void testExecuteAction_04( ) throws TracciabilitaException, RemoteException
        {
            Mockit.redefineMethods( TracciabilitaPlichiCommonDataAccess.class, new Object( ) {
                public boolean isExistPlichi( String barCode ) throws TracciabilitaException
                {
                    return Boolean.TRUE;
                }  
            } );
            expect( this.requestEvent.getAttribute( CONSTANTS.WINBOX2_BARCODE.getValue( ) ) ).andReturn( "1000000766721" );    
            replay( this.smSession );
            replay( this.requestEvent );
            final AbstractExecuter abstractExecuter = new StampaCopertinaAction( );
            final Enum actual = abstractExecuter.executeAction( requestEvent );
            assertEquals( CONSTANTS.TR_ERROR, actual ); 
        }
       
        public void testGetLoggerMap( )
        {
            Mockit.redefineMethods( LogHelper.class, new Object( ) {
                public String getWbx2PreparazioneXML( final Map<Enum,Object> sessionMap )
                {
                    return "</xml>";
                }  
            } );
            final AbstractExecuter abstractExecuter = new StampaCopertinaAction( );
            final Map<CONSTANTS,String> actual = abstractExecuter.getLoggerMap( new HashMap<Enum, Object>( 1 ) );
            assertEquals( LOGGER.WBX2.PREPARAZIONE.getValue( ), actual.get( CONSTANTS.OPERATION_CODE ) );
            assertEquals( "</xml>", actual.get( CONSTANTS.LOG_XML ) );
        }
        protected void tearDown( )
        {
            Mockit.restoreAllOriginalDefinitions( );
        }
        
        private void mockNeccessary( )
        {
            expect( this.smSession.put( CONSTANTS.STAMPE_ID.getValue( ), 123456789012L ) ).andReturn( Boolean.TRUE );
            final Enum[ ]  enumArray = { CONSTANTS.IS_CDR_VISIBILITY,CONSTANTS.ACCODA_PRATICA,CONSTANTS.CUSTOM_ACCESS };
            for( final Enum constant : Arrays.asList( enumArray ) )
            {
                expect( this.smSession.remove( constant.toString( ) ) ).andReturn( null );
            }

        }
        public void testGetLogger( )
        {
            final Log4Debug expected = Log4DebugFactory.getLog4Debug( StampaCopertinaAction.class );
            final AbstractExecuter abstractExecuter = new StampaCopertinaAction( );
            assertEquals(  expected.getClass( ), abstractExecuter.getLogger( ).getClass( ) );
        }
}*/