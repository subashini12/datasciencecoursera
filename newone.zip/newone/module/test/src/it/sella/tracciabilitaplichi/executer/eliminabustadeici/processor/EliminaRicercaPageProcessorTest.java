package it.sella.tracciabilitaplichi.executer.eliminabustadeici.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.util.Hashtable;

import junit.framework.Assert;

public class EliminaRicercaPageProcessorTest extends AbstractSellaExecuterMock {

	public EliminaRicercaPageProcessorTest(final String name) {
		super(name);
	}

	EliminaRicercaPageProcessor processor = new EliminaRicercaPageProcessor();

	public void testEliminaRicercaPageProcessor_01() {
		UtilMock.setAlphaNumericFalse();
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NC", "1");
		setUpMockMethods(Util.class, UtilMock.class);
		assertEquals("TRPL-1396",processor.validateRicerca(hashtable));
	}

	public void testEliminaRicercaPageProcessor_02() {
		UtilMock.setAlphaNumericFalse();
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NC", "");
		hashtable.put("NCD", "1");
		setUpMockMethods(Util.class, UtilMock.class);
		assertEquals("TRPL-1397",processor.validateRicerca(hashtable));
	}

	public void testEliminaRicercaPageProcessor_03() {
		UtilMock.setAlphaNumericFalse();
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NC", "");
		hashtable.put("NCD", "");
		hashtable.put("CIF8", "1");
		setUpMockMethods(Util.class, UtilMock.class);
		assertEquals("TRPL-1398",processor.validateRicerca(hashtable));
	}

	public void testEliminaRicercaPageProcessor_04() {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NC", "");
		hashtable.put("NCD", "");
		hashtable.put("CIF8", "");
		hashtable.put("endDate","12/12/2000");
		hashtable.put("startDate", "12/12/2000");
		setUpMockMethods(Util.class, UtilMock.class);
		processor.validateRicerca(hashtable);
		Assert.assertTrue(true);
	}

	public void testEliminaRicercaPageProcessor_05() {
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NC", "");
		hashtable.put("NCD", "");
		hashtable.put("CIF8", "");
		hashtable.put("endDate","12/12/2000");
		hashtable.put("startDate", "12/12/2000");
		setUpMockMethods(Util.class, UtilMock.class);
		assertEquals("TRPL-1052",processor.validateRicerca(hashtable));
	}

}
