package it.sella.tracciabilitaplichi.executer.eliminabustadeici.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciRicercaView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;


public class EliminaFilterPageProcessorTest extends AbstractSellaExecuterMock{

	public EliminaFilterPageProcessorTest(final String name) {
		super(name);
	}

	EliminaFilterPageProcessor processor = new EliminaFilterPageProcessor() ;
	
	public void testEliminaFilterPageProcessor_01() {
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getStateMachineSession().get("ricercaQuery")).andReturn(getBustaDeiciRicercaView()).anyTimes();
		expecting(getStateMachineSession().get("DR")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("statcon")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("nc")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("CODCONTRATTO")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("productId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("anagrafe")).andReturn("df").anyTimes();
		expecting(getRequestEvent().getAttribute("dipIns")).andReturn("asdfgv").anyTimes();
		expecting(getRequestEvent().getAttribute("daigg")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("daimm")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("daiaa")).andReturn("1212").anyTimes();
		playAll();
		try {
			assertNotNull(processor.mapFilterPageData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testEliminaFilterPageProcessor_02() {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getStateMachineSession().get("ricercaQuery")).andReturn(getBustaDeiciRicercaView()).anyTimes();
		expecting(getStateMachineSession().get("DR")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("statcon")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("nc")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("CODCONTRATTO")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("productId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("anagrafe")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("dipIns")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("daigg")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("daimm")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("daiaa")).andReturn("12").anyTimes();
		playAll();
		try {
			assertNotNull(processor.mapFilterPageData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	private static BustaDeiciRicercaView getBustaDeiciRicercaView() {
		final BustaDeiciRicercaView bustaDeiciRicercaView = new BustaDeiciRicercaView();
		return bustaDeiciRicercaView;
	}
	
	private static Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("startDate", "12");
		hashtable.put("endDate", "12");
		return hashtable ;
	}
	
	public void testEliminaFilterPageProcessor_03() {
		processor.setUniqueCodContrattoColl( getCollection(), "A");
	}
	
	private static Collection getCollection() {
		final Collection collection = new ArrayList() ;
		collection.add("");
		return collection ;
	}
}
