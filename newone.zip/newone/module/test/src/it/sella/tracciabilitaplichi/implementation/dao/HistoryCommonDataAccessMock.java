package it.sella.tracciabilitaplichi.implementation.dao;

import mockit.Mock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

public class HistoryCommonDataAccessMock 
{
	@Mock
	public boolean isExistsPlichiForBarcodeHistory( String barCode ) throws TracciabilitaException
	{
		return true;
	}

}
