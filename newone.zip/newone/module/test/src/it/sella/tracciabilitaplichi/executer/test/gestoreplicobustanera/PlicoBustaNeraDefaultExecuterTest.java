package it.sella.tracciabilitaplichi.executer.test.gestoreplicobustanera;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplicobustanera.PlicoBustaNeraDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;

import org.easymock.EasyMock;


public class PlicoBustaNeraDefaultExecuterTest extends AbstractSellaExecuterMock
{

	public PlicoBustaNeraDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlicoBustaNeraDefaultExecuter executer = new PlicoBustaNeraDefaultExecuter();
	
	public void testExecuter_01()
	{
	    setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		Hashtable hashtable=getPreparazioneBustaNeraHashTable();
		hashtable=null;
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  hashtable );
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_02()
	{
	    setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  getPreparazioneBustaNeraHashTable()  ).anyTimes();
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_03()
	{
	    setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		final Hashtable hashtable= getPreparazioneBustaNeraHashTable();
		hashtable.put( CONSTANTS.IS_BN_EXPEDITION_OFFICE.toString( ),Boolean.FALSE );
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  hashtable );
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_04()
	{  
	    TracciabilitaPlichiPlichiDataAccessMock.setBarCodeReaderAvailableTrue();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		Hashtable hashtable=getPreparazioneBustaNeraHashTable();
		hashtable=null;
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  hashtable );
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_05()
	{  
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		final Hashtable hashtable= getPreparazioneBustaNeraHashTable();
		final Hashtable pageInfo= new Hashtable();
		pageInfo.put("pageNo",3);
		hashtable.put( "pageInfo",pageInfo);
		hashtable.put( CONSTANTS.IS_BN_EXPEDITION_OFFICE.toString( ),Boolean.FALSE );
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  hashtable );
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_06()
	{  
		SecurityWrapperMock.setTracciabilitaException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		final Hashtable hashtable= getPreparazioneBustaNeraHashTable();
		final Hashtable pageInfo= new Hashtable();
		pageInfo.put("pageNo",3);
		hashtable.put( "pageInfo",pageInfo);
		hashtable.put( CONSTANTS.IS_BN_EXPEDITION_OFFICE.toString( ),Boolean.FALSE );
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  hashtable );
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	public void testExecuter_07()
	{  
		SecurityDBpersonaleWrapperMock.setRemoteException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   (Serializable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		final Hashtable hashtable= getPreparazioneBustaNeraHashTable();
		final Hashtable pageInfo= new Hashtable();
		pageInfo.put("pageNo",3);
		hashtable.put( "pageInfo",pageInfo);
		hashtable.put( CONSTANTS.IS_BN_EXPEDITION_OFFICE.toString( ),Boolean.FALSE );
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  hashtable );
		expecting( getStateMachineSession().remove( "PreparazioneBustaNeraHashTable" ) ).andReturn(null).anyTimes();	
		playAll();		
		executer.execute( getRequestEvent());
	}
	
	private Hashtable  getPreparazioneBustaNeraHashTable()
	{
		final Hashtable PreparazioneBustaNeraHashTable = new Hashtable();
		final ArrayList OggettoCollection = new ArrayList(); 
		PreparazioneBustaNeraHashTable.put("OggettoCollection", OggettoCollection);
		PreparazioneBustaNeraHashTable.put( CONSTANTS.IS_BN_EXPEDITION_OFFICE.toString( ),Boolean.TRUE);
		PreparazioneBustaNeraHashTable.put( "Operation","Conferma-Archive");
		final Hashtable pageInfo= new Hashtable();
		pageInfo.put("pageNo",1);
		PreparazioneBustaNeraHashTable.put( "Hashtable","Conferma-Archive");
		PreparazioneBustaNeraHashTable.put( "pageInfo",pageInfo);
		PreparazioneBustaNeraHashTable.put("PageNo","5");
		return PreparazioneBustaNeraHashTable;
	}
}
