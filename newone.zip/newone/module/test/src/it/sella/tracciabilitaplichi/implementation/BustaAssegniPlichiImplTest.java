package it.sella.tracciabilitaplichi.implementation;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.TracciabilitaImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Properties;



public class BustaAssegniPlichiImplTest extends AbstractSellaMock{

	public BustaAssegniPlichiImplTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	BustaAssegniPlichiImpl bustaAssegniPlichiImpl=new BustaAssegniPlichiImpl();


	/*public void testBustaAssegniPlichiImpl_02()
	{
		setUpMockMethods(TracciabilitaImpl.class, TracciabilitaImplMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		final Properties properties=getNullOggettoViewProperties();
		try {
			bustaAssegniPlichiImpl.censitoOggetto(properties);
		} catch (final RemoteException e) {
		} catch (final TracciabilitaException e) {
		}
	}*/

	public void testBustaAssegniPlichiImpl_01()
	{
		UtilMock.setCheckNullFalse();
		setUpMockMethods(TracciabilitaImpl.class, TracciabilitaImplMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		final Properties properties=getProperties();
		try {
			bustaAssegniPlichiImpl.censitoOggetto(properties);
		} catch (final RemoteException e) {
		} catch (final TracciabilitaException e) {
		}
	}

	public void testBustaAssegniPlichiImpl_03()
	{
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		final Properties properties=getProperties();
		try {
			bustaAssegniPlichiImpl.cancelliOggetto(properties);
		} catch (final RemoteException e) {
		} catch (final TracciabilitaException e) {
		}
	}

	private static OggettoView getOggettoView()
	{
		final OggettoView oggettoView=new OggettoView();
		oggettoView.setUserId("2");
		oggettoView.setCdrName("01235");
		oggettoView.setStatusId(2L);
		oggettoView.setUserId("56");
		new SimpleDateFormat("dd/MM/yyyy");
		final Date date = new Date("2012,jan,9");
		final Timestamp timeStamp = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(timeStamp);
		return oggettoView;
	}

	private static Properties getProperties()
	{
		final HistoryView historyView=getHistoryView();
		final PlichiAttributeView plichiAttributeView=getPlichiAttributeView();
		final Collection collection=getCollection();
		final OggettoView oggettoView=getOggettoView();
		final Properties properties=new Properties();
		properties.put(ITPConstants.OGGETTO_VIEW ,oggettoView );
		properties.put(ITPConstants.INVIO_BA_COLLECTION ,collection );
		properties.put(ITPConstants.PLICHI_ATTRIBUTE_VIEW ,plichiAttributeView );
		properties.put(ITPConstants.HISTORY_VIEW, historyView);
		return properties;
	}

	private static HistoryView getHistoryView()
	{
		final HistoryView historyView=new HistoryView();
		historyView.setDocumentId(2L);
		return historyView;
	}

	private static Properties getNullOggettoViewProperties()
	{
		final PlichiAttributeView plichiAttributeView=getPlichiAttributeView();
		final Collection collection=getCollection();
		final Properties properties=new Properties();
		properties.put(ITPConstants.INVIO_BA_COLLECTION ,collection );
		properties.put(ITPConstants.PLICHI_ATTRIBUTE_VIEW ,plichiAttributeView );
		return properties;
	}

	private static Collection getCollection()
	{
		final Collection collection=new ArrayList();
		return collection;
	}

	public static PlichiAttributeView getPlichiAttributeView()
	{
		final PlichiAttributeView plichiAttributeView=new PlichiAttributeView();
		plichiAttributeView.setBarCode("1234567890123");
		return plichiAttributeView;
	}


}
