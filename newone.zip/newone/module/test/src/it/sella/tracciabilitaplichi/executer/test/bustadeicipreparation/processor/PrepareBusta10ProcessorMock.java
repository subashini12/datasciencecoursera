package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation.processor;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class PrepareBusta10ProcessorMock 
{
	 private static Boolean tracciabilitaException = false;	
	 private static Boolean remoteException = false;
	 
	 public  static void setTracciabilitaException() 
	 {
 			  tracciabilitaException = true;
     }
	 public  static void setRemoteException() 
	 {
		 remoteException = true;
     }
	@Mock
	public static void prepareBusta10(Busta10PreparationPageView pageView) throws TracciabilitaException, RemoteException 
	{
		if(tracciabilitaException)
		  {
	    	tracciabilitaException = false;
	    	throw new TracciabilitaException();
		  }
	      if( remoteException )
	      {
	    	  remoteException = false;
	    	  throw new RemoteException();
	      }	
		return ;
	}
	@Mock
	public static Collection<BustaDeiciAttributeView> getContractList(Busta10PreparationPageView pageView) throws TracciabilitaException, RemoteException {
		
		if(tracciabilitaException)
		  {
	    	tracciabilitaException = false;
	    	throw new TracciabilitaException();
		  }
	      if( remoteException )
	      {
	    	  remoteException = false;
	    	  throw new RemoteException();
	      }
		Collection<BustaDeiciAttributeView> col = new ArrayList<BustaDeiciAttributeView>();
		BustaDeiciAttributeView  view1 = new BustaDeiciAttributeView();
		view1.setBarcode("123");
		view1.setBustaDeiciId(1L);
		BustaDeiciAttributeView  view2 = new BustaDeiciAttributeView();
		view2.setBarcode("123123");
		view2.setBustaDeiciId(2L);
		col.add(view2);
		return col;
	}
}
