package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichi;

import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.Paging;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import mockit.Mock;
import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;



public class SituazionePlichiExecuterTest {

	SituazionePlichiExecuter executer = new SituazionePlichiExecuter() ;
	
	@Test
	public void executer_01() {
		
		Hashtable views  = new Hashtable() ;
		views.put("TypesOfOggettos","");
		views.put("BankViewList","");
		views.put("SearchQuery","");
		views.put("paramValues","");
		views.put("PageNo","");
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.containsKey(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(session.containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.get( EasyMock.anyObject() )).andReturn(views).anyTimes();
		EasyMock.expect(session.put("GESTORE_SITUAZIONE_PLICHI_SESSION",views ) ).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent rqEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(rqEvent.getEventName()).andReturn("TrBack").anyTimes();
		EasyMock.expect(rqEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(rqEvent);
		
		ExecuteResult executeResult = executer.execute(rqEvent);
		String bankViewList = (String) executeResult.getAttribute("BankViewList");
		Assert.assertTrue(bankViewList.isEmpty());
		
	}
	
	@Test
	public void executer_02() {
		
		Hashtable views  = new Hashtable() ;
		views.put("TypesOfOggettos","");
		views.put("BankViewList","");
		views.put("SearchQuery","");
		views.put("paramValues","");
		views.put("PageNo","");
		views.put("FilteredTypesOfOggettos","");
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.containsKey(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.get( EasyMock.anyObject() )).andReturn(views).anyTimes();
		EasyMock.expect(session.put("GESTORE_SITUAZIONE_PLICHI_SESSION",views ) ).andReturn("").anyTimes();
		EasyMock.expect(session.remove(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent rqEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(rqEvent.getEventName()).andReturn("TrBack").anyTimes();
		EasyMock.expect(rqEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(rqEvent);
		
		executer.execute(rqEvent);
		
		Assert.assertTrue(Boolean.TRUE);
		
	}
	
	@Test
	public void executer_03() {
		
		TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		final Collection collectionPlichiview = new ArrayList(); 
		collectionPlichiview.add(tracciabilitaPlichiView);
		
		Mockit.setUpMock(Paging.class, new Object(){
			@Mock
			public Collection getPageData( final int pageNo ) {
				return collectionPlichiview;
		    }
		});
		
		Hashtable views  = new Hashtable() ;
		views.put("TypesOfOggettos","");
		views.put("BankViewList","");
		views.put("SearchQuery","");
		views.put("paramValues","");
		views.put("PageNo","");
		views.put("StatusViewList","");
		
		LazyFetchCollection lazyFetchCollection = EasyMock.createMock(LazyFetchCollection.class);
		EasyMock.expect(lazyFetchCollection.size()).andReturn(2).anyTimes();
		EasyMock.expect(lazyFetchCollection.iterator(0,2)).andReturn(null).anyTimes();
		EasyMock.replay(lazyFetchCollection);
		
		views.put("FiltraCollPlichiView",lazyFetchCollection);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.containsKey(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(session.containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(views).anyTimes();
		EasyMock.expect(session.put("GESTORE_SITUAZIONE_PLICHI_SESSION",views ) ).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent rqEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(rqEvent.getEventName()).andReturn("TrPageLink").anyTimes();
		EasyMock.expect(rqEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.expect(rqEvent.getAttribute( "PageNo" )).andReturn("1").anyTimes();
		EasyMock.replay(rqEvent);
		
		ExecuteResult executeResult = executer.execute(rqEvent);
		String bankViewList = (String) executeResult.getAttribute("TypesOfOggettos");
		Assert.assertTrue(bankViewList.isEmpty());
		
	}
	
	@Test
	public void executer_04() {
		
		Mockit.setUpMock(Paging.class, new Object(){
			@Mock
			public Collection getPageData( final int pageNo ) {
				return null;
		    }
		});
		
		Hashtable views  = new Hashtable() ;
		views.put("TypesOfOggettos","");
		views.put("BankViewList","");
		views.put("SearchQuery",new StringBuilder(" select * from "));
		views.put("paramValues",new ArrayList());
		views.put("PageNo","");
		views.put("StatusViewList","");
		views.put("FilteredTypesOfOggettos","");
		
		LazyFetchCollection lazyFetchCollection = EasyMock.createMock(LazyFetchCollection.class);
		EasyMock.expect(lazyFetchCollection.size()).andReturn(2).anyTimes();
		EasyMock.expect(lazyFetchCollection.iterator(0,2)).andReturn(null).anyTimes();
		EasyMock.replay(lazyFetchCollection);
		
		views.put("FiltraCollPlichiView",lazyFetchCollection);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.containsKey(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(session.containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(views).anyTimes();
		EasyMock.expect(session.put("GESTORE_SITUAZIONE_PLICHI_SESSION",views) ).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent rqEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(rqEvent.getEventName()).andReturn("TrPageLink").anyTimes();
		EasyMock.expect(rqEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.expect(rqEvent.getAttribute( "PageNo" )).andReturn("1").anyTimes();
		EasyMock.replay(rqEvent);
		
		executer.execute(rqEvent);
		
		Assert.assertTrue(Boolean.TRUE);
		
	}
	
}
