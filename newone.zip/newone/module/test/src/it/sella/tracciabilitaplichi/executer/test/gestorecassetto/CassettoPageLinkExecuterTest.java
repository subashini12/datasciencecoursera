package it.sella.tracciabilitaplichi.executer.test.gestorecassetto;

import it.sella.tracciabilitaplichi.executer.gestorecassetto.CassettoPageLinkExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccessMock;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

public class CassettoPageLinkExecuterTest extends AbstractSellaExecuterMock
{

	public CassettoPageLinkExecuterTest(final String name) 
	{
		super(name);	
	}
	
	CassettoPageLinkExecuter executer = new CassettoPageLinkExecuter();
	
	public void testCassettoPageLinkExecuter_01()
	{
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "pageNumber" )).andReturn( "01").anyTimes();
		expecting( getStateMachineSession().get( "collCassetto" ) ).andReturn( (Serializable) getCollCassetto() ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCassettoPageLinkExecuter_02()
	{
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "pageNumber" )).andReturn( "01").anyTimes();
		expecting( getStateMachineSession().get( "collCassetto" ) ).andReturn( null ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCassettoPageLinkExecuter_forFailureCase()
	{
		TracciabilitaPlichiCassettoDataAccessMock.setRemoteException();
		setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting( getRequestEvent().getAttribute( "pageNumber" )).andReturn( "01").anyTimes();
		expecting( getStateMachineSession().get( "collCassetto" ) ).andReturn( (Serializable) getCollCassetto() ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private Collection getCollCassetto()
	{
		final Collection collCassetto = new ArrayList();
		final Hashtable tempHash = new Hashtable( 2 );
		tempHash.put( "CASETTO",  "LC_CASETTO"  );
		tempHash.put( "BANKID",  "LC_BANK_ID"  );
		collCassetto.add( tempHash );
		return collCassetto;
	}

}
