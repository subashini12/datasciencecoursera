package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoBustaInsersciExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Hashtable;

public class ArchivoBustaInsersciExecuterTest  extends AbstractSellaExecuterMock {

    ArchivoBustaInsersciExecuter   archivoBustaInsersciExecuter = new   ArchivoBustaInsersciExecuter();

  public   ArchivoBustaInsersciExecuterTest(final String name) {
      super(name);
  }

 public void testArchivoBustaInsersciExecuter_01() {
      final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "24") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "12") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
      playAll();
      final ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1043" );
       
  }
  
  /*public void testArchivoBustaInsersciExecuter_02() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
     
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "BarCodeBuste") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "24") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "12") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
             @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  return  true;
              }
              });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals( "TRPL-1110", executeResult.getAttribute( "MSG") );
  }
  
  public void testArchivoBustaInsersciExecuter_03() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
     
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "BarCodeBuste") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  return  true;
              }
              });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1016" );
  }
  
  public void testArchivoBustaInsersciExecuter_04() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
     
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "BarCodeBuste") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
     
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  return  true;
              }
              });
          
    
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1110" );
  }
  
  public void testArchivoBustaInsersciExecuter_05() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
     
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "9010000000390") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  return  true;
              }
              });
          
      redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
    	  @Mock
          public boolean isExistPlichi( String barCode ) throws TracciabilitaException{
              return  true;
              }
      });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1024" );
  }
  public void testArchivoBustaInsersciExecuter_06() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
      PlichiAttributeView plView = new PlichiAttributeView();
      plView.setBarCode( "9010000000390" );
      TracciabilitaPlichiView trView = new TracciabilitaPlichiView();
      trView.setPlichiAttributeView( plView );
      list.add( trView  );
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "9010000000390") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  return  true;
              }
              });
          
      redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
    	  @Mock
          public boolean isExistPlichi( String barCode ) throws TracciabilitaException{
              return  false;
              }
      });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals(executeResult.getAttribute( "MSG"), "TRPL-1310" );
  } 
  public void testArchivoBustaInsersciExecuter_07() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
      PlichiAttributeView plView = new PlichiAttributeView();
      plView.setBarCode( "9010000000420" );
      TracciabilitaPlichiView trView = new TracciabilitaPlichiView();
      trView.setPlichiAttributeView( plView );
      list.add( trView  );
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "9010000000390") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  return  true;
              }
              });
          
      redefineMethod(TracciabilitaPlichiCommonDataAccess.class, new Object(){
    	  @Mock
          public boolean isExistPlichi( String barCode ) throws TracciabilitaException{
              return  false;
              }
    	  @Mock
          public String getCdrForLid( String lid, Long bankId ) throws TracciabilitaException, RemoteException{
             return  "";
          }
      });
      
      redefineMethod(SecurityWrapper.class, new Object(){
    	  @Mock
          public String getUserId() throws TracciabilitaException{
              return  "";
              }
    	  @Mock
          public String getBankPrefixCode() throws TracciabilitaException{
              return "BAG";
          }
    	  @Mock
          public Long getBankId() throws TracciabilitaException{
              return 1L;
          }
      });
      redefineMethod( ClassificazioneWrapper.class, new Object( ){
    	  @Mock
          public ClassificazioneView getClassificazioneView( String causale, String parentCausale )
          {
              ClassificazioneView classificazioneView = getMock( ClassificazioneView.class );
              expecting( classificazioneView.getId( ) ).andReturn( 5905L );
              play( classificazioneView );
              return classificazioneView;
          }
      });
      redefineMethod(TracciabilitaPlichiStatusDataAccess.class, new Object(){
    	  @Mock
          public Long getStatusId( final String statusType ) throws TracciabilitaException{
              return  23l;
              }
      });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getTransition( ), ("TrConferma"));
      assertEquals(executeResult.getAttribute( "BustaCinqueArchivoSession"), archivoBustaCinqueSession);
  }
  public void testArchivoBustaInsersciExecuter_08() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
      PlichiAttributeView plView = new PlichiAttributeView();
      plView.setBarCode( "9010000000390" );
      TracciabilitaPlichiView trView = new TracciabilitaPlichiView();
      trView.setPlichiAttributeView( plView );
      list.add( trView  );
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "9010000000390") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  throw new TracciabilitaException();
              }
              });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getException( ).toString( ), ("it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException"));
  } 
  
  public void testArchivoBustaInsersciExecuter_09() {
      Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
      List list = new ArrayList();
      PlichiAttributeView plView = new PlichiAttributeView();
      plView.setBarCode( "9010000000390" );
      TracciabilitaPlichiView trView = new TracciabilitaPlichiView();
      trView.setPlichiAttributeView( plView );
      list.add( trView  );
      archivoBustaCinqueSession.put( "Busta5List", list);
      expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession"  )).andReturn(
              archivoBustaCinqueSession) ;
      expecting(getRequestEvent( ).getAttribute( "Lid"  )).andReturn(
              "Lid") ; 
      expecting(getRequestEvent( ).getAttribute( "BarCodeBuste"  )).andReturn(
      "9010000000390") ; 
      expecting(getRequestEvent( ).getAttribute( "dateDD"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateMM"  )).andReturn(
      "01") ; 
      expecting(getRequestEvent( ).getAttribute( "dateYYYY"  )).andReturn(
      "2010") ; 
          redefineMethod(TracciabilitaPlichiBustasDataAccess.class, new Object(){
        	  @Mock
              public boolean isValidLid( String lid ) throws TracciabilitaException, RemoteException{
                  throw new RemoteException();
              }
              });
      playAll();
      ExecuteResult executeResult =   archivoBustaInsersciExecuter
              .execute(getRequestEvent());
      assertEquals(executeResult.getException( ).toString( ), ("java.rmi.RemoteException"));
  } */
  }

