package it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.CdrGroupAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.CdrGroupAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import mockit.Mockit;

public class CdrGroupInserciConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	public CdrGroupInserciConfermaExecuterTest(final String name) {
		super(name);
	}

	CdrGroupInserciConfermaExecuter executer = new CdrGroupInserciConfermaExecuter();

	public void testCdrGroupInserciConfermaExecute_01() {
		TracciabilitaPlichiImplMock.setBusta20();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(CdrGroupAdminImpl.class,CdrGroupAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public void testCdrGroupInserciConfermaExecute_02() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(CdrGroupAdminImpl.class,CdrGroupAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

	public void testCdrGroupInserciConfermaExecute_03() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(CdrGroupAdminImpl.class,CdrGroupAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
}
