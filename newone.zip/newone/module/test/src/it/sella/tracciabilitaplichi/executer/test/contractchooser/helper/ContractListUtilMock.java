package it.sella.tracciabilitaplichi.executer.test.contractchooser.helper;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ContractListUtilMock 
{
	private static Boolean tracciabilitaException = false;
	
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}
	
	@Mock
	public static Map getContractForPlicoNumero(Map plichiBusta10Map) throws TracciabilitaException 
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
		Map map = new HashMap();
		map.put("a", "value");
		return map;
	}

}
