package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.mock.DBHelperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.HashMap;
import java.util.Iterator;

import junit.framework.Assert;
import mockit.Mockit;
import oracle.jdbc.OracleTypes;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.mockrunner.mock.jdbc.MockResultSet;

public class GestoreBustaDeiciDataAccessTest {

	GestoreBustaDeiciDataAccess gestoreBustaDeiciDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private DBHelperMock dbHelperMock;

	@Before
	public void setUp() throws Exception {
		gestoreBustaDeiciDataAccess = new GestoreBustaDeiciDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		dbHelperMock = new DBHelperMock();
		dbHelperMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(DBConnector.class, dbHelperMock);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
	}

	@After
	public void tearDown() throws Exception {
		gestoreBustaDeiciDataAccess = null;
	}

	@Test
	public void testGetContrattiStatus_01() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(getContrattiStatusQuery());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "ST_TYPE","ST_01");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		gestoreBustaDeiciDataAccess.getContrattiStatus(1l);
		Assert.assertTrue(true);
	}

	@Test
	public void testGetEsitoDescription() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getGetEsitoDescriptionCallableStmt());
		mockStatementProvider.setCallableStatementOutParam(1,
				java.sql.Types.VARCHAR, "ravi");
		mockConnectionProvider.setCallableStatement(mockStatementProvider);
		mockConnectionProvider.replay();
		gestoreBustaDeiciDataAccess.getEsitoDescription(1L);
		Assert.assertEquals("ravi", gestoreBustaDeiciDataAccess.getEsitoDescription(1L));
	}

	@Test
	public void testGetEsitoIdandDesc() throws TracciabilitaException{
		String key = null;
		String val = null;
		mockStatementProvider = new MockStatementProvider(getGetEsitoIdandDescCallableStmt());
		final MockResultSet rs = new MockResultSet("myMock");
		rs.addColumn("DIPEN", new String[]{"Column DIPEN Value"});
		rs.addColumn("CDR", new String[]{"Column CDR Value"});
		mockStatementProvider.setCallableStatementOutParam(1,
				OracleTypes.CURSOR,  rs);
		mockStatementProvider.setCallableStatementOutParam(6,
				java.sql.Types.INTEGER, 5);
		mockStatementProvider.setCallableStatementOutParam(7,
				java.sql.Types.VARCHAR, null);
		mockConnectionProvider.setCallableStatement(mockStatementProvider);
		mockConnectionProvider.replay();
		final HashMap map = gestoreBustaDeiciDataAccess.getEsitoIdandDesc();
		final Iterator iter = map.keySet().iterator();
		while (iter.hasNext()) {
			key = (String) iter.next();
			val = (String) map.get(key);
		}
		Assert.assertEquals("Column CDR Value", val);
	}

	@Test
	public void testGetSFId() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(getGetSFIdCallableStmt());
		mockStatementProvider.setCallableStatementOutParam(1,
				java.sql.Types.BIGINT,Long.valueOf(10));
		mockConnectionProvider.setCallableStatement(mockStatementProvider);
		mockConnectionProvider.replay();
		final Long sfId = gestoreBustaDeiciDataAccess.getSFId("1", "CUN");
		Assert.assertEquals(Long.valueOf(10), sfId);
	}

	private String getGetSFIdCallableStmt() {
		return "{? = call scanner_dba.SCAN_PA_EXTERNAL_INTERFACE.SCAN_FN_GETSFIDBYAPPTAGIMAGE(?,?)}";
	}

	private String getGetEsitoIdandDescCallableStmt() {
		return "{? = call scanner_dba.ctrl_pkg_external_interface.ctrl_fn_get_tipo_controllo(?)}";
	}

	private String getGetEsitoDescriptionCallableStmt() {
		return "{? = call scanner_dba.ctrl_pkg_external_interface.CTRL_FN_GET_DESC_CONTROLLO(?)}";
	}

	private String getContrattiStatusQuery() {
		final StringBuilder query = new StringBuilder( "SELECT ST.ST_TYPE FROM TP_MA_STATUS ST, TP_TR_BUSTA_DEICI_ATTRIBUTE BD WHERE " );
		query.append( " BD.BD_CURR_STATUS_ID = ST.ST_ID AND BD.BD_ID = ?" );
		return query.toString();
	}

}
