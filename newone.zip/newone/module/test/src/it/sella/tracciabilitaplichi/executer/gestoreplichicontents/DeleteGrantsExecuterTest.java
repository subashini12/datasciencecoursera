package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.LogHelper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.LogHelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;
import it.sella.tracciabilitaplichi.persistence.dao.GrantsImpl;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.mock.dao.GrantsImplMock;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mockit.Mockit;

public class DeleteGrantsExecuterTest extends AbstractSellaExecuterMock {

	public DeleteGrantsExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	DeleteGrantsExecuter executer = new DeleteGrantsExecuter();

	public void testDeleteGrantsExecuter_01() {
		Mockit.setUpMock(GrantsImpl.class,GrantsImplMock.class);
		Mockit.setUpMock(LogHelper.class,LogHelperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		final Map map = new HashMap();
		map.put(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ),getMap());
		map.put(CONSTANTS.GRANTS_COLLECTION, getGrantsList());
		expecting(getRequestEvent().getAttribute("grantsIndex")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn((Serializable) map).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private Map<Enum,Object> getMap()
	{
		final Map<Enum,Object> map = new HashMap<Enum,Object>() ;
		map.put(CONSTANTS.GRANTS_COLLECTION , getGrantsList());
		return map ;
	}
	
	private List<Grants> getGrantsList()
	{
		final List<Grants> grantsList = new ArrayList<Grants>();
		final Grants grant1 = new Grants() ;
		grant1.setBarcode("1234567891234");
		grant1.setIdSoggetto(1L);
		final Grants grant2 = new Grants() ;
		grant2.setBarcode("1345678912544");
		grant2.setIdSoggetto(2L);
		grantsList.add(grant1);
		grantsList.add(grant2);
		return grantsList ;
	}
}
