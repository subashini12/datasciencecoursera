package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio;

import it.sella.tracciabilitaplichi.b10archivation.B10InputPutProcessor;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor.RicezionePlichiArchivioProcessor;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor.RicezionePlichiArchivioProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Hashtable;
import java.util.Properties;

import mockit.Mockit;

import org.easymock.EasyMock;


public class B10ArchivioMismatchContinueProcessExecuterTest extends AbstractSellaExecuterMock{

	public B10ArchivioMismatchContinueProcessExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	B10ArchivioMismatchContinueProcessExecuter executer = new B10ArchivioMismatchContinueProcessExecuter() ;
	
	public void testB10ArchivioMismatchContinueProcessExecuter_01()
	{
		TracciabilitaPlichiImplMock.setBusta20();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);  
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(RicezionePlichiArchivioProcessor.class, RicezionePlichiArchivioProcessorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		expecting(getStateMachineSession().containsKey("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent())	;
	}
	
	public Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("NoOfPlichiRecieved",1L);
		hashtable.put("Properties",getProperties());
		hashtable.put("FinalB10ValuesToUpdate",new B10InputPutProcessor("", ""));
		return hashtable ;
	}
	
	public Properties getProperties()
	{
		final Properties properties = new Properties() ;
		return properties ;
	}
}
