package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.ArchivationHistoryConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor.ArchivationHistoryProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio.processor.ArchivationHistoryProcessorMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ArchivationHistoryConfermaExecuterTest extends AbstractSellaExecuterMock
{

	ArchivationHistoryConfermaExecuter executer = new ArchivationHistoryConfermaExecuter();
	
	public ArchivationHistoryConfermaExecuterTest(String name) 
	{
		super(name);		
	}
	
	public void testArchivationHistoryConfermaExecuter_01()
	{
		ArchivationHistoryProcessorMock.setEndorser() ;
		setUpMockMethods( ArchivationHistoryProcessor.class, ArchivationHistoryProcessorMock.class ) ;
		expecting( getStateMachineSession().containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "b10Barcode" ) ).andReturn( "124435436576" ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "barCodeStr" ) ).andReturn( "abc" ).anyTimes( );		
		expecting( getRequestEvent().getAttribute( "boxId" ) ).andReturn( "12" ).anyTimes( );		
		expecting( getStateMachineSession().get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION )).andReturn( (Serializable) getRicezionePlichiArchivioSession( ) ).anyTimes( );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testArchivationHistoryConfermaExecuter_02()
	{
		setUpMockMethods( ArchivationHistoryProcessor.class, ArchivationHistoryProcessorMock.class ) ;
		expecting( getStateMachineSession().containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "b10Barcode" ) ).andReturn( "124435436576" ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "barCodeStr" ) ).andReturn( "abc" ).anyTimes( );		
		expecting( getRequestEvent().getAttribute( "boxId" ) ).andReturn( "12" ).anyTimes( );		
		expecting( getStateMachineSession().get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION )).andReturn( (Serializable) getRicezionePlichiArchivioSession( ) ).anyTimes( );
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testArchivationHistoryConfermaExecuter_forTracciabilitaException()
	{
		ArchivationHistoryProcessorMock.setTracciabilitaException();
		setUpMockMethods( ArchivationHistoryProcessor.class, ArchivationHistoryProcessorMock.class ) ;
		expecting( getStateMachineSession().containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "b10Barcode" ) ).andReturn( "124435436576" ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "barCodeStr" ) ).andReturn( "abc" ).anyTimes( );		
		expecting( getRequestEvent().getAttribute( "boxId" ) ).andReturn( "12" ).anyTimes( );		
		expecting( getStateMachineSession().get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION )).andReturn( (Serializable) getRicezionePlichiArchivioSession( ) ).anyTimes( );
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testArchivationHistoryConfermaExecuter_forRemoteException()
	{
		ArchivationHistoryProcessorMock.setRemoteException();
		setUpMockMethods( ArchivationHistoryProcessor.class, ArchivationHistoryProcessorMock.class ) ;
		expecting( getStateMachineSession().containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "b10Barcode" ) ).andReturn( "124435436576" ).anyTimes( );
		expecting( getRequestEvent().getAttribute( "barCodeStr" ) ).andReturn( "abc" ).anyTimes( );		
		expecting( getRequestEvent().getAttribute( "boxId" ) ).andReturn( "12" ).anyTimes( );		
		expecting( getStateMachineSession().get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION )).andReturn( (Serializable) getRicezionePlichiArchivioSession( ) ).anyTimes( );
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private Map getRicezionePlichiArchivioSession( )
	{
		Map views = new HashMap();		
		views.put( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ), "ab");
		views.put( CONSTANTS.OggettoType.toString( ), "ab");
		views.put( CONSTANTS.TypesOfOggettos.toString( ), "ab");
		views.put(CONSTANTS.PlichiReceived.toString( ), "ab");
		views.put(CONSTANTS.PlichiToBeReceived.toString( ), "ab");		
		return views ;		
	}
	


}
