package it.sella.tracciabilitaplichi.executer.winbox2.preparazione;

import java.util.Map;

import mockit.Mock;

public class LogHelperMock {
	@Mock
	public String getFolderCancellazioneXML(final Map<Enum, Object> sessionMap) {
		return "</XML>";
	}

}
