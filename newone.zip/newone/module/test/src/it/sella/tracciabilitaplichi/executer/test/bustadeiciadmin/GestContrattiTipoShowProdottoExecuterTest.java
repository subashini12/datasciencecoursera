package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestContrattiTipoShowProdottoExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.io.Serializable;

import org.easymock.EasyMock;

public class GestContrattiTipoShowProdottoExecuterTest extends AbstractSellaExecuterMock
{
	final GestContrattiTipoShowProdottoExecuter executer = new GestContrattiTipoShowProdottoExecuter();
	
	public GestContrattiTipoShowProdottoExecuterTest(final String name)
	{
		super(name);		
	}	
	
	public void testForSuccessCase()
   {
	   expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("21").anyTimes();	
	   expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
	   playAll();	
	   setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
	   setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);	   
	   executer.execute(getRequestEvent());   
	}
   public void testForTracciabilitaExceptionCase()
   {
	   TPContrattiProdottoDataAccessMock.setTracciabilitaException();
	   expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("21").anyTimes();	
	   expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
	   playAll();	
	   setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
	   setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);	   
	   executer.execute(getRequestEvent());   
	}
}


