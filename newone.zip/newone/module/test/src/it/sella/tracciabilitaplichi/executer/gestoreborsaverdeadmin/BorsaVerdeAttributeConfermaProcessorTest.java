/*package it.sella.tracciabilitaplichi.executer.gestoreborsaverdeadmin;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestoreborsaverdeadmin.processor.BorsaVerdeAttributeConfermaProcessor;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;

import java.rmi.RemoteException;
import java.util.Date;

public class BorsaVerdeAttributeConfermaProcessorTest extends AbstractSellaExecuterTest{

	public BorsaVerdeAttributeConfermaProcessorTest(final String name) {
		super(name);
	}

	BorsaVerdeAttributeConfermaProcessor processor = new BorsaVerdeAttributeConfermaProcessor() ;


	private  BorsaVerdeAttributeView getBorsaVerdeAttributeView() {
		final BorsaVerdeAttributeView borsaVerdeAttributeView = new BorsaVerdeAttributeView() ;
		borsaVerdeAttributeView.setStatusId(1L);
		borsaVerdeAttributeView.setDocumentId(1L);
		borsaVerdeAttributeView.setCode("");
		borsaVerdeAttributeView.setDataCreato(new Date());
		borsaVerdeAttributeView.setIdSucc(2L);
		borsaVerdeAttributeView.setCdrDestination("");
		return borsaVerdeAttributeView ;
	}

	public void testBorsaVerdeAttributeConfermaProcessor_04() throws RemoteException, TracciabilitaException {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.CODE )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.CDR )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.CURR_STATUS_ID  )).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent(), getBorsaVerdeAttributeView()));
	}

	public void testBorsaVerdeAttributeConfermaProcessor_05() throws RemoteException, TracciabilitaException {
		UtilMock.setAlphaNumericFalse();
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.CODE )).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.CDR )).andReturn("123212");
		expecting(getRequestEvent().getAttribute(ITPConstants.CURR_STATUS_ID  )).andReturn("");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent(), getBorsaVerdeAttributeView()));
	}

}
 */