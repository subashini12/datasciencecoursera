package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Hashtable;

import mockit.Mock;

public class PlichiContentsModificaPBNProcessorMock {

	@Mock
	public static ExecuteResult modifyPBNRecords( final RequestEvent rqEvent, final String barCode, final Hashtable restoreMap, final ExecuteResult executeResult ) throws TracciabilitaException, RemoteException
	{
		executeResult.setAttribute("name", "ravi");
		return executeResult;

	}

}
