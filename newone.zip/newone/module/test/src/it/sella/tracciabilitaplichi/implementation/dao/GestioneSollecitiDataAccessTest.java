package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TpMaPropertiesView;

import java.util.Collection;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class GestioneSollecitiDataAccessTest {

	GestioneSollecitiDataAccess commonDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;

	@Before
	public void setUp() throws Exception {
		commonDataAccess = new GestioneSollecitiDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
	}

	@After
	public void tearDown() throws Exception {
		commonDataAccess = null;
	}

	@Test
	public void getTpMaPropertiesViewCollection() throws TracciabilitaException {
		final TpMaPropertiesView tpMaPropertiesTO= new  TpMaPropertiesView("KEY","VALUE");
		mockStatementProvider = new MockStatementProvider(getStampeIdSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 0, "PR_KEY","KEY");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "PR_VALUE","VALUE");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection<String> tpMaPropertiesViewColl = commonDataAccess.getTpMaPropertiesViewCollection(tpMaPropertiesTO);
		Assert.assertEquals(tpMaPropertiesViewColl.size(), 1);
	}

	private String getStampeIdSt(){
		return "SELECT PR_KEY,PR_VALUE FROM TP_MA_PROPERTIES WHERE PR_KEY = ?" ;
	}

	@Test
	public void getAllEsiti( ) throws TracciabilitaException {
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(getAllEsitiSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 0, "ES_ID",2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "ES_CODE","VALUE");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, "ES_DESC","KEY");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 3, "ES_GROUP",5l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 4, "ES_BANK",6l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection esitiColl = commonDataAccess.getAllEsiti();
		Assert.assertEquals(4, esitiColl.size());
	}

	private String getAllEsitiSt(){
		return "SELECT ES_ID,ES_CODE,ES_DESC,ES_GROUP,ES_BANK FROM TP_MA_ESITI WHERE ES_BANK=?" ;
	}

	@Test
	public void getAllTipocontrollo() throws TracciabilitaException{

		mockStatementProvider = new MockStatementProvider(getAllTipocontrolloQuerySt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 0, "PR_KEY",5l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "PR_VALUE","VALUE");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection allTipoControlloColl = commonDataAccess.getAllTipocontrollo();
		Assert.assertEquals( 1,allTipoControlloColl.size());
	}

	private String getAllTipocontrolloQuerySt(){
		return  "SELECT TC_ID, TC_DESC FROM SCANNER_DBA.CTRL_MA_TIPI_CONTROLLO WHERE TC_PROC = 'CUN' ORDER BY TC_ID";
	}
	@Test
	public void getValue() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getStampeIdSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 0, "PR_KEY","KEY");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "PR_VALUE","VALUE");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final String value = commonDataAccess.getValue("KEY");
		Assert.assertEquals("VALUE",value);
	}

	@Test
	public void getTpMaPropertiesView() throws TracciabilitaException{
		final TpMaPropertiesView tpMaPropertiesTO= new  TpMaPropertiesView("KEY","VALUE");
		mockStatementProvider = new MockStatementProvider(getStampeIdSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 0, "PR_KEY","KEY");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "PR_VALUE","VALUE");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final TpMaPropertiesView tpMaPropertiesView = commonDataAccess.getTpMaPropertiesView(tpMaPropertiesTO);
		Assert.assertEquals("KEY",tpMaPropertiesView.getKey());
		Assert.assertEquals("VALUE",tpMaPropertiesView.getValue());
	}

}
