package it.sella.tracciabilitaplichi.executer.gestorecassetto;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.LinkedCasettoAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.LinkedCasettoAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import mockit.Mockit;

public class CassettoEliminaExecuterTest extends AbstractSellaExecuterMock {

	public CassettoEliminaExecuterTest(final String name) {
		super(name);
	}

	CassettoEliminaExecuter executer = new CassettoEliminaExecuter();

	/*public void testCassettoEliminaExecuter_01() {
		TracciabilitaPlichiImplMock.setCassetto();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(LinkedCasettoAdminImpl.class,LinkedCasettoAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bankid")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertTrue(true);
	}*/

	public void testCassettoEliminaExecuter_02() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(LinkedCasettoAdminImpl.class,LinkedCasettoAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bankid")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null, executeResult.getAttribute("MSG"));
		assertEquals(null, executeResult.getAttribute("Success"));
	}

	public void testCassettoEliminaExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(LinkedCasettoAdminImpl.class,LinkedCasettoAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bankid")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null, executeResult.getAttribute("MSG"));
		assertEquals(null, executeResult.getAttribute("Success"));
	}

}
