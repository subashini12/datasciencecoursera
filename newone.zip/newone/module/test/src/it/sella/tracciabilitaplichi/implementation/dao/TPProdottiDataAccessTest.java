package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.mock.DBHelperMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;

import java.util.Hashtable;
import java.util.Map.Entry;

import junit.framework.Assert;
import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TPProdottiDataAccessTest {

	TPProdottiDataAccess tpProdottiDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private DBHelperMock dbHelperMock;

	@Before
	public void setUp() throws Exception {

		mockConnectionProvider = new MockConnectionProvider();
		tpProdottiDataAccess = new TPProdottiDataAccess();
		dbHelperMock = new DBHelperMock();
		dbHelperMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(DBConnector.class, dbHelperMock);
	}

	@After
	public void tearDown() throws Exception {
		tpProdottiDataAccess = null;
	}
	@Test
	public void getProdottiViewById_01() throws TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider("SELECT PR_ID,PR_COD,PR_DESC,PR_FLAG FROM TP_MA_B10_PRODOTTI WHERE PR_ID = ?");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 1,Long.valueOf("4"));
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, 2,"12");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 3, 3,"ABC");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 4, 4,"1");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final ProdottiView view = tpProdottiDataAccess.getProdottiViewById(Long.valueOf("2"));
		Assert.assertEquals("12", view.getCodProdotto());;
	}

	@Test
	public void getDescForProdConto() throws TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider("SELECT PR_DESC FROM TP_MA_B10_PRODOTTI WHERE PR_COD = ?");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 1,"ABCD");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final String descForProdConto = tpProdottiDataAccess.getDescForProdConto("20");
		Assert.assertEquals("ABCD", descForProdConto);
	}
	@Test
	public void getAllProdottiView() throws TracciabilitaException{
		String key = null;
		String value = null;
		final String query = "SELECT PR_COD,PR_DESC FROM TP_MA_B10_PRODOTTI";
		mockStatementProvider = new MockStatementProvider(query);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 1,"34");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, 2,"ABCD");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Hashtable<String, String> prodottiViewColl = tpProdottiDataAccess.getAllProdottiView();
		for(final Entry<String, String> entry : prodottiViewColl.entrySet()) {
			key = entry.getKey();
			value = entry.getValue();
		}
		Assert.assertEquals("ABCD", value);
	}

}
