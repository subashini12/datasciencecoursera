package it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.test.processor;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.processor.PropertyInserisciProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Map;

import mockit.Mockit;

import org.easymock.EasyMock;

public class PropertyInserisciProcessorTest extends AbstractSellaExecuterMock {
	
    RequestEvent requestEvent = null;
    
    public PropertyInserisciProcessorTest( final String name ) {
        super( name );
    }

    PropertyInserisciProcessor propertyInserisciProcessor = new PropertyInserisciProcessor() ;
    
    @Override
	protected void setUp( ) throws Exception {
        super.setUp( );
        this.requestEvent = createMock( RequestEvent.class );
    }
    
    public void testGetResultMap_01( ) throws TracciabilitaException, RemoteException {
        expect( this.requestEvent.getAttribute( ITPConstants.PR_KEY  ) ).andReturn( "" );
        expect( this.requestEvent.getAttribute( ITPConstants.PR_VALUE  ) ).andReturn( null );
        replay( this.requestEvent );
        final Map actual = PropertyInserisciProcessor.getResultMap( this.requestEvent );
        assertEquals( false, actual.containsKey( ITPConstants.PR_KEY ) );
        assertEquals( false, actual.containsKey( ITPConstants.PR_VALUE ) );
        assertEquals( true, actual.containsKey( ITPConstants.MSG ) );
        assertEquals( IErrorCodes.TRPL_1500, actual.get( ITPConstants.MSG ) );
        assertEquals( ITPConstants.PR_KEY, ( ( String [ ] ) actual.get( ITPConstants.ARGUMENT ) ) [ 0 ] );
    }
    
    public void testGetResultMap_02( ) throws TracciabilitaException, RemoteException {
        expect( this.requestEvent.getAttribute( ITPConstants.PR_KEY  ) ).andReturn( "1" );
        expect( this.requestEvent.getAttribute( ITPConstants.PR_VALUE  ) ).andReturn( null );
        replay( this.requestEvent );
        final Map actual = PropertyInserisciProcessor.getResultMap( this.requestEvent );
        assertEquals( false, actual.containsKey( ITPConstants.PR_KEY ) );
        assertEquals( false, actual.containsKey( ITPConstants.PR_VALUE ) );
        assertEquals( true, actual.containsKey( ITPConstants.MSG ) );
        assertEquals( IErrorCodes.TRPL_1500, actual.get( ITPConstants.MSG ) );
        assertEquals( ITPConstants.PR_VALUE, ( ( String [ ] ) actual.get( ITPConstants.ARGUMENT ) ) [ 0 ] );
    }
    
    public void testGetResultMap_03( ) throws TracciabilitaException, RemoteException {
        final StringBuilder prValue = new StringBuilder( );
        for( int i = 1; i < 4002; i++ ) {
            prValue.append( "a" );
        }
        expect( this.requestEvent.getAttribute( ITPConstants.PR_KEY  ) ).andReturn( "1" );
        expect( this.requestEvent.getAttribute( ITPConstants.PR_VALUE  ) ).andReturn( prValue.toString( ) ).times( 2 );
        replay( this.requestEvent );
        final Map actual = PropertyInserisciProcessor.getResultMap( this.requestEvent );
        assertEquals( false, actual.containsKey( ITPConstants.PR_KEY ) );
        assertEquals( false, actual.containsKey( ITPConstants.PR_VALUE ) );
        assertEquals( true, actual.containsKey( ITPConstants.MSG ) );
        assertEquals( IErrorCodes.TRPL_1541, actual.get( ITPConstants.MSG ) );
        assertEquals( null, ( ( String [ ] ) actual.get( ITPConstants.ARGUMENT ) ) [ 0 ] );
    }
    
    public void testGetResultMap_04() {
    	Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
    	final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
    	EasyMock.expect(requestEvent.getAttribute("PR_KEY")).andReturn("12").anyTimes();
    	EasyMock.expect(requestEvent.getAttribute("PR_VALUE")).andReturn("12").anyTimes();
    	EasyMock.replay(requestEvent);
    	try {
			final Map map = propertyInserisciProcessor.getResultMap(requestEvent);
			assertNotNull(map);
			assertEquals("TRPL-1340",map.get("MSG"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
    }

     public void testGetResultMap_05() {
    	TracciabilitaPlichiImplMock.setNullValue();
    	Mockit.setUpMock(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
    	final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
    	EasyMock.expect(requestEvent.getAttribute("PR_KEY")).andReturn("12").anyTimes();
    	EasyMock.expect(requestEvent.getAttribute("PR_VALUE")).andReturn("12").anyTimes();
    	EasyMock.replay(requestEvent);
    	try {
    		final Map map = propertyInserisciProcessor.getResultMap(requestEvent);
    		assertNotNull(map);
			assertEquals("12",map.get("PR_VALUE"));
			assertEquals("12",map.get("PR_KEY"));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
    }
    
    @Override
	protected void tearDown( ) throws Exception {
        super.tearDown( );
        Mockit.tearDownMocks( );
    }

}
