package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RicezionePlichiArchivioProcessorTest extends
		AbstractSellaExecuterMock {

	public RicezionePlichiArchivioProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezionePlichiArchivioProcessor processor = new RicezionePlichiArchivioProcessor();

	public void testRicezionePlichiArchivioProcessor_01() {
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult( "TrFail" );
		final Map map =new HashMap();
		map.put("OggettoType", "PBUST5");
		map.put("PlichiToBeReceived", 1L);
		map.put("PlichiReceived", 1L);
		try {
			processor.processPlichiType(map, executeResult, 1L, "TRPL-1039");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testProcessRecordsOtherThanB5_01()
	{
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult( "TrFail" );
		try {
			processor.processRecordsOtherThanB5(executeResult, getRequestEvent(), getList() , getList(), new ArrayList(), new HashMap() , "", "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testProcessRecordsOtherThanB5_02()
	{
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult( "TrFail" );
		try {
			processor.processRecordsOtherThanB5(executeResult, getRequestEvent(), getList() , new ArrayList(), new ArrayList(), new HashMap() , "", "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private List getList()
	{
		final List list = new ArrayList() ;
		list.add("1");
		list.add("2");
		return list ;
	}
	
}
