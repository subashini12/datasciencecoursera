package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;
import java.util.Hashtable;


public class PlichiContentsModificaBNProcessorTest extends AbstractSellaExecuterMock{

	public PlichiContentsModificaBNProcessorTest(final String name) {
		super(name);
	}

	PlichiContentsModificaBNProcessor processor = new PlichiContentsModificaBNProcessor();
	
	public void testPlichiContentsModificaBNProcessor_01()
	{
		TracciabilitaPlichiPlichiContentsDataAccessMock.setExistNonDeletedPlichi();
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Desc1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Note1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateMM1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateYYYY1")).andReturn("1898");
		expecting(getRequestEvent().getAttribute("Importo1")).andReturn("1478523693214");
		expecting(getRequestEvent().getAttribute("Importoprec1")).andReturn(null);
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaBNProcessor_02()
	{
		TracciabilitaPlichiPlichiContentsDataAccessMock.setExistNonDeletedPlichi();
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Desc1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Note1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateMM1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateYYYY1")).andReturn("1898");
		expecting(getRequestEvent().getAttribute("Importo1")).andReturn("1478523693214");
		expecting(getRequestEvent().getAttribute("Importoprec1")).andReturn(null);
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaBNProcessor_03()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Desc1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Note1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateMM1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateYYYY1")).andReturn("1898");
		expecting(getRequestEvent().getAttribute("Importo1")).andReturn("1478523693214");
		expecting(getRequestEvent().getAttribute("Importoprec1")).andReturn("aa");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaBNProcessor_04()
	{
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Desc1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Note1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateMM1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateYYYY1")).andReturn("1898");
		expecting(getRequestEvent().getAttribute("Importo1")).andReturn("1478523693214");
		expecting(getRequestEvent().getAttribute("Importoprec1")).andReturn("aa");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaBNProcessor_05()
	{
		UtilMock.setNumericFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Desc1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Note1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateMM1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateYYYY1")).andReturn("8");
		expecting(getRequestEvent().getAttribute("Importo1")).andReturn("asas");
		expecting(getRequestEvent().getAttribute("Importoprec1")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaBNProcessor_06()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("BustaNeraID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Desc1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("Note1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateMM1")).andReturn("11");
		expecting(getRequestEvent().getAttribute("dateYYYY1")).andReturn("1898");
		expecting(getRequestEvent().getAttribute("Importo1")).andReturn("1478523693214");
		expecting(getRequestEvent().getAttribute("Importoprec1")).andReturn("aa");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyBNRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable () ;
		return hashtable;
	}
	
}
