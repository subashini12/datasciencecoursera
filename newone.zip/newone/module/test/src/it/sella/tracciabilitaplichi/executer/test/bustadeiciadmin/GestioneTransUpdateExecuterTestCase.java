package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestioneTransUpdateExecuter;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor.GestioneTransUpdateProcessor;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor.GestioneTransUpdateProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.BustaDeiciControlliImpl;
import it.sella.tracciabilitaplichi.implementation.BustaDeiciControlliImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;
import mockit.Mockit;

public class GestioneTransUpdateExecuterTestCase extends
		AbstractSellaExecuterMock {

	public GestioneTransUpdateExecuterTestCase(final String name) {
		super(name);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	GestioneTransUpdateExecuter gestoreCodiceHostCensitoExecuter = new GestioneTransUpdateExecuter();

	/*public void testGestioneTransUpdateExecuterTest_01() {
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(BustaDeiciControlliImpl.class,
					BustaDeiciControlliImplMock.class);
			setUpMockMethods(TPUtil.class, TPUtilMock.class);
			setUpMockMethods(GestioneTransUpdateProcessor.class,
					GestioneTransUpdateProcessorMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getAttribute("clCoddip")).andReturn(
					"12");
			expecting(getRequestEvent().getAttribute("dataCondd")).andReturn(
					"12");
			expecting(getRequestEvent().getAttribute("dataConmm")).andReturn(
					"12");
			expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn(
					"2010");
			expecting(getRequestEvent().getAttribute("dataConTime")).andReturn(
					"04").times(3);
			expecting(getRequestEvent().getAttribute("clEsito"))
					.andReturn("11").times(3);
			expecting(getRequestEvent().getAttribute("clContratoId"))
					.andReturn("11").times(3);
			final ControlliView controlliView = new ControlliView();
			controlliView.setContrattoId(Long.valueOf("111"));
			expecting(getStateMachineSession().get("ControlliView")).andReturn(
					controlliView).times(3);
			expecting(getRequestEvent().getAttribute("note")).andReturn(
					"Note For GestioneTransUpdateExecuter").times(3);
			playAll();
			final ExecuteResult executeResult = gestoreCodiceHostCensitoExecuter
					.execute(getRequestEvent());
	}*/

	public void testGestioneTransUpdateExecuterTest_02() {
			SecurityWrapperMock.setValidCdrFalse();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(BustaDeiciControlliImpl.class,
					BustaDeiciControlliImplMock.class);
			setUpMockMethods(TPUtil.class, TPUtilMock.class);
			setUpMockMethods(GestioneTransUpdateProcessor.class,
					GestioneTransUpdateProcessorMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("dataCondd")).andReturn(
					"12").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConmm")).andReturn(
					"12").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn(
					"2010").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConTime")).andReturn(
					"04").anyTimes();
			expecting(getRequestEvent().getAttribute("clEsito"))
					.andReturn("11").anyTimes();
			expecting(getRequestEvent().getAttribute("clContratoId"))
					.andReturn("11").anyTimes();
			final ControlliView controlliView = new ControlliView();
			controlliView.setContrattoId(Long.valueOf("111"));
			expecting(getStateMachineSession().get("ControlliView")).andReturn(
					controlliView).anyTimes();
			expecting(getRequestEvent().getAttribute("note")).andReturn(
					"Note For GestioneTransUpdateExecuter").anyTimes();
			playAll();
			gestoreCodiceHostCensitoExecuter
					.execute(getRequestEvent());
	}

	public void testGestioneTransUpdateExecuterTest_03() {
			TPUtilMock.setValidateDate(2);
			SecurityWrapperMock.setValidCdrFalse();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(BustaDeiciControlliImpl.class,
					BustaDeiciControlliImplMock.class);
			setUpMockMethods(TPUtil.class, TPUtilMock.class);
			setUpMockMethods(GestioneTransUpdateProcessor.class,
					GestioneTransUpdateProcessorMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("dataCondd")).andReturn(
					"12").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConmm")).andReturn(
					"12").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn(
					"2010").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConTime")).andReturn(
					"04").anyTimes();
			expecting(getRequestEvent().getAttribute("clEsito"))
					.andReturn("11").anyTimes();
			expecting(getRequestEvent().getAttribute("clContratoId"))
					.andReturn("11").anyTimes();
			final ControlliView controlliView = new ControlliView();
			controlliView.setContrattoId(Long.valueOf("111"));
			expecting(getStateMachineSession().get("ControlliView")).andReturn(
					controlliView).anyTimes();
			expecting(getRequestEvent().getAttribute("note")).andReturn(
					"Note For GestioneTransUpdateExecuter").anyTimes();
			playAll();
			gestoreCodiceHostCensitoExecuter
					.execute(getRequestEvent());
	}

	public void testGestioneTransUpdateExecuterTest_04() {
			SecurityWrapperMock.setValidCdrFalse();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(BustaDeiciControlliImpl.class,
					BustaDeiciControlliImplMock.class);
			setUpMockMethods(TPUtil.class, TPUtilMock.class);
			setUpMockMethods(GestioneTransUpdateProcessor.class,
					GestioneTransUpdateProcessorMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getAttribute("clCoddip")).andReturn("")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("dataCondd")).andReturn(
					"12").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConmm")).andReturn(
					"12").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConyyyy")).andReturn(
					"2010").anyTimes();
			expecting(getRequestEvent().getAttribute("dataConTime")).andReturn(
					"04").anyTimes();
			expecting(getRequestEvent().getAttribute("clEsito"))
					.andReturn("11").anyTimes();
			expecting(getRequestEvent().getAttribute("clContratoId"))
					.andReturn("11").anyTimes();
			final ControlliView controlliView = new ControlliView();
			controlliView.setContrattoId(Long.valueOf("111"));
			expecting(getStateMachineSession().get("ControlliView")).andReturn(
					controlliView).anyTimes();
			expecting(getRequestEvent().getAttribute("note")).andReturn(
					"Note For GestioneTransUpdateExecuter").anyTimes();
			playAll();
			gestoreCodiceHostCensitoExecuter
					.execute(getRequestEvent());
	}
}	
