package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.classextension.EasyMock;



public class AccodaPraticaExecuterTest extends AbstractSellaExecuterMock{

	public AccodaPraticaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	AccodaPraticaExecuter executer=new AccodaPraticaExecuter();
	public void testAccodaPraticaExecuter_01()
	{
		final Map map = new HashMap();
		map.put(CONSTANTS.GRANTS_COLLECTION, getGrantsList());
		map.put( "TracciabilitaPlichiView" , getTracciabilitaPlichiView());
		expecting(getStateMachineSession().get(CONSTANTS.PLICHI_CONTENTS_HASH_TABLE.getValue( ))).andReturn((Serializable) map);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( FolderAttributes) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		
	}
	private static TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		new HashMap();
		final TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		final FolderAttributes folderAttributes=new FolderAttributes();
		folderAttributes.setBarcode("1234567891023");
		folderAttributes.setTipoPraticaDescription("");
		folderAttributes.setFolderArchiveFlow((short) 1);
		folderAttributes.isCustomAccess();
		tracciabilitaPlichiView.setFolderAttributes(folderAttributes);		
		return tracciabilitaPlichiView;
	}

	private List<Grants> getGrantsList()
	{
		final List<Grants> grantsList = new ArrayList<Grants>();
		final Grants grant1 = new Grants() ;
		grant1.setBarcode("1234567891234");
		grant1.setIdSoggetto(1L);
		final Grants grant2 = new Grants() ;
		grant2.setBarcode("1345678912544");
		grant2.setIdSoggetto(2L);
		grantsList.add(grant1);
		grantsList.add(grant2);
		return grantsList ;
	}
}
