package it.sella.tracciabilitaplichi.executer.test.ricercabustacinque;

import it.sella.tracciabilitaplichi.executer.ricercabustacinque.RicercaBustaCinqueStampaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.mock.pdfgenerator.BustaCinqueRicercaPDFGeneratorMock;
import it.sella.tracciabilitaplichi.pdfgenerator.BustaCinqueRicercaPDFGenerator;

import java.util.ArrayList;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class RicercaBustaCinqueStampaExecuterTest extends AbstractSellaExecuterMock
{

	public RicercaBustaCinqueStampaExecuterTest(final String name) 
	{
		super(name);
	}
	
	RicercaBustaCinqueStampaExecuter executer = new RicercaBustaCinqueStampaExecuter();

	public void testRicercaBustaCinqueStampaExecuter_01()
	{
		setUpMockMethods(BustaCinqueRicercaPDFGenerator.class, BustaCinqueRicercaPDFGeneratorMock.class);
		final ArrayList arrayList = new ArrayList();
		arrayList.add("");
		final Hashtable hashtable = new Hashtable();
		hashtable.put("FiltraCollRicercaView",arrayList);
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting( getRequestEvent().getEventName()).andReturn( "TrStampa" ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	
	public void testRicercaBustaCinqueStampaExecuter_02()
	{
		BustaCinqueRicercaPDFGeneratorMock.setRemoteException();
		setUpMockMethods(BustaCinqueRicercaPDFGenerator.class, BustaCinqueRicercaPDFGeneratorMock.class);
		final ArrayList arrayList = new ArrayList();
		arrayList.add("");
		final Hashtable hashtable = new Hashtable();
		hashtable.put("FiltraCollRicercaView",arrayList);
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting( getRequestEvent().getEventName()).andReturn( "TrStampa" ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	public void testRicercaBustaCinqueStampaExecuter_03()
	{
		BustaCinqueRicercaPDFGeneratorMock.setTracciabilitaException();
		setUpMockMethods(BustaCinqueRicercaPDFGenerator.class, BustaCinqueRicercaPDFGeneratorMock.class);
		final ArrayList arrayList = new ArrayList();
		arrayList.add("");
		final Hashtable hashtable = new Hashtable();
		hashtable.put("FiltraCollRicercaView",arrayList);
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting( getRequestEvent().getEventName()).andReturn( "TrStampa" ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	public void testRicercaBustaCinqueStampaExecuter_04()
	{
		final ArrayList arrayList = new ArrayList();
		arrayList.add("");
		final Hashtable hashtable = new Hashtable();
		hashtable.put("FiltraCollRicercaView",arrayList);
		hashtable.put("CollRicercaList","");
		hashtable.put("SearchType","");
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(true);
		expecting( getRequestEvent().getEventName()).andReturn( "TrBack" ).anyTimes();
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	
}
