package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestContrattiTipoDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccessMock;

public class GestContrattiTipoDefaultExecuterTest extends  AbstractSellaExecuterMock
{
	final GestContrattiTipoDefaultExecuter gestContrattiTipoDefaultExecuter = new GestContrattiTipoDefaultExecuter();
	
	public GestContrattiTipoDefaultExecuterTest(String name) 
	{
		super(name);
	}
	
	public void testForTracciabilitaExceptionCase()
	{   
		TPProdottiDataAccessMock.setTracciabilitaException();
		setUpMockMethods( TPProdottiDataAccess.class, TPProdottiDataAccessMock.class );
		gestContrattiTipoDefaultExecuter.execute( getRequestEvent() );		
	}
	
	public void testForSuccessCase()
	{   
		setUpMockMethods( TPProdottiDataAccess.class, TPProdottiDataAccessMock.class );
		gestContrattiTipoDefaultExecuter.execute( getRequestEvent() );		
	}

}
