package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.statemachine.StateMachineException;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestContrattiAdminConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor.GestContrattiAdminProcessor;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor.GestContrattiAdminProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.ContrattiProdottoAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.ContrattiProdottoAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

import java.util.Hashtable;

import mockit.Mockit;

public class GestContrattiAdminConfermaExecuterTestCase extends
		AbstractSellaExecuterMock {

	public GestContrattiAdminConfermaExecuterTestCase(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	GestContrattiAdminConfermaExecuter executer = new GestContrattiAdminConfermaExecuter();

	public void testGestContrattiAdminConfermaExecuter_01()
			throws StateMachineException {
		TracciabilitaPlichiImplMock.setCdr();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		GestContrattiAdminProcessorMock.setViewHashMap();
		setUpMockMethods(GestContrattiAdminProcessor.class, GestContrattiAdminProcessorMock.class);
		setUpMockMethods(ContrattiProdottoAdminImpl.class, ContrattiProdottoAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL )).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW)).andReturn(getContrattiProdottoView()).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.ABIBANCA)).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiProdCont")).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.VIEW)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.VIEW)).andReturn(getContrattiProdottoView()).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn("");
		expecting(getStateMachineSession().containsKey(ITPConstants.CONTRATTI_COLL )).andReturn(Boolean.TRUE).anyTimes();
		expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiDesc")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiCod")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Imagini")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("startingId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTR_ID)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.SELECTED_CONTR_ID)).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW )).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW )).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiId" )).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	
	public void testGestContrattiAdminConfermaExecuter_02()throws StateMachineException {
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		GestContrattiAdminProcessorMock.setViewHashMap();
		setUpMockMethods(GestContrattiAdminProcessor.class, GestContrattiAdminProcessorMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(ContrattiProdottoAdminImpl.class, ContrattiProdottoAdminImplMock.class);
		expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL )).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiProdCont")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW)).andReturn( getNullContrattiProdottoView()).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.ABIBANCA)).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.VIEW)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.VIEW)).andReturn(getContrattiProdottoView()).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn("");
		expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiDesc")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiCod")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Imagini")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("startingId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.CONTRATTI_COLL )).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTR_ID)).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.SELECTED_CONTR_ID)).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW )).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW )).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiId" )).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		}
	
		public void testGestContrattiAdminConfermaExecuter_03()throws StateMachineException {
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			GestContrattiAdminProcessorMock.setErrorHashMap();
			setUpMockMethods(GestContrattiAdminProcessor.class, GestContrattiAdminProcessorMock.class);
			setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
			setUpMockMethods(ContrattiProdottoAdminImpl.class, ContrattiProdottoAdminImplMock.class);
			expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL )).andReturn(getHashtable()).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW)).andReturn( getNullContrattiProdottoView()).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.ABIBANCA)).andReturn("").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.ERROR)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.VIEW)).andReturn(Boolean.FALSE).anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiProdCont")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiDesc")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiCod")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("Imagini")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("startingId")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiId" )).andReturn("1").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTR_ID)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTR_ID)).andReturn("").anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn("").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.CONTRATTI_COLL )).andReturn(Boolean.FALSE).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		}
	
		public void testGestContrattiAdminConfermaExecuter_04()throws StateMachineException {
			GestContrattiAdminProcessorMock.setRemoteException();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(GestContrattiAdminProcessor.class, GestContrattiAdminProcessorMock.class);
			setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
			setUpMockMethods(ContrattiProdottoAdminImpl.class, ContrattiProdottoAdminImplMock.class);
			expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL )).andReturn(getHashtable()).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW)).andReturn( getNullContrattiProdottoView()).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.ABIBANCA)).andReturn("").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.ERROR)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.VIEW)).andReturn(Boolean.FALSE).anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiProdCont")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiDesc")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiCod")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("Imagini")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("startingId")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiId" )).andReturn("1").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTR_ID)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTR_ID)).andReturn("").anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn("").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.CONTRATTI_COLL )).andReturn(Boolean.FALSE).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		}
		public void testGestContrattiAdminConfermaExecuter_05()throws StateMachineException {
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			GestContrattiAdminProcessorMock.setTracciabilitaException();
			setUpMockMethods(GestContrattiAdminProcessor.class, GestContrattiAdminProcessorMock.class);
			setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
			setUpMockMethods(ContrattiProdottoAdminImpl.class, ContrattiProdottoAdminImplMock.class);
			expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL )).andReturn(getHashtable()).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTRATTI_PRODOTTI_VIEW)).andReturn( getNullContrattiProdottoView()).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.ABIBANCA)).andReturn("").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.ERROR)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.VIEW)).andReturn(Boolean.FALSE).anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiProdCont")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ProdottiId")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiDesc")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiCod")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("Imagini")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("startingId")).andReturn("").anyTimes();
			expecting(getRequestEvent().getAttribute("ContrattiId" )).andReturn("1").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.SELECTED_CONTR_ID)).andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.SELECTED_CONTR_ID)).andReturn("").anyTimes();
			expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn("").anyTimes();
			expecting(getStateMachineSession().containsKey(ITPConstants.CONTRATTI_COLL )).andReturn(Boolean.FALSE).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}
	public Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable() ;
		return hashtable ;
	}
	
	public ContrattiProdottoView  getContrattiProdottoView()
	{
		final ContrattiProdottoView contrattiProdottoView = new ContrattiProdottoView() ;
		contrattiProdottoView.setAbiBanca("");
		return contrattiProdottoView ;
	}
	
	public ContrattiProdottoView  getNullContrattiProdottoView()
	{
		final ContrattiProdottoView contrattiProdottoView = null ;
		return contrattiProdottoView ;
	}
}
