package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.ConnectionLifeCycleMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class ArchivationBustaDeiciDataAccessTest extends BasicJDBCTestCaseAdapter {
	
	ArchivationBustaDeiciDataAccess archivationBustaDeiciDataAccess = new ArchivationBustaDeiciDataAccess() ;
	
	public void testGetNCDsForOggettoIds_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_ID", new Object[] { "27" });
		result.addColumn("BD_NC", new Object[] { "T1A9679837670" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_COD_PRODCONT", new Object[] { "30" });
		result.addColumn("BD_OGGETTO_ID", new Object[] { "4979086" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			final List ncdList= new ArrayList();
			ncdList.add("1");
			archivationBustaDeiciDataAccess.getNCDsForOggettoIds(ncdList);
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
			e.printStackTrace();
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetNCDsForOggettoIds_02() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_ID", new Object[] { "27" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_COD_PRODCONT", new Object[] { "30" });
		result.addColumn("BD_OGGETTO_ID", new Object[] { "4979086" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			archivationBustaDeiciDataAccess.getNCDsForOggettoIds(getNcdList());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
			e.printStackTrace();
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetContractsDetailsToSendMail_exception() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_ID", new Object[] { "27" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_NC", new Object[] { "13600172" });
		result.addColumn("BD_COD_PRODCONT", new Object[] { "30" });
		result.addColumn("BD_OGGETTO_ID", new Object[] { "4979086" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			archivationBustaDeiciDataAccess.getContractsDetailsToSendMail(getNcdList());
		} catch (final TracciabilitaException e) {
			assertNotNull( e.getMessage() ) ;
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetContractsDetailsToSendMail_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_NC", new Object[] { "13600172" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_ACTUAL_DATE", new Object[] { new Timestamp(1L) });
		result.addColumn("BD_USER", new Object[] { "BSZI223" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			final Map ncdMap = archivationBustaDeiciDataAccess.getContractsDetailsToSendMail(getNcdList());
			assertNotNull( ncdMap ) ;
		} catch (final TracciabilitaException e) {
			assertNotNull( e.getMessage() ) ;
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testIsValidContract_01() throws SQLException
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_NC", new Object[] { "13600172" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_ACTUAL_DATE", new Object[] { new Timestamp(1L) });
		result.addColumn("BD_USER", new Object[] { "BSZI223" });
		statementHandler.prepareGlobalResultSet(result);
		final String[] statusTypes = new String[3];
		statusTypes[0] = "";
		try {
			archivationBustaDeiciDataAccess.isValidContract("1360017276508",statusTypes );
		} catch (final RemoteException e) {
			assertNotNull( e.getMessage() ) ;
		} catch (final TracciabilitaException e) {
			 e.printStackTrace();
			assertNotNull( e.getMessage() ) ;
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	
	public void testIsValidContract_02() throws SQLException
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_NC", new Object[] { "13600172" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_ACTUAL_DATE", new Object[] { new Timestamp(1L) });
		result.addColumn("BD_USER", new Object[] { "BSZI223" });
		statementHandler.prepareGlobalResultSet(result);
		final String[] statusTypes = new String[1];
		statusTypes[0] = "";
		try {
			final boolean actual = archivationBustaDeiciDataAccess.isValidContract("1360017276508",statusTypes );
			assertEquals(true, actual);
		} catch (final RemoteException e) {
			assertNotNull( e.getMessage() ) ;
		} catch (final TracciabilitaException e) {
			 e.printStackTrace();
			assertNotNull( e.getMessage() ) ;
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testIsValidContract_03() throws SQLException
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("BD_NC", new Object[] { "13600172" });
		result.addColumn("BD_NCD", new Object[] { "1360017276508" });
		result.addColumn("BD_ANAGRAFICA", new Object[] { "BSG96" });
		result.addColumn("BD_ACTUAL_DATE", new Object[] { new Timestamp(1L) });
		result.addColumn("BD_USER", new Object[] { "BSZI223" });
		statementHandler.prepareGlobalResultSet(result);
		final String[] statusTypes = new String[1];
		statusTypes[0] = "";
		try {
			final boolean actual = archivationBustaDeiciDataAccess.isValidContract(null,statusTypes );
			assertEquals(false, actual);
		} catch (final RemoteException e) {
			assertNotNull( e.getMessage() ) ;
		} catch (final TracciabilitaException e) {
			 e.printStackTrace();
			assertNotNull( e.getMessage() ) ;
		} finally {
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	
	public void testGetContractsOggettoIds4B10OggettoId_01()
	{
		
	}
	
	private List getNcdList()
	{
		final List ncdList= new ArrayList();
		ncdList.add("1");
		ncdList.add("1");
		return ncdList ;
	}
}
