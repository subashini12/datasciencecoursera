package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.PAltriAttributeView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Vector;

import mockit.Mock;

public class TracciabilitaPlichiAdminTransactionDataAccessMock {
	private static Boolean isViewSizeZero = false;
	private static Boolean tracciabilitaException = false;
	private static Boolean isValidRefIdFalse = false;
	private static Boolean isBustaCinqueAttributeViewNotNull = false;
	private static Boolean isHistoryViewNotNull = false;
	private static Boolean remoteException=false;
	
	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setHistoryViewNotNull() {
		isHistoryViewNotNull = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setViewSizeZero() {
		isViewSizeZero = true;
	}

	public static void setValidRefIdFalse() {
		isValidRefIdFalse = true;
	}

	public static void setBustaCinqueAttributeViewNotNull() {
		isBustaCinqueAttributeViewNotNull = true;
	}

	@Mock
	public Collection getBustaNeraErrorCodeView(long id)
			throws TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		Collection collection = new Vector();
		collection.add("a");
		if (isViewSizeZero) {
			isViewSizeZero = false;
			collection.remove("a");
		}
		return collection;
	}

	@Mock
	public boolean isValidRefId(String refId) throws TracciabilitaException {
		Boolean flag = true;
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (isValidRefIdFalse) {
			isValidRefIdFalse = false;
			flag = false;
		}

		return flag;
	}

	@Mock
	public Collection getBustaCinqueAttributeView(long id)
			throws TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		Collection collection = new Vector();
		if (isBustaCinqueAttributeViewNotNull) {
			isBustaCinqueAttributeViewNotNull = false;
			collection.add("a");
		}
		return collection;
	}

	@Mock
	public HistoryView getOggettoStatusView(long id)
			throws TracciabilitaException, RemoteException {
		HistoryView historyView = null;
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (isHistoryViewNotNull) {
			historyView = new HistoryView();
		}
		if(remoteException)
		{
			throw new RemoteException();
		}
		return historyView;
	}
	
	@Mock
	public PAltriAttributeView getPlichiAltriAttributeView( String id ) throws TracciabilitaException
	{
		if (tracciabilitaException) 
		{
			
			System.out.println("traException");
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		PAltriAttributeView view = new PAltriAttributeView();
		view.setAltriId(1L);
		view.setDocId(1L);
		if(isViewSizeZero)
		{
			isViewSizeZero= false;
			view = null;
		}
		return view;
	}
	
		
}
