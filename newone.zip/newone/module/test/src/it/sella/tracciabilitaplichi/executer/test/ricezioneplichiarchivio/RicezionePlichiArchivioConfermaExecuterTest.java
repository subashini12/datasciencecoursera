package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CAUSALE;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.RicezionePlichiArchivioConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;

public class RicezionePlichiArchivioConfermaExecuterTest extends AbstractSellaExecuterMock
{

	public RicezionePlichiArchivioConfermaExecuterTest ( final String name )
	{
		super( name );
	}
	

	public void testExecute_1( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.FALSE );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) );
	}
	
	/*redefineMethod( B10InputPutProcessor.class, new Object( ) {
	public void parseBarcodeString( )
	{
		return;
	}
	public int getCountOfCassetto( )
	{
		return 0;
	}
} );*/

	// boxId error case 1
	/*public void testExecute_PB10_1( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234455434534" );
		mockPlichiDAO( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_ERROR.getValue( ), executeResult.getTransition( ) );
		assertEquals( "TRPL-1036", executeResult.getAttribute( ITPConstants.MSG ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, executeResult.getAttribute( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, executeResult.getAttribute( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( CAUSALE.PBUSTA_10.getValue( ), executeResult.getAttribute( CONSTANTS.OggettoType.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.TypesOfOggettos.toString( ) ) );
		assertTrue( sessionMap.containsKey( ITPConstants.CASSETTO_BOX_ID ) && sessionMap.get( ITPConstants.CASSETTO_BOX_ID ).equals( 1L ) );
		assertEquals( 1L, executeResult.getAttribute( CONSTANTS.LastBoxCode.toString( ) ) );
		assertTrue( ( Boolean ) executeResult.getAttribute( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ) ) );
	}
	
	// boxId error case 2
	public void testExecute_PB10_2( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "$$$$$$$$$$" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( null );
		mockPlichiDAO( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_ERROR.getValue( ), executeResult.getTransition( ) );
		assertEquals( "TRPL-1036", executeResult.getAttribute( ITPConstants.MSG ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, executeResult.getAttribute( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, executeResult.getAttribute( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( CAUSALE.PBUSTA_10.getValue( ), executeResult.getAttribute( CONSTANTS.OggettoType.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.TypesOfOggettos.toString( ) ) );
		assertTrue( sessionMap.containsKey( ITPConstants.CASSETTO_BOX_ID ) && sessionMap.get( ITPConstants.CASSETTO_BOX_ID ).equals( 1L ) );
		assertEquals( 1L, executeResult.getAttribute( CONSTANTS.LastBoxCode.toString( ) ) );
		assertTrue( ( Boolean ) executeResult.getAttribute( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ) ) );
	}

	// no barcode str, conferma case
	public void testExecute_PB10_3( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "1" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "" );
		mockPlichiDAO( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_ERROR.getValue( ), executeResult.getTransition( ) );
		assertEquals( "TRPL-1026", executeResult.getAttribute( ITPConstants.MSG ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, executeResult.getAttribute( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, executeResult.getAttribute( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( CAUSALE.PBUSTA_10.getValue( ), executeResult.getAttribute( CONSTANTS.OggettoType.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.TypesOfOggettos.toString( ) ) );
		assertTrue( sessionMap.containsKey( ITPConstants.CASSETTO_BOX_ID ) && sessionMap.get( ITPConstants.CASSETTO_BOX_ID ).equals( 1L ) );
		assertEquals( 1L, executeResult.getAttribute( CONSTANTS.LastBoxCode.toString( ) ) );
		assertTrue( ( Boolean ) executeResult.getAttribute( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ) ) );
	}

	// isConfirmationNeededCase
	public void testExecute_PB10_4( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "1" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234567891234\n1234567891234" );
		mockPlichiDAO( );
		final HashMap confirmationNeededMap = new HashMap( );
		redefineMethod( B10InputPutProcessor.class, new Object( )
		{
			public void parseBarcodeString ( )
			{
				return;
			}

			public int getCountOfCassetto ( )
			{
				return 1;
			}
			public boolean isAnyConfirmationNeedForNCD( )
			{
				return true;
			}
			public HashMap getConfirmationNeededMap( )
			{
				return confirmationNeededMap;
			}
		} );

		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		expecting( this.getStateMachineSession( ).put( "PlichiBusta10Map", confirmationNeededMap ) ).andReturn( confirmationNeededMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( "TrDuplicatedContract", executeResult.getTransition( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( "FinalB10ValuesToUpdate" ) );
		assertTrue( sessionMap.containsKey( "TextAreaValue" ) );
		assertEquals( "1234567891234\n1234567891234", sessionMap.get( "TextAreaValue" ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertTrue( sessionMap.containsKey( "BoxNumber" ) );
		assertEquals( "1", sessionMap.get( "BoxNumber" ) );
	}
	
	// isValidBarcode + isInvalidBarcode case
	public void testExecute_PB10_5( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "1" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234567891234\n1234567891234\n0000000000024\n234234232323434\n53453454545445" );
		mockPlichiDAO( );
		redefineMethod( B10InputPutProcessor.class, new Object( )
		{
			public void parseBarcodeString ( )
			{
				return;
			}
			public int getCountOfCassetto ( )
			{
				return 1;
			}
			public boolean isAnyConfirmationNeedForNCD( )
			{
				return false;
			}
			public boolean isAnyValidBarcodeToUpdate( )
			{
				return true;
			}
			public boolean isAnyInvalidBarcodeEntered( )
			{
				return true;
			}
			
		} );
		mockTPUtil( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( "TrPartialB10Conferma", executeResult.getTransition( ) );
		assertTrue( sessionMap.containsKey( "Properties" ) );
		final Properties properties = ( Properties ) sessionMap.get( "Properties" );
		assertTrue( properties.containsKey( "B10ARCHIVATION" ) && "YES".equals( properties.get( "B10ARCHIVATION" ) ) );
		assertTrue( properties.containsKey( "HistoryView" ) );
		assertTrue( properties.containsKey( "OggettoView" ) );
		assertTrue( properties.containsKey( "FinalB10ValuesToUpdate" ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( "FinalB10ValuesToUpdate" ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertTrue( sessionMap.containsKey( "BoxNumber" ) );
		assertEquals( "1", sessionMap.get( "BoxNumber" ) );
		assertEquals( "TRPL-1322", executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) );
		assertNotNull( executeResult.getAttribute( "FinalB10ValuesToUpdate" ) );
	}
	
	// isValidBarcode case
	public void testExecute_PB10_6( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "1" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234567891234\n1234567891234\n" );
		mockPlichiDAO( );
		redefineMethod( B10InputPutProcessor.class, new Object( )
		{
			public void parseBarcodeString ( )
			{
				return;
			}
			public int getCountOfCassetto ( )
			{
				return 1;
			}
			public boolean isAnyConfirmationNeedForNCD( )
			{
				return false;
			}
			public boolean isAnyValidBarcodeToUpdate( )
			{
				return true;
			}
			public boolean isAnyInvalidBarcodeEntered( )
			{
				return false;
			}
			public List getCassettoDetails( )
			{
				final List casList = new ArrayList( );
				final List b10List = new ArrayList( );
				final CassettoDetails cassettoDetails = new CassettoDetails( "1", b10List );
				cassettoDetails.getBusta10LinkedToThisBoxId( ).add( new Object( ) );
				casList.add( cassettoDetails );
				return casList;
			}
		} );
		mockEJB( );
        redefineMethod( TracciabilitaPlichiManagerBean.class, new Object( ) {
            public Long censitoOggetto( final Properties properties )
            {
                return 1L;
            }  
        } );
		mockTPUtil( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), executeResult.getTransition( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 19L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 6L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 19L, executeResult.getAttribute( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 6L, executeResult.getAttribute( CONSTANTS.PlichiReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertEquals( "TRPL-1039", executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) );
		assertEquals( "yes", executeResult.getAttribute( "Success" ) );
		assertTrue( sessionMap.containsKey( ITPConstants.CASSETTO_BOX_ID ) && Long.valueOf( 1L ).equals( sessionMap.get( ITPConstants.CASSETTO_BOX_ID ) ) );
		assertEquals( 1L, executeResult.getAttribute( CONSTANTS.LastBoxCode.toString( ) ) );
	}
	
	// isValidBarcode - no more plichi to receive case
	public void testExecute_PB10_7( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), 1L );
		sessionMap.put( CONSTANTS.PlichiReceived.toString( ), 25L );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "1" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234567891234\n1234567891234\n" );
		mockPlichiDAO( );
		redefineMethod( B10InputPutProcessor.class, new Object( )
		{
			public void parseBarcodeString ( )
			{
				return;
			}
			public int getCountOfCassetto ( )
			{
				return 1;
			}
			public boolean isAnyConfirmationNeedForNCD( )
			{
				return false;
			}
			public boolean isAnyValidBarcodeToUpdate( )
			{
				return true;
			}
			public boolean isAnyInvalidBarcodeEntered( )
			{
				return false;
			}
			public List getCassettoDetails( )
			{
				final List casList = new ArrayList( );
				final List b10List = new ArrayList( );
				final CassettoDetails cassettoDetails = new CassettoDetails( "1", b10List );
				cassettoDetails.getBusta10LinkedToThisBoxId( ).add( new Object( ) );
				casList.add( cassettoDetails );
				return casList;
			}
		} );
		mockEJB( );
        redefineMethod( TracciabilitaPlichiManagerBean.class, new Object( ) {
            public Long censitoOggetto( final Properties properties )
            {
                return 1L;
            }  
        } );
		mockTPUtil( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), executeResult.getTransition( ) );
		assertNull( executeResult.getAttribute( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertNull( executeResult.getAttribute( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( CAUSALE.PBUSTA_10.getValue( ), executeResult.getAttribute( CONSTANTS.OggettoType.toString( ) ) );
		assertEquals( "TRPL-1039", executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) );
		assertEquals( "yes", executeResult.getAttribute( "Success" ) );
		assertTrue( sessionMap.containsKey( ITPConstants.CASSETTO_BOX_ID ) && Long.valueOf( 1L ).equals( sessionMap.get( ITPConstants.CASSETTO_BOX_ID ) ) );
		assertEquals( 1L, executeResult.getAttribute( CONSTANTS.LastBoxCode.toString( ) ) );
	}
	
	// no valid barcode str case
	public void testExecute_PB10_8( )
	{
		expecting( this.getStateMachineSession( ).containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
		final Hashtable sessionMap =  getSessionMap( CAUSALE.PBUSTA_10 );
		expecting( this.getStateMachineSession( ).get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( sessionMap ).anyTimes( );
		expecting( this.getRequestEvent( ).getAttribute( "boxId" ) ).andReturn( "1" );
		expecting( this.getRequestEvent( ).getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234567891234\n1234567891234\n0000000000024\n234234232323434\n53453454545445" );
		mockPlichiDAO( );
		redefineMethod( B10InputPutProcessor.class, new Object( )
		{
			public void parseBarcodeString ( )
			{
				return;
			}
			public int getCountOfCassetto ( )
			{
				return 1;
			}
			public boolean isAnyConfirmationNeedForNCD( )
			{
				return false;
			}
			public boolean isAnyValidBarcodeToUpdate( )
			{
				return false;
			}
		} );
		mockTPUtil( );
		expecting( this.getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );
		final ExecuteResult executeResult = new RicezionePlichiArchivioConfermaExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( "TrError", executeResult.getTransition( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, sessionMap.get( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, sessionMap.get( CONSTANTS.PlichiReceived.toString( ) ) );
		assertEquals( 20L, executeResult.getAttribute( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		assertEquals( 5L, executeResult.getAttribute( CONSTANTS.PlichiReceived.toString( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.OggettoType.toString( ) ) && CAUSALE.PBUSTA_10.getValue( ).equals( sessionMap.get( CONSTANTS.OggettoType.toString( ) ) ) );
		assertTrue( sessionMap.containsKey( ITPConstants.CASSETTO_BOX_ID ) );
		assertEquals( 1L, sessionMap.get( ITPConstants.CASSETTO_BOX_ID ) );
		assertEquals( 1L, executeResult.getAttribute( CONSTANTS.LastBoxCode.toString( ) ) );
		assertEquals( "TRPL-1429", executeResult.getAttribute( CONSTANTS.MSG.toString( ) ) );
	}*/
	
	private Hashtable getSessionMap( final Enum<CAUSALE> causale )
	{
		final Hashtable sessionMap = new Hashtable( );
		sessionMap.put( CONSTANTS.IsBarCodeReaderAvailable.toString( ), Boolean.TRUE );
		sessionMap.put( CONSTANTS.OggettoType.toString( ), ((CAUSALE)causale).getValue( ) );
		sessionMap.put( CONSTANTS.TypesOfOggettos.toString( ), new ArrayList( ) );
		if ( CAUSALE.PBUSTA_10.getValue( ).equals( (( CAUSALE )causale).getValue( ) ) )
		{
			sessionMap.put( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ),  Boolean.TRUE );	
		}
		sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), 20L );
		sessionMap.put( CONSTANTS.PlichiReceived.toString( ), 5L );
		return sessionMap;
	}
	
	private void mockPlichiDAO( )
	{
		redefineMethod( TracciabilitaPlichiPlichiDataAccess.class, new Object( ) {
			public Long getLastBoxCode( final String plichiType )
			{
				return 1L;
			}
		} );
	}
	
	private void mockTPUtil( )
	{
		redefineMethod( TPUtil.class, new Object( ) {
			public HistoryView getBasicHistoryView( final String status ) throws TracciabilitaException, RemoteException
			{
			    final HistoryView historyView = new HistoryView();
				historyView.setIpAddress( "192.50.51.110" );
				historyView.setUserId( "BSSC6" );
				historyView.setOggettoDate( new Timestamp( new Date().getTime() ) );
				historyView.setCdr( "099231" );
				historyView.setStatusId( 106L );
				return historyView;
			}

			// This method will load the logged in user values in the oggettoview and
			// the given status, and type of oggetto
			public OggettoView getBasicOggettoView( final String status, final String oggettoType ) throws TracciabilitaException, RemoteException
			{
			    final OggettoView oggettoView = new OggettoView();
				oggettoView.setLid( "090" );
				oggettoView.setOggettoDate( new Timestamp( Util.truncDate( new java.util.Date() ).getTime() ) );
				oggettoView.setUserId( "BSSC6" );
				oggettoView.setCdrName( "099231" );
				oggettoView.setBankId( 1L );
				oggettoView.setStatusId( 36L );
				if ( oggettoType != null )
				{
					oggettoView.setOggettoType( 5904L );
				}
				return oggettoView;
			}
		} );
	}
	
	
}
