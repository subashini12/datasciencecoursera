package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.mock.DBHelperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ChannelElementsView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ChannelElementsAdminImplTest {

	ChannelElementsAdminImpl channelElementsAdminImpl = null ;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private DBHelperMock dbHelperMock;

	@Before
	public void setUp() throws Exception {
		channelElementsAdminImpl = new ChannelElementsAdminImpl();
		mockConnectionProvider = new MockConnectionProvider();
		dbHelperMock = new DBHelperMock();
		dbHelperMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(DBConnector.class, dbHelperMock);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
	}

	@After
	public void tearDown() throws Exception {
		channelElementsAdminImpl = null;
	}

	@Test(expected=TracciabilitaException.class)
	public void testCensitoOggetto_01() throws SQLException, TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider(
				getCensitoOggettoStmt());
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		channelElementsAdminImpl.censitoOggetto(getChannelElementsView());

	}
	@Test(expected=TracciabilitaException.class)
	public void testModificaOggetto_01() throws SQLException, TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider(
				getModificaOggettoStmt());
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		channelElementsAdminImpl.modificaOggetto(getChannelElementsView());

	}

	private String getCensitoOggettoStmt() {
		final StringBuilder query = new StringBuilder( "INSERT INTO TP_MA_CHANNEL_ELEMENTS (CE_ID, CE_ID_CHANNEL, " );
		query.append( "CE_ELEMENT_VALUE, CE_BANK) VALUES (TP_SQ_CHANNEL_ELEMENT_ID.NEXTVAL,?,?,?)" );
		return query.toString();
	}
	private String getModificaOggettoStmt() {
		final StringBuilder query = new StringBuilder( "UPDATE TP_MA_CHANNEL_ELEMENTS SET CE_ID_CHANNEL = ? , " );
		query.append( " CE_ELEMENT_VALUE = ?, CE_BANK = ? WHERE CE_ID = ?" );
		return query.toString();
	}

	private static ChannelElementsView getChannelElementsView()
	{
		final ChannelElementsView channelElementsView = new ChannelElementsView() ;
		channelElementsView.setChannelDefinitionId(1L);
		channelElementsView.setChannelElementId(1L);
		channelElementsView.setChannelElementValue("0T18T1");
		channelElementsView.setIdBanca(1L);
		return channelElementsView ;
	}

}
