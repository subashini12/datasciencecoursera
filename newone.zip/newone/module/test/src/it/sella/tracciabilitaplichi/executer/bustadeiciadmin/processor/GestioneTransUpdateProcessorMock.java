package it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;
import mockit.Mock;

public class GestioneTransUpdateProcessorMock {
	@Mock
	public static ExecuteResult getControlliErrorExecuteResult(
			final RequestEvent rqEvent, final ExecuteResult executeResult,
			final ControlliView controlliView) {
		return null;
	}
}
