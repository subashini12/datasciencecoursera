package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.ToDetaglioExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import org.easymock.EasyMock;

public class ToDetaglioExecuterTest extends  AbstractSellaExecuterMock {
	
	ToDetaglioExecuter executer = new ToDetaglioExecuter();
	
	public ToDetaglioExecuterTest(final String name)  {
		super(name);	
	}
	
	public void testToDetaglioExecuter() {
		expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
		expecting(getStateMachineSession().put( ( String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	    playAll();
	    final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
}
