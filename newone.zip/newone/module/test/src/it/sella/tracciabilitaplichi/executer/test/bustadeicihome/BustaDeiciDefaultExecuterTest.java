/*package it.sella.tracciabilitaplichi.executer.test.bustadeicihome;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.BustaDeiciDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.RicercaPageProcessor;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.processor.RicercaandFilterPageProcessor;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor.RicercaPageProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor.RicercaandFilterPageProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor.HomePageProcessorMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.B10UltimoEsitoHandlerMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.B10UltimoEsitoHandler;

import java.util.Map;

import org.easymock.EasyMock;

public class BustaDeiciDefaultExecuterTest extends AbstractSellaExecuterTest 
{

	public BustaDeiciDefaultExecuterTest(final String name) 
	{
		super(name);
	}

	BustaDeiciDefaultExecuter executer = new 	BustaDeiciDefaultExecuter();
	
	public void testBustaDeiciDefaultExecuter_01()
	{
		SecurityWrapperMock.setOperationAllowedToFalse();
		setUpMockMethods(RicercaPageProcessor.class, RicercaPageProcessorMock.class);
		setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class );
		setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class );
		setUpMockMethods( HomePageProcessor.class,HomePageProcessorMock.class );
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class );
		setUpMockMethods( RicercaandFilterPageProcessor.class,RicercaandFilterPageProcessorMock.class);		
		setUpMockMethods( B10UltimoEsitoHandler.class,B10UltimoEsitoHandlerMock.class);	
		expecting( getStateMachineSession().containsKey( CONSTANTS.SEARCH_FILTER.toString( )) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (Boolean)EasyMock.anyObject() ) ).andReturn(Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map<Long, String>) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute( getRequestEvent() );
	}
	
	public void testBustaDeiciDefaultExecuter_03()
	{
		RicercaPageProcessorMock.setRemoteException();
		SecurityWrapperMock.setOperationAllowedToFalse();
		setUpMockMethods(RicercaPageProcessor.class, RicercaPageProcessorMock.class);
		setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class );
		setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class );
		setUpMockMethods( HomePageProcessor.class,HomePageProcessorMock.class );
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class );
		setUpMockMethods( RicercaandFilterPageProcessor.class,RicercaandFilterPageProcessorMock.class);		
		setUpMockMethods( B10UltimoEsitoHandler.class,B10UltimoEsitoHandlerMock.class);	
		expecting( getStateMachineSession().containsKey( CONSTANTS.SEARCH_FILTER.toString( )) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (Boolean)EasyMock.anyObject() ) ).andReturn(Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map<Long, String>) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute( getRequestEvent() );
	}
	
	public void testBustaDeiciDefaultExecuter_04()
	{
		RicercaPageProcessorMock.setRemoteException();
		SecurityWrapperMock.setOperationAllowedToFalse();
		setUpMockMethods(RicercaPageProcessor.class, RicercaPageProcessorMock.class);
		setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class );
		setUpMockMethods( DBPersonaleWrapper.class,DBPersonaleWrapperMock.class );
		setUpMockMethods( HomePageProcessor.class,HomePageProcessorMock.class );
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class );
		setUpMockMethods( RicercaandFilterPageProcessor.class,RicercaandFilterPageProcessorMock.class);		
		setUpMockMethods( B10UltimoEsitoHandler.class,B10UltimoEsitoHandlerMock.class);	
		expecting( getStateMachineSession().containsKey( CONSTANTS.SEARCH_FILTER.toString( )) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (Boolean)EasyMock.anyObject() ) ).andReturn(Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map<Long, String>) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute( getRequestEvent() );
	}
}
*/