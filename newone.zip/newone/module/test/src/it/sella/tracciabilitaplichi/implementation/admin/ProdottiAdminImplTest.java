/**
 * 
 */
package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


/**
 * @author gbs03134
 *
 */

public class ProdottiAdminImplTest extends BasicJDBCTestCaseAdapter {

	ProdottiAdminImpl prodottiAdminImpl = new ProdottiAdminImpl() ;
	
	public void testModificaOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn(addColumn());
		result.addRow(addRow());
		statementHandler.prepareGlobalResultSet(result);
		try {
			prodottiAdminImpl.modificaOggetto(getProdottiView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testCancelliOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn(addColumn());
		result.addRow(addRow());
		statementHandler.prepareGlobalResultSet(result);
		try {
			prodottiAdminImpl.cancelliOggetto(getProdottiView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testCensitoOggetto_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock( ExternalServicesFactory.class , ExternalServicesFactoryMock.class );
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn(addColumn());
		result.addRow(addRow());
		statementHandler.prepareGlobalResultSet(result);
		try {
			prodottiAdminImpl.censitoOggetto(getProdottiView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	private ProdottiView getProdottiView()
	{
		final ProdottiView prodottiView = new ProdottiView() ;
		prodottiView.setProdottiId(261L);
		return prodottiView ;
	}
	
	private List addRow() {
		final List rowList = new ArrayList() ;
		rowList.add(261);
		rowList.add(6L);
		rowList.add(5L);
		rowList.add("BSM16");
		rowList.add("099288");
		rowList.add("171.97.4.35");
		rowList.add(new Date());
		rowList.add(null);
		return rowList;
	}

	private List addColumn() {
		final List columnList = new ArrayList() ;
		columnList.add("OS_ID");
		columnList.add("OS_DOC_ID");
		columnList.add("OS_STATUS_ID");
		columnList.add("OS_USER");
		columnList.add("OS_CDR");
		columnList.add("OS_IP_ADDRESS");
		columnList.add("OS_DATE_TIME");
		columnList.add("OS_REF_ID");
		return columnList;
	}

}
