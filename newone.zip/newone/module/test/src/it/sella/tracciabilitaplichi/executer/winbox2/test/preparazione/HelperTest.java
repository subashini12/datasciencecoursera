package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor.HomePageProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.Helper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.persistence.dto.WinBox2;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;



public class HelperTest extends AbstractSellaExecuterMock
{
    

    public HelperTest( final String name )
    {
        super( name );
    }

   
    /*public void testGetSessionMap1( ) throws TracciabilitaException, RemoteException
    {
    	setUpMockMethods(HomePageProcessor.class,HomePageProcessorMock.class);        
    	setUpMockMethods(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
        expecting(getStateMachineSession().containsKey(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ))).andReturn(Boolean.FALSE).anyTimes();
        expecting( getStateMachineSession().put( (String)EasyMock.anyObject(), (HashMap)EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
        expecting(getStateMachineSession().containsKey( CONSTANTS.ACCODA_PRATICA.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes();
        expecting( getStateMachineSession( ).get(  "ACCODA_PRATICA" ) ).andReturn("abc").anyTimes();
        expecting( getStateMachineSession( ).get(  "IS_CDR_VISIBILITY" ) ).andReturn("abc").anyTimes();
        playAll();
        final Map<Enum, Object> sessionMap = Helper.getSessionMap( getStateMachineSession() );
        assertNotNull(sessionMap);
    }*/
    public void testGetSessionMap2( ) throws TracciabilitaException, RemoteException
    {
    	setUpMockMethods(HomePageProcessor.class,HomePageProcessorMock.class);        
    	setUpMockMethods(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(DBPersonaleWrapper.class,DBPersonaleWrapperMock.class);
        expecting(getStateMachineSession().containsKey(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ))).andReturn(Boolean.TRUE).anyTimes(); 
        final Map<Enum, Object> map = new HashMap<Enum, Object>();
		map.put(CONSTANTS.NUMBER_OF_PAGES, 2L);
        expecting( getStateMachineSession( ).get(  "WINBOX2_PREPARAZIONE_MAP" ) ).andReturn((Serializable) map).anyTimes();     
        playAll();
        final Map<Enum, Object> sessionMap = Helper.getSessionMap( getStateMachineSession() );
        assertNotNull(sessionMap);
    }

    public void testSetFolderArchiveFlowInSession(){
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>();
    	sessionMap.put( CONSTANTS.ACCODA_PRATICA, "abc" );
		sessionMap.put( CONSTANTS.IS_CDR_VISIBILITY, "cde" );
		expecting( getRequestEvent().getAttribute( "folderFlow" ) ).andReturn("1").anyTimes();  
		playAll();
    	Helper.setFolderArchiveFlowInSession(getRequestEvent(), sessionMap);
    }
    
    public void testGetFolderFromSession1(){
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>();
        final Folder folderFromSession = new Folder();
        final OggettoView oggettoView = new OggettoView();
        oggettoView.setBankDescription("Banca Sella");
        folderFromSession.setOggettoView(oggettoView);
    	sessionMap.put( CONSTANTS.FOLDER, folderFromSession );
		Helper.getFolderFromSession(sessionMap);
    }
    public void testGetFolderFromSession2(){
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>();
        sessionMap.put( CONSTANTS.NAME, "ravi" );
		Helper.getFolderFromSession(sessionMap);
    }
    
    public void testGetFolderOggettoIdColl(){
    	final WinBox2 winBox2 = new WinBox2();
        final OggettoView oggettoView = new OggettoView();
        oggettoView.setBankDescription("Banca Sella");
        oggettoView.setId(1L);        
    	winBox2.setOggettoView(oggettoView);
    	Helper.getFolderOggettoIdColl(winBox2);
    }
    /*public void testGetFolderBarcode(){
    	setUpMockMethods(WB2Helper.class,WB2HelperMock.class);
    	setUpMockMethods(ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);
    	setUpMockMethods(Util.class,UtilMock.class);
    	setUpMockMethods(StampeWrapper.class,StampeWrapperMock.class);
    	final Map<Enum,Object> sessionMap =new HashMap<Enum, Object>();
    	final Map<String, Object> userDetailsMap = new HashMap<String, Object>();
    	userDetailsMap.put("1", "RAVI");
    	sessionMap.put(CONSTANTS.USER_DETAILS ,userDetailsMap);
    	final Map<Long,String> folderTypesMap = new HashMap<Long, String>();
    	folderTypesMap.put(1L, "ravi");
    	sessionMap.put( CONSTANTS.FOLDER_TYPES_MAP,folderTypesMap );
    	final Map<Long,String> societaGBSmap = new HashMap<Long, String>();
    	societaGBSmap.put(1L, "ravi");
    	sessionMap.put( CONSTANTS.GBS_COMPANY, societaGBSmap);
    	final FolderAttributes folderAttributes=new FolderAttributes();
    	folderAttributes.setTipoPratica(1L);
    	try {
			Helper.getFolderBarcode(sessionMap, folderAttributes, "documentCode");
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }*/
    /*public void testGetSessionMap2( ) throws TracciabilitaException, RemoteException
    {
        setForGetSessionMap( );
        expect( this.smSession.containsKey( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ) ) ).andReturn( Boolean.TRUE );
        expect( this.smSession.get( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ) ) ).andReturn( new HashMap<Enum, Object>( 1 ) );
        replay( this.smSession );
        final Map<Enum, Object> sessionMap = Helper.getSessionMap( this.smSession );
        assertEquals( false, sessionMap == null );
        assertEquals( true, sessionMap.isEmpty( ) );
        assertEquals( false, sessionMap.containsKey( CONSTANTS.USER ) );
        assertEquals( false, sessionMap.containsKey( CONSTANTS.CDR ) );
    }

    public void testGetSessionMap3( ) throws TracciabilitaException, RemoteException
    {
        setForGetSessionMap( );
        expect( this.smSession.containsKey( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ) ) ).andReturn( Boolean.FALSE );
        expect( this.smSession.get( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ) ) ).andReturn( null );
        expect( this.smSession.put( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ), new HashMap( ){ } ) ).andReturn( null );
        expect( this.smSession.containsKey( CONSTANTS.ACCODA_PRATICA.toString( ) ) ).andReturn( Boolean.TRUE );
		expect( this.smSession.get( CONSTANTS.ACCODA_PRATICA.toString( ) ) ).andReturn( new FolderAttributes( ) );
		expect( this.smSession.get( CONSTANTS.IS_CDR_VISIBILITY.toString( ) ) ).andReturn( Boolean.TRUE );

        replay( this.smSession );
        final Map<Enum, Object> sessionMap = Helper.getSessionMap( this.smSession );
        assertEquals( false, sessionMap == null );
        assertEquals( false, sessionMap.isEmpty( ) );
        assertEquals( true, sessionMap.containsKey( CONSTANTS.USER ) );
        assertEquals( true, sessionMap.containsKey( CONSTANTS.CDR ) );
        assertEquals( "SSILQ74 - MANIKANDAN R", sessionMap.get( CONSTANTS.USER ).toString( ) );
        assertEquals( "IN2030 TECHNICAL", sessionMap.get( CONSTANTS.CDR ).toString( ) );
        assertTrue( sessionMap.containsKey( CONSTANTS.ACCODA_PRATICA ) );
        assertTrue( sessionMap.containsKey( CONSTANTS.IS_CDR_VISIBILITY ) );
    }
    
    private void setForGetSessionMap( )
    {
        Mockit.redefineMethods( SecurityDBPersonaleWrapper.class, new Object( )
        {
            public String getDipendente( final String userId ) throws RemoteException
            {
                return "MANIKANDAN R";
            }
        } );

        Mockit.redefineMethods( DBPersonaleWrapper.class, new Object( )
        {
            public String getDenominazioneForCdr( final String cdr ) throws RemoteException
            {
                return "TECHNICAL";
            }
        } );

        Mockit.redefineMethods( HomePageProcessor.class, new Object( )
        {
            public Hashtable getUserDetails( ) throws RemoteException
            {
                final Map userDetails = new Hashtable<String, Object>( 1 );
                userDetails.put( CONSTANTS.USER.getValue( ), "SSILQ74" );
                userDetails.put( CONSTANTS.CDR.getValue( ), "IN2030" );
                return ( Hashtable ) userDetails;
            }
        } );
    }

    public void testGetBasicOggettoView( ) throws TracciabilitaException, RemoteException
    {
        Mockit.redefineMethods( TracciabilitaPlichiStatusDataAccess.class, new Object( )
        {
            public Long getStatusId( final String statusType ) throws RemoteException
            {
                return 281L;
            }
        } );

        Mockit.redefineMethods( ClassificazioneWrapper.class, new Object( )
        {
            public ClassificazioneView getClassificazioneView( final String causale, final String parentCausale ) throws RemoteException
            {
                final ClassificazioneView classificazioneView = createMock( ClassificazioneView.class );
                expect( classificazioneView.getId( ) ).andReturn( Long.valueOf( 25791 ) );
                return classificazioneView;
            }
        } );

        final Map<String, Object> userDetails = new HashMap<String, Object>( 1 );
        userDetails.put( CONSTANTS.USER.getValue( ), "SSILQ74" );
        userDetails.put( CONSTANTS.CDR.getValue( ), "IN2030" );
        userDetails.put( CONSTANTS.BANK.getValue( ), 1L );
        final OggettoView oggettoView = WB2Helper.getBasicOggettoView( userDetails, CAUSALE.WINBOX2, STATUS.WINBOX2.PREPARATO.getValue( ) );
        assertEquals( "SSILQ74", oggettoView.getUserId( ) );
        assertEquals( "IN2030", oggettoView.getCdrName( ) );
        assertEquals( Long.valueOf( 1 ), oggettoView.getBankId( ) );
        assertEquals( Long.valueOf( 281 ), oggettoView.getStatusId( ) );
    }
    
    public void testGetValue( )
    {
    	String valueFromGetValue = WB2Helper.getValue( null );
    	assertEquals( "", valueFromGetValue );
    	
    	valueFromGetValue = WB2Helper.getValue( "Folder" );
    	assertEquals( "Folder", valueFromGetValue );
    	
    	valueFromGetValue = WB2Helper.getValue( new Long( 123 ) );
    	assertEquals( "123", valueFromGetValue );
    }
    

    public void testGetFolderOggettoIdColl1( )
    {
        final WinBox2 winBox2 = new WinBox2( );
        OggettoView oggettoView;
        Folder folder;
        oggettoView = new OggettoView( );
        oggettoView.setId( 1L );
        folder = new Folder( oggettoView, null, null );
        winBox2.add( folder );
        
        oggettoView = new OggettoView( );
        oggettoView.setId( 2L );
        folder = new Folder( oggettoView, null, null );
        winBox2.add( folder );
        final Collection<String> collection = Helper.getFolderOggettoIdColl( winBox2 );
        assertEquals( false, collection == null  );
        assertEquals( false, collection.isEmpty( ) );
        assertEquals( 2, collection.size( ) );
        assertEquals( "1", ( ( List ) collection ).get( 0 ).toString( ) );
        assertEquals( "2", ( ( List ) collection ).get( 1 ).toString( ) );
    }
    
    public void testGetFolderOggettoIdColl2( )
    {
        final WinBox2 winBox2 = new WinBox2( );
        final Collection<String> collection = Helper.getFolderOggettoIdColl( winBox2 );
        assertEquals( false, collection == null  );
        assertEquals( true, collection.isEmpty( ) );
        assertEquals( 0, collection.size( ) );
    }
    
    public void testGetFolderFromSession1( )
    {
    	final HashMap<Enum, Object> sessionMap = null;
    	final Folder folder = Helper.getFolderFromSession( sessionMap );
    	assertEquals( true, ( folder == null ) );
    }
    
    public void testGetFolderFromSession2( )
    {
    	final HashMap<Enum, Object> sessionMap = new HashMap<Enum, Object>( );
    	assertEquals( true, !sessionMap.containsKey( CONSTANTS.FOLDER ) );
    	final Folder folder = Helper.getFolderFromSession( sessionMap );
    	assertEquals( false, ( folder == null ) );
    	assertEquals( true, sessionMap.containsKey( CONSTANTS.FOLDER ) );
    }
    
    public void testGetFolderFromSession3( )
    {
    	final HashMap<Enum, Object> sessionMap = new HashMap<Enum, Object>( );
    	sessionMap.put( CONSTANTS.FOLDER, new Folder( ) );
    	assertEquals( true, sessionMap.containsKey( CONSTANTS.FOLDER ) );
    	final int hashCodeBefore = ( ( Folder )sessionMap.get( CONSTANTS.FOLDER ) ).hashCode( );
    	final Folder folder = Helper.getFolderFromSession( sessionMap );
    	assertEquals( false, ( folder == null ) );
    	assertEquals( true, sessionMap.containsKey( CONSTANTS.FOLDER ) );
    	final int hashCodeAfter = folder.hashCode( );
    	assertEquals( hashCodeBefore, hashCodeAfter );
    }
    
    public void testGetWinbox2XML( )
    {
        final WinBox2 winBox2 = new WinBox2( );
        Folder folder = new Folder( null, null, new FolderAttributes( ) );
        final String FOLD_BARCODE1 = "1044015860302";
        folder.getFolderAttributes( ).setBarcode( FOLD_BARCODE1 );
        folder.getFolderAttributes( ).setTipoPratica( Long.valueOf( 2L ) );
        winBox2.add( folder );
        
        folder = new Folder( null, null, new FolderAttributes( ) );
        final String FOLD_BARCODE2 = "1044014423430";
        folder.getFolderAttributes( ).setBarcode( FOLD_BARCODE2 );
        folder.getFolderAttributes( ).setTipoPratica( Long.valueOf( 1L ) );
        winBox2.add( folder );
        
        final Map userDetails = getUserDetails( );
        
        final String PRATICADESC1 = "PraticaDescriptionForTesting";
        final String PRATICADESC2 = "NewPraticaDescriptionForTesting";
        
        final Map<Long, String> folderTypesMap = new HashMap<Long, String>( );
        folderTypesMap.put( Long.valueOf( 1L ), PRATICADESC1 );
        folderTypesMap.put( Long.valueOf( 2L ), PRATICADESC2 );
        
        final StringBuilder expected = new StringBuilder( )
        .append( "<WINBOX2>" )
        	.append( "<USER_ID>" ).append( "SSILQ40" ).append( "</USER_ID>" )
        	.append( "<NAME>" ).append( "ANBARASU  SHANMUGHAM" ).append( "</NAME>" )
        	.append( "<CDR>" ).append( "IN2030" ).append( "</CDR>" )
        	.append( "<CDR_DESCRIPTION>" ).append( "TECHNICAL" ).append( "</CDR_DESCRIPTION>" )
        	.append( "<ABI_BANCA>" ).append( "03268" ).append( "</ABI_BANCA>" )
        	.append( "<BANK_DESCRIPTION>" ).append( "Banca Sella Spa." ).append( "</BANK_DESCRIPTION>" )
        	.append( "<NO_OF_FOLDERS>" ).append( 2 ).append( "</NO_OF_FOLDERS>" )
        	.append( "<FOLDER_DETAILS>" )
        		.append( "<FOLDER>" )
        			.append( "<BARCODE>" ).append( FOLD_BARCODE1 ).append( "</BARCODE>" )
        			.append( "<TYPE>" ).append( PRATICADESC2 ).append( "</TYPE>" )
        		.append( "</FOLDER>" )
        		.append( "<FOLDER>" )
        			.append( "<BARCODE>" ).append( FOLD_BARCODE2 ).append( "</BARCODE>" )
        			.append( "<TYPE>" ).append( PRATICADESC1 ).append( "</TYPE>" )
        		.append( "</FOLDER>" )
        	.append( "</FOLDER_DETAILS>" )
        .append( "</WINBOX2>" );
         assertEquals( expected.toString( ), WB2Helper.getWinbox2XML( userDetails, folderTypesMap, winBox2 ) );
    }
    
    public void testGetWinbox2Barcode( ) throws TracciabilitaException, RemoteException
    {
    	Mockit.redefineMethods( StampeWrapper.class, new Object( )
        {
            public String censitoPrintingData( final String documentoCode, final String xmlData  )
            {
                return "123456789123";
            }
        } );
    	
    	Mockit.redefineMethods( WB2Helper.class, new Object( )
    	{
    		public String getWinbox2XML( final Map userDetails, final Map<Long,String> folderTypesMap, final WinBox2 winBox2 )
    		{
    			return "WINBOX2 XML";
    		}
    		
    		public void updateStampeWithBarcode( final String stampeXML, final String stampeId, final String barcode, final String rootTag ) throws TracciabilitaException, RemoteException
    		{
    			return;
    		}
    	} );
    	
    	final String expectedBarcode = Util.getEAN13BarcodeFromStampeId( "123456789123" );
    	final String actualBarcode = WB2Helper.getWinbox2Barcode( new Hashtable<String, Object>( ), new HashMap<Long, String>( ), new WinBox2( ), CONSTANTS.TP_WB2.getValue( ) );
    	assertEquals( expectedBarcode, actualBarcode );
    }
    
    public void testGetFolderXML1( )
    {
    	final Map userDetails = HelperTest.getUserDetails( );
        
    	final String folderDescription = "DOCUMENTO GENERICO";
        final String cifre = "6053196242060";
        final String meseAnno = "12/2009";
        final BigDecimal importo = new BigDecimal( "10000.97" );
        final String name = "ANBARASU";
        final String surName = "SHANMUGHAM";
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setCifre( cifre );
    	folderAttributes.setMeseAnno( meseAnno );
    	folderAttributes.setImporto( importo );
    	folderAttributes.setNome( name );
    	folderAttributes.setCogNome( surName );
    	
    	final StringBuilder expected = new StringBuilder( )
        .append( "<FOLDER>" )
        	.append( "<USER_ID>" ).append( "SSILQ40" ).append( "</USER_ID>" )
        	.append( "<NAME>" ).append( "ANBARASU  SHANMUGHAM" ).append( "</NAME>" )
        	.append( "<CDR>" ).append( "IN2030" ).append( "</CDR>" )
        	.append( "<CDR_DESCRIPTION>" ).append( "TECHNICAL" ).append( "</CDR_DESCRIPTION>" )
        	.append( "<ABI_BANCA>" ).append( "03268" ).append( "</ABI_BANCA>" )
        	.append( "<BANK_DESCRIPTION>" ).append( "Banca Sella Spa." ).append( "</BANK_DESCRIPTION>" )
        	.append( "<DETAILS>" )
        		.append( "<TIPO_PRATICA>" ).append( folderDescription ).append( "</TIPO_PRATICA>" )
        		.append( "<MESE_ANNO>" ).append( meseAnno ).append( "</MESE_ANNO>" )
        		.append( "<CIFRE>" ).append( cifre ).append( "</CIFRE>" )
        		.append( "<IMPORTO>" ).append( Util.getItalianCurrency( importo ) ).append( "</IMPORTO>" )
        		.append( "<NOTE>").append( "</NOTE>" )
        		.append( "<NOME>" ).append( name + "  " + surName ).append( "</NOME>" )
        		.append( "<PROTOCOLLO>" ).append( "</PROTOCOLLO>" )
        		.append( "<SOCIETA_GBS>" ).append( "</SOCIETA_GBS>" )
        		.append( "<SOCIETA>" ).append( "</SOCIETA>" )
        		.append( "<CODFIS_PIVA>" ).append( "</CODFIS_PIVA>" )
        	.append( "</DETAILS>" )
        .append( "</FOLDER>" );
    	
        final String actual = WB2Helper.getFolderXML( userDetails, folderDescription, folderAttributes, new HashMap<Long, String>( ) );
        assertEquals( expected.toString( ), actual );
    }

    public void testGetFolderXML2( )
    {
    	final Map userDetails = HelperTest.getUserDetails( );
        
    	final String folderDescription = "DOCUMENTO GENERICO";
        final String cifre = "6053196242060";
        final String meseAnno = "12/2009";
        final BigDecimal importo = new BigDecimal( "10000.97" );
        final String name = "ANBARASU";
        final String surName = "SHANMUGHAM";
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setCifre( cifre );
    	folderAttributes.setMeseAnno( meseAnno );
    	folderAttributes.setImporto( importo );
    	folderAttributes.setNome( name );
    	folderAttributes.setCogNome( surName );
    	folderAttributes.setSocietaGBS( Long.valueOf( 1L ) );
    	
    	final HashMap<Long, String> societaGBSMap = new HashMap<Long, String>( );
    	societaGBSMap.put( Long.valueOf( 1L ), "Banca Sella Spa." );
    	
    	final StringBuilder expected = new StringBuilder( )
        .append( "<FOLDER>" )
        	.append( "<USER_ID>" ).append( "SSILQ40" ).append( "</USER_ID>" )
        	.append( "<NAME>" ).append( "ANBARASU  SHANMUGHAM" ).append( "</NAME>" )
        	.append( "<CDR>" ).append( "IN2030" ).append( "</CDR>" )
        	.append( "<CDR_DESCRIPTION>" ).append( "TECHNICAL" ).append( "</CDR_DESCRIPTION>" )
        	.append( "<ABI_BANCA>" ).append( "03268" ).append( "</ABI_BANCA>" )
        	.append( "<BANK_DESCRIPTION>" ).append( "Banca Sella Spa." ).append( "</BANK_DESCRIPTION>" )
        	.append( "<DETAILS>" )
        		.append( "<TIPO_PRATICA>" ).append( folderDescription ).append( "</TIPO_PRATICA>" )
        		.append( "<MESE_ANNO>" ).append( meseAnno ).append( "</MESE_ANNO>" )
        		.append( "<CIFRE>" ).append( cifre ).append( "</CIFRE>" )
        		.append( "<IMPORTO>" ).append( Util.getItalianCurrency( importo ) ).append( "</IMPORTO>" )
        		.append( "<NOTE>").append( "</NOTE>" )
        		.append( "<NOME>" ).append( name + "  " + surName ).append( "</NOME>" )
        		.append( "<PROTOCOLLO>" ).append( "</PROTOCOLLO>" )
        		.append( "<SOCIETA_GBS>" ).append( societaGBSMap.get( Long.valueOf( 1L ) ) ).append( "</SOCIETA_GBS>" )
        		.append( "<SOCIETA>" ).append( "</SOCIETA>" )
        		.append( "<CODFIS_PIVA>" ).append( "</CODFIS_PIVA>" )
        	.append( "</DETAILS>" )
        .append( "</FOLDER>" );
        
        final String actual = WB2Helper.getFolderXML( userDetails, folderDescription, folderAttributes, societaGBSMap );
        assertEquals( expected.toString( ), actual );
    }

    public void testGetFolderBarcode1( ) throws RemoteException, TracciabilitaException
    {
    	Mockit.redefineMethods( StampeWrapper.class, new Object( )
        {
            public String censitoPrintingData( final String documentoCode, final String xmlData  )
            {
                return "123456789123";
            }
        } );
    	
    	Mockit.redefineMethods( WB2Helper.class, new Object( )
    	{
    		public String getFolderXML( final Map userDetails, final String folderDescription, final FolderAttributes folderAttributes, final Map<Long,String> societaGBSmap )
    		{
    			return "FOLDER XML";
    		}
    		
    		public void updateStampeWithBarcode( final String stampeXML, final String stampeId, final String barcode, final String rootTag ) throws TracciabilitaException, RemoteException
    		{
    			return;
    		}
    	} );
    	Mockit.redefineMethods( ImageStorageSystemWrapper.class, new Object( )
    	{
    		public String getCodeWithPrefix( final String prefix ) throws TracciabilitaException, RemoteException
    		{
    			return "123456789123";
    		}
    	} );
    	
    	final Map<Long, String> folderTypesMap = new HashMap<Long, String>( );
        folderTypesMap.put( Long.valueOf( 1L ), "Dummy Description" );
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setTipoPratica( Long.valueOf( 1L ) );
        
        final String expectedBarcode = Util.getEAN13BarcodeFromStampeId( "123456789123" );
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 1 );
        sessionMap.put( CONSTANTS.FOLDER_TYPES_MAP, folderTypesMap );
        final Map<Enum,Object> resultMap = Helper.getFolderBarcode( sessionMap, folderAttributes, CONSTANTS.TP_FOL.getValue( ) );
        assertTrue( resultMap.containsKey( CONSTANTS.BARCODE ) );
        final String actualBarcode = resultMap.get( CONSTANTS.BARCODE ).toString( );
    	assertEquals( expectedBarcode, actualBarcode );
    	assertTrue( resultMap.containsKey( CONSTANTS.STAMPE_ID ) );
    	assertEquals( "123456789123", ( ( Long ) resultMap.get( CONSTANTS.STAMPE_ID ) ).toString( ) );
    }
    
    public void testGetFolderBarcode2( ) throws RemoteException, TracciabilitaException
    {
    	Mockit.redefineMethods( StampeWrapper.class, new Object( )
        {
            public String censitoPrintingData( final String documentoCode, final String xmlData  )
            {
                return "123456789123";
            }
        } );
    	
    	Mockit.redefineMethods( WB2Helper.class, new Object( )
    	{
    		public String getFolderXML( final Map userDetails, final String folderDescription, final FolderAttributes folderAttributes, final Map<Long,String> societaGBSmap )
    		{
    			return "FOLDER XML";
    		}
    		
    		public void updateStampeWithBarcode( final String stampeXML, final String stampeId, final String barcode, final String rootTag ) throws TracciabilitaException, RemoteException
    		{
    			return;
    		}
    	} );
    	Mockit.redefineMethods( ImageStorageSystemWrapper.class, new Object( )
    	{
    		public String getCodeWithPrefix( final String prefix ) throws TracciabilitaException, RemoteException
    		{
    			return "123456789123";
    		}
    	} );
        expect( this.smSession.containsKey( CONSTANTS.ACCODA_PRATICA.toString( ) ) ).andReturn( Boolean.TRUE );
        final FolderAttributes folderAttributes = new FolderAttributes( );
        folderAttributes.setBarcode( Util.getEAN13BarcodeFromStampeId( "123456789123" ) );
        folderAttributes.setTipoPratica( Long.valueOf( 1L ) );
		expect( this.smSession.get( CONSTANTS.ACCODA_PRATICA.toString( ) ) ).andReturn( folderAttributes );
		replay( this.smSession );
		
    	final Map<Long, String> folderTypesMap = new HashMap<Long, String>( );
        folderTypesMap.put( Long.valueOf( 1L ), "Dummy Description" );
        
        
        final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 1 );
        sessionMap.put( CONSTANTS.FOLDER_TYPES_MAP, folderTypesMap );
        final Map<Enum,Object> resultMap = Helper.getFolderBarcode( sessionMap, folderAttributes, CONSTANTS.TP_FOL.getValue( ) );
        assertTrue( resultMap.containsKey( CONSTANTS.BARCODE ) );
        final String actualBarcode = resultMap.get( CONSTANTS.BARCODE ).toString( );
    	assertEquals( folderAttributes.getBarcode( ), actualBarcode );
    	assertTrue( resultMap.containsKey( CONSTANTS.STAMPE_ID ) );
    	assertEquals( "123456789123", ( ( Long ) resultMap.get( CONSTANTS.STAMPE_ID ) ).toString( ) );
    }
    public void testSetFolderArchiveFlowInSession_01( )
    {
        expect( this.requestEvent.getAttribute( CONSTANTS.FOLDER_FLOW.getValue( ) ) ).andReturn( "0" );
        replay( this.requestEvent );
        final Map<Enum,Object> sessionMap = new HashMap<Enum, Object>( 1 );
        Helper.setFolderArchiveFlowInSession( this.requestEvent, sessionMap );
        assertEquals( true, sessionMap.containsKey( CONSTANTS.FOLDER_FLOW ) );
        assertEquals( "0", sessionMap.get( CONSTANTS.FOLDER_FLOW ) );
    }
    public void testSetFolderArchiveFlowInSession_02( )
    {
        expect( this.requestEvent.getAttribute( CONSTANTS.FOLDER_FLOW.getValue( ) ) ).andReturn( null );
        replay( this.requestEvent );
        final Map<Enum,Object> sessionMap = new HashMap<Enum, Object>( 1 );
        Helper.setFolderArchiveFlowInSession( this.requestEvent, sessionMap );
        assertEquals( false, sessionMap.containsKey( CONSTANTS.FOLDER_FLOW ) );
        assertEquals( null, sessionMap.get( CONSTANTS.FOLDER_FLOW ) );
    }*/
    private static final Map<String, Object> getUserDetails( )
    {
    	final Map userDetails = new HashMap( );
        userDetails.put( CONSTANTS.USER.getValue( ), "SSILQ40" );
        userDetails.put( CONSTANTS.NAME.getValue( ), "ANBARASU" );
        userDetails.put( CONSTANTS.SUR_NAME.getValue( ), "SHANMUGHAM" );
        userDetails.put( CONSTANTS.CDR.getValue( ), "IN2030" );
        userDetails.put( CONSTANTS.CDR_DESCRIPTION.getValue( ), "TECHNICAL" );
        userDetails.put( CONSTANTS.ABI_BANCA.getValue( ), "03268" );
        userDetails.put( CONSTANTS.BANK_DESCRIPTION.getValue( ), "Banca Sella Spa." );
        return userDetails;
    }
    
}    
