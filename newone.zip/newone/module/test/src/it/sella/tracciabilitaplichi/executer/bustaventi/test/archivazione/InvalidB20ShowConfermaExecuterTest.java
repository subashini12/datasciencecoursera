package it.sella.tracciabilitaplichi.executer.bustaventi.test.archivazione;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.bustaventi.archivazione.InvalidB20ShowConfermaExecuter;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import junit.framework.TestCase;

public class InvalidB20ShowConfermaExecuterTest extends TestCase
{

    RequestEvent requestEvent = null;
    StateMachineSession stateMachineSession = null; 
    
    public InvalidB20ShowConfermaExecuterTest( final String name ) {
        super( name );
    }

    @Override
	public void setUp( ) throws Exception {
        this.requestEvent = createMock( RequestEvent.class );
        this.stateMachineSession = createMock( StateMachineSession.class );
    }
    
    public void testInvalidB20ShowConfermaExecuter_01( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.FALSE );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_02( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.SUCCESS, ITPConstants.SUCCESS );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( ITPConstants.YES, executeResult.getAttribute( ITPConstants.SUCCESS ) );
        assertEquals( IErrorCodes.TRPL_1039, executeResult.getAttribute( ITPConstants.MSG ) );
        assertEquals( false, views.containsKey( ITPConstants.SUCCESS ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_03( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED, 1 );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( true, views.containsKey( ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED ) );
        assertEquals( 1, executeResult.getAttribute( ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_04( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.TOTAL_PLICHI_RECEIVED, 2 );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( true, views.containsKey( ITPConstants.TOTAL_PLICHI_RECEIVED ) );
        assertEquals( 2, executeResult.getAttribute( ITPConstants.TOTAL_PLICHI_RECEIVED ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_05( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.SELECTED_OGGETTO_TYPE, 5900 );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( true, views.containsKey( ITPConstants.SELECTED_OGGETTO_TYPE ) );
        assertEquals( 5900, executeResult.getAttribute( ITPConstants.SELECTED_OGGETTO_TYPE ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_06( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.CASSETTO_BOX_ID, 12345 );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( 12345, executeResult.getAttribute( "LastBoxCode" ) );
        assertEquals( false, views.containsKey( ITPConstants.CASSETTO_BOX_ID ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_07( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.IS_BARCODE_READER_AVAILABLE, true );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( true, views.containsKey( ITPConstants.IS_BARCODE_READER_AVAILABLE ) );
        assertEquals( true, executeResult.getAttribute( ITPConstants.IS_BARCODE_READER_AVAILABLE ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    public void testInvalidB20ShowConfermaExecuter_08( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.stateMachineSession.containsKey( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION ) ).andReturn( Boolean.TRUE );
        final Map views = new Hashtable( 1 );
        views.put( ITPConstants.TYPES_OF_OGGETTOS, "BV" );
        expect( this.stateMachineSession.get( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION  ) ).andReturn( ( Serializable ) views );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult executeResult = new InvalidB20ShowConfermaExecuter( ).execute( this.requestEvent );
        assertEquals( true, views.containsKey( ITPConstants.TYPES_OF_OGGETTOS ) );
        assertEquals( "BV", executeResult.getAttribute( ITPConstants.TYPES_OF_OGGETTOS ) );
        assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) ); 
    }
    
    @Override
    public void tearDown( ) throws Exception {
    	requestEvent = null;
    	stateMachineSession = null; 
    }

}
