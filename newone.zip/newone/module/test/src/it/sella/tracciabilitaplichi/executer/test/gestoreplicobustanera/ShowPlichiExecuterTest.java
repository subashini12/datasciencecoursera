package it.sella.tracciabilitaplichi.executer.test.gestoreplicobustanera;

import it.sella.tracciabilitaplichi.executer.gestoreplicobustanera.ShowPlichiExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import org.easymock.EasyMock;

public class ShowPlichiExecuterTest extends AbstractSellaExecuterMock
{

	public ShowPlichiExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	ShowPlichiExecuter executer = new ShowPlichiExecuter();
	
	public void testShowPlichiExecuter_01()
	{
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("21").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

}
