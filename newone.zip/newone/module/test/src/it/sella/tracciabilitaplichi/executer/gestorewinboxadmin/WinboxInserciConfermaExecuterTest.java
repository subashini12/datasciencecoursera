package it.sella.tracciabilitaplichi.executer.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin.WinboxAdminHelperMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;

public class WinboxInserciConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	public WinboxInserciConfermaExecuterTest(final String name) {
		super(name);
	}

	WinboxInserciConfermaExecuter executer = new WinboxInserciConfermaExecuter();

	public void testWinboxInserciConfermaExecuter_01() {
		TracciabilitaPlichiImplMock.setCdr();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testWinboxInserciConfermaExecuter_02() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testWinboxInserciConfermaExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

}
