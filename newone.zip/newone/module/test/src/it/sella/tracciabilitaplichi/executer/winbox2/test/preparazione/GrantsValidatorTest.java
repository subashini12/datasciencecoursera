package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsValidator;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;

public class GrantsValidatorTest extends AbstractSellaMock
{
	
	GrantsValidator grantsValidator = null;
    
	public GrantsValidatorTest(final String name) {
		super(name);		 
	}
	
    @Override
    @Before
	public void setUp( ) throws Exception
    {
    	grantsValidator = new GrantsValidator();
    }

    @Override
    @After
	public void tearDown( )
    {
    	grantsValidator =  null;
    }

	public void testValidateofTwoParams_01(){
		
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>(1);
		sessionMap.put(CONSTANTS.GRANTS_COLLECTION, getGrantsList());
		try {
			grantsValidator.validate("BSSC6", sessionMap);
		} catch (final Exception e) {
			
		}
		assertEquals( true, sessionMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
        assertEquals( IErrorCodes.TRPL_1340, sessionMap.get( CONSTANTS.ERROR_MESSAGE ) );
	}
		
	public void testValidateofTwoParams_02(){
		
		DBPersonaleWrapperMock.setUserSoggIdAsNotNull();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>(1);
		sessionMap.put(CONSTANTS.GRANTS_COLLECTION, getGrantsList());
		try {
			grantsValidator.validate("BSSC6", sessionMap);
		 } catch (final Exception e) {
	   }    
		 assertEquals( true, sessionMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
	        assertEquals( IErrorCodes.TRPL_1340, sessionMap.get( CONSTANTS.ERROR_MESSAGE ) );
    }
	
	public void testValidateofTwoParams_03(){
		
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>(1);
		sessionMap.put(CONSTANTS.GRANTS_COLLECTION, new ArrayList<Grants>());
		try {
			grantsValidator.validate("BSSC6", sessionMap);
		} catch (final Exception e) {
			
		}
	}
	
	public void testValidateofThreeParams_01(){
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>(1);
		sessionMap.put(CONSTANTS.GRANTS_COLLECTION, new ArrayList<Grants>());
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		try {
			grantsValidator.validate("BSSC6",getAltriWinboxView(), sessionMap);
		} catch (final Exception e) {
			
		}
	}
	
	public void testValidateofThreeParams_02(){
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>(1);
		sessionMap.put(CONSTANTS.GRANTS_COLLECTION, new ArrayList<Grants>());
		DBPersonaleWrapperMock.setUserSoggIdAsNotNull();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		try {
			grantsValidator.validate("BSSC6",getAltriWinboxView(), sessionMap);
		} catch (final Exception e) {			
		}
		assertEquals( false, sessionMap.containsKey( CONSTANTS.ERROR_MESSAGE ) );
	}
	
	 	
    private List<Grants> getGrantsList()
	{
		final List<Grants> grantsList = new ArrayList<Grants>();
		final Grants grant1 = new Grants() ;
		grant1.setBarcode("1234567891234");
		grant1.setIdSoggetto(1L);
		final Grants grant2 = new Grants() ;
		grant2.setBarcode("1345678912544");
		grant2.setIdSoggetto(2L);
		grantsList.add(grant1);
		grantsList.add(grant2);
		return grantsList ;
	}
    
    private AltriWinboxView getAltriWinboxView(){
    	final AltriWinboxView altriWinboxView = new AltriWinboxView();
    	altriWinboxView.setBank(1L);
    	return altriWinboxView;
    	
    }  
}
