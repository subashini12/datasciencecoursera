package it.sella.tracciabilitaplichi.executer.test.gestoreplichiattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestoreplichiattributeadmin.PlichiAttributeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;

import java.io.Serializable;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class PlichiAttributeCercaExecuterTest extends AbstractSellaExecuterMock 
{
  public PlichiAttributeCercaExecuterTest(String name) 
  {
		super(name);
  }
  
  PlichiAttributeCercaExecuter executer = new PlichiAttributeCercaExecuter();
  
    public void testPlichiAttributeCercaExecuter_01()
    {
	   expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.TRUE ).anyTimes();
	   expecting(getStateMachineSession().get("PlichiTable")).andReturn(new Hashtable()).anyTimes();
	   playAll();
	   executer.execute(getRequestEvent()); 
    }
    public void testPlichiAttributeCercaExecuter_02()
    {  
    	TracciabilitaPlichiCommonDataAccessMock.setplichiAttributeViewNull();
    	expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
        expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
        setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
        expecting( getStateMachineSession().put( ( String )EasyMock.anyObject() , ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
        playAll();
        executer.execute(getRequestEvent()); 
    }
  
    public void testPlichiAttributeCercaExecuter_03()
    {
       expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
       expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
       setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
       expecting( getStateMachineSession().put( ( String )EasyMock.anyObject() , ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
       playAll();
       executer.execute(getRequestEvent());
    }
    public void testPlichiAttributeCercaExecuter_04()
    {
       expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
       expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.FALSE );
       setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
       expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.TRUE );
       expecting( getStateMachineSession().put( ( String )EasyMock.anyObject() , ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
       expecting(getStateMachineSession().get("PlichiTable")).andReturn(new Hashtable()).anyTimes();
       playAll();
       executer.execute(getRequestEvent());
    }
    
    public void testPlichiAttributeCercaExecuter_05()
    {
       expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("").anyTimes();
       expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
       playAll();
       executer.execute(getRequestEvent());
    }
    public void testPlichiAttributeCercaExecuter_06()
    {
       expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("ab").anyTimes();
       expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
       playAll();
       executer.execute(getRequestEvent());
    }

    public void testPlichiAttributeCercaExecuter_07()
    {
       TracciabilitaPlichiCommonDataAccessMock.setTracciabilitaException();
       expecting( getRequestEvent().getAttribute( "ID" ) ).andReturn("01").anyTimes();
       expecting( getStateMachineSession().containsKey( "PlichiTable" ) ).andReturn( Boolean.FALSE ).anyTimes();
       setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
       expecting( getStateMachineSession().put( ( String )EasyMock.anyObject() , ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
       playAll();
       executer.execute(getRequestEvent());
    }
}
