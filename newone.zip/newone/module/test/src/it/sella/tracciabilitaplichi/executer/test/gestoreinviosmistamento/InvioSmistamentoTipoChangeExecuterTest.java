package it.sella.tracciabilitaplichi.executer.test.gestoreinviosmistamento;

import it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento.InvioSmistamentoTipoChangeExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

public class InvioSmistamentoTipoChangeExecuterTest extends AbstractSellaExecuterMock
{

	public InvioSmistamentoTipoChangeExecuterTest(final String name) 
	{
		super(name);
		
	}

	InvioSmistamentoTipoChangeExecuter executer = new InvioSmistamentoTipoChangeExecuter();
	
	public void testExecuter_01()
	{
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("SelectedType")).andReturn("12").anyTimes();
		expecting( getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("ghi").anyTimes();
		expecting( getStateMachineSession().containsKey( "GESTORE_INVIO_SMISTAMENTO_SESSION" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "GESTORE_INVIO_SMISTAMENTO_SESSION" )).andReturn( (Serializable) getMap()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_02()
	{
		TracciabilitaPlichiStatusDataAccessMock.setlistObjectStatusesNull();
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("SelectedType")).andReturn("12").anyTimes();
		expecting( getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("ghi").anyTimes();
		expecting( getStateMachineSession().containsKey( "GESTORE_INVIO_SMISTAMENTO_SESSION" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "GESTORE_INVIO_SMISTAMENTO_SESSION" )).andReturn( (Serializable) getMap()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_03()
	{
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("SelectedType")).andReturn("12").anyTimes();
		expecting( getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("ghi").anyTimes();
		expecting( getStateMachineSession().containsKey( "GESTORE_INVIO_SMISTAMENTO_SESSION" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "GESTORE_INVIO_SMISTAMENTO_SESSION" )).andReturn( (Serializable) getMap()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testExecuter_04()
	{
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods( ClassificazioneWrapper.class , ClassificazioneWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("SelectedType")).andReturn("12").anyTimes();
		expecting( getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("ghi").anyTimes();
		expecting( getStateMachineSession().containsKey( "GESTORE_INVIO_SMISTAMENTO_SESSION" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "GESTORE_INVIO_SMISTAMENTO_SESSION" )).andReturn( (Serializable) getMap()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}


	private Map getMap()
	{
		final Map map = new Hashtable();		
		map.put("UserName","a");
		map.put("CurrDate","b");
		map.put("coll10BustaNeraView","c");
		map.put("TotPages","TotPages");
		map.put("CurrPage","c");
		map.put("TipoCollection","c");		
		return map;
	}
}
