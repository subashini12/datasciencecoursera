package it.sella.tracciabilitaplichi.executer.test.gestoreoggettoadmin;

import it.sella.tracciabilitaplichi.executer.gestoreoggettoadmin.OggettoCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;

public class OggettoCercaExecuterTest extends AbstractSellaExecuterMock
{

	final OggettoCercaExecuter executer = new OggettoCercaExecuter();
	
	public OggettoCercaExecuterTest(String name) 
	{
		super(name);		
	}
	public void testOggettoCercaExecuter_containsKey_OggettoTable()
	{
		
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("0").anyTimes();
		expecting( getStateMachineSession().get("OggettoTable" )).andReturn((Serializable)oggettoHashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().containsKey( "OggettoTable") ).andReturn( Boolean.TRUE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	
	public void testOggettoCercaExecuter_without_containsKey_OggettoTable()
	{
		
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		expecting( getStateMachineSession().get("OggettoTable" )).andReturn((Serializable)oggettoHashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().containsKey( "OggettoTable") ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	
	public void testOggettoCercaExecuter_without_forErrorMsgNull()
	{
		
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().get("OggettoTable" )).andReturn((Serializable)oggettoHashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().containsKey( "OggettoTable") ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	
	public void testOggettoCercaExecuter_without_forErrorMsgNullWithOggViewNull()
	{
		TracciabilitaPlichiCommonDataAccessMock.setOggettoViewNull();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().get("OggettoTable" )).andReturn((Serializable)oggettoHashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().containsKey( "OggettoTable") ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	public void testOggettoCercaExecuter_without_forErrorMsgWithIDNonNumeric()
	{
		
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("abc").anyTimes();
		expecting( getStateMachineSession().get("OggettoTable" )).andReturn((Serializable)oggettoHashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().containsKey( "OggettoTable") ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	
	
	public void testOggettoCercaExecuter_forTracciabilitaExcetion()
	{
		TracciabilitaPlichiCommonDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().get("OggettoTable" )).andReturn((Serializable)oggettoHashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().containsKey( "OggettoTable") ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());		
	}
	private Map oggettoHashtable()
	{
		Map map = new Hashtable();
		map.put(1,"RAvi");;
		return map;
		
	}

	
	
}
