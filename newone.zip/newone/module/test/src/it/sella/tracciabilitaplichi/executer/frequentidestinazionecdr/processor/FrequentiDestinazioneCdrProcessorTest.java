package it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.rmi.RemoteException;


public class FrequentiDestinazioneCdrProcessorTest extends AbstractSellaExecuterMock{

	public FrequentiDestinazioneCdrProcessorTest(final String name) {
		super(name);
	}

	FrequentiDestinazioneCdrProcessor processor = new FrequentiDestinazioneCdrProcessor() ;
	
	public void testFrequentiDestinazioneCdrProcessor_01() {
		expecting(getRequestEvent().getAttribute("banca")).andReturn("");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("");
		playAll();
		assertEquals("TRPL-1077",processor.validateRicercaData(getRequestEvent()));
	}
	
	public void testFrequentiDestinazioneCdrProcessor_02() {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("banca")).andReturn("1");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("1");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		processor.validateRicercaData(getRequestEvent());
		assertTrue(true);
	}
	
	public void testFrequentiDestinazioneCdrProcessor_03() {
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("banca")).andReturn("");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("");
		playAll();
		assertNotNull(processor.setInserciPageData(getRequestEvent()));
	}
	
	public void testFrequentiDestinazioneCdrProcessor_05() {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("banca")).andReturn("1");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("1");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		try {
			processor.validateInserciData(getRequestEvent());
			assertTrue(true);
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testFrequentiDestinazioneCdrProcessor_06() {
		UtilMock.setNumericFalse();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("banca")).andReturn("1");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("1");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		try {
			assertEquals("TRPL-1352",processor.validateInserciData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testFrequentiDestinazioneCdrProcessor_07() {
		UtilMock.setNumericFalse();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("12");
		expecting(getRequestEvent().getAttribute("banca")).andReturn("1");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("1");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		try {
			assertEquals("TRPL-1352",processor.validateInserciData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testFrequentiDestinazioneCdrProcessor_08() {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("banca")).andReturn("1");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		try {
			assertEquals("TRPL-1352",processor.validateInserciData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testFrequentiDestinazioneCdrProcessor_09() {
		TPUtilMock.setTracciabilitaException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("banca")).andReturn("1");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		try {
			assertEquals("TRPL-1352",processor.validateInserciData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
	public void testFrequentiDestinazioneCdrProcessor_10() {
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class, TPFrequentiDestinazioneCdrDataAccessMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("cdrId")).andReturn(null);
		expecting(getRequestEvent().getAttribute("banca")).andReturn("");
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1");
		expecting(getRequestEvent().getAttribute("descrizione")).andReturn("");
		expecting(getRequestEvent().getAttribute("posizione")).andReturn("1");
		playAll();
		try {
			assertEquals("TRPL-1352",processor.validateInserciData(getRequestEvent()));
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
	
}
