package it.sella.tracciabilitaplichi.executer.inserimentobustadeici.processor;

import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

import java.rmi.RemoteException;
import java.util.HashMap;

public class InserimentoPageProcessorTest extends AbstractSellaMock {

	public InserimentoPageProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	InserimentoPageProcessor processor = new InserimentoPageProcessor();

	public void testInserimentoPageProcessor_01() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		try {
			processor.setInserimentoPage(getHashMap(), 1L, 1L);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public void testInserimentoPageProcessor_02() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		try {
			processor.setInserimentoPage(getnumeroConto(), 1L, 1L);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public void testValidateInserimentoPage_03() {
		setUpMockMethods(
				DBPersonaleWrapper.class,
				it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class,
				TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		try {
			processor.validateInserimentoPage(getHashMap(), 1L);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public HashMap getHashMap() {
		final HashMap map = new HashMap();
		map.put("daaa", "12");
		map.put("damm", "12");
		map.put("dagg", "12");
		map.put("prodconsel", "");
		map.put("nc", "1234567894561");
		map.put("ncd", "");
		map.put("anag", "");
		return map;
	}

	public HashMap getnumeroConto() {
		final HashMap map = new HashMap();
		map.put("daaa", "12");
		map.put("damm", "12");
		map.put("dagg", "12");
		map.put("prodconsel", "");
		map.put("nc", "12345678945");
		map.put("ncd", "");
		map.put("anag", "");
		return map;
	}
}
