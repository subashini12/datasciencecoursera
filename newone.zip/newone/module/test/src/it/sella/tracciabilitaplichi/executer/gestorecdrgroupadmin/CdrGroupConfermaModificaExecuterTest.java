package it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.CdrGroupAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.CdrGroupAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import mockit.Mockit;

public class CdrGroupConfermaModificaExecuterTest extends
		AbstractSellaExecuterMock {

	public CdrGroupConfermaModificaExecuterTest(final String name) {
		super(name);
	}

	CdrGroupConfermaModificaExecuter executer = new CdrGroupConfermaModificaExecuter();

	public void testCdrGroupConfermaModificaExecuter_01() {
		TracciabilitaPlichiImplMock.setCdr();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(CdrGroupAdminImpl.class,CdrGroupAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testCdrGroupConfermaModificaExecuter_02() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(CdrGroupAdminImpl.class,CdrGroupAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	public void testCdrGroupConfermaModificaExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(CdrGroupAdminImpl.class,CdrGroupAdminImplMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
}
