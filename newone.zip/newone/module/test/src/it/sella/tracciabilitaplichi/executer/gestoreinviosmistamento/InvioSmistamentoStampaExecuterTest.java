package it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.pdfgenerator.InvioSmistamentoPDFGenerator;
import it.sella.tracciabilitaplichi.pdfgenerator.InvioSmistamentoPDFGeneratorMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;


public class InvioSmistamentoStampaExecuterTest extends AbstractSellaExecuterMock{

	public InvioSmistamentoStampaExecuterTest(final String name) {
		super(name);
	}

	InvioSmistamentoStampaExecuter executer = new InvioSmistamentoStampaExecuter() ;
	
	public void testInvioSmistamentoStampaExecuter_01() {
		ClassificazioneWrapperMock.setPBUSTN();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(InvioSmistamentoPDFGenerator.class, InvioSmistamentoPDFGeneratorMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().get("cassettoCode")).andReturn("CHIV").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoStampaExecuter_02() {
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(InvioSmistamentoPDFGenerator.class, InvioSmistamentoPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().get("cassettoCode")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoStampaExecuter_03() {
		TracciabilitaPlichiCommonDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(InvioSmistamentoPDFGenerator.class, InvioSmistamentoPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		expecting(getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().get("cassettoCode")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testInvioSmistamentoStampaExecuter_04() {
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(InvioSmistamentoPDFGenerator.class, InvioSmistamentoPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().get("cassettoCode")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}
	
	private static Map getMap() {
		final Map map = new HashMap();
		map.put("smistamentoId", "1");
		return map ;
	}
	
	
}
