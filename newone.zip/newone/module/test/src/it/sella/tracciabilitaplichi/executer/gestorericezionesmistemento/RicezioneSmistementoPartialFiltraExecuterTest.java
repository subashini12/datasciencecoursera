package it.sella.tracciabilitaplichi.executer.gestorericezionesmistemento;


import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;

public class RicezioneSmistementoPartialFiltraExecuterTest extends AbstractSellaExecuterMock{

	public RicezioneSmistementoPartialFiltraExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezioneSmistementoPartialFiltraExecuter executer=new RicezioneSmistementoPartialFiltraExecuter();
	
	public void testRicezioneSmistementoPartialFiltraExecuter_01()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("tutti");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_02()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_03()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("winbox2");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("tutti");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_04()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("1");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("tutti");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_07()
	{
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("01");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("01");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("2013");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("tutti");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_08()
	{
		UtilMock.setTracciabilitaException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("01");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("01");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("2013");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("tutti");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_09()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_10()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtableWithOutRicezioneSmistementoMainCollection();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("status")).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_11()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("A");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("5");
		expecting(getRequestEvent().getAttribute("status")).andReturn("tutti");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezioneSmistementoPartialFiltraExecuter_12()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCodeFiltra")).andReturn("");
		expecting(getRequestEvent().getAttribute("casettoDest")).andReturn("");
		expecting(getRequestEvent().getAttribute("utente")).andReturn("");
		expecting(getRequestEvent().getAttribute("errorCode")).andReturn("5");
		expecting(getRequestEvent().getAttribute("status")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Hashtable getHashtable()
	{
		Collection collection=new ArrayList();
		PlichiAttributeView plichiAttributeView=new PlichiAttributeView();
		plichiAttributeView.setBarCode("");
		TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		OggettoView oggettoView=new OggettoView();
		oggettoView.setStatusId(2L);
		oggettoView.setUserId("4");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date("2012,jan,9");
		Timestamp timeStamp = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(timeStamp);
		tracciabilitaPlichiView.setErrorCode("2");
		tracciabilitaPlichiView.setCasetto("Winbox");
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		tracciabilitaPlichiView.setPlichiAttributeView(plichiAttributeView);
		collection.add(tracciabilitaPlichiView);
		Hashtable hashtable=new Hashtable();
		hashtable.put("RicezioneSmistementoBackUpCollection",collection);
		hashtable.put("RicezioneSmistementoMainCollection", "");
		hashtable.put("SelectedStatus","");
		return hashtable;
	}
	private static Hashtable getHashtableWithOutRicezioneSmistementoMainCollection()
	{
		Hashtable hashtable=new Hashtable();
		hashtable.put("SelectedStatus","");
		return hashtable;
	}
}
