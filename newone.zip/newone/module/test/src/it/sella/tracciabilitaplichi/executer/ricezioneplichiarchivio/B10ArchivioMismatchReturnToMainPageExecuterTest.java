package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio;

import it.sella.msg.MsgManager;
import it.sella.tracciabilitaplichi.b10archivation.B10InputPutProcessor;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor.RicezionePlichiArchivioProcessor;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor.RicezionePlichiArchivioProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.B10InputPutProcessorMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class B10ArchivioMismatchReturnToMainPageExecuterTest extends
AbstractSellaExecuterMock {

	public B10ArchivioMismatchReturnToMainPageExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	B10ArchivioMismatchReturnToMainPageExecuter executer = new B10ArchivioMismatchReturnToMainPageExecuter();

	public void testB10ArchivioMismatchReturnToMainPageExecuter_01() {
		TracciabilitaPlichiImplMock.setBusta20();
		setUpMockMethods(LogEvent.class,LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(B10InputPutProcessor.class,B10InputPutProcessorMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(MsgManager.class, MsgManagerMock.class);
		setUpMockMethods(RicezionePlichiArchivioProcessor.class, RicezionePlichiArchivioProcessorMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testB10ArchivioMismatchReturnToMainPageExecuter_02() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(LogEvent.class,LogEventMock.class);
		setUpMockMethods(B10InputPutProcessor.class,B10InputPutProcessorMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(RicezionePlichiArchivioProcessor.class, RicezionePlichiArchivioProcessorMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testB10ArchivioMismatchReturnToMainPageExecuter_03() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(MsgManager.class, MsgManagerMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class);
		setUpMockMethods(B10InputPutProcessor.class,B10InputPutProcessorMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(RicezionePlichiArchivioProcessor.class, RicezionePlichiArchivioProcessorMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	private Map getMap() {
		final Map map = new HashMap();
		map.put("NoOfPlichiRecieved", 1L);
		map.put("Properties", new Properties());
		map.put("FinalB10ValuesToUpdate",getB10InputPutProcessor());
		map.put(CONSTANTS.IS_ENDORSER_VISIBLE.toString( ), "");
		return map;
	}

	public void testB10ArchivioMismatchReturnToMainPageExecuter_04() {
		TracciabilitaPlichiImplMock.setBusta20();
		TracciabilitaPlichiPlichiDataAccessMock.setTracciabilitaExternalServicesException();
		setUpMockMethods(LogEvent.class,LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(B10InputPutProcessor.class,B10InputPutProcessorMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(RicezionePlichiArchivioProcessor.class, RicezionePlichiArchivioProcessorMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	private B10InputPutProcessor getB10InputPutProcessor()
	{
		final B10InputPutProcessor b10InputPutProcessor = new B10InputPutProcessor("","");
		return b10InputPutProcessor;
	}
}
