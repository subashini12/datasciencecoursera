package it.sella.tracciabilitaplichi.executer.test.gestorebustadeiciattributesadmin;

import it.sella.tracciabilitaplichi.executer.gestorebustadeiciattributesadmin.DeiciAttributeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.gestorebustadeiciattributesadmin.processor.DeiciAttributeConfermaProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestorebustadeiciattributesadmin.processor.DeiciAttributeConfermaProcessorMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class DeiciAttributeConfermaExecuterTest extends AbstractSellaExecuterMock
{

	DeiciAttributeConfermaExecuter executer = new DeiciAttributeConfermaExecuter();
	
	public DeiciAttributeConfermaExecuterTest(String name) 
	{
		super(name);		
	}
	public void testDeiciAttributeConfermaExecuter_01()
	{
		setUpMockMethods(DeiciAttributeConfermaProcessor.class, DeiciAttributeConfermaProcessorMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn( "Conferma").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}	
	
	public void testDeiciAttributeConfermaExecuter_02()
	{
		DeiciAttributeConfermaProcessorMock.setResDetailscontainsAsErrorKey();
		setUpMockMethods(DeiciAttributeConfermaProcessor.class, DeiciAttributeConfermaProcessorMock.class);
		expecting( getStateMachineSession().containsKey( "ContrProd" )).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "ContrProd" )).andReturn(  new Hashtable() ).anyTimes();expecting( getStateMachineSession().get( "ESITO_COLLECTION" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting(getRequestEvent().getAttribute("IdSucc")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("21").anyTimes();expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("2104").anyTimes();	
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("2104").anyTimes();	
		expecting(getRequestEvent().getEventName()).andReturn( "Conferma").anyTimes();
		expecting( getStateMachineSession().get( "DeiciAttributesView" )).andReturn(  "abc" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDeiciAttributeConfermaExecuter_03()
	{
		DeiciAttributeConfermaProcessorMock.setResDetailscontainsAsErrorKey();
		setUpMockMethods(DeiciAttributeConfermaProcessor.class, DeiciAttributeConfermaProcessorMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		expecting( getStateMachineSession().containsKey( "ContrProd" )).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().get( "ContrProd" )).andReturn(  new Hashtable() ).anyTimes();expecting( getStateMachineSession().get( "ESITO_COLLECTION" )).andReturn(  new ArrayList()  ).anyTimes();
		expecting(getRequestEvent().getAttribute("IdSucc")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("Anagrafica")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("OggettoId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataVistoFirDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataVistoFirMM")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataVistoFirYY")).andReturn("21").anyTimes();expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataLCDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataLCMM")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("DataLCYY")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("CodiceDipLastCon")).andReturn("2104").anyTimes();	
		expecting(getRequestEvent().getAttribute("CodProdCont")).andReturn("2104").anyTimes();	
		expecting(getRequestEvent().getEventName()).andReturn( "Conferma").anyTimes();
		expecting( getStateMachineSession().get( "DeiciAttributesView" )).andReturn(  "abc" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDeiciAttributeConfermaExecuter_04()
	{
		DeiciAttributeConfermaProcessorMock.setTracciabilitaException();
		setUpMockMethods(DeiciAttributeConfermaProcessor.class, DeiciAttributeConfermaProcessorMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn( "Conferma").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}	
	
	public void testDeiciAttributeConfermaExecuter_05()
	{
		DeiciAttributeConfermaProcessorMock.setRemoteException();
		setUpMockMethods(DeiciAttributeConfermaProcessor.class, DeiciAttributeConfermaProcessorMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn( "Conferma").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}	
	public void testDeiciAttributeConfermaExecuter_06()
	{
		expecting(getRequestEvent().getEventName()).andReturn( "Confermaa").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

}
