package it.sella.tracciabilitaplichi.executer.inserimentobustadieci;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;

import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class InserimentoContrattiHelperMock {
	@Mock
	public Map<Enum<CONSTANTS>, Object> getSessionMap(
			final RequestEvent requestEvent) {
		
		final Map<Enum<CONSTANTS>, Object> map = new HashMap<Enum<CONSTANTS>, Object>();
		
		return map;

	}
}
