package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxCancelliConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.AltriWinboxAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.AltriWinboxAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import mockit.Mockit;

public class WinboxCancelliConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	WinboxCancelliConfermaExecuter winboxCancelliConfermaExecuter = new WinboxCancelliConfermaExecuter();

	public WinboxCancelliConfermaExecuterTest(final String name) {
		super(name);
	}

	public void testWinboxCancelliConfermaExecuter_01() {
		TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminDataAccess.class,TracciabilitaPlichiAdminDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		playAll();
		winboxCancelliConfermaExecuter.execute(getRequestEvent());
	}

	public void testWinboxCancelliConfermaExecuter_02() {
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		TracciabilitaPlichiAdminDataAccessMock.setAltriDocNotInUse();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(AltriWinboxAdminImpl.class,AltriWinboxAdminImplMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminDataAccess.class,TracciabilitaPlichiAdminDataAccessMock.class);
		setUpMockMethods(WinboxAdminHelper.class,WinboxAdminHelperMock.class);
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		playAll();
		winboxCancelliConfermaExecuter.execute(getRequestEvent());
	}

	public void testWinboxCancelliConfermaExecuter_03() {
		TracciabilitaPlichiAdminDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminDataAccess.class,TracciabilitaPlichiAdminDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("22").anyTimes();
		playAll();
		winboxCancelliConfermaExecuter.execute(getRequestEvent());
	}

}
