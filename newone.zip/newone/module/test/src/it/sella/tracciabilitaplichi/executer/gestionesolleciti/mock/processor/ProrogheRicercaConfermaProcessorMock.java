package it.sella.tracciabilitaplichi.executer.gestionesolleciti.mock.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ProrogheRicercaConfermaProcessorMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	@Mock
	public static Map validateInput(RequestEvent requestEvent)
			throws RemoteException, TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		Map map = new HashMap();
		map.put(ITPConstants.MSG, "");
		map.put(ITPConstants.PROROGHE_MAP, null);
		return map;
	}
}
