package it.sella.tracciabilitaplichi.executer.ricezioneplichi;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.RicezionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.util.RicezionePlichiCacheUtil;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;
import it.sella.tracciabilitaplichi.processor.RicezionePlichiProcessor;
import it.sella.tracciabilitaplichi.processor.mock.RicezionePlichiProcessorMock;

public class RicezionePlichiFiltraExecuterTest extends AbstractSellaExecuterMock{

	public RicezionePlichiFiltraExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezionePlichiFiltraExecuter executer=new RicezionePlichiFiltraExecuter();
	public void testRicezionePlichiFiltraExecuterTest_01()
	{
		RicezionePlichiCacheUtilMock.setMapNotNull();
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezionePlichiFiltraExecuterTest_02()
	{
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
		public void testRicezionePlichiFiltraExecuterTest_03()
	{
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("type");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("099256");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("IT");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1234567890123");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezionePlichiFiltraExecuterTest_04()
	{
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("type");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("099256");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("IT");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("12345678910211");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezionePlichiFiltraExecuterTest_05()
	{
		TracciabilitaPlichiPlichiDataAccessMock.setTracciabilitaException();
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("type");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("099256");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("12345678910211");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezionePlichiFiltraExecuterTest_06()
	{
		TracciabilitaPlichiPlichiDataAccessMock.setRemoteException();
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("typet");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("099256");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("12345678910211");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezionePlichiFiltraExecuterTest_07()
	{
		DBPersonaleWrapperMock.setValidCdrFalse();
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("type");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("099256");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("ITOrganization");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("12345678910211");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testRicezionePlichiFiltraExecuterTest_10()
	{
		TracciabilitaPlichiPlichiDataAccessMock.setTracciabilitaExternalServicesException();
		DBPersonaleWrapperMock.setValidCdrFalse();
		RicezionePlichiCacheUtilMock.setMapValues();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("type")).andReturn("type");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("099256");
		expecting(getRequestEvent().getAttribute("deptName")).andReturn("ITOrganization");
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("12345678910211");
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());
	}
}
