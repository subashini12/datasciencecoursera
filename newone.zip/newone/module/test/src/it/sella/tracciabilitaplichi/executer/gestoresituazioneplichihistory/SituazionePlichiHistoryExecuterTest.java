package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichihistory;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;

import java.util.ArrayList;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class SituazionePlichiHistoryExecuterTest extends AbstractSellaExecuterMock{

	public SituazionePlichiHistoryExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SituazionePlichiHistoryExecuter executer=new SituazionePlichiHistoryExecuter();
	
	public void testSituazionePlichiHistoryExecuter_01()
	{
		
		final Hashtable hashtable=getHashtable1();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn(null);
		expecting(getRequestEvent().getEventName()).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiHistoryExecuter_02()
	{
		
		final Hashtable hashtable=getHashtable1();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn(null);
		expecting(getRequestEvent().getEventName()).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryExecuter_03()
	{
		TracciabilitaPlichiStatusDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		final Hashtable hashtable=getHashtable1();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn(null);
		expecting(getRequestEvent().getEventName()).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiHistoryExecuter_04()
	{
		
		final Hashtable hashtable1=getHashtable1();
		final Hashtable hashtable2=getHashtableWithEmptyFiltraCollPlichiView();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable1);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable2);
		expecting(getRequestEvent().getEventName()).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiHistoryExecuter_05()
	{
		
		final Hashtable hashtable1=getHashtable1();
		final Hashtable hashtable2=getHashtableWithNonEmptyFiltraCollPlichiView();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable1);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable2);
		expecting(getRequestEvent().getAttribute("PageNo")).andReturn("1");
		expecting(getRequestEvent().getEventName()).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiHistoryExecuter_06()
	{
		
		final Hashtable hashtable1=getHashtable1();
		final Hashtable hashtable2=getHashtableWithNonEmptyFiltraCollPlichiView();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable1);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("TrDefault");
		expecting(getStateMachineSession().containsKey("PageNo")).andReturn(true);
		expecting(getStateMachineSession().get("PageNo")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());	
	}
	
	
	public void testSituazionePlichiHistoryExecuter_07()
	{
		
		final Hashtable hashtable1=getHashtable1();
		final Hashtable hashtable2=getHashtableWithNonEmptyFiltraCollPlichiView();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable2);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("TrDefault");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable2);
		expecting(getStateMachineSession().containsKey("PageNo")).andReturn(false);
		expecting(getStateMachineSession().get("PageNo")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());	
	}
	
	public void testSituazionePlichiHistoryExecuter_08()
	{
		
		final Hashtable hashtable1=getHashtable1();
		final Hashtable hashtable2=getHashtableWithTypesOfOggettos();
		expecting(getRequestEvent().getEventName()).andReturn("TrPageLink");
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable2);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("TrDefault");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable2);
		expecting(getStateMachineSession().containsKey("PageNo")).andReturn(false);
		expecting(getStateMachineSession().get("PageNo")).andReturn("1");
		playAll();
		executer.execute(getRequestEvent());	
	}
	
	
	public void testSituazionePlichiHistoryExecuter_09()
	{
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		final Hashtable hashtable=getHashtable1();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn(null);
		expecting(getRequestEvent().getEventName()).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testSituazionePlichiHistoryExecuter_10()
	{
		TracciabilitaPlichiStatusDataAccessMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		final Hashtable hashtable=getHashtable1();
		expecting(getRequestEvent().getEventName()).andReturn("TrBack");
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true);
		expecting(getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn(null);
		expecting(getRequestEvent().getEventName()).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Hashtable getHashtable1()
	{
		final Hashtable hashtable=new Hashtable();
		hashtable.put("TypesOfOggettos", "");
		hashtable.put("BankViewList", "");
		hashtable.put("StatusViewList","");
		return hashtable;
	}
	
	private static Hashtable getHashtableWithEmptyFiltraCollPlichiView()
	{
		final ArrayList arrayList=new ArrayList();
		final Hashtable hashtable=new Hashtable();
		hashtable.put("FiltraCollPlichiView", arrayList);
		return hashtable;	
	}
	private static Hashtable getHashtableWithNonEmptyFiltraCollPlichiView()
	{
		final ArrayList arrayList=new ArrayList();
		arrayList.add("1");
		final Hashtable hashtable=new Hashtable();
		hashtable.put("FiltraCollPlichiView", arrayList);
		hashtable.put("FilteredTypesOfOggettos", "");
		hashtable.put("StatusViewList", "");
		return hashtable;	
	}
	
	private static Hashtable getHashtableWithTypesOfOggettos()
	{
		final ArrayList arrayList=new ArrayList();
		arrayList.add("1");
		final Hashtable hashtable=new Hashtable();
		hashtable.put("FiltraCollPlichiView", arrayList);
		hashtable.put("TypesOfOggettos", "");
		hashtable.put("StatusViewList", "");
		return hashtable;	
	}
}
