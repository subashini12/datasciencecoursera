package it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.test;

import it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.StoricoRicercaBustaCinqueRicercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryInterrogazioneDettagliDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryInterrogazioneDettagliDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import org.easymock.classextension.EasyMock;


public class StoricoRicercaBustaCinqueRicercaExecuterTestCase extends AbstractSellaExecuterMock
{
	StoricoRicercaBustaCinqueRicercaExecuter storicoRicercaBustaCinqueRicercaExecuter = new StoricoRicercaBustaCinqueRicercaExecuter();
	public StoricoRicercaBustaCinqueRicercaExecuterTestCase(final String name) {
		super(name);
	}
	
	public void testStoricoRicercaBustaCinqueRicercaExecuter_01()
	{
		final Hashtable views = new Hashtable();
		views.put("CollRicercaList", new ArrayList());
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.FALSE).anyTimes();	
		playAll();
		storicoRicercaBustaCinqueRicercaExecuter.execute(getRequestEvent());
	}
 
	public void testStoricoRicercaBustaCinqueRicercaExecuter_02()
	{
		final Hashtable views = new Hashtable();
		views.put("CollRicercaList", new ArrayList());
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE).anyTimes();		
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(new Hashtable()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		storicoRicercaBustaCinqueRicercaExecuter.execute(getRequestEvent());
	}
	
	public void testStoricoRicercaBustaCinqueRicercaExecuter_03()
	{
		final Collection col = new ArrayList();
		final Hashtable views = new Hashtable();
		final List arrListRicercaView = new ArrayList();
		arrListRicercaView.add("12/12/2009");
		arrListRicercaView.add("2345678");
		arrListRicercaView.add("12345678");
		arrListRicercaView.add("13/12/2009");
		views.put("CollRicercaList",arrListRicercaView);
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( HistoryInterrogazioneDettagliDataAccess.class, HistoryInterrogazioneDettagliDataAccessMock.class );
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE).anyTimes();		
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting(getRequestEvent().getAttribute("SearchType") ).andReturn("Type").anyTimes();
		playAll();
		storicoRicercaBustaCinqueRicercaExecuter.execute(getRequestEvent());
		//assertEquals("TRPL-1017" ,executeResult.getAttribute("MSG") );
	}
	public void testStoricoRicercaBustaCinqueRicercaExecuter_04()
	{
		HistoryInterrogazioneDettagliDataAccessMock.setRicercaViewCollNull();
		final Collection col = new ArrayList();
		final Hashtable views = new Hashtable();
		final List arrListRicercaView = new ArrayList();
		arrListRicercaView.add("12/12/2009");
		arrListRicercaView.add("2345678");
		arrListRicercaView.add("12345678");
		arrListRicercaView.add("13/12/2009");
		views.put("CollRicercaList",arrListRicercaView);
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( HistoryInterrogazioneDettagliDataAccess.class, HistoryInterrogazioneDettagliDataAccessMock.class );
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE).anyTimes();		
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting(getRequestEvent().getAttribute("SearchType") ).andReturn("Type").anyTimes();
		playAll();
		storicoRicercaBustaCinqueRicercaExecuter.execute(getRequestEvent());
		
	}
	
	public void testStoricoRicercaBustaCinqueRicercaExecuter_05()
	{
		HistoryInterrogazioneDettagliDataAccessMock.setRemoteException();
		final Collection col = new ArrayList();
		final Hashtable views = new Hashtable();
		final List arrListRicercaView = new ArrayList();
		arrListRicercaView.add("12/12/2009");
		arrListRicercaView.add("2345678");
		arrListRicercaView.add("12345678");
		arrListRicercaView.add("13/12/2009");
		views.put("CollRicercaList",arrListRicercaView);
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( HistoryInterrogazioneDettagliDataAccess.class, HistoryInterrogazioneDettagliDataAccessMock.class );
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE).anyTimes();		
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting(getRequestEvent().getAttribute("SearchType") ).andReturn("Type").anyTimes();
		playAll();
		storicoRicercaBustaCinqueRicercaExecuter.execute(getRequestEvent());
		//assertEquals("TRPL-1017" ,executeResult.getAttribute("MSG") );
	}
}
