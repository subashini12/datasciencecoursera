/*package it.sella.tracciabilitaplichi.executer.test.gestionesolleciti;

import it.sella.tracciabilitaplichi.executer.gestionesolleciti.ISDefaultTestoMailExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import org.easymock.EasyMock;

public class ISDefaultTestoMailExecuterTest   extends AbstractSellaExecuterTest {

	public ISDefaultTestoMailExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	 final ISDefaultTestoMailExecuter executer =  new ISDefaultTestoMailExecuter(); 
	 
	 public void testISDefaultTestoMailExecuter_01()
	 {
		 
		 setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 expecting( getStateMachineSession().containsKey( "GESTIONE_SOLLECITI_TESTO_MAP" ) ).andReturn( Boolean.FALSE ).anyTimes();
		 expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		 playAll();
		 executer.execute(getRequestEvent()); 
	 }
	 
	 public void testISDefaultTestoMailExecuter_02()
	 {
		 SecurityWrapperMock.setTracciabilitaException(); 
		 setUpMockMethods( GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class );
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 expecting( getStateMachineSession().containsKey( "GESTIONE_SOLLECITI_TESTO_MAP" ) ).andReturn( Boolean.FALSE ).anyTimes();
		 expecting( getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		 playAll();
		 executer.execute(getRequestEvent()); 
	 }
	
}
*/