/*package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.tracciabilitaplichi.implementation.admin.LIDBookKeepingAdminImpl;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.test.dao.AbstractSellaDBTest;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import it.sella.tracciabilitaplichi.log.LogEvent;
import mockit.Mockit;

import org.junit.Test;

*//**
 *
 * @author GBS02360
 *//*
public class LIDBookKeepingAdminImplTest extends AbstractSellaDBTest {

	public LIDBookKeepingAdminImplTest(final String name) {
		super(name);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp(Boolean.TRUE);
		Mockit.redefineMethods(LogEvent.class, new Object() {
			public void log(final String operationCode,
					final boolean operationResult, final String operationXml) {

			}
		});
		Mockit.redefineMethods(SecurityWrapper.class, new Object() {
			public Long getBankId() throws TracciabilitaException {
				return 1L;
			}
		});
		Mockit.redefineMethods(MsgManagerWrapper.class, new Object() {
			public String getErrorMessage(final String errCode)
					throws TracciabilitaException {
				return "MSA-01";
			}
		});
	}
    *//**
     * Test of censitoOggetto method, of class LIDBookKeepingAdminImpl.
     *//*
    @Test
    public void testCensitoOggetto() {
        TPView adminView = new LIDBookKeepingView();
        LIDBookKeepingAdminImpl instance = new LIDBookKeepingAdminImpl();
        try {
        	final LIDBookKeepingView lidBookKeepingView = ( LIDBookKeepingView ) adminView;
        	lidBookKeepingView.setBankId(1L);
        	lidBookKeepingView.setDate(new Date("12/12/2010"));
        	lidBookKeepingView.setLid("23456");
        	lidBookKeepingView.setOperation("1234");
        	lidBookKeepingView.setStampe("123321111");
			instance.censitoOggetto(adminView);
		} catch (TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    *//**
     * Test of cancelliOggetto method, of class LIDBookKeepingAdminImpl.
     *//*
    @Test
    public void testCancelliOggetto() {
        System.out.println("cancelliOggetto");
        final TPView adminView = null;
        final LIDBookKeepingAdminImpl instance = new LIDBookKeepingAdminImpl();
        try {
			instance.cancelliOggetto(adminView);
		} catch (final TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    *//**
     * Test of modificaOggetto method, of class LIDBookKeepingAdminImpl.
     *//*
    @Test
    public void testModificaOggetto() {
        System.out.println("modificaOggetto");
        final TPView adminView = null;
        final LIDBookKeepingAdminImpl instance = new LIDBookKeepingAdminImpl();
        try {
			instance.modificaOggetto(adminView);
		} catch (final TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}*/