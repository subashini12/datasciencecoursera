/*package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.DefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor.HomePageProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciContrattiView;
import it.sella.tracciabilitaplichi.interfaces.dao.IBustaDieciDataAccess;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import org.easymock.EasyMock;

public class DefaultExecuterTest extends AbstractSellaExecuterTest
{
	
	public DefaultExecuterTest( final String name )
	{
		super( name );
	}
	DefaultExecuter defaultExecuter = new DefaultExecuter() ;
	
	public void testDefaultExecuterTest_01()
	{
		setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		final BustaDeiciContrattiView bustaDeiciContrattiView = new BustaDeiciContrattiView() ;
		final Collection<BustaDeiciContrattiView> bustaDeiciAttributeViewColl = new ArrayList<BustaDeiciContrattiView>();
		bustaDeiciAttributeViewColl.add(bustaDeiciContrattiView);
		final IBustaDieciDataAccess bustaDieciDataAccess =EasyMock.createMock(IBustaDieciDataAccess.class);
		try {
			EasyMock.expect(bustaDieciDataAccess.getBustaDieciContrattiViewColl("", 1L)).andReturn(bustaDeiciAttributeViewColl);
			EasyMock.replay(bustaDieciDataAccess);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		defaultExecuter.execute(getRequestEvent());
	}
	
	}
*/