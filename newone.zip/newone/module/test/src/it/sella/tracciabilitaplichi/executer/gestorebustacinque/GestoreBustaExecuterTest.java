/*package it.sella.tracciabilitaplichi.executer.gestorebustacinque;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.CommonPropertiesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.log.LogEvent;
import it.sella.util.CommonPropertiesFactory;

public class GestoreBustaExecuterTest extends AbstractSellaExecuterTest{

	public GestoreBustaExecuterTest(final String name) {
		super(name);
	}

	GestoreBustaExecuter executer=new GestoreBustaExecuter();

	public void testGestoreBustaExecuter_01() {
		TracciabilitaPlichiImplMock.setStatus();
		TracciabilitaPlichiCommonDataAccessMock.setCdrForLidAsNull();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(CommonPropertiesFactory.class,CommonPropertiesFactoryMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class);
		expecting(getRequestEvent().getAttribute("selDate")).andReturn("");
		expecting(getStateMachineSession().get("DateCollection")).andReturn(null);
		expecting(getRequestEvent().getAttribute("barcode")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}

	public void testGestoreBustaExecuter_02() {
		TracciabilitaPlichiImplMock.setStatus();
		SecurityWrapperMock.setLidNull();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(CommonPropertiesFactory.class,CommonPropertiesFactoryMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("selDate")).andReturn("");
		expecting(getStateMachineSession().get("DateCollection")).andReturn(null);
		expecting(getRequestEvent().getAttribute("barcode")).andReturn("");
		playAll();
		final ExecuteResult executeResult =executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}

}

 */