package it.sella.tracciabilitaplichi.executer.gestorecompatiblebanksadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;

public class CompatibleBanksInserciVerificaExecuterTest extends AbstractSellaExecuterMock {

	public CompatibleBanksInserciVerificaExecuterTest(final String name) {
		super(name);
	}
	
	CompatibleBanksInserciVerificaExecuter executer = new CompatibleBanksInserciVerificaExecuter();
	
	public void testExecuter_01() {
	    setUpMockMethods( TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class );
	    setUpMockMethods(Util.class, UtilMock.class);
	    setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getRequestEvent().getAttribute("bankId") ).andReturn("21").anyTimes();
		expecting( getRequestEvent().getAttribute("otherBankId") ).andReturn("21").anyTimes();
		playAll();
		final ExecuteResult executeResult =  executer.execute( getRequestEvent() );
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testExecuter_02() {
	    setUpMockMethods( TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class );
	    setUpMockMethods(Util.class, UtilMock.class);
	    setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getRequestEvent().getAttribute("bankId") ).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute("otherBankId") ).andReturn("21").anyTimes();
		playAll();
		final ExecuteResult executeResult =  executer.execute( getRequestEvent() );
		assertEquals("TrError",executeResult.getTransition());
	}

	public void testExecuter_03() {
	    setUpMockMethods( TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class );
	    setUpMockMethods(Util.class, UtilMock.class);
	    setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getRequestEvent().getAttribute("bankId") ).andReturn("21").anyTimes();
		expecting( getRequestEvent().getAttribute("otherBankId") ).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult =  executer.execute( getRequestEvent() );
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testExecuter_04() {
		TracciabilitaPlichiBustasDataAccessMock.setTracciabilitaException();
		setUpMockMethods( TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class );
	    setUpMockMethods(Util.class, UtilMock.class);
	    setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getRequestEvent().getAttribute("bankId") ).andReturn("21").anyTimes();
		expecting( getRequestEvent().getAttribute("otherBankId") ).andReturn("21").anyTimes();
		playAll();
		final ExecuteResult executeResult =  executer.execute( getRequestEvent() );
		assertTrue(true);
	}
	
}
