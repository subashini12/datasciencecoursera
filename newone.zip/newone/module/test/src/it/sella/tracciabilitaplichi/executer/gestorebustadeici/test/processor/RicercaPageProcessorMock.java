package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class RicercaPageProcessorMock {

	private static Boolean isNotNullMap = false;
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setNotNullMap() {
		isNotNullMap = true;
	}

	@Mock
	public Map<Long, String> getResponsibleIdSuccAndCdrMap(final String userId)
			throws RemoteException, TracciabilitaException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		if (remoteException) {
			throw new RemoteException();
		}

		Map<Long, String> map = null;
		if (isNotNullMap) {
			map = new HashMap<Long, String>();
			map.put(1L, "");
		}
		return map;
	}

}
