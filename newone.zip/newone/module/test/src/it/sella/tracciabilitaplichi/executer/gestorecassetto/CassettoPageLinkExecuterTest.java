package it.sella.tracciabilitaplichi.executer.gestorecassetto;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;


public class CassettoPageLinkExecuterTest extends AbstractSellaExecuterMock{

	public CassettoPageLinkExecuterTest(final String name) {
		super(name);
	}

	CassettoModificaExecuter cassettoModificaExecuter = new CassettoModificaExecuter() ;
	
	public void testCassettoModificaExecuter_01() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = cassettoModificaExecuter.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_02() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("12323").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = cassettoModificaExecuter.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_03() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("12323").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("2").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult executeResult = cassettoModificaExecuter.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_04() {
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		final Collection<LinkedCasettoView> linkedCasettoViewcollection =new ArrayList<LinkedCasettoView>() ;
		final LinkedCasettoView linkedCasettoView = new LinkedCasettoView() ;
		linkedCasettoView.setCasetto("");
		linkedCasettoView.setDescription("");
		linkedCasettoView.setBankId(1L);
		linkedCasettoView.setPrincipaleId(2L);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("12323").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("2361").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("2361").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) linkedCasettoViewcollection).anyTimes();
		playAll();
		final ExecuteResult executeResult = cassettoModificaExecuter.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_05() {	
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
		final Collection<LinkedCasettoView> linkedCasettoViewcollection =new ArrayList<LinkedCasettoView>() ;
		final LinkedCasettoView linkedCasettoView = new LinkedCasettoView() ;
		linkedCasettoView.setCasetto("");
		linkedCasettoView.setDescription("");
		linkedCasettoView.setBankId(1L);
		linkedCasettoView.setPrincipaleId(2L);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("12323").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("2361").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("2361").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) linkedCasettoViewcollection).anyTimes();
		playAll();
		final ExecuteResult executeResult = cassettoModificaExecuter.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
}
