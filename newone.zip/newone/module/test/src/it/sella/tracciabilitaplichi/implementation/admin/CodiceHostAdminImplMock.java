package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import mockit.Mock;

public class CodiceHostAdminImplMock {
	@Mock
	public void cancelliOggetto(final TPView codiceHostAdminView)
			throws TracciabilitaException {
		return;
	}
}
