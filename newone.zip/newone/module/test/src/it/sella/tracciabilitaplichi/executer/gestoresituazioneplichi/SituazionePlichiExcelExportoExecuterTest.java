package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichi;

import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoresituazioneplichi.SituazionePlichiExcelExportoExecuter;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.classextension.EasyMock;



public class SituazionePlichiExcelExportoExecuterTest extends AbstractSellaExecuterMock{

	public SituazionePlichiExcelExportoExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	SituazionePlichiExcelExportoExecuter executer=new SituazionePlichiExcelExportoExecuter();
	
	public void testSituazionePlichiExcelExportoExecuter_01()
	{
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		Hashtable hashtable=getHashTable();
		Map<Long, String> map=getMap();
		expecting(getStateMachineSession().get(ITPConstants.GESTORE_SITUAZIONE_PLICHI_SESSION )).andReturn(hashtable);
		expecting(getStateMachineSession().get(CONSTANTS.FOLDER_TYPES_MAP.toString( ) )).andReturn((Serializable) map);
		expecting(getStateMachineSession().containsKey(CONSTANTS.IS_BN_WITH_CDR_DEST_SEARCH.toString( ))).andReturn(true);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testSituazionePlichiExcelExportoExecuter_02()
	{
		Hashtable hashtable=new Hashtable();
		expecting(getStateMachineSession().get(ITPConstants.GESTORE_SITUAZIONE_PLICHI_SESSION )).andReturn(hashtable);
		expecting(hashtable.get( "FiltraCollPlichiView" )).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Hashtable getHashTable()
	{
		Hashtable hashtable=new Hashtable();
		LazyFetchCollection lazyFetchCollection=EasyMock.createMock(LazyFetchCollection.class);
		EasyMock.replay(lazyFetchCollection);
		hashtable.put("FiltraCollPlichiView",lazyFetchCollection);
		return hashtable;
	}
	private static Map getMap()
	{
		Map<Long, String> map=new HashMap<Long, String>();
		return map;
	}

}
