package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.DeleteGrantsExecuter;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin.WinboxAdminHelperMock;

public class DeleteGrantsExecuterTest extends AbstractSellaExecuterMock 
{
	
	final DeleteGrantsExecuter deleteGrantsExecuter = new DeleteGrantsExecuter();
	
	public DeleteGrantsExecuterTest(String name) 
	{
		super(name);
	}
	
	public void testDeleteGrantsExecuter()
	{
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		expecting( getRequestEvent().getAttribute(CONSTANTS.GRANTS_INDEX.getValue( ))).andReturn("0").anyTimes();
		playAll();
		deleteGrantsExecuter.execute(getRequestEvent());		
	}

}
