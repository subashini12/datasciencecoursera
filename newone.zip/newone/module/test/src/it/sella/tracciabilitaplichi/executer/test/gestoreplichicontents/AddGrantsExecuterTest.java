package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents;


import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.AddGrantsExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsValidator;
import it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione.GrantsValidatorMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.log.LogEvent;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import mockit.Mockit;

public class AddGrantsExecuterTest extends AbstractSellaExecuterMock 
{
	final AddGrantsExecuter executer = new AddGrantsExecuter();

	public AddGrantsExecuterTest(final String name) 
	{
		super(name);
	}
	public void testAddGrantsExecuter_forElse()
	{
	setUpMockMethods( GrantsValidator.class , GrantsValidatorMock.class);
	Mockit.setUpMock(LogEvent.class,LogEventMock.class );
	expecting( getRequestEvent().getAttribute( CONSTANTS.CDR.getValue( ))).andReturn("0").anyTimes();
	final Map map = getPlichiContentsHashTable1() ;
	expecting( getStateMachineSession().get( ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn((Serializable)map).anyTimes();
	playAll();
	executer.execute(getRequestEvent());
	}
	
	public void testAddGrantsExecuter_forIf()
	{
	setUpMockMethods( GrantsValidator.class , GrantsValidatorMock.class);
	Mockit.setUpMock(LogEvent.class,LogEventMock.class );
	expecting( getRequestEvent().getAttribute( CONSTANTS.CDR.getValue( ))).andReturn("0").anyTimes();
	final Map map = getPlichiContentsHashTable2() ;
	final Map winbox2PreView = (Map) map.get(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ));
	winbox2PreView.put(CONSTANTS.ERROR_MESSAGE.toString( ) ,"ErrorMessage");
	expecting( getStateMachineSession().get( ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn((Serializable)map).anyTimes();
	playAll();
	executer.execute(getRequestEvent());
	}
	
	public void testAddGrantsExecuter_forTracciabiltaException()
	{
    GrantsValidatorMock.setTracciabilitaException();
	setUpMockMethods( GrantsValidator.class , GrantsValidatorMock.class);
	expecting( getRequestEvent().getAttribute( CONSTANTS.CDR.getValue( ))).andReturn("0").anyTimes();
	final Map map = getPlichiContentsHashTable2() ;
	final Map winbox2PreView = (Map) map.get(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ));
	winbox2PreView.put(CONSTANTS.ERROR_MESSAGE.toString( ) ,"ErrorMessage");
	expecting( getStateMachineSession().get( ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn((Serializable)map).anyTimes();
	playAll();
	executer.execute(getRequestEvent());
	}
	
	public void testAddGrantsExecuter_forRemoteException()
	{
    GrantsValidatorMock.setRemoteException();
	setUpMockMethods( GrantsValidator.class , GrantsValidatorMock.class);
	expecting( getRequestEvent().getAttribute( CONSTANTS.CDR.getValue( ))).andReturn("0").anyTimes();
	final Map map = getPlichiContentsHashTable2() ;
	final Map winbox2PreView = (Map) map.get(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ));
	winbox2PreView.put(CONSTANTS.ERROR_MESSAGE.toString( ) ,"ErrorMessage");
	expecting( getStateMachineSession().get( ITPConstants.PLICHI_CONTENTS_HASH_TABLE )).andReturn((Serializable)map).anyTimes();
	playAll();
	executer.execute(getRequestEvent());
	}
		
	private Map getPlichiContentsHashTable1()
	{
		final Map plichiContentsHashTable = new Hashtable();
		plichiContentsHashTable.put(ITPConstants.TRACCIABILITA_PLICHI_VIEW , getTracciabilitaPlichiView() );
		plichiContentsHashTable.put( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ), getWinbox2PreparazioneMap() );		
		return plichiContentsHashTable;		
	}
	
	private Map getPlichiContentsHashTable2()
	{
		final Map plichiContentsHashTable = new Hashtable();
		plichiContentsHashTable.put(ITPConstants.TRACCIABILITA_PLICHI_VIEW , getTracciabilitaPlichiView() );
		plichiContentsHashTable.put( CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ), getWinbox2PreparazioneMapwithErrMsg() );		
		return plichiContentsHashTable;		
	}
	
	
	private Map getWinbox2PreparazioneMapwithErrMsg()
	{
		final Map map = new HashMap();
		map.put(1,"abcd");
		map.put(CONSTANTS.GRANTS_COLLECTION, getGrantsCollection());
		map.put(CONSTANTS.ERROR_MESSAGE ,"ErrorMessage");
		return map;
	}
	private Map getWinbox2PreparazioneMap()
	{
		final Map map = new HashMap();
		map.put(1,"abcd");
		map.put(CONSTANTS.GRANTS_COLLECTION, getGrantsCollection());
		return map;
	}
	
	private Collection getGrantsCollection()
	{
		final Grants grant1 = new Grants();
		grant1.setDescription("description");
		grant1.setId(Long.valueOf("1000"));
		final Grants grant2 = new Grants();
		grant2.setDescription("desc");
		grant2.setId(Long.valueOf("2000"));
		final Collection collection = new ArrayList();
		collection.add( grant1 );
		collection.add( grant2 );
		return collection;
	}
	private TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final FolderAttributes folderAttributes = new FolderAttributes();
		folderAttributes.setBarcode("pqrs");
		final TracciabilitaPlichiView view = new TracciabilitaPlichiView();
		view.setCasettoDescription("casettoDescription");
		view.setFolderAttributes(folderAttributes);
	    return view;
	}
}
