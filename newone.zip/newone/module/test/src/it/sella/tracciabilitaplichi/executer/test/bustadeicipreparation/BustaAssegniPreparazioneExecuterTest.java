package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.bustaassegni.preparazione.BustaAssegniPreparazioneExecuter;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.test.view.BustaAssegniPreparazioneViewMock;
import it.sella.tracciabilitaplichi.implementation.view.BustaAssegniPreparazioneView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class BustaAssegniPreparazioneExecuterTest extends AbstractSellaExecuterMock {
	
	BustaAssegniPreparazioneExecuter bustaAssegniDefaultExecuterTest =  new  BustaAssegniPreparazioneExecuter();
	
	public BustaAssegniPreparazioneExecuterTest(final String name) 
	{
		super(name);
	}
	 
	/* public void testBustaAssegniDefaultExecuter_forErrorMsgNotNull()
	 {
		 Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		 BustaAssegniPreparazioneViewMock.setNullString();
		 setUpMockMethods(TracciabilitaPlichiManagerBeanHelper.class, TracciabilitaPlichiManagerBeanHelperMock.class);
		 setUpMockMethods(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		 setUpMockMethods(BustaAssegniPreparazioneView.class, BustaAssegniPreparazioneViewMock.class);
		 setUpMockMethods(Util.class, UtilMock.class);
		 setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 expecting( getRequestEvent().getAttribute(ITPConstants.BARCODE)).andReturn("1044100013378").anyTimes();
		 expecting( getStateMachineSession().get( ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP )).andReturn( (Serializable)getPreparazioneMap()).anyTimes();
		 setUpMockMethods(BustaAssegniPreparazioneView.class, BustaAssegniPreparazioneViewMock.class );
		 setUpMockMethods(LogEvent.class,LogEventMock.class );
		 setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class );
		 playAll();
		 bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
	 }
	 */
	 public void testBustaAssegniDefaultExecuter_forRemoteException()
	 {
		 BustaAssegniPreparazioneViewMock.setRemoteException();
		 setUpMockMethods(LogEvent.class,LogEventMock.class );
		 expecting( getRequestEvent().getAttribute(ITPConstants.BARCODE)).andReturn("1044100013378").anyTimes();
		 expecting( getStateMachineSession().get( ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP )).andReturn( (Serializable)getPreparazioneMap()).anyTimes();
		 setUpMockMethods(BustaAssegniPreparazioneView.class, BustaAssegniPreparazioneViewMock.class );
		 setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class );
		 playAll();
		 bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
	 }
	 
	 public void testBustaAssegniDefaultExecuter_forTracciabilitaException()
	 {
		 BustaAssegniPreparazioneViewMock.setTracciabilitaException();
		 setUpMockMethods(LogEvent.class,LogEventMock.class );
		 expecting( getRequestEvent().getAttribute(ITPConstants.BARCODE)).andReturn("1044100013378").anyTimes();
		 expecting( getStateMachineSession().get( ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP )).andReturn( (Serializable)getPreparazioneMap()).anyTimes();
		 setUpMockMethods(BustaAssegniPreparazioneView.class, BustaAssegniPreparazioneViewMock.class );
		 setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class );
		 playAll();
		 bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
	 }
	 

	 public Map getPreparazioneMap()
	 {
		 final Map map = new HashMap();
		 map.put("abc", "abc");
		 return map;
		 
	 }
	 
}
