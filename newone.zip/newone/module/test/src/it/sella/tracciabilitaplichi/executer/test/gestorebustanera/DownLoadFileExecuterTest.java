/*package it.sella.tracciabilitaplichi.executer.test.gestorebustanera;

import it.sella.statemachine.StateMachineException;
import it.sella.tracciabilitaplichi.FileOperation;
import it.sella.tracciabilitaplichi.FileOperationMock;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.DownLoadFileExecuter;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.processor.FileReaderHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.gestorebustanera.processor.FileReaderHelperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.CommonPropertiesWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.CommonPropertiesWrapper;

public class DownLoadFileExecuterTest extends AbstractSellaExecuterTest
{
    final DownLoadFileExecuter executer = new DownLoadFileExecuter();   

	public DownLoadFileExecuterTest(String name) 
	{
		super(name);
	}
	
    public void testDownLoadFileExecuter_ifFileNotExists() throws StateMachineException
    {
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	setUpMockMethods(CommonPropertiesWrapper.class, CommonPropertiesWrapperMock.class);
    	setUpMockMethods(FileReaderHelper.class, FileReaderHelperMock.class);
    	setUpMockMethods(FileOperation.class, FileOperationMock.class);    	
    	executer.execute(getRequestEvent());
    }
    
    public void testDownLoadFileExecuter_ifFileExists() throws StateMachineException
    {
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	setUpMockMethods(CommonPropertiesWrapper.class, CommonPropertiesWrapperMock.class);
    	setUpMockMethods(FileReaderHelper.class, FileReaderHelperMock.class);
    	setUpMockMethods(FileOperation.class, FileOperationMock.class);
    	FileReaderHelperMock.setFileOccurence();
    	executer.execute(getRequestEvent());
	}
    
    public void testDownLoadFileExecuter_forTracciabilitaException() throws StateMachineException
    {
    	setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
    	setUpMockMethods(CommonPropertiesWrapper.class, CommonPropertiesWrapperMock.class);
    	setUpMockMethods(FileReaderHelper.class, FileReaderHelperMock.class);
    	setUpMockMethods(FileOperation.class, FileOperationMock.class);
    	FileReaderHelperMock.setTracciabilitaException();
    	FileReaderHelperMock.setFileOccurence();
    	executer.execute(getRequestEvent());			
	}
	
}


*/