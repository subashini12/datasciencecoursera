package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ImageStorageSystemWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.StampeWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.dao.ImageStorageSystemDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ImageStorageSystemDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ImageStorageSystemWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.StampeWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.BustaDeiciAttributeViewMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.HelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TransactionHistoryDeciderMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.util.Helper;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.TransactionHistoryDecider;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Stack;

import org.easymock.EasyMock;

public class PlichiContentsDefaultB10ProcessorTest extends AbstractSellaExecuterMock{

	public PlichiContentsDefaultB10ProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiContentsDefaultB10Processor processor = new PlichiContentsDefaultB10Processor();

	public void testGetUserDetail_01() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		processor.getUserDetail();
	}

	public void testSetRicezioneData_01() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Stack stack=new Stack();
		stack.push("1");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("123456789123456");
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("123456789123456");
		expecting(getRequestEvent().getAttribute("drgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("drmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("draa")).andReturn("");
		playAll();
		processor.setRicezioneData(getRequestEvent(),getStateMachineSession());
	}

	public void testSetRicezioneData_02() throws RemoteException, TracciabilitaException
	{
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Stack stack=new Stack();
		stack.push("1");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn(null);
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn(null);
		expecting(getRequestEvent().getAttribute("drgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("drmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("draa")).andReturn("");
		playAll();
		processor.setRicezioneData(getRequestEvent(),getStateMachineSession());
	}

	/*@Test(expected = TracciabilitaException.class)
	public void testSetRicezioneData_03() throws RemoteException, TracciabilitaException
	{
		TracciabilitaPlichiImplMock.setPbusta10();
		TracciabilitaPlichiCommonDataAccessMock.setExistPlichi();
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Stack stack=new Stack();
		stack.push("1");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("123456789123456");
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("123456789123456");
		expecting(getRequestEvent().getAttribute("drgg")).andReturn("12");
		expecting(getRequestEvent().getAttribute("drgg")).andReturn("12");
		expecting(getRequestEvent().getAttribute("drmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("drmm")).andReturn("12");
		expecting(getRequestEvent().getAttribute("draa")).andReturn("12");
		expecting(getRequestEvent().getAttribute("draa")).andReturn("12");
		playAll();
		processor.setRicezioneData(getRequestEvent(),getStateMachineSession());
	}*/

	public void testSetRicezioneData_04() throws RemoteException, TracciabilitaException
	{
		GestoreBustaDeiciDataAccessMock.setisPB10InRequiredStatus();
		TracciabilitaPlichiCommonDataAccessMock.setExistPlichi();
		BarcodeValidatorMock.setInvalidBarcode();
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Stack stack=new Stack();
		stack.push("1");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("123456789123456");
		expecting(getRequestEvent().getAttribute("Barcode")).andReturn("123456789123456");
		expecting(getRequestEvent().getAttribute("drgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("drmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("draa")).andReturn("");
		playAll();
		processor.setRicezioneData(getRequestEvent(),getStateMachineSession());
	}

	public void testAddControlloData_01() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Stack stack=new Stack();
		stack.push("1");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("Plichiusrgc")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("");
		expecting(getRequestEvent().getAttribute("esito")).andReturn("1");
		expecting(getRequestEvent().getAttribute("esito")).andReturn("1");
		playAll();
		processor.addControlloData(getRequestEvent(),getStateMachineSession());
	}

	/*public void testAddControlloData_02() throws RemoteException, TracciabilitaException
	{
		TracciabilitaPlichiImplMock.setPbusta10();
		TPUtilMock.setValidateDate(1);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class, TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		final Stack stack=new Stack();
		stack.push("1");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("Plichiusrgc")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("");
		expecting(getRequestEvent().getAttribute("esito")).andReturn("1");
		expecting(getRequestEvent().getAttribute("esito")).andReturn("1");
		playAll();
		processor.addControlloData(getRequestEvent(),getStateMachineSession());
	}*/


	public void testprocessB10Records_01() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(ImageStorageSystemDataAccess.class, ImageStorageSystemDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(StampeWrapper.class, StampeWrapperMock.class);
		setUpMockMethods(BustaDeiciAttributeView.class, BustaDeiciAttributeViewMock.class);
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("BustaDeici");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		processor.processB10Records(getRequestEvent(), "");
	}


	public void testprocessB10Records_02() throws RemoteException, TracciabilitaException
	{
		setUpMockMethods(ImageStorageSystemDataAccess.class, ImageStorageSystemDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(StampeWrapper.class, StampeWrapperMock.class);
		setUpMockMethods(BustaDeiciAttributeView.class, BustaDeiciAttributeViewMock.class);
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("B10History");
		playAll();
		processor.processB10Records(getRequestEvent(), "");
	}

	public void testprocessB10Records_03() throws RemoteException, TracciabilitaException
	{
		BustaDeiciAttributeViewMock.setIsValidBarcode();
		setUpMockMethods(ImageStorageSystemDataAccess.class, ImageStorageSystemDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(StampeWrapper.class, StampeWrapperMock.class);
		setUpMockMethods(BustaDeiciAttributeView.class, BustaDeiciAttributeViewMock.class);
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("BustaDeici");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		processor.processB10Records(getRequestEvent(), "");
	}

}
