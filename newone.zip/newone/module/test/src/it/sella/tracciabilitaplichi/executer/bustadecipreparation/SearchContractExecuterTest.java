package it.sella.tracciabilitaplichi.executer.bustadecipreparation;


import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.SearchContractExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;

import org.easymock.EasyMock;

public class SearchContractExecuterTest extends AbstractSellaExecuterMock{

	public SearchContractExecuterTest(final String name) {
		super(name);
	}
	
	SearchContractExecuter executer=new SearchContractExecuter();
	
	public void testSearchContractExecuter_01() {
		final Busta10PreparationPageView busta10PreparationPageView=new Busta10PreparationPageView();
		busta10PreparationPageView.setArgument("argument");
		expecting(getStateMachineSession().containsKey(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn(true);
		expecting(getStateMachineSession().remove(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn("cdr");
		expecting(getStateMachineSession().containsKey(CONSTANTS.ERROR_MESSAGE.toString( ) )).andReturn(true);
		expecting(getStateMachineSession().remove(CONSTANTS.ERROR_MESSAGE.toString( ))).andReturn("");
		expecting(getStateMachineSession().get(CONSTANTS.B10_PREPARATION_PAGE_VIEW.getValue())).andReturn(busta10PreparationPageView);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	public void testSearchContractExecuter_02() {
		expecting(getStateMachineSession().containsKey(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn(false);
		expecting(getRequestEvent().getAttribute(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	public void testSearchContractExecuter_04() {
		expecting(getStateMachineSession().containsKey(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn(false);
		expecting(getRequestEvent().getAttribute(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn("66577");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma", executeResult.getTransition());
	}
	
	public void testSearchContractExecuter_03() {
		final Busta10PreparationPageView busta10PreparationPageView=new Busta10PreparationPageView();
		busta10PreparationPageView.setArgument("CDR");
		expecting(getStateMachineSession().containsKey(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn(true);
		expecting(getStateMachineSession().remove(CONSTANTS.SEARCH_FILTER.toString( ))).andReturn("CDR");
		expecting(getStateMachineSession().containsKey(CONSTANTS.ERROR_MESSAGE.toString( ) )).andReturn(true);
		expecting(getStateMachineSession().remove(CONSTANTS.ERROR_MESSAGE.toString( ))).andReturn("");
		expecting(getStateMachineSession().get(CONSTANTS.B10_PREPARATION_PAGE_VIEW.getValue())).andReturn(busta10PreparationPageView);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma", executeResult.getTransition());
	}

}
