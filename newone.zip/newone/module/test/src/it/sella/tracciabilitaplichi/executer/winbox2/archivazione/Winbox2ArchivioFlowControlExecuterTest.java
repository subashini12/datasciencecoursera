package it.sella.tracciabilitaplichi.executer.winbox2.archivazione;


import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione.HelperMock;
import it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione.Winbox2InputProcessorMock;
import it.sella.tracciabilitaplichi.winbox2.archivazione.Winbox2InputProcessor;

import java.util.Map;

import org.easymock.EasyMock;

public class Winbox2ArchivioFlowControlExecuterTest extends AbstractSellaExecuterMock{

	public Winbox2ArchivioFlowControlExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	Winbox2ArchivioFlowControlExecuter executer=new Winbox2ArchivioFlowControlExecuter();

	public void testWinbox2ArchivioFlowControlExecuter_01()
	{
		HelperMock.setMapWithWINBOX2INPUTPROCESSOR();
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(Winbox2InputProcessor.class, Winbox2InputProcessorMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testWinbox2ArchivioFlowControlExecuter_02()
	{
		HelperMock.setMapWithTrWBX2PartialConferma();
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(Winbox2InputProcessor.class, Winbox2InputProcessorMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testWinbox2ArchivioFlowControlExecuter_03()
	{
		HelperMock.setMapWithOutWINBOX2INPUTPROCESSOR();
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(Winbox2InputProcessor.class, Winbox2InputProcessorMock.class);
		playAll();
		executer.execute(getRequestEvent());
	}
}
