package it.sella.tracciabilitaplichi.executer.gestorehistoryadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.util.Hashtable;



public class HistoryConfermaExecuterTest extends AbstractSellaExecuterMock{

	public HistoryConfermaExecuterTest(final String name) {
		super(name);
	}

	HistoryConfermaExecuter executer=new HistoryConfermaExecuter();

	public void testHistoryConfermaExecuter_01() {
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("A");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("02154");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testHistoryConfermaExecuter_02() {
		TracciabilitaPlichiStatusDataAccessMock.setValidStatusId();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("A");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("User")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testHistoryConfermaExecuter_03() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("2");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("123.23.23.23");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testHistoryConfermaExecuter_04() {
		SecurityWrapperMock.setValidCdrFalse();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testHistoryConfermaExecuter_05() {
		DBPersonaleWrapperMock.setValidCdrFalse();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testHistoryConfermaExecuter_06() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("AS");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testHistoryConfermaExecuter_07() {
		UtilMock.setValidIPTrue();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("1988");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testHistoryConfermaExecuter_08() {
		UtilMock.setValidIPTrue();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("1988");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("3");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testHistoryConfermaExecuter_09() {
		DBPersonaleWrapperMock.setTracciabilitaException();
		UtilMock.setValidIPTrue();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("1988");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("3");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testHistoryConfermaExecuter_10() {
		DBPersonaleWrapperMock.setRemoteException();
		UtilMock.setValidIPTrue();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("1988");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("3");
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testHistoryConfermaExecuter_11() {
		TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		UtilMock.setValidIPTrue();
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		final Hashtable hashtable=getHashtable();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().get("HistoryTable")).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1");
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("StatusId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("dateDD")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateMM")).andReturn("12");
		expecting(getRequestEvent().getAttribute("dateYYYY")).andReturn("1988");
		expecting(getRequestEvent().getAttribute("User")).andReturn("A");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("13564");
		expecting(getRequestEvent().getAttribute("IpAddress")).andReturn("");
		expecting(getRequestEvent().getAttribute("RefId")).andReturn("3");
		playAll();
		final ExecuteResult executeResult =  executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	private static Hashtable getHashtable() {
		final Hashtable hashtable=new Hashtable();
		return hashtable;
	}

}
