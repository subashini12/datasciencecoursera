package it.sella.tracciabilitaplichi.executer.test.gestorebustaneraerrcodeadmin;

import it.sella.tracciabilitaplichi.executer.gestorebustaneraerrcodeadmin.BustaNeraErrCodeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;

import java.io.Serializable;
import java.util.Collection;
import java.util.Vector;

import org.easymock.EasyMock;

public class BustaNeraErrCodeConfermaExecuterTest extends AbstractSellaExecuterMock
{
    public BustaNeraErrCodeConfermaExecuterTest(String name) 
	{
		super(name);	
	}
    
    BustaNeraErrCodeConfermaExecuter executer = new BustaNeraErrCodeConfermaExecuter();
  
	public void testBustaNeraErrCodeConfermaExecuter_forErrMsgNull()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getEventName() ).andReturn( "Conferma" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "docId" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "errorCode" )).andReturn( "01" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null );		
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().get( "BustaNeraErrCodeView" )).andReturn(  ( Serializable ) collection ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeConfermaExecuter_forErrMsg_04()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getEventName() ).andReturn( "Conferma" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "docId" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "errorCode" )).andReturn( "" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null );		
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().get( "BustaNeraErrCodeView" )).andReturn(  ( Serializable ) collection ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeConfermaExecuter_forErrMsg_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getEventName() ).andReturn( "Conferma" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "docId" )).andReturn( "" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "errorCode" )).andReturn( "01" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null );		
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().get( "BustaNeraErrCodeView" )).andReturn(  ( Serializable ) collection ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeConfermaExecuter_forErrMsg_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getEventName() ).andReturn( "Conferma" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "docId" )).andReturn( "av" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "errorCode" )).andReturn( "01" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null );		
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().get( "BustaNeraErrCodeView" )).andReturn(  ( Serializable ) collection ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testBustaNeraErrCodeConfermaExecuter_forErrMsg_03()
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getEventName() ).andReturn( "Conferma" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "docId" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "errorCode" )).andReturn( "01" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null );		
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().get( "BustaNeraErrCodeView" )).andReturn(  ( Serializable ) collection ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testBustaNeraErrCodeConfermaExecuter_forTracciabilitaException()
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setTracciabilitaException() ;
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class );
		expecting( getRequestEvent().getEventName() ).andReturn( "Conferma" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "ID" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "docId" )).andReturn( "01" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "errorCode" )).andReturn( "asc" ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable ) EasyMock.anyObject() ) ).andReturn( null );		
		Collection collection = new Vector();
		collection.add("a");
		expecting( getStateMachineSession().get( "BustaNeraErrCodeView" )).andReturn(  ( Serializable ) collection ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
}
