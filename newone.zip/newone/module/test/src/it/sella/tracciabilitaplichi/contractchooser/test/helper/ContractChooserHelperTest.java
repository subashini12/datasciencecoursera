package it.sella.tracciabilitaplichi.contractchooser.test.helper;

import it.sella.tracciabilitaplichi.contractchooser.helper.ContractChooserHelper;
import it.sella.tracciabilitaplichi.implementation.util.TPAsserts;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.util.ArrayList;
import java.util.Collection;

import junit.framework.TestCase;

public class ContractChooserHelperTest extends TestCase
{

	public ContractChooserHelperTest ( final String name ) {
		super( name );
	}
	
	@Override
	protected void setUp( ) {
		TPAsserts.assertPojoGetterSetter(BustaDeiciAttributeView.class);
	}

	public void testGetSelectedBustaDeici1( ) {
		final Collection selectedBustaDeiciColl = ContractChooserHelper.getSelectedBustaDeici( null );
		assertNull( selectedBustaDeiciColl );
	}
	
	public void testGetSelectedBustaDeici2( ) {
		final String[ ] selectedBustaArray = new String[ ]{ "1", "2", "3" };
		final Collection selectedBustaDeiciColl = ContractChooserHelper.getSelectedBustaDeici( selectedBustaArray );
		assertEquals( 3, selectedBustaDeiciColl.size( ) );
		for( final String selectBuste : selectedBustaArray ) {
			assertTrue( selectedBustaDeiciColl.contains( selectBuste ) );
		}
	}
	
	public void testGetSelectedBustaDeici3( ) {
		final String selectedBuste = "21";
		final Collection selectedBustaDeiciColl = ContractChooserHelper.getSelectedBustaDeici( selectedBuste );
		assertEquals( 1, selectedBustaDeiciColl.size( ) );
		final String actualSelectedBuste = selectedBustaDeiciColl.iterator( ).next( ).toString( );
		assertEquals( selectedBuste, actualSelectedBuste );
	}
	
	public void testGetBustaDeiciAttributeViews1( ) {
		assertNull( ContractChooserHelper.getBustaDeiciAttributeViews( null, new ArrayList( ) ) );
		assertNull( ContractChooserHelper.getBustaDeiciAttributeViews( new ArrayList( ), null ) );
	}
	
	public void testGetBustaDeiciAttributeViews2( ) {
		final Collection bustaDeiciIdColl = new ArrayList( );
		bustaDeiciIdColl.add( "1" );
		bustaDeiciIdColl.add( "2" );
		final Collection<BustaDeiciAttributeView> allBustaDeiciAttributeViews = new ArrayList( );
		final BustaDeiciAttributeView bustaDeiciAttributeView1 = new BustaDeiciAttributeView( );
		bustaDeiciAttributeView1.setBustaDeiciId( Long.valueOf( 1L ) );
		allBustaDeiciAttributeViews.add( bustaDeiciAttributeView1 );
		final BustaDeiciAttributeView bustaDeiciAttributeView2 = new BustaDeiciAttributeView( );
		bustaDeiciAttributeView2.setBustaDeiciId( Long.valueOf( 2L ) );
		allBustaDeiciAttributeViews.add( bustaDeiciAttributeView2 );
		final BustaDeiciAttributeView bustaDeiciAttributeView3 = new BustaDeiciAttributeView( );
		bustaDeiciAttributeView3.setBustaDeiciId( Long.valueOf( 3L ) );
		allBustaDeiciAttributeViews.add( bustaDeiciAttributeView3 );
		final Collection<BustaDeiciAttributeView> bustaDeiciAttributeViews = ContractChooserHelper.getBustaDeiciAttributeViews( bustaDeiciIdColl, allBustaDeiciAttributeViews );
		assertEquals( 2, bustaDeiciAttributeViews.size( ) );
		for ( final BustaDeiciAttributeView attributeView : bustaDeiciAttributeViews ) {
			assertTrue( bustaDeiciIdColl.contains( attributeView.getBustaDeiciId( ).toString( ) ) );
		}
	}
	
}
