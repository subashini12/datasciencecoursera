package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.util.Hashtable;

import org.easymock.EasyMock;


public class BustaVentiArchivioProcessorTest extends AbstractSellaExecuterMock{

	public BustaVentiArchivioProcessorTest(final String name) {
		super(name);
	}

	BustaVentiArchivioProcessor processor = new BustaVentiArchivioProcessor() ;
	
	public void testBustaVentiArchivioProcessor_01()
	{
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute(ITPConstants.CASSETTO_BOX_ID)).andReturn("").anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(getHashtable()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		processor.processBustaVentiRecords(getRequestEvent());
	}
	
	private Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put(ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED, 1L);
		hashtable.put(ITPConstants.TOTAL_PLICHI_RECEIVED, 1L);
		hashtable.put(ITPConstants.SELECTED_OGGETTO_TYPE, "");
		hashtable.put(ITPConstants.CASSETTO_BOX_ID, "");
		hashtable.put(ITPConstants.IS_BARCODE_READER_AVAILABLE, "");
		hashtable.put("TypesOfOggettos", "");
		return hashtable ;
	}
}
