package it.sella.tracciabilitaplichi.executer.ise;

import it.sella.integrazione_sistemi_esterni.ServiceException;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.MapperServices;
import it.sella.tracciabilitaplichi.implementation.util.MapperServicesMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;

import junit.framework.TestCase;
import mockit.Mockit;

public class ISETPLLidTrackingTest extends TestCase {

	ISETPLLidTracking isetplLidTracking = new ISETPLLidTracking();

	public void testISETPLLidTracking_01() {
			TracciabilitaPlichiImplMock.setBusta20();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			Mockit.setUpMock(MapperServices.class, MapperServicesMock.class);
			Mockit.setUpMock(TracciabilitaPlichiISEDataAccess.class,
					TracciabilitaPlichiISEDataAccessMock.class);
			Mockit.setUpMock(DBPersonaleWrapper.class,
					DBPersonaleWrapperMock.class);
			Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
			try {
				isetplLidTracking.invokeService("133");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final ServiceException e) {
				e.printStackTrace();
			}
	}

	public void testISETPLLidTracking_02() {
			TracciabilitaPlichiISEDataAccessMock.setZeroLbProc();
			TracciabilitaPlichiImplMock.setBusta20();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			Mockit.setUpMock(MapperServices.class, MapperServicesMock.class);
			Mockit.setUpMock(TracciabilitaPlichiISEDataAccess.class,
					TracciabilitaPlichiISEDataAccessMock.class);
			Mockit.setUpMock(DBPersonaleWrapper.class,
					DBPersonaleWrapperMock.class);
			Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
			try {
				isetplLidTracking.invokeService("133");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public void testISETPLLidTracking_03() {
			MapperServicesMock.setNonExistsOnHostStampe();
			TracciabilitaPlichiImplMock.setBusta20();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			Mockit.setUpMock(MapperServices.class, MapperServicesMock.class);
			Mockit.setUpMock(TracciabilitaPlichiISEDataAccess.class,
					TracciabilitaPlichiISEDataAccessMock.class);
			Mockit.setUpMock(DBPersonaleWrapper.class,
					DBPersonaleWrapperMock.class);
			Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
			try {
				isetplLidTracking.invokeService("133");
			} catch (final RemoteException e) {
				e.printStackTrace();
			} catch (final ServiceException e) {
				e.printStackTrace();
			}
	}
	
	public void testISETPLLidTracking_04() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		TracciabilitaPlichiImplMock.setBusta20();
			TracciabilitaPlichiISEDataAccessMock.setZeroLbProc();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			Mockit.setUpMock(MapperServices.class, MapperServicesMock.class);
			Mockit.setUpMock(TracciabilitaPlichiISEDataAccess.class,
					TracciabilitaPlichiISEDataAccessMock.class);
			Mockit.setUpMock(DBPersonaleWrapper.class,
					DBPersonaleWrapperMock.class);
			Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
			try {
				isetplLidTracking.invokeService("133");
			} catch (final RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (final ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
}
