package it.sella.tracciabilitaplichi.executer.test.gestorecdrgroupadmin;

import it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin.CdrGroupConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.CdrGroupView;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;

public class CdrGroupConfermaExecuterTest extends AbstractSellaExecuterMock
{

	public CdrGroupConfermaExecuterTest(final String name) 
	{
		super(name);
		// TODO Auto-generated constructor stub
	}

	CdrGroupConfermaExecuter executer = new CdrGroupConfermaExecuter();
	
	/*public void testCdrGroupConfermaExecuter_01()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}*/
	public void testCdrGroupConfermaExecuter_02()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupConfermaExecuter_03()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("ab").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupConfermaExecuter_04()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	/*public void testCdrGroupConfermaExecuter_05()
	{
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCdrGroupConfermaExecuter_06()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("02").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupConfermaExecuter_07()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCdrGroupConfermaExecuter_forTracciabilitaException()
	{
		it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock.setTracciabilitaException();
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupConfermaExecuter_forRemoteException()
	{
		it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock.setRemoteException();
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)getCdrGroupTable()).anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}*/
	private Map getCdrGroupTable()
	{
		final Map cdrGroupHashtable = new Hashtable();
		cdrGroupHashtable.put( "OldCdrGroupView", getcdrGroupView() );
		cdrGroupHashtable.put( "NewCdrGroupView", getcdrGroupView() );
		return cdrGroupHashtable ;
	}
	private CdrGroupView getcdrGroupView()
	{
		final CdrGroupView cdrGroupView = new CdrGroupView();
		cdrGroupView.setId( Long.valueOf( 1L ) );
		cdrGroupView.setCdr( "cdr" );
		cdrGroupView.setGroup( "group" );
		return cdrGroupView ;
	}
}
