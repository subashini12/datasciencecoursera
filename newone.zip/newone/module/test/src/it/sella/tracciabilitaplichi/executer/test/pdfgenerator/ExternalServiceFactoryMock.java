package it.sella.tracciabilitaplichi.executer.test.pdfgenerator;


public class ExternalServiceFactoryMock {

	
	public SecurityDBpersonaleWrapperMock getSecurityDBPersonaleWrapper( )
	{
		return new SecurityDBpersonaleWrapperMock();
	}



}
