package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestContrattiTipoShowContrattiExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

public class GestContrattiTipoShowContrattiExecuterTest extends
		AbstractSellaExecuterMock {

	final GestContrattiTipoShowContrattiExecuter executer = new GestContrattiTipoShowContrattiExecuter();

	public GestContrattiTipoShowContrattiExecuterTest(String name) {
		super(name);
	}

	public void testGestContrattiTipoShowContrattiExecuter() {
		expecting(getStateMachineSession().get("ContrattiCollection"))
				.andReturn((Serializable) getContrattiCollection()).anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiId"))
				.andReturn("08").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );

		playAll();
		ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("SelectedContrattiInfo", executeResult.getTransition());
	}

	private List getContrattiCollection() {
		List contrattiCollection = new ArrayList();
		ContrattiProdottoView codProdView1 = new ContrattiProdottoView();
		codProdView1.setContrattiProdottoId(Long.valueOf("08"));
		contrattiCollection.add(codProdView1);
		return contrattiCollection;
	}
}
