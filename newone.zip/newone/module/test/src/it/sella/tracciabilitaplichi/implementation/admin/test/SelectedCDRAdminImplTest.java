/*package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.tracciabilitaplichi.implementation.admin.SelectedCDRAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;

import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

*//**
 *
 * @author GBS02360
 *//*
public class SelectedCDRAdminImplTest extends BasicJDBCTestCaseAdapter {

	public SelectedCDRAdminImplTest(final String name) {
		super(name);
	}

	SelectedCDRAdminImpl selectedCDRAdminImpl = new SelectedCDRAdminImpl() ;
	
	public void testInsert_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SC_ID",new Object[]{"1"});
		result.addColumn("SC_CDR",new Object[]{"1"});
		result.addColumn("SC_BANK_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			selectedCDRAdminImpl.insert(getTpMaSelectedCdrView());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}
	
	public void testUpdate_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SC_ID",new Object[]{"1"});
		result.addColumn("SC_CDR",new Object[]{"1"});
		result.addColumn("SC_BANK_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			selectedCDRAdminImpl.update(getTpMaSelectedCdrView());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}
	
	public void testDelete_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SC_ID",new Object[]{"1"});
		result.addColumn("SC_CDR",new Object[]{"1"});
		result.addColumn("SC_BANK_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			selectedCDRAdminImpl.delete(1);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}
	
	public void testGetAll_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SC_ID",new Object[]{"1"});
		result.addColumn("SC_CDR",new Object[]{"1"});
		result.addColumn("SC_BANK_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			selectedCDRAdminImpl.getAll();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}
	
	public void testGetViewById_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SC_ID",new Object[]{"1"});
		result.addColumn("SC_CDR",new Object[]{"1"});
		result.addColumn("SC_BANK_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			selectedCDRAdminImpl.getViewById(1L);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}
	
	public void testSearch_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler = 
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SC_ID",new Object[]{"1"});
		result.addColumn("SC_CDR",new Object[]{"1"});
		result.addColumn("SC_BANK_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			selectedCDRAdminImpl.search(getTpMaSelectedCdrView());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}
	
	private static TpMaSelectedCdrView getTpMaSelectedCdrView()
	{
		final TpMaSelectedCdrView selectedCdrView = new TpMaSelectedCdrView() ;
		selectedCdrView.setScBankId("");
		selectedCdrView.setScCdr("");
		selectedCdrView.setScId("1");
		return selectedCdrView ;
	}
}*/