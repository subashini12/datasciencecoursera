package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsHelper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsHelperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.persistence.dto.TailoredGrants;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class WinboxAdminHelperTest extends AbstractSellaExecuterMock
{

	public WinboxAdminHelperTest ( final String name )
	{
		super( name );
	}

	public void testGetSessionMap_1( )
	{
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( Boolean.FALSE );
		expecting( getStateMachineSession( ).put( CONSTANTS.WINBOX_ADMIN_MAP.toString( ), new HashMap<Enum, Object>( ) ) ).andReturn( new HashMap<Enum, Object>( ) );
		expecting( getStateMachineSession( ).get( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( new HashMap<Enum, Object>( ) );
		playAll( );
		final Map<Enum, Object> sessionMap = WinboxAdminHelper.getInstance( ).getSessionMap( getRequestEvent( ) );
		assertNotNull( sessionMap );
		assertTrue( sessionMap.isEmpty( ) );
	}


	public void testSetGrantsForGivenId_1( )
	{
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( );
		expecting( getStateMachineSession( ).get( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( (Serializable)sessionMap );
		expecting( getStateMachineSession().containsKey( CONSTANTS.WINBOX_ADMIN_MAP.toString( )) ).andReturn( Boolean.TRUE ).anyTimes();
		playAll( );
		final AltriWinboxView altriWinboxView = new AltriWinboxView( );
		altriWinboxView.setCustomAccess( Byte.valueOf( "0" ) );
		try
		{
			WinboxAdminHelper.getInstance( ).setGrantsForGivenId( getRequestEvent( ), altriWinboxView );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		assertFalse( sessionMap.containsKey( CONSTANTS.GRANTS ) );
		assertNull( altriWinboxView.getTailoredGrants( ) );
	}
	
	
	
	public void testSetTailoredGrants_1( )
	{
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 3 );
		final AltriWinboxView altriWinboxView = new AltriWinboxView( );
		altriWinboxView.setId( 1L );
		WinboxAdminHelper.getInstance( ).setTailoredGrants( sessionMap, altriWinboxView );
		assertNull( altriWinboxView.getTailoredGrants( ) );
		altriWinboxView.setTailoredGrants( new TailoredGrants( ) );
		altriWinboxView.getTailoredGrants( ).setTipoPraticaId( 1L );
		WinboxAdminHelper.getInstance( ).setTailoredGrants( sessionMap, altriWinboxView );
		assertEquals( Long.valueOf( 1L ), altriWinboxView.getTailoredGrants( ).getTipoPraticaId( ) );
	}
	
	public void testSetTailoredGrants_2( )
	{
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 3 );
		sessionMap.put( CONSTANTS.GRANTS, getNewGrants( Boolean.FALSE ) );
		final AltriWinboxView altriWinboxView = new AltriWinboxView( );
		altriWinboxView.setId( 1L );
		WinboxAdminHelper.getInstance( ).setTailoredGrants( sessionMap, altriWinboxView );
		assertNotNull( altriWinboxView.getTailoredGrants( ) );
		assertEquals( Long.valueOf( 1L ), altriWinboxView.getTailoredGrants( ).getTipoPraticaId( ) );
		assertNotNull( altriWinboxView.getTailoredGrants( ).getGrants( ) );
		assertEquals( 1, altriWinboxView.getTailoredGrants( ).getGrants( ).size( ) );
		assertEquals( new Grants( null, 1L, null ), altriWinboxView.getTailoredGrants( ).getGrants( ).iterator( ).next( ) );
	}
	
	public void testSetDefaultGrants_1( )
	{
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 3 );
		sessionMap.put( CONSTANTS.DEFAULT_GRANTS, new ArrayList<Grants>( 1 ) );
		sessionMap.put( CONSTANTS.GRANTS_COLLECTION, new ArrayList<Grants>( 1 ) );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( Boolean.TRUE );
		expecting( getStateMachineSession( ).get( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( (Serializable)sessionMap );
		playAll( );
		try
		{
			WinboxAdminHelper.getInstance( ).setDefaultGrants( getRequestEvent( ) );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		assertTrue( ( ( Collection<Grants> ) sessionMap.get( CONSTANTS.GRANTS_COLLECTION ) ).isEmpty( ) );
	}
	
	public void testSetDefaultGrants_2( )
	{
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 3 );
		sessionMap.put( CONSTANTS.GRANTS_COLLECTION, new ArrayList<Grants>( 1 ) );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( Boolean.TRUE );
		expecting( getStateMachineSession( ).get( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn((Serializable) sessionMap );
		playAll( );
		try
		{
			WinboxAdminHelper.getInstance( ).setDefaultGrants( getRequestEvent( ) );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		final Grants defaultGrant = new Grants( "", Long.valueOf( -1L ), CONSTANTS.LOGGED_CDR.getValue( ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.DEFAULT_GRANTS ) );
		assertEquals( defaultGrant, ( ( Collection<Grants> ) sessionMap.get( CONSTANTS.DEFAULT_GRANTS ) ).iterator( ).next( ) );
		assertTrue( ( ( Collection<Grants> ) sessionMap.get( CONSTANTS.GRANTS_COLLECTION ) ).isEmpty( ) );
	}
	
	public void testSetDefaultGrants_3( )
	{
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( 3 );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( Boolean.TRUE );
		expecting( getStateMachineSession( ).get( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn((Serializable) sessionMap );
		playAll( );
		try
		{
			WinboxAdminHelper.getInstance( ).setDefaultGrants( getRequestEvent( ) );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		final Grants defaultGrant = new Grants( "", Long.valueOf( -1L ), CONSTANTS.LOGGED_CDR.getValue( ) );
	}
	
	private void mockGrantsHelper( final Boolean isEmpty )
	{
		
		redefineMethod( GrantsHelper.class, new Object( ) {
			public Collection<Grants> getGrants( final Long praticaId ) throws TracciabilitaException, RemoteException
			{
				return getNewGrants( isEmpty );
			}
		} );
	}
	
	private Collection<Grants> getNewGrants( final Boolean isEmpty )
	{
		final Collection<Grants> tailoredGrants = new ArrayList<Grants>( );
		if ( !isEmpty )
		{
			tailoredGrants.add( new Grants( null, 1L, null ) );
		}
		return tailoredGrants;

	}
	
	public void testsetGrantsForGivenId_01()
	{
		setUpMockMethods(GrantsHelper.class, GrantsHelperMock.class);
		final Map<Enum, Object> sessionMap = new HashMap<Enum, Object>( );
		expecting( getStateMachineSession( ).get( CONSTANTS.WINBOX_ADMIN_MAP.toString( ) ) ).andReturn( (Serializable)sessionMap ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.WINBOX_ADMIN_MAP.toString( )) ).andReturn( Boolean.TRUE ).anyTimes();
		playAll( );
		final AltriWinboxView altriWinboxView = new AltriWinboxView( );
		altriWinboxView.setCustomAccess( Byte.valueOf( "1" ) );
		altriWinboxView.setId(1L);
		try {
			WinboxAdminHelper.getInstance( ).setGrantsForGivenId(getRequestEvent(), altriWinboxView);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testgetAltriWinboxView_01()
	{
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("Desc")).andReturn("description").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("099231").anyTimes();
		expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("abilitato")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("customAccess")).andReturn("1").anyTimes();
		playAll() ;
		WinboxAdminHelper.getInstance( ).getAltriWinboxView(getRequestEvent());
	}
	
}
