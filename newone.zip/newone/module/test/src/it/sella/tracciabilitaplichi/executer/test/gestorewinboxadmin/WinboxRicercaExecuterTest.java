package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.Processor;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxRicercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import org.easymock.EasyMock;

public class WinboxRicercaExecuterTest extends AbstractSellaExecuterMock 
{
	
	final WinboxRicercaExecuter executer = new WinboxRicercaExecuter();
	public WinboxRicercaExecuterTest(final String name) 
	{
		super(name);
	}
	
	public void testWinboxRicercaExecuter_forResultNullNNotRicercaEventEventNameNWinlistNotNullCase()
	{
		final Collection winList = new ArrayList();
    	winList.add("abc");
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("abc").anyTimes();
		expecting( getStateMachineSession().get(CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ))).andReturn(getAltriWinboxView()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting(getStateMachineSession().put(  "WinboxList", winList) ).andReturn( null ).anyTimes();
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		playAll();		
		executer.execute( getRequestEvent() );		
	 }
	
	public void testWinboxRicercaExecuter_forResultNullNRicercaEventNameNWinlistNullCase()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setWinBoxListNull();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("Ricerca").anyTimes();
		expecting( getStateMachineSession().get(CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ))).andReturn(getAltriWinboxView()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		playAll();		
		executer.execute( getRequestEvent() );
		
	}
	
	public void testWinboxRicercaExecuter_forResultNotNullCase()
	{
		ProcessorMock.setResultNotNull();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("abc").anyTimes();
		expecting( getStateMachineSession().get(CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ))).andReturn(getAltriWinboxView()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		setUpMockMethods( Processor.class, ProcessorMock.class);
		playAll();		
		executer.execute( getRequestEvent() );		
	}
		
	public void testWinboxRicercaExecuter_forRemoteException()
	{
		ProcessorMock.setRemoteException();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("abc").anyTimes();
		expecting( getStateMachineSession().get(CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ))).andReturn(getAltriWinboxView()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		setUpMockMethods( Processor.class, ProcessorMock.class);
		playAll();		
		executer.execute( getRequestEvent() );		
	}

	public void testWinboxRicercaExecuter_forTracciabilitaException()
	{
		ProcessorMock.setTracciabilitaException();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("abc").anyTimes();
		expecting( getStateMachineSession().get(CONSTANTS.ALTRI_WINBOX_VIEW.getValue( ))).andReturn(getAltriWinboxView()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		setUpMockMethods( Processor.class, ProcessorMock.class);
		playAll();		
		executer.execute( getRequestEvent() );		
	}	
	
	private AltriWinboxView getAltriWinboxView() 
	{
		final AltriWinboxView altriWinboxView = new AltriWinboxView();
		altriWinboxView.setDesc("ravi");		
		return altriWinboxView;
	}

}

