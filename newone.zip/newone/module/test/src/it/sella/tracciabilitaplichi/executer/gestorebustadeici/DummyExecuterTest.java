package it.sella.tracciabilitaplichi.executer.gestorebustadeici;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.implementation.util.BustaDeiciPagging;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;


public class DummyExecuterTest {

	DummyExecuter dummyExecuter = new DummyExecuter() ;
	
	@Test
	public void executer_01() {
		
		BustaDeiciPagging bustaDeiciPagging = EasyMock.createMock(BustaDeiciPagging.class);
		try {
			EasyMock.expect(bustaDeiciPagging.getPageData(Integer.parseInt( "1" ))).andReturn(new Hashtable()).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isPreviousSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isNextSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.getCurrentSection()).andReturn(new ArrayList()).anyTimes();
		} catch (RemoteException e) {
			Assert.fail(e.getMessage());
		}
		EasyMock.replay(bustaDeiciPagging);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.get("Pagging")).andReturn(bustaDeiciPagging).anyTimes();
		EasyMock.expect(session.get("pageNo")).andReturn("1").anyTimes();
		EasyMock.expect(session.containsKey("plichIds")).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( new ArrayList()).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( "").anyTimes();
		EasyMock.expect(session.get( EasyMock.anyObject() )).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(requestEvent);
		
		ExecuteResult executeResult = dummyExecuter.execute(requestEvent);
		Assert.assertFalse((Boolean) executeResult.getAttribute("prevLink"));
		
	}
	
	@Test
	public void executer_02() {
		
		BustaDeiciPagging bustaDeiciPagging = EasyMock.createMock(BustaDeiciPagging.class);
		try {
			EasyMock.expect(bustaDeiciPagging.getPageData(Integer.parseInt( "1" ))).andReturn(new Hashtable()).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isPreviousSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.isNextSection()).andReturn(false).anyTimes();
			EasyMock.expect(bustaDeiciPagging.getCurrentSection()).andReturn(new ArrayList()).anyTimes();
		} catch (RemoteException e) {
			Assert.fail(e.getMessage());
		}
		EasyMock.replay(bustaDeiciPagging);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.get("Pagging")).andReturn(bustaDeiciPagging).anyTimes();
		EasyMock.expect(session.get("pageNo")).andReturn("1").anyTimes();
		EasyMock.expect(session.containsKey("plichIds")).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.get( "plichIds" )).andReturn(new HashMap()).anyTimes();
		EasyMock.expect(session.containsKey("pageNo")).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( new ArrayList()).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( "").anyTimes();
		EasyMock.expect(session.get( EasyMock.anyObject() )).andReturn("").anyTimes();
		EasyMock.replay(session);
		
		RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(requestEvent);
		
		ExecuteResult executeResult = dummyExecuter.execute(requestEvent);
		System.out.println(executeResult.getAttribute("preChkIds"));
		
		ArrayList list = (ArrayList) executeResult.getAttribute("preChkIds");
		
		Assert.assertFalse((Boolean) executeResult.getAttribute("prevLink"));
		Assert.assertTrue(list.isEmpty());
		
	}
	
}
