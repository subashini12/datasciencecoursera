package it.sella.tracciabilitaplichi.executer.test.gestorehostlidattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestorehostlidattributeadmin.HostlIdAttributeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

import java.io.Serializable;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class HostlIdAttributeCercaExecuterTest extends AbstractSellaExecuterMock
{

	public HostlIdAttributeCercaExecuterTest(String name) 
	{
		super(name);
	}

	HostlIdAttributeCercaExecuter executer = new HostlIdAttributeCercaExecuter();
	
	public void testHostlIdAttributeCercaExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "HostIdAttributeHt") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( "HostIdAttributeHt",  new  Hashtable() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testHostlIdAttributeCercaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "HostIdAttributeHt") ).andReturn( Boolean.TRUE ).anyTimes();
		expecting(getStateMachineSession().put( "HostIdAttributeHt",  new  Hashtable() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().get( "HostIdAttributeHt" )).andReturn(  new Hashtable()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testHostlIdAttributeCercaExecuter_03()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setHostlIdAttributeViewNull() ;
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testHostlIdAttributeCercaExecuter_04()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testHostlIdAttributeCercaExecuter_05()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("abc").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testHostlIdAttributeCercaExecuter_06()
	{
		expecting(getRequestEvent().getAttribute("ID")).andReturn("abc").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testHostlIdAttributeCercaExecuter_07()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException() ;
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "HostIdAttributeHt") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( "HostIdAttributeHt",  new  Hashtable() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
}
