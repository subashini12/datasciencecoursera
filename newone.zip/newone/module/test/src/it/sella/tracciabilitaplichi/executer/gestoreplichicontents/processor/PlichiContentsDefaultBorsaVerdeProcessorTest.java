/*package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

public class PlichiContentsDefaultBorsaVerdeProcessorTest extends
		AbstractSellaExecuterTest {

	public PlichiContentsDefaultBorsaVerdeProcessorTest(final String name) {
		super(name);
	}

	PlichiContentsDefaultBorsaVerdeProcessor processor = new PlichiContentsDefaultBorsaVerdeProcessor();

	public void testPlichiContentsDefaultBorsaVerdeProcessor_01() {
		try {
			processor.processBorsaVerdeRecords(getRequestEvent(), "");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
}
*/