package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestContrattiAdminDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

public class GestContrattiAdminDefaultExecuterTest extends AbstractSellaExecuterMock
{

	public GestContrattiAdminDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	GestContrattiAdminDefaultExecuter executer = new GestContrattiAdminDefaultExecuter();
	
	public void testGestContrattiAdminDefaultExecuter_01()
	{
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class );
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		executer.execute( getRequestEvent() );
	}
	
	public void testGestContrattiAdminDefaultExecuter_02()
	{
		TPProdottiDataAccessMock.setTracciabilitaException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class );
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		executer.execute( getRequestEvent() );
	}
	
}
