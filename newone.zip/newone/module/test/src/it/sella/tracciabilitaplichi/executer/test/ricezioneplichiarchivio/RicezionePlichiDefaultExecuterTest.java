/*package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.ricezioneplichi.RicezionePlichiDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.RicezionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPCacheMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.RicezionePlichiCacheUtil;
import it.sella.tracciabilitaplichi.implementation.util.TPCache;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;
import it.sella.tracciabilitaplichi.processor.RicezionePlichiProcessor;
import it.sella.tracciabilitaplichi.processor.mock.RicezionePlichiProcessorMock;

public class RicezionePlichiDefaultExecuterTest extends AbstractSellaExecuterTest {

	public RicezionePlichiDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}	
	RicezionePlichiDefaultExecuter executer = new RicezionePlichiDefaultExecuter();
	
	public void testExecuter_1(){
		RicezionePlichiCacheUtilMock.setNonEmptyMap();		
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);		
		setUpMockMethods( TPUtil.class,TPUtilMock.class);
		setUpMockMethods( TPCache.class,TPCacheMock.class);
		setUpMockMethods( RicezionePlichiCacheUtil.class,RicezionePlichiCacheUtilMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( RicezionePlichiProcessor.class,RicezionePlichiProcessorMock.class);		
		expecting(getStateMachineSession().containsKey("ToPlichiContents")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("PlichiContentsModified")).andReturn(Boolean.FALSE).anyTimes();		
		expecting( getStateMachineSession().remove( "ToPlichiContents" ) ).andReturn(null).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_2(){
		TracciabilitaPlichiPlichiDataAccessMock.setNotNull();
		RicezionePlichiCacheUtilMock.setNonEmptyMap();		
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);		
		setUpMockMethods( TPUtil.class,TPUtilMock.class);
		setUpMockMethods( TPCache.class,TPCacheMock.class);
		setUpMockMethods( RicezionePlichiCacheUtil.class,RicezionePlichiCacheUtilMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( RicezionePlichiProcessor.class,RicezionePlichiProcessorMock.class);		
		expecting(getStateMachineSession().containsKey("ToPlichiContents")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("PlichiContentsModified")).andReturn(Boolean.FALSE).anyTimes();		
		expecting( getStateMachineSession().remove( "ToPlichiContents" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "PlichiContentsModified" ) ).andReturn(null).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_3(){
		RicezionePlichiCacheUtilMock.setNonEmptyMap();	
		TracciabilitaPlichiPlichiDataAccessMock.setBarCodeReaderAvailableTrue();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);		
		setUpMockMethods( TPUtil.class,TPUtilMock.class);
		setUpMockMethods( TPCache.class,TPCacheMock.class);
		setUpMockMethods( RicezionePlichiCacheUtil.class,RicezionePlichiCacheUtilMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods( RicezionePlichiProcessor.class,RicezionePlichiProcessorMock.class);		
		expecting(getStateMachineSession().containsKey("ToPlichiContents")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("PlichiContentsModified")).andReturn(Boolean.FALSE).anyTimes();		
		expecting( getStateMachineSession().remove( "ToPlichiContents" ) ).andReturn(null).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_4(){
		ClassificazioneWrapperMock.setTracciabilitaException();
		RicezionePlichiCacheUtilMock.setNonEmptyMap();		
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);		
		setUpMockMethods( TPUtil.class,TPUtilMock.class);
		setUpMockMethods( TPCache.class,TPCacheMock.class);
		setUpMockMethods( RicezionePlichiCacheUtil.class,RicezionePlichiCacheUtilMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( RicezionePlichiProcessor.class,RicezionePlichiProcessorMock.class);		
		expecting(getStateMachineSession().containsKey("ToPlichiContents")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("PlichiContentsModified")).andReturn(Boolean.FALSE).anyTimes();		
		expecting( getStateMachineSession().remove( "ToPlichiContents" ) ).andReturn(null).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals( "it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException", executeResult.getException( ).toString() );
	}
	
	public void testExecuter_5(){
		ClassificazioneWrapperMock.setRemoteException();
		RicezionePlichiCacheUtilMock.setNonEmptyMap();		
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);		
		setUpMockMethods( TPUtil.class,TPUtilMock.class);
		setUpMockMethods( TPCache.class,TPCacheMock.class);
		setUpMockMethods( RicezionePlichiCacheUtil.class,RicezionePlichiCacheUtilMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods( RicezionePlichiProcessor.class,RicezionePlichiProcessorMock.class);		
		expecting(getStateMachineSession().containsKey("ToPlichiContents")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().containsKey("PlichiContentsModified")).andReturn(Boolean.FALSE).anyTimes();		
		expecting( getStateMachineSession().remove( "ToPlichiContents" ) ).andReturn(null).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );	
		
	}

}
*/