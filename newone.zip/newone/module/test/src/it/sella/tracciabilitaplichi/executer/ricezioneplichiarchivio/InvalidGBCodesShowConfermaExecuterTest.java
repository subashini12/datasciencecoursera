package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.borsaverdearchivation.BVInputProcessor;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.mock.RicezionePlichiArchivioBVProcessorMock;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor.RicezionePlichiArchivioBVProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Hashtable;

import org.easymock.EasyMock;

public class InvalidGBCodesShowConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	public InvalidGBCodesShowConfermaExecuterTest(final String name) {
		super(name);
	}

	InvalidGBCodesShowConfermaExecuter executer = new InvalidGBCodesShowConfermaExecuter() ;
	
	public void testInvalidGBCodesShowConfermaExecuter_01()
	{
		setUpMockMethods(RicezionePlichiArchivioBVProcessor.class,RicezionePlichiArchivioBVProcessorMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(getHashtable()).anyTimes();
		playAll() ;
		executer.execute(getRequestEvent())	;
	}
	
	public void testInvalidGBCodesShowConfermaExecuter_02()
	{
		RicezionePlichiArchivioBVProcessorMock.setRemoteException();
		setUpMockMethods(RicezionePlichiArchivioBVProcessor.class,RicezionePlichiArchivioBVProcessorMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(getHashtable()).anyTimes();
		playAll() ;
		executer.execute(getRequestEvent())	;
	}
	
	public void testInvalidGBCodesShowConfermaExecuter_03()
	{
		RicezionePlichiArchivioBVProcessorMock.setTracciabilitaException();
		setUpMockMethods(RicezionePlichiArchivioBVProcessor.class,RicezionePlichiArchivioBVProcessorMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(getHashtable()).anyTimes();
		playAll() ;
		executer.execute(getRequestEvent())	;
	}
	
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable();
		hashtable.put(ITPConstants.SELECTED_OGGETTO_TYPE, "");
		hashtable.put(ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED , 1L);
		hashtable.put(ITPConstants.TOTAL_PLICHI_RECEIVED, 1L);
		hashtable.put(ITPConstants.BV_INPUT_PROCESSOR, getBVInputProcessor());
		hashtable.put("TypesOfOggettos","");
		hashtable.put(ITPConstants.INVALID_GB_CODE_COLLECTION,"");
		return hashtable ;
	}
	
	private static Hashtable getHashtable1()
	{
		final Hashtable hashtable = new Hashtable();
		hashtable.put(ITPConstants.SELECTED_OGGETTO_TYPE, "");
		hashtable.put(ITPConstants.TOTAL_PLICHI_TO_BE_RECEIVED , 1L);
		hashtable.put(ITPConstants.TOTAL_PLICHI_RECEIVED, 1L);
		hashtable.put("TypesOfOggettos","");
		hashtable.put(ITPConstants.INVALID_GB_CODE_COLLECTION,"");
		return hashtable ;
	}
	
	public void testInvalidGBCodesShowConfermaExecuter_04()
	{
		setUpMockMethods(RicezionePlichiArchivioBVProcessor.class,RicezionePlichiArchivioBVProcessorMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION)).andReturn(getHashtable1()).anyTimes();
		playAll() ;
		executer.execute(getRequestEvent())	;
	}
	
	private static BVInputProcessor getBVInputProcessor()
	{
		final BVInputProcessor bVInputProcessor = new BVInputProcessor ("", null) ;
		return bVInputProcessor ;
	}
	
}
