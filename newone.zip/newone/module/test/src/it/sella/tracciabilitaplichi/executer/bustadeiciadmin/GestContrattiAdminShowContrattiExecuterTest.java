package it.sella.tracciabilitaplichi.executer.bustadeiciadmin;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

import java.util.Hashtable;

import org.easymock.EasyMock;



public class GestContrattiAdminShowContrattiExecuterTest extends AbstractSellaExecuterMock{

	public GestContrattiAdminShowContrattiExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	GestContrattiAdminShowContrattiExecuter executer=new GestContrattiAdminShowContrattiExecuter();
	public void testGestContrattiAdminShowContrattiExecuter_01()
	{
		Hashtable hashtable=new Hashtable();
		expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL)).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ContrattiID")).andReturn("-1");
		expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL )).andReturn(true);
		expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testGestContrattiAdminShowContrattiExecuter_02()
	{
		ContrattiProdottoView contrattiProdottoView2=new ContrattiProdottoView();
		ContrattiProdottoView contrattiProdottoView1=new ContrattiProdottoView();
		contrattiProdottoView1.setCodContratto("Contratto");
		contrattiProdottoView1.setCodProdottoContratto("ProdottoContratto");
		contrattiProdottoView1.setDescrizioneContratto("DescrizioneContratto");
		contrattiProdottoView1.setAbiBanca("1");
		contrattiProdottoView1.setFlagObbligatorio("1");
		contrattiProdottoView1.setImagini(Long.valueOf(1));
		contrattiProdottoView1.setContrattoDaControllare(Long.valueOf(1));
		Hashtable hashtable=new Hashtable();
		hashtable.put(Long.valueOf(1), contrattiProdottoView1);
		hashtable.put(Long.valueOf(2), contrattiProdottoView2);
		expecting(getStateMachineSession().get(ITPConstants.CONTRATTI_COLL)).andReturn(hashtable);
		expecting(getRequestEvent().getAttribute("ContrattiID")).andReturn("1");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ContrattiProdottoView) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.PRODOTTI_COLL )).andReturn(false);
		expecting(getStateMachineSession().get(ITPConstants.PRODOTTI_COLL)).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
}
