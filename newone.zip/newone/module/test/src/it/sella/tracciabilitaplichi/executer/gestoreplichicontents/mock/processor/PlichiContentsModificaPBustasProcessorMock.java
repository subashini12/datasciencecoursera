package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Hashtable;

import mockit.Mock;

public class PlichiContentsModificaPBustasProcessorMock {

@Mock
public static ExecuteResult modifyPAltriRecords( RequestEvent rqEvent, String barCode, Hashtable restoreMap, ExecuteResult executeResult ) throws TracciabilitaException, RemoteException
{
	return executeResult; 
}
@Mock
public static ExecuteResult modifyPB10Records( RequestEvent rqEvent, String barCode, Hashtable restoreMap, ExecuteResult executeResult ) throws TracciabilitaException, RemoteException
{
	return executeResult;
}
}
