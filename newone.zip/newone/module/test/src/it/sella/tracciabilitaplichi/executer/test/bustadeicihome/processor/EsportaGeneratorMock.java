package it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class EsportaGeneratorMock 
{
	
	private static Boolean tracciabilitaException = false;
	
	private static Boolean remoteException = false;
			
	public  static void setTracciabilitaException() 
	{  
		tracciabilitaException = true;
	}
	public  static void setRemoteException() 
	{  
		remoteException = true;
	}
		
	@Mock
	public static Map mapExportaPageData( RequestEvent rqEvent ) throws TracciabilitaException, RemoteException
	{
		
		if( tracciabilitaException )
		{
		   tracciabilitaException = false ;
		   throw new TracciabilitaException();
		}
		if( remoteException )
		{
			remoteException = false;
			throw new RemoteException();
		}
		Map map = new HashMap() ;
		map.put("a","abc") ;
		return map ;		
	}

	
}
