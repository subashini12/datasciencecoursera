package it.sella.tracciabilitaplichi.ajax.inserimentocontratti.handler;

import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.webutil.ajax.returntypes.AjaxStringBuffer;
import it.sella.webutil.ajax.returntypes.StringItemsTreeSet;
import mockit.Mockit;

import org.junit.Assert;
import org.junit.Test;


public class InserimentoContrattiHandlerTest {
	
	InserimentoContrattiHandler inserimentoContrattiHandler = new InserimentoContrattiHandler() ;
	
	@Test
	public void testgetContrattiTipologia_01() {
		ExternalServicesFactoryMock.setOperationAllowed();
		Mockit.setUpMock(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		final StringItemsTreeSet stringItemsTreeSet = inserimentoContrattiHandler.getContrattiTipologia("14");
		Assert.assertEquals(null,stringItemsTreeSet.iterator().next());
	}
	
	@Test
	public void testgetContrattiTipologia_02() {
		ExternalServicesFactoryMock.setOperationAllowed();
		Mockit.setUpMock(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		final StringItemsTreeSet stringItemsTreeSet = inserimentoContrattiHandler.getContrattiTipologia("14");
		Assert.assertEquals(null,stringItemsTreeSet.iterator().next());
	}
	
	@Test
	public void testgetContrattiTipologia_tpexception() {
		ExternalServicesFactoryMock.setTracciabilitaException();
		ExternalServicesFactoryMock.setOperationAllowed();
		Mockit.setUpMock(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		final StringItemsTreeSet stringItemsTreeSet = inserimentoContrattiHandler.getContrattiTipologia("14");
		Assert.assertNotNull(stringItemsTreeSet);
	}
	
	@Test
	public void getAnagrafica_02() {
		ExternalServicesFactoryMock.setNullAnagrafe();
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		final AjaxStringBuffer ajaxStringBuffer = inserimentoContrattiHandler.getAnagrafica("", "", "67983767", "", "", "");
		final StringBuilder stringBuilder = new StringBuilder("<input type=\"text\" size=\"35\" maxlength=\"200\" id=\"Anagrafica\" name=\"Anagrafica\" tabindex=\"8\" value=\"\"/>");
		Assert.assertEquals(stringBuilder.toString(),ajaxStringBuffer.toString());
	}
	
	@Test
	public void getAnagrafica_03() {
		ExternalServicesFactoryMock.setAnagrafe();
		Mockit.setUpMock(ExternalServicesFactory.class, ExternalServicesFactoryMock.class);
		final AjaxStringBuffer ajaxStringBuffer = inserimentoContrattiHandler.getAnagrafica("", "", "899", "", "", "");
		final StringBuilder stringBuilder = new StringBuilder("<input type=\"text\" size=\"35\" maxlength=\"200\" id=\"Anagrafica\" name=\"Anagrafica\" tabindex=\"8\" value=\"\"/>");
		Assert.assertEquals(stringBuilder.toString(),ajaxStringBuffer.toString());
	}
	
}
