package it.sella.tracciabilitaplichi.executer.test.gestorechannelelementsadmin;

import it.sella.tracciabilitaplichi.executer.gestorechannelelementsadmin.ChannelElementsAdminExecuter;
import it.sella.tracciabilitaplichi.executer.gestorechannelelementsadmin.processor.ChannelElementsAdminProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.view.ChannelElementsView;

import java.util.Hashtable;

import org.easymock.EasyMock;

public class ChannelElementsAdminExecuterTest extends AbstractSellaExecuterMock {

	public ChannelElementsAdminExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ChannelElementsAdminExecuter executer = new ChannelElementsAdminExecuter();
	
	
	public void testExecuterForShowChannelElementDetailEvent_01(){
		expecting(getRequestEvent().getEventName()).andReturn("ShowChannelElementDetail").anyTimes() ;		
		expecting( getStateMachineSession( ).get(  "ChannelElementsColl" ) ).andReturn(getChannelElementsMap()).anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelDefinitionColl") ).andReturn(new Hashtable()).anyTimes();
		expecting( getRequestEvent().getAttribute( "ChannelElementID" ) ).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testExecuterForShowChannelElementDetailEvent_02(){
		TracciabilitaPlichiImplMock.setCassetto();
		setUpMockMethods(TPMultiChannelDataAccess.class,TPMultiChannelDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(ChannelElementsAdminProcessor.class,ChannelElementsAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes() ;
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Hashtable) EasyMock.anyObject())).andReturn("").anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelElementsColl" ) ).andReturn(getChannelElementsMap()).anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelDefinitionColl") ).andReturn(new Hashtable()).anyTimes();
		expecting( getRequestEvent().getAttribute( "ChannelElementID" ) ).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}	
	
	public void testExecuterForShowChannelElementDetailEvent_tracciabilitaException(){
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TPMultiChannelDataAccess.class,TPMultiChannelDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(ChannelElementsAdminProcessor.class,ChannelElementsAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes() ;
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Hashtable) EasyMock.anyObject())).andReturn("").anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelElementsColl" ) ).andReturn(getChannelElementsMap()).anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelDefinitionColl") ).andReturn(new Hashtable()).anyTimes();
		expecting( getRequestEvent().getAttribute( "ChannelElementID" ) ).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}	
	
	
	public void testExecuterForShowChannelElementDetailEvent_remoteException(){
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TPMultiChannelDataAccess.class,TPMultiChannelDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(ChannelElementsAdminProcessor.class,ChannelElementsAdminProcessorMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("Conferma").anyTimes() ;
		expecting(getStateMachineSession().put((String) EasyMock.anyObject(),(Hashtable) EasyMock.anyObject())).andReturn("").anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelElementsColl" ) ).andReturn(getChannelElementsMap()).anyTimes();
		expecting( getStateMachineSession( ).get(  "ChannelDefinitionColl") ).andReturn(new Hashtable()).anyTimes();
		expecting( getRequestEvent().getAttribute( "ChannelElementID" ) ).andReturn("1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}	
	
	private Hashtable<Long,ChannelElementsView> getChannelElementsMap(){
		final Hashtable<Long,ChannelElementsView> channelElementsMap = new Hashtable();
		final ChannelElementsView channelElementsView1 = new ChannelElementsView(); 
		channelElementsView1.setChannelDefinitionId(1L);
		channelElementsView1.setChannelElementId(1L);
		channelElementsView1.setChannelElementValue("abcd");
		channelElementsView1.setIdBanca(1L);
		channelElementsMap.put(1L, channelElementsView1);
		return channelElementsMap;
	}
	
}
