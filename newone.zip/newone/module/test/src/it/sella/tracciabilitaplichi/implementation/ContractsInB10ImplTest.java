/*package it.sella.tracciabilitaplichi.implementation;


import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.ConnectionLifeCycleMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ContractsInB10View;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ContractsInB10ImplTest {
	
	@Before
	public void setUp() throws Exception {
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_TR_CTR_IN_B10( CB_ID numeric(12), CB_BD_ID numeric(12), CB_USER_CODE varchar(12),CB_USER_CDR varchar(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("INSERT INTO TP_TR_CTR_IN_B10( CB_ID, CB_BD_ID, CB_USER_CODE,CB_USER_CDR ) VALUES(1,1,'CS21','099231')");
	}
	
	ContractsInB10Impl contractsInB10Impl=new ContractsInB10Impl();
	
	@Test
	public void cancelliOggetto_01()
	{
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final ContractsInB10View contractsInB10View=getcontractsInB10View();
		try {
			contractsInB10Impl.cancelliOggetto(contractsInB10View);
		} catch (final TracciabilitaException e) {
		}
	}

	@Test
	public void cancelliOggetto_02()
	{
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifeCycleMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final Properties properties=getProperties();
		try {
			contractsInB10Impl.cancelliOggetto(properties);
		} catch (final TracciabilitaException e) {
		}
	}
	
	private static Collection<ContractsInB10View> getCollection()
	{
		final ContractsInB10View contractsInB10View=getcontractsInB10View();
		final Collection<ContractsInB10View> contractsInB10ViewsCollection=new ArrayList<ContractsInB10View>();
		contractsInB10ViewsCollection.add(contractsInB10View);
		return contractsInB10ViewsCollection;
	}
	
	private static Properties getProperties()
	{
		final Collection<ContractsInB10View> contractsInB10ViewsCollection=getCollection();
		final Properties properties=new Properties();
		properties.put(CONSTANTS.CONTRACTS_IN_B10,contractsInB10ViewsCollection );
		return properties;
	}
	
	public static ContractsInB10View getcontractsInB10View()
	{
		final ContractsInB10View contractsInB10View=new ContractsInB10View();
		contractsInB10View.setContractId(2L);
		contractsInB10View.setId(1L);
		return contractsInB10View;
	}
	
	@After
	public void tearDown() throws Exception {
		SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_TR_CTR_IN_B10");
	}

	
}
*/