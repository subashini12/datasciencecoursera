package it.sella.tracciabilitaplichi.executer.test.gestorealtriplichi;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.gestorealtriplichi.DisplayPageExecuter;

import java.util.Hashtable;

import junit.framework.TestCase;

public class DisplayPageExecuterTest extends TestCase
{
    RequestEvent        requestEvent        = null;
    StateMachineSession stateMachineSession = null;

    public DisplayPageExecuterTest( final String name )
    {
        super( name );
    }

    @Override
	protected void setUp( ) throws Exception
    {
        super.setUp( );
        this.requestEvent = createMock( RequestEvent.class );
        this.stateMachineSession = createMock( StateMachineSession.class );
    }

    public void testDisplayPageExecuter_01( )
    {
        callExecuter( "ONE:TWO" );
    }

    public void testDisplayPageExecuter_02( )
    {
        callExecuter( "" );
    }

    public void testDisplayPageExecuter_03( )
    {
        callExecuter( null );
    }

    private void callExecuter( final String checkedIds )
    {
        expect( this.requestEvent.getAttribute( "BarCode" ) ).andReturn( "1234567890123" );
        expect( this.requestEvent.getAttribute( "Cdr" ) ).andReturn( "IN2030" );
        expect( this.requestEvent.getAttribute( "checkedIds" ) ).andReturn( checkedIds );
        expect( this.requestEvent.getAttribute( "pageNumber" ) ).andReturn( "2" );
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        final Hashtable hashTable = new Hashtable( 2 );
        hashTable.put( "PageNo", "1" );
        hashTable.put( "pageInfo", new Hashtable( 1 ) );
        expect( this.stateMachineSession.get( "AltriPlichiHashTable" ) ).andReturn( hashTable );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult actual = new DisplayPageExecuter( ).execute( this.requestEvent );
        assertEquals( "1234567890123", actual.getAttribute( "BarCode" ) );
        assertEquals( "IN2030", actual.getAttribute( "Cdr" ) );
        assertEquals( "TrDisplayPage", actual.getTransition( ) );
    }

    @Override
	protected void tearDown( ) throws Exception
    {
    	 requestEvent        = null;
    	 stateMachineSession = null;
       
    }

}
