package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.PlichiContentsPushFromSummaryExecuter;

import java.util.Stack;

import junit.framework.TestCase;

public class PlichiContentsPushFromSummaryExecuterTest extends TestCase
{
    RequestEvent requestEvent = null;
    StateMachineSession stateMachineSession = null;
    public PlichiContentsPushFromSummaryExecuterTest( final String name )
    {
        super( name );
    }

    protected void setUp( ) throws Exception
    {
        super.setUp( );
        this.requestEvent = createMock( RequestEvent.class );
        this.stateMachineSession = createMock( StateMachineSession.class );
    }
    public void testPlichiContentsPushFromSummaryExecuter( )
    {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.requestEvent.getAttribute( "ID" ) ).andReturn( "2" );
        expect( this.stateMachineSession.put( "SearchFrom", "BustaDeici" ) ).andReturn( "BustaDeici" );
        final Stack stack = new Stack( );
        stack.push( "2" );
        expect( this.stateMachineSession.put( "BarCodeStack", stack ) ).andReturn( stack );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult actual = new PlichiContentsPushFromSummaryExecuter( ).execute( this.requestEvent );
        assertEquals( "TrConferma", actual.getTransition( ) );
    }
    protected void tearDown( ) throws Exception
    {
        super.tearDown( );
    }

}
