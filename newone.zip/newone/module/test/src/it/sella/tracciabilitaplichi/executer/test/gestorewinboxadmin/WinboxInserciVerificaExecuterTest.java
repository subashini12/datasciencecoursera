package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.Processor;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxInserciVerificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

public class WinboxInserciVerificaExecuterTest extends AbstractSellaExecuterMock 
{   
	final WinboxInserciVerificaExecuter executer = new WinboxInserciVerificaExecuter();

	public WinboxInserciVerificaExecuterTest(final String name) 
	{
		super(name);
	}	
	
	public void testWinboxInserciVerificaExecuter_forResultNullCase()
	{
		
		
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		playAll();
		executer.execute( getRequestEvent() );				
	}
	
	public void testWinboxInserciVerificaExecuter_forGRANTS_COLLECTION()
	{
		ProcessorMock.setPratica();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		playAll();
		executer.execute( getRequestEvent() );		
	}
	public void testWinboxInserciVerificaExecuter_forResultOneNotNullCase()
	{
		ProcessorMock.setResultNotNull();
		ProcessorMock.setPratica();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		playAll();
		executer.execute( getRequestEvent() );		
	}
	
	
	public void testWinboxInserciVerificaExecuter_forRemoteException()
	{
		ProcessorMock.setRemoteException();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		playAll();
		executer.execute( getRequestEvent() );		
	}

	public void testWinboxInserciVerificaExecuter_forTracciabilitaException()
	{
		ProcessorMock.setTracciabilitaException();
		expecting( getRequestEvent().getAttribute(CONSTANTS.TIPO_OGGETTO.getValue( ))).andReturn("01").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.ABILITATO.getValue( ))).andReturn("0").anyTimes();
		expecting( getRequestEvent().getAttribute("Desc")).andReturn("abc").anyTimes();
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("123").anyTimes();
		expecting( getRequestEvent().getAttribute( CONSTANTS.CUSTOM_ACCESS.getValue( ) )).andReturn("1").anyTimes();
		setUpMockMethods( Processor.class, ProcessorMock.class);
		setUpMockMethods( WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		playAll();
		executer.execute( getRequestEvent() );		
	}	
}
