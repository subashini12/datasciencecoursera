package it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.processor;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

/**
 * @author gbs03134
 * 
 */
public class RicezionePlichiArchivioPB10ProcessorTest extends
		AbstractSellaExecuterMock {
	public RicezionePlichiArchivioPB10ProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezionePlichiArchivioPB10Processor processor = new RicezionePlichiArchivioPB10Processor();

	public void testRicezionePlichiArchivioPB10Processor_01() {
		setUpMockMethods(Util.class,UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		try {
			processor.executeB10Records(getRequestEvent());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public void testRicezionePlichiArchivioPB10Processor_02() {
		UtilMock.setNumericFalse();
		setUpMockMethods(Util.class,UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		expecting(getStateMachineSession().get("GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("barCodeStr")).andReturn("").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		try {
			processor.executeB10Records(getRequestEvent());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	private Map getMap() {
		final Map map = new HashMap();
		map.put("OggettoType","");
		map.put("PlichiToBeReceived",1l);
		map.put("PlichiReceived",1l);
		map.put("TypesOfOggettos", "");
		map.put(CONSTANTS.IS_ENDORSER_VISIBLE.toString( ), "");
		return map;
	}
}
