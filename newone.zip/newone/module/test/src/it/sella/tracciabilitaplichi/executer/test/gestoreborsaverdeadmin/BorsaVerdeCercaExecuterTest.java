package it.sella.tracciabilitaplichi.executer.test.gestoreborsaverdeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestoreborsaverdeadmin.BorsaVerdeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.interfaces.dao.IBorsaVerdeDataAccess;
import it.sella.tracciabilitaplichi.persistence.dao.AbstractDAOFactory;

import java.util.Hashtable;
import java.util.Map;

public class BorsaVerdeCercaExecuterTest  extends AbstractSellaExecuterMock {

    BorsaVerdeCercaExecuter  BorsaVerdeCercaExecuter = new  BorsaVerdeCercaExecuter();
    private IBorsaVerdeDataAccess borsaVerdeDataAccess = null;
    
   public  BorsaVerdeCercaExecuterTest(final String name) {
       super(name);
   }

   @Override
protected void setUp( ) throws Exception
   {
	   super.setUp( );
	   borsaVerdeDataAccess = getMock( IBorsaVerdeDataAccess.class );
	   redefineMethod( AbstractDAOFactory.class, new Object( ) {
		   public IBorsaVerdeDataAccess getBorsaVerdeDataAccess ( )
		   {
			   return borsaVerdeDataAccess;
		   }
	   });
   }
   public void testBorsaVerdeCercaExecuter_01() {
       final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
 
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,archivoBustaCinqueSession)).andReturn(
               archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "") ;
       playAll();
       final ExecuteResult executeResult =  BorsaVerdeCercaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("Failure"));
       assertEquals(executeResult.getAttribute( "MESSAGE" ), "TRPL-1059");
   }
   public void testBorsaVerdeCercaExecuter_02() {
       final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
 
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,archivoBustaCinqueSession)).andReturn(
               archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "gutu") ;
       playAll();
       final ExecuteResult executeResult =  BorsaVerdeCercaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("Failure"));
       assertEquals(executeResult.getAttribute( "MESSAGE" ), "TRPL-1060");
   }
   
   public void testBorsaVerdeCercaExecuter_03() {
    /*   Map  archivoBustaCinqueSession =  new Hashtable( 15 );
 
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,archivoBustaCinqueSession)).andReturn(
               archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "123") ;
       try
       {
		expecting( this.borsaVerdeDataAccess.getBorsaVerdeAttributeView( Long.valueOf( 123L ) ) ).andReturn( null );
       }
       catch ( TracciabilitaException e ) { }
       play( this.borsaVerdeDataAccess );
       playAll();
       ExecuteResult executeResult =  BorsaVerdeCercaExecuter
               .execute(getRequestEvent());*/
   }
   
   public void testBorsaVerdeCercaExecuter_04() {
      /* final Map borsaVerdeMap = new HashMap( );
       final Map borsaVerdeMap1 = new HashMap( );
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,borsaVerdeMap1)).andReturn(
               borsaVerdeMap1);
       borsaVerdeMap.put( ITPConstants.BORSA_VERDE_STATUS_COLLECTION,  new ArrayList() );
       borsaVerdeMap.put( ITPConstants.OLD_STATUS_DESC, "" );
       final BorsaVerdeAttributeView  view = new BorsaVerdeAttributeView();
       borsaVerdeMap.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW, view );
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,borsaVerdeMap)).andReturn(
               borsaVerdeMap);
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "123") ;
       redefineMethod(TracciabilitaPlichiFactory.class, new Object(){
           public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException{
              return  new TracciabilitaPlichiImpl();
           }
       });
       redefineMethod(TracciabilitaPlichiStatusDataAccess.class, new Object(){
           public Collection<ComboView> statusViewList( final Long tipoOggetto ) throws TracciabilitaException{
              return new ArrayList<ComboView>();
           }
       });
       
       redefineMethod(ClassificazioneWrapper.class, new Object(){
       public ClassificazioneView getClassificazioneView( final String causale, final String parentCausale )
       {
           final ClassificazioneView classificazioneView = getMock( ClassificazioneView.class );
           expecting( classificazioneView.getId( ) ).andReturn( 5905L );
           play( classificazioneView );
           return classificazioneView;
       }
   });
       
       try
       {
		expecting( this.borsaVerdeDataAccess.getBorsaVerdeAttributeView( Long.valueOf( 123L ) ) ).andReturn( view );
       }
       catch ( final TracciabilitaException e ) { }
       play( this.borsaVerdeDataAccess );

       playAll();
       final ExecuteResult executeResult =  BorsaVerdeCercaExecuter
               .execute(getRequestEvent());*/
   }
   public void testBorsaVerdeCercaExecuter_05() {
     /*  final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
 
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,archivoBustaCinqueSession)).andReturn(
               archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "123") ;
       redefineMethod(TracciabilitaPlichiFactory.class, new Object(){
           public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException{
            throw new TracciabilitaException();
           }
       });
       playAll();
       final ExecuteResult executeResult =  BorsaVerdeCercaExecuter
               .execute(getRequestEvent());*/
   }
   public void testBorsaVerdeCercaExecuter_06() {
      /* final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
 
       expecting(getStateMachineSession( ).put( ITPConstants.BORSA_VERDE_MAP ,archivoBustaCinqueSession)).andReturn(
               archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "123") ;
       redefineMethod(TracciabilitaPlichiFactory.class, new Object(){
           public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException{
            throw new RemoteException();
           }
       });
       playAll();
       final ExecuteResult executeResult =  BorsaVerdeCercaExecuter
           .execute(getRequestEvent()); */   
   }
}
