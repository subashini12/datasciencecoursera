package it.sella.tracciabilitaplichi.executer.gestorehostlidattributeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.HostlIdAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.HostlIdAttributeAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import mockit.Mockit;

public class HostlIdAttributeConfermaModificaExecuterTest extends
		AbstractSellaExecuterMock {

	public HostlIdAttributeConfermaModificaExecuterTest(final String name) {
		super(name);
	}

	HostlIdAttributeConfermaModificaExecuter executer = new HostlIdAttributeConfermaModificaExecuter();

	public void testHostlIdAttributeConfermaModificaExecuter_01() {
		TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(HostlIdAttributeAdminImpl.class,HostlIdAttributeAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("HostIdAttributeHt")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("HostIdAttributeHt")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TRPL-1055",executeResult.getAttribute(ITPConstants.MSG));
		assertEquals("yes",executeResult.getAttribute(ITPConstants.SUCCESS));
	}

	public void testHostlIdAttributeConfermaModificaExecuter_02() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(HostlIdAttributeAdminImpl.class,HostlIdAttributeAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("HostIdAttributeHt")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("HostIdAttributeHt")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getAttribute(ITPConstants.MSG));
		assertEquals(null,executeResult.getAttribute(ITPConstants.SUCCESS));
	}
	
	public void testHostlIdAttributeConfermaModificaExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(HostlIdAttributeAdminImpl.class,HostlIdAttributeAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("HostIdAttributeHt")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("HostIdAttributeHt")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getAttribute(ITPConstants.MSG));
		assertEquals(null,executeResult.getAttribute(ITPConstants.SUCCESS));
	}

}
