/*package it.sella.tracciabilitaplichi.executer.test.inserimentobustadieci;

import it.sella.tracciabilitaplichi.implementation.bustadieci.inserimento.InserimentoContrattiViewHelper;
import it.sella.tracciabilitaplichi.implementation.bustadieci.test.inserimento.InserimentoContrattiViewHelperMock;
import mockit.Mockit;

class ViewHelperMock
{
	public static final void mockViewHelper( )
	{
		Mockit.redefineMethods( InserimentoContrattiViewHelper.class, InserimentoContrattiViewHelperMock.class  ) ;
	}	
}
*/