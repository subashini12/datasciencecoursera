package it.sella.tracciabilitaplichi.executer.gestoreplichialtriattributeadmin;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.PAltriAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.PAltriAttributeAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.PAltriAttributeView;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

public class PlichiAltriAttributeConfermaModificaExecuterTest extends
		AbstractSellaExecuterMock {

	public PlichiAltriAttributeConfermaModificaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiAltriAttributeConfermaModificaExecuter executer = new PlichiAltriAttributeConfermaModificaExecuter();

	public void testPlichiAltriAttributeConfermaModificaExecuter_01() {
		TracciabilitaPlichiImplMock.setCdr();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getStateMachineSession().get("PlichiAltriAttributeTable"))
				.andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testPlichiAltriAttributeConfermaModificaExecuter_02() {
     		TracciabilitaPlichiImplMock.setCdr();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(PAltriAttributeAdminImpl.class, PAltriAttributeAdminImplMock.class);
			expecting(getStateMachineSession().get("PlichiAltriAttributeTable"))
					.andReturn((Serializable) getMap()).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}

	public void testPlichiAltriAttributeConfermaModificaExecuter_03() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(PAltriAttributeAdminImpl.class, PAltriAttributeAdminImplMock.class);
			expecting(getStateMachineSession().get("PlichiAltriAttributeTable"))
					.andReturn((Serializable) getMap()).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}
	
	public void testPlichiAltriAttributeConfermaModificaExecuter_04() {
		TracciabilitaPlichiImplMock.setRemoteException();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			setUpMockMethods(PAltriAttributeAdminImpl.class, PAltriAttributeAdminImplMock.class);
			expecting(getStateMachineSession().get("PlichiAltriAttributeTable"))
					.andReturn((Serializable) getMap()).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}
	public Map getMap() {
		final Map map = new HashMap();
		map.put("NewPAltriAttributeView", getAltriAttributeView());
		return map;
	}

	public PAltriAttributeView getAltriAttributeView() {
		final PAltriAttributeView pAltriAttributeView = new PAltriAttributeView();
		return pAltriAttributeView;
	}
}
