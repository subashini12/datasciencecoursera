package it.sella.tracciabilitaplichi.executer.test.gestorebustadeiciattributesadmin.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.rmi.RemoteException;
import java.util.HashMap;

import mockit.Mock;

public class DeiciAttributeConfermaProcessorMock 
{
	private static Boolean tracciabilitaException = false;	
	private static Boolean remoteException = false;
	private static Boolean isResDetailscontainsErrorKey = false;
	 
	 public  static void setResDetailscontainsAsErrorKey() 
	 {
		 isResDetailscontainsErrorKey = true;
	 }
	
	 public  static void setTracciabilitaException() 
	 {
			  tracciabilitaException = true;
	 }
	 public  static void setRemoteException() 
	 {
		 remoteException = true;
     }

	@Mock
	public static HashMap validateEvent( RequestEvent rqEvent ) throws TracciabilitaException, RemoteException
	{
		if(tracciabilitaException)
		{
	    	tracciabilitaException = false;
	    	throw new TracciabilitaException();
		}
	    if( remoteException )
	    {
	          remoteException = false;
	    	  throw new RemoteException();
	    }		
		HashMap result = new HashMap(2);
		BustaDeiciAttributeView bdView = new BustaDeiciAttributeView();
		bdView.setAnagrafica("abc");
		bdView.setCodiceDipendenteLastControl("codiceDipLastCon");
		bdView.setCodProdottoContratto("codProdCont");
		result.put("View", bdView);
		if (isResDetailscontainsErrorKey) 
		{
			isResDetailscontainsErrorKey = false;
			result.put("Error", "please enter properly");
			result.put("Argument", "IGI-001");
		}
		return result;
	}
	
}
