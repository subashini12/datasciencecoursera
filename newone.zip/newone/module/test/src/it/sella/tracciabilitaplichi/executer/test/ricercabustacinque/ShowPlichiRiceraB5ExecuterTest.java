package it.sella.tracciabilitaplichi.executer.test.ricercabustacinque;

import it.sella.tracciabilitaplichi.executer.ricercabustacinque.ShowPlichiRiceraB5Executer;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TransactionHistoryDeciderMock;
import it.sella.tracciabilitaplichi.implementation.util.TransactionHistoryDecider;

import org.easymock.EasyMock;

public class ShowPlichiRiceraB5ExecuterTest extends AbstractSellaExecuterMock
{

	public ShowPlichiRiceraB5ExecuterTest(final String name) 
	{
		super(name);
	}

	ShowPlichiRiceraB5Executer executer = new ShowPlichiRiceraB5Executer();
	
	public void testShowPlichiRiceraB5Executer_forsearchBustaDeiciIf()
	{
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting( getStateMachineSession().remove( "SearchFrom" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "isOneRec" ) ).andReturn(null).anyTimes();
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "0123456789123" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "SearchFrom" )).andReturn( "BustaDeici" ).anyTimes();
		EasyMock.expect( getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiRiceraB5Executer_forsearchBustaDeiciElse()
	{
		TransactionHistoryDeciderMock.setFormNameAsHistory();
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting( getStateMachineSession().remove( "SearchFrom" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "isOneRec" ) ).andReturn(null).anyTimes();
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "0123456789123" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "SearchFrom" )).andReturn( "BustaDeici" ).anyTimes();
		EasyMock.expect( getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testShowPlichiRiceraB5Executer_forSearchFormNotBustaDeici()
	{
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(HistoryCommonDataAccess.class, HistoryCommonDataAccessMock.class);
		expecting( getStateMachineSession().remove( "SearchFrom" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "isOneRec" ) ).andReturn(null).anyTimes();
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "0123456789123" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "SearchFrom" )).andReturn( "NoBustaDeici" ).anyTimes();
		EasyMock.expect( getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiRiceraB5Executer_forTracciabilitaException()
	{
		TransactionHistoryDeciderMock.setTracciabilitaException();
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting( getStateMachineSession().remove( "SearchFrom" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "isOneRec" ) ).andReturn(null).anyTimes();
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "0123456789123" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "SearchFrom" )).andReturn( "BustaDeici" ).anyTimes();
		EasyMock.expect( getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
	
	public void testShowPlichiRiceraB5Executer_forRemoteException()
	{
		TransactionHistoryDeciderMock.setRemoteException();
		setUpMockMethods(TransactionHistoryDecider.class, TransactionHistoryDeciderMock.class);
		expecting( getStateMachineSession().remove( "SearchFrom" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "isOneRec" ) ).andReturn(null).anyTimes();
		expecting( getRequestEvent().getAttribute( "BarCode" )).andReturn( "0123456789123" ).anyTimes();
		expecting( getRequestEvent().getAttribute( "SearchFrom" )).andReturn( "BustaDeici" ).anyTimes();
		EasyMock.expect( getStateMachineSession().put( (String ) EasyMock.anyObject(), (String )  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();		
		executer.execute(getRequestEvent());
	}
}
