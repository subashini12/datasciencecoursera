package it.sella.tracciabilitaplichi.implementation.borsaverde;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.Properties;

import mockit.Mock;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.mock.jdbc.MockConnection;

public class AbstractBorsaVerdeImplMock extends BasicJDBCTestCaseAdapter{
	
	private static MockConnection connection = null ;
	
	@Mock
	public Long censitoOggetto(final Properties properties)
			throws TracciabilitaException, RemoteException {
		return 1L;
	}

	@Mock
	public void modificaOggetto(final Properties properties)
			throws TracciabilitaException, RemoteException {
		return;
	}

	@Mock
	public void cancelliOggetto(final Properties properties)
			throws TracciabilitaException, RemoteException {
		return;
	}
	
	@Mock
	Connection getConnection( ) throws TracciabilitaException
    {
		connection=getJDBCMockObjectFactory().getMockConnection();
		return connection;
    }
	
	public static MockConnection getMockConnection()
	{
		return connection ;
	}
}
