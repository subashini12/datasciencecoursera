package it.sella.tracciabilitaplichi.executer.gestorepbustaneraattributeadmin;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class PBustaNeraAttributeInserireExecuterTest extends
		AbstractSellaExecuterMock {

	public PBustaNeraAttributeInserireExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PBustaNeraAttributeInserireExecuter executer = new PBustaNeraAttributeInserireExecuter();

	public void testPBustaNeraAttributeInserireExecuter_01() {
			TracciabilitaPlichiImplMock.setBustaNera();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(Util.class, UtilMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("conferma").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute")).andReturn((Serializable) getMap()).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}

	public void testPBustaNeraAttributeInserireExecuter_02() {
			TracciabilitaPlichiImplMock.setRemoteException();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(Util.class, UtilMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("indietro").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute")).andReturn((Serializable) getMap()).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}

	public void testPBustaNeraAttributeInserireExecuter_03() {
			TracciabilitaPlichiImplMock.setTracciabilitaException();
			setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(Util.class, UtilMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
			expecting(getRequestEvent().getEventName()).andReturn("conferma").anyTimes();
			expecting(getStateMachineSession().get("mapPBustaNeraAttribute")).andReturn((Serializable) getMap()).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
	}

	public void testPBustaNeraAttributeInserireExecuter_04() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		expecting(getRequestEvent().getEventName()).andReturn("conferma").anyTimes();
		expecting(getStateMachineSession().get("mapPBustaNeraAttribute")).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public static Map getMap() {
		final Map map = new HashMap();
		map.put("docId", "1");
		map.put("date", "12/02/2012");
		map.put("importo", "");
		map.put("note", "");
		map.put("description", "");
		return map;
	}
}
