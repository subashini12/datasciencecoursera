package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class PlichiContentsDefaultProcessorMock {
	
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;
	
	
	public static void setRemoteException() {
		remoteException = true;
	}
	
	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}
	
	@Mock
	public static ExecuteResult processRecords(final RequestEvent requestEvent,
			final String barCode, final String causale, final String status)
			throws TracciabilitaException, RemoteException {
		return null;
	}
	@Mock
	   public static Collection getOggettoStatusReferenceColl( final RequestEvent reqEvent, final String barcodeOrBdID ) throws RemoteException, TracciabilitaException
	    {
		
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		
		if (remoteException) {
			throw new RemoteException();
		}
		
		Collection collection=new ArrayList();
		return collection;
		
	    }
}
