package it.sella.tracciabilitaplichi.executer.test.inserimentobustadieci;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.InserimentoContrattiHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

public class InsertBarcodeActionTest extends AbstractSellaExecuterMock
{

	public InsertBarcodeActionTest( final String name )
	{
		super( name );
	}
	
	public void testInsertBarcodeAction_1( )
	{
	/*	mockContrattiHelper( Boolean.FALSE );
		mockViewHelper( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.ABILITATO.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		playAll( );
		AbstractInserimentoExecuter executer = new InsertBarcodeAction( );
		final ExecuteResult executeResult = executer.execute( getRequestEvent( ) );
		assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), executeResult.getTransition( ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.VIEW_HELPER.toString( ) ) );*/
	}
	
	public void testInsertBarcodeAction_2( )
	{
		/*mockContrattiHelper( Boolean.TRUE );
		mockViewHelper( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.ABILITATO.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		playAll( );
		final AbstractInserimentoExecuter executer = new InsertBarcodeAction( );
		final ExecuteResult executeResult = executer.execute( getRequestEvent( ) );
		assertNull( executeResult.getTransition( ) );
		assertNotNull( executeResult.getAttribute( CONSTANTS.VIEW_HELPER.toString( ) ) );*/
	}
	
	private void mockContrattiHelper( final Boolean isException )
	{
		redefineMethod( InserimentoContrattiHelper.class, new Object( ) {
			public Map<Enum<CONSTANTS>, Object> getSessionMap( final RequestEvent requestEvent )
			{
				return new HashMap<Enum<CONSTANTS>, Object>( 1 ); 
			}
			public Enum<CONSTANTS> validateBarcode( final RequestEvent requestEvent ) throws TracciabilitaException, RemoteException
			{
				if ( isException )
				{
					throw new RemoteException( "TrRemoteException" );
				}
				return CONSTANTS.TR_CONFERMA;
			}
		} );
	}
	
	
}
