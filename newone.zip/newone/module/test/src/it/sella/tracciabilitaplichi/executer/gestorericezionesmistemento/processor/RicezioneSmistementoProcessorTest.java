package it.sella.tracciabilitaplichi.executer.gestorericezionesmistemento.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiImplDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiImplDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;


/**
 * @author gbs03134
 *
 */

public class RicezioneSmistementoProcessorTest extends AbstractSellaExecuterMock{

	public RicezioneSmistementoProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	RicezioneSmistementoProcessor processor = new RicezioneSmistementoProcessor();
	

	public void testProcessIfValidBN_01()
	{
		ClassificazioneWrapperMock.setBUSTN();
		setUpMockMethods(TracciabilitaPlichiImplDataAccess.class, TracciabilitaPlichiImplDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		try {
			processor.processIfValidBN("1234890543212", "2");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testProcessIfValidBN_02()
	{
		TracciabilitaPlichiCommonDataAccessMock.setNullTracciabilitaPlichiView();
		ClassificazioneWrapperMock.setBUSTN();
		setUpMockMethods(TracciabilitaPlichiImplDataAccess.class, TracciabilitaPlichiImplDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		try {
			processor.processIfValidBN("1234890543212", "2");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testProcessIfValidBN_03()
	{
		TracciabilitaPlichiCommonDataAccessMock.setWrongStatusType();
		setUpMockMethods(TracciabilitaPlichiImplDataAccess.class, TracciabilitaPlichiImplDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		try {
			processor.processIfValidBN("1234890543212", "2");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testGetPropertiesForView_01()
	{
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(TPUtil.class,TPUtilMock.class);
		try {
			processor.getPropertiesForView(getTracciabilitaPlichiView());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testGetPropertiesForView_02()
	{
		TracciabilitaPlichiSmistamentoDataAccessMock.setBustaNeraCountForPBustaNera();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(TPUtil.class,TPUtilMock.class);
		try {
			processor.getPropertiesForView(getTracciabilitaPlichiView());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testVerifyStatus_01()
	{
		ClassificazioneWrapperMock.setPBUSTN();
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiImplDataAccess.class, TracciabilitaPlichiImplDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		try {
			processor.verifyStatus(getTracciabilitaPlichiView(), "12");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testVerifyStatus_02()
	{
		ClassificazioneWrapperMock.setBUSTN();
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiImplDataAccess.class, TracciabilitaPlichiImplDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		try {
			processor.verifyStatus(getTracciabilitaPlichiView(), "12");
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private static TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setReferenceId(1L);
		oggettoView.setCdrName("099231");
		oggettoView.setStatusType("ST_70");
		oggettoView.setOggettoType(2L);
		oggettoView.setId(2L);
		final PlichiAttributeView plichiAttributeView=new PlichiAttributeView();
		plichiAttributeView.setCdrDestination("099231");
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		tracciabilitaPlichiView.setPlichiAttributeView(plichiAttributeView);
		return tracciabilitaPlichiView;
	}
	
}
