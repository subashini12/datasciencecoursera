package it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.StoricoRicercaBustaCinqueFiltraExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.view.RicercaView;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class StoricoRicercaBustaCinqueFiltraExecuterTest extends AbstractSellaExecuterMock
{
	StoricoRicercaBustaCinqueFiltraExecuter storicoRicercaBustaCinqueFiltraExecuter = new StoricoRicercaBustaCinqueFiltraExecuter();
	public StoricoRicercaBustaCinqueFiltraExecuterTest(String name) {
		super(name);
	}
	
	public void testStoricoRicercaBustaCinqueFiltraExecuter_01()
	{
		Date date = new Date("2012,jan,9");
		Timestamp timeStamp = new Timestamp(date.getDate());
		RicercaView ricercaView=new RicercaView();
		ricercaView.setLid("");
		ricercaView.setCdrDesc("Description");
		ricercaView.setBarCode("1234567891234");
		ricercaView.setActualDate(timeStamp);
		ricercaView.setStatusDesc(null);
		ArrayList arrayList=new ArrayList();
		arrayList.add(ricercaView);
		final Map sessionMap = new HashMap(  );
		sessionMap.put("RicercaCollRicercaView", arrayList);
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn((Serializable)sessionMap);
		expecting( getRequestEvent().getAttribute("datedd")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("datemm")).andReturn( "05" ).anyTimes();
        expecting( getRequestEvent().getAttribute("dateyyyy")).andReturn( "2011" ).anyTimes();
        expecting( getRequestEvent().getAttribute("lid")).andReturn( "1*23456*77" ).anyTimes();
        expecting( getRequestEvent().getAttribute("userCode")).andReturn( "BSA09" ).anyTimes();
        expecting( getRequestEvent().getAttribute("senderCdr")).andReturn( "BA090" ).anyTimes();
        expecting( getRequestEvent().getAttribute("senderDenominazione")).andReturn( "ASda" ).anyTimes();
        expecting( getRequestEvent().getAttribute("barCode")).andReturn( "33333333333332" ).anyTimes();
        expecting( getRequestEvent().getAttribute("barCodePlico")).andReturn( "233333333333" ).anyTimes();
        expecting( getRequestEvent().getAttribute("boxId")).andReturn( "1234566" ).anyTimes();
        expecting( getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION", sessionMap) ).andReturn(sessionMap);
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueFiltraExecuter.execute(getRequestEvent());
	}
	
	public void testStoricoRicercaBustaCinqueFiltraExecuter_02()
	{
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		Date date = new Date("2012,jan,9");
		Timestamp timeStamp = new Timestamp(date.getDate());
		RicercaView ricercaView=new RicercaView();
		ricercaView.setLid("");
		ricercaView.setCdrDesc("Description");
		ricercaView.setBarCode("1234567891234");
		ricercaView.setActualDate(timeStamp);
		ricercaView.setStatusDesc("");
		ArrayList arrayList=new ArrayList();
		arrayList.add(ricercaView);
		final Map sessionMap = new HashMap(  );
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn((Serializable)sessionMap);
		expecting( getRequestEvent().getAttribute("datedd")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("datemm")).andReturn( "05" ).anyTimes();
        expecting( getRequestEvent().getAttribute("dateyyyy")).andReturn( "2011" ).anyTimes();
        expecting( getRequestEvent().getAttribute("lid")).andReturn( "1*23456*77" ).anyTimes();
        expecting( getRequestEvent().getAttribute("userCode")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("senderCdr")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("senderDenominazione")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("barCode")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("barCodePlico")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("boxId")).andReturn( "" ).anyTimes();
        expecting( getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION", sessionMap) ).andReturn(sessionMap);
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueFiltraExecuter.execute(getRequestEvent());
	}
} 

