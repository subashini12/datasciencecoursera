package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import mockit.Mock;

public class ContrattiProdottoAdminImplMock {
	@Mock
	public void modificaOggetto(final TPView contrattiProdottoView)
			throws TracciabilitaException {
		return;
	}

	@Mock
	public void censitoOggetto(final TPView contrattiProdottoView)
			throws TracciabilitaException {
		return;
	}
}
