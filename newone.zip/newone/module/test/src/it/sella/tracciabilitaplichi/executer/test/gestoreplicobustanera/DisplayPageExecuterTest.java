package it.sella.tracciabilitaplichi.executer.test.gestoreplicobustanera;

import it.sella.tracciabilitaplichi.executer.gestoreplicobustanera.DisplayPageExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Hashtable;

public class DisplayPageExecuterTest extends AbstractSellaExecuterMock
{

	public DisplayPageExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	DisplayPageExecuter executer = new DisplayPageExecuter();
	
	public void testDisplayPageExecuter_01()
	{
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn("a:b:c:").anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  getPreparazioneBustaNeraHashTable() );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDisplayPageExecuter_02()
	{
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().get( "PreparazioneBustaNeraHashTable" )).andReturn(  getPreparazioneBustaNeraHashTable() );
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private Hashtable  getPreparazioneBustaNeraHashTable()
	{
		Hashtable PreparazioneBustaNeraHashTable = new Hashtable();
		PreparazioneBustaNeraHashTable.put( "Operation","Conferma-Archive");
		Hashtable pageInfo= new Hashtable();
		pageInfo.put("PageNo",5);		
		PreparazioneBustaNeraHashTable.put( "Hashtable","Conferma-Archive");
		PreparazioneBustaNeraHashTable.put( "pageInfo",pageInfo);
		PreparazioneBustaNeraHashTable.put("PageNo","5");
		return PreparazioneBustaNeraHashTable;
	}
	
}
