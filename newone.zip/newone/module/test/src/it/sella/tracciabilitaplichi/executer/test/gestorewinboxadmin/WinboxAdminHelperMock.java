package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class WinboxAdminHelperMock 
{
  private static Boolean tracciabilitaException = false;
  private static Boolean remoteException = false;
  
	public  static void setTracciabilitaException() 
	{  
		tracciabilitaException = true;
	}
	public  static void setRemoteException() 
	{
		remoteException = true;
	}

	@Mock
	public Map<Enum, Object> getSessionMap( final RequestEvent rqEvent )
	{
		Map map =new HashMap<Enum, Object>( 5 ); 
		Collection collection = new ArrayList();
		collection.add("abcd");
		map.put( CONSTANTS.GRANTS_COLLECTION , collection);
		map.put(CONSTANTS.ERROR_MESSAGE , "errorMessage");
		return map;
	}
	@Mock
	public void setDefaultGrants( final RequestEvent requestEvent ) throws TracciabilitaException, RemoteException 
    {		
		if( remoteException )
		{  
			remoteException = false;
			throw new RemoteException();
		}
		if( tracciabilitaException )
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		return ;
    }
	
	@Mock
	public void setGrantsForGivenId ( final RequestEvent rqEvent, final AltriWinboxView altriWinboxView ) throws TracciabilitaException, RemoteException
	{
		if( remoteException )
		{  
			remoteException = false;
			throw new RemoteException();
		}
		if( tracciabilitaException )
		{
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		return ;
	}
	
}
