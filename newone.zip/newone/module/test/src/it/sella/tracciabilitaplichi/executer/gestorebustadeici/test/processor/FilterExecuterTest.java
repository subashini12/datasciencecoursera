package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor;

import it.sella.tracciabilitaplichi.executer.gestorebustadeici.FilterExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;



public class FilterExecuterTest extends AbstractSellaExecuterMock{

	public FilterExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	FilterExecuter executer=new FilterExecuter();
	public void testFilterExecuter_01()
	{

	}

	private static void getMap()
	{
	}
}
