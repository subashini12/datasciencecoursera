package it.sella.tracciabilitaplichi.executer.test.gestorebustadeiciattributesadmin;

import it.sella.tracciabilitaplichi.executer.gestorebustadeiciattributesadmin.DeiciAttributesCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.io.Serializable;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class DeiciAttributesCercaExecuterTest extends AbstractSellaExecuterMock
{

	DeiciAttributesCercaExecuter executer = new DeiciAttributesCercaExecuter();
	
	public DeiciAttributesCercaExecuterTest(final String name) 
	{
		super(name);		
	}

	/*public void testDeiciAttributesCercaExecuter_01()
	{
		setUpMockMethods(TPBustaDeiciDataAccess.class, TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "ContrProd" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}*/

	public void testDeiciAttributesCercaExecuter_02()
	{
		setUpMockMethods(TPBustaDeiciDataAccess.class, TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "ContrProd" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "ContrProd" )).andReturn(  new  Hashtable() ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDeiciAttributesCercaExecuter_03()
	{
		TPBustaDeiciDataAccessMock.setBustaDeiciAttributeViewToNull();
		setUpMockMethods(TPBustaDeiciDataAccess.class, TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "ContrProd" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDeiciAttributesCercaExecuter_04()
	{
		expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDeiciAttributesCercaExecuter_05()
	{
		expecting(getRequestEvent().getAttribute("ID")).andReturn("abc").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDeiciAttributesCercaExecuter_06()
	{
		TPBustaDeiciDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TPBustaDeiciDataAccess.class, TPBustaDeiciDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class );
		setUpMockMethods(SecurityWrapper.class , SecurityWrapperMock.class);
		expecting(getRequestEvent().getAttribute("ID")).andReturn("21").anyTimes();
		expecting( getStateMachineSession().containsKey( "ContrProd" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute(getRequestEvent());
	}
}
