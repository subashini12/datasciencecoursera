package it.sella.tracciabilitaplichi.executer.inserimentobustadieci;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;

import mockit.Mock;

public class ValidatorMock {
@Mock

public void validateBarcode( final RequestEvent requestEvent ) throws TracciabilitaException, RemoteException
{
	return ;
}

@Mock
public void validateContratti( final RequestEvent requestEvent ) throws TracciabilitaException, RemoteException
{
	return ;
}
}
