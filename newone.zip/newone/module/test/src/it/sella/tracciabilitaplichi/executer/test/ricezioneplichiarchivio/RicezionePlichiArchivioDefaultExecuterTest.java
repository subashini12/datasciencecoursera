package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.ITracciabilitaPlichi;
import it.sella.tracciabilitaplichi.TracciabilitaPlichiFactory;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.RicezionePlichiArchivioDefaultExecuter;
import it.sella.tracciabilitaplichi.implementation.dao.IGestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ExternalServicesFactory.class,ClassificazioneWrapper.class,HomePageProcessor.class,TracciabilitaPlichiFactory.class})
public class RicezionePlichiArchivioDefaultExecuterTest {
	
	RicezionePlichiArchivioDefaultExecuter defaultExecuter = new RicezionePlichiArchivioDefaultExecuter();
	
	@Test
	public void defaultExecuter_01() {
		
		ITracciabilitaPlichi tracciabilitaPlichi = EasyMock.createMock(ITracciabilitaPlichi.class);
		IGestioneSollecitiDataAccess gestioneSollecitiDataAccess = EasyMock.createMock(IGestioneSollecitiDataAccess.class);
		try {
			EasyMock.expect(gestioneSollecitiDataAccess.getValue(CONSTANTS.ARCHIVATION_ENDORSER_DISPLAY_USERS.toString( ))).andReturn("").anyTimes();
		} catch (TracciabilitaException e) {
			Assert.fail(e.getMessage());
		}
		EasyMock.replay(gestioneSollecitiDataAccess);
		EasyMock.expect(tracciabilitaPlichi.getGestioneSollecitiDataAccess()).andReturn(gestioneSollecitiDataAccess).anyTimes();
		EasyMock.replay(tracciabilitaPlichi);
		
		PowerMock.mockStatic(TracciabilitaPlichiFactory.class);
		TracciabilitaPlichiFactory plichiFactory = EasyMock.createMock(TracciabilitaPlichiFactory.class);
		EasyMock.expect(TracciabilitaPlichiFactory.getInstance()).andReturn(plichiFactory).anyTimes();
		try {
			EasyMock.expect(plichiFactory.getTracciabilitaPlichi()).andReturn(tracciabilitaPlichi).anyTimes();
		} catch (RemoteException e) {
			Assert.fail(e.getMessage());
		} catch (TracciabilitaException e) {
			Assert.fail(e.getMessage());
		}
		EasyMock.replay(plichiFactory);
		PowerMock.replay(TracciabilitaPlichiFactory.class);
		
		ClassificazioneWrapper classificazioneWrapper = PowerMock.createMock(ClassificazioneWrapper.class);
		PowerMock.replay(ClassificazioneWrapper.class);
		
		Map userDetailsMap = new HashMap();
		userDetailsMap.put( CONSTANTS.NAME.getValue( ),"BANU");
		userDetailsMap.put( CONSTANTS.SUR_NAME.getValue( ),"S");
		userDetailsMap.put( CONSTANTS.USER.getValue( ), "BSZI223");
		userDetailsMap.put( CONSTANTS.CDR.getValue( ), "099231" );
		userDetailsMap.put( CONSTANTS.BANK.getValue( ), "1" );
		
		Map map = new HashMap() ;
		map.put(CONSTANTS.IS_ENDORSER_VISIBLE.toString( ),Boolean.TRUE);
		map.put(CONSTANTS.USER_DETAILS.toString( ), userDetailsMap);
		
		PowerMock.mockStatic(HomePageProcessor.class);
		HomePageProcessor homePageProcessor = EasyMock.createMock(HomePageProcessor.class);
		try {
			EasyMock.expect(HomePageProcessor.getUserDetails()).andReturn(userDetailsMap).anyTimes();
		} catch (RemoteException e) {
			Assert.fail(e.getMessage());
		} catch (TracciabilitaException e) {
			Assert.fail(e.getMessage());
		}
		EasyMock.replay(homePageProcessor);
		PowerMock.replay(HomePageProcessor.class);
		
		PowerMock.mockStatic(ExternalServicesFactory.class);
		ExternalServicesFactory externalServicesFactory = EasyMock.createMock(ExternalServicesFactory.class);
		EasyMock.expect(ExternalServicesFactory.getInstance()).andReturn(externalServicesFactory).anyTimes();
		EasyMock.expect(externalServicesFactory.getClassificazioneWrapper()).andReturn(classificazioneWrapper).anyTimes();
		EasyMock.replay(externalServicesFactory);
	    PowerMock.replay(ExternalServicesFactory.class);
		
		StateMachineSession session = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(session.containsKey(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString())).andReturn(true).anyTimes();
		EasyMock.expect(session.get(ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString())).andReturn((Serializable) getPlichiMap()).anyTimes();
		EasyMock.expect(session.put( (String)EasyMock.anyObject(),( Boolean) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		EasyMock.replay(session);
		
		RequestEvent rqEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(rqEvent.getStateMachineSession()).andReturn(session).anyTimes();
		EasyMock.replay(rqEvent);
		
		defaultExecuter.execute(rqEvent);
		
	}
	
	private Map getPlichiMap() {
		Map plichiMap = new Hashtable();
		plichiMap.put("barCodeStr","1044100012555");
		return plichiMap ;
	}
	
}
