package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultB10Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents.processor.PlichiContentsDefaultB10ProcessorMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.B10UltimoEsitoHandlerMock;
import it.sella.tracciabilitaplichi.implementation.util.B10UltimoEsitoHandler;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Stack;

public class ControlloExecuterTest extends AbstractSellaExecuterMock {

	public ControlloExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ControlloExecuter executer = new ControlloExecuter();

	public void testControlloExecuter_01() {
		setUpMockMethods(B10UltimoEsitoHandler.class,
				B10UltimoEsitoHandlerMock.class);
		setUpMockMethods(PlichiContentsDefaultB10Processor.class,
				PlichiContentsDefaultB10ProcessorMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn(null);
		expecting(getRequestEvent().getAttribute("user")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn("note");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testControlloExecuter_02() {
		setUpMockMethods(B10UltimoEsitoHandler.class,
				B10UltimoEsitoHandlerMock.class);
		setUpMockMethods(PlichiContentsDefaultB10Processor.class,
				PlichiContentsDefaultB10ProcessorMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("01");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("02");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("03");
		expecting(getRequestEvent().getAttribute("user")).andReturn("");
		expecting(getRequestEvent().getAttribute("user")).andReturn("user");
		expecting(getRequestEvent().getAttribute("note")).andReturn("");
		expecting(getRequestEvent().getAttribute("note")).andReturn("note");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testControlloExecuter_03() {
		PlichiContentsDefaultB10ProcessorMock.setMapEmpty();
		setUpMockMethods(B10UltimoEsitoHandler.class,
				B10UltimoEsitoHandlerMock.class);
		setUpMockMethods(PlichiContentsDefaultB10Processor.class,
				PlichiContentsDefaultB10ProcessorMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		final Stack stack = getStack();
		expecting(getStateMachineSession().containsKey("collControlliView"))
				.andReturn(true);
		expecting(getStateMachineSession().remove("collControlliView"))
				.andReturn("");
		expecting(getStateMachineSession().containsKey("BarCodeStack"))
				.andReturn(true);
		expecting(getStateMachineSession().get("BarCodeStack"))
				.andReturn(stack);
		expecting(getStateMachineSession().remove("1234567890123")).andReturn(
				"");
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn("01");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn("02");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("");
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn("03");
		expecting(getRequestEvent().getAttribute("user")).andReturn("");
		expecting(getRequestEvent().getAttribute("user")).andReturn("user");
		expecting(getRequestEvent().getAttribute("note")).andReturn("");
		expecting(getRequestEvent().getAttribute("note")).andReturn("note");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testControlloExecuter_04() {
		PlichiContentsDefaultB10ProcessorMock.setRemoteException();
		setUpMockMethods(B10UltimoEsitoHandler.class,
				B10UltimoEsitoHandlerMock.class);
		setUpMockMethods(PlichiContentsDefaultB10Processor.class,
				PlichiContentsDefaultB10ProcessorMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn(null);
		expecting(getRequestEvent().getAttribute("user")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn("note");
		playAll();
		executer.execute(getRequestEvent());
	}

	public void testControlloExecuter_05() {
		PlichiContentsDefaultB10ProcessorMock.setTracciabilitaException();
		setUpMockMethods(B10UltimoEsitoHandler.class,
				B10UltimoEsitoHandlerMock.class);
		setUpMockMethods(PlichiContentsDefaultB10Processor.class,
				PlichiContentsDefaultB10ProcessorMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute("dcgg")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dcmm")).andReturn(null);
		expecting(getRequestEvent().getAttribute("dcaa")).andReturn(null);
		expecting(getRequestEvent().getAttribute("user")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn(null);
		expecting(getRequestEvent().getAttribute("note")).andReturn("note");
		playAll();
		executer.execute(getRequestEvent());
	}

	private static Stack getStack() {
		final Stack stack = new Stack();
		stack.push("1234567890123");
		return stack;
	}

}
