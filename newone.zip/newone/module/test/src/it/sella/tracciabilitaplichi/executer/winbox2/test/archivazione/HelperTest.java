package it.sella.tracciabilitaplichi.executer.winbox2.test.archivazione;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.eao.IGestoreTracciabilitaEAO;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.archivazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione.Winbox2InputProcessorMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.interfaces.dao.IWinbox2DataAccess;
import it.sella.tracciabilitaplichi.persistence.dao.AbstractDAOFactory;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;
import it.sella.tracciabilitaplichi.winbox2.archivazione.Winbox2InputProcessor;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class HelperTest extends AbstractSellaMock
{
	
    private RequestEvent requestEvent = null;
    private StateMachineSession smSession = null;
    private IWinbox2DataAccess winbox2DataAccess = null;
    private static final String VIRTUAL_WB2_BARCODE = "XXXXXGBS01475";
    private static final Collection<String> WB2_OGID_COLL = Arrays.asList( new String[ ] { "1L", "2l" } );
    
	public HelperTest( final String name )
    {
        super( name );
    }

    @Override
	protected void setUp( ) throws Exception
    {
    	setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
    	setUpMockMethods(Winbox2InputProcessor.class, Winbox2InputProcessorMock.class);
        super.setUp( );
        this.requestEvent = createMock( RequestEvent.class );
        this.smSession = createMock( StateMachineSession.class );
        expect( requestEvent.getStateMachineSession( ) ).andReturn( this.smSession );
        redefineMethod( TracciabilitaPlichiImpl.class,  new Object( ){
        	public IGestoreTracciabilitaEAO getManager() throws RemoteException, TracciabilitaException
        	{
        		IGestoreTracciabilitaEAO tracciabilitaEAO = null ;
        		try
        		{
        			if(tracciabilitaEAO == null)
        			{
        				tracciabilitaEAO = (IGestoreTracciabilitaEAO) new InitialContext().lookup("it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean");
        			}
        		}
        		catch ( final NamingException exception )
        		{
        			throw new TracciabilitaException(exception.getMessage(), exception);
        		}
        		return tracciabilitaEAO;
        	}
    	}) ;
        
        winbox2DataAccess = createMock( IWinbox2DataAccess.class );
		redefineMethod( AbstractDAOFactory.class, new Object( ){
			public IWinbox2DataAccess getWinbox2DataAccess( )
			{
				return winbox2DataAccess;
			}
		});

    }

   
    
    public void testGetArchivioSessionMap1( )
    {
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.FALSE );
    	final Map sessionMap = Helper.getArchivioSessionMap( this.smSession );
    	assertEquals( true, ( sessionMap == null ) );
    }
    
    public void testGetArchivioSessionMap2( )
    {
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.TRUE );
    	expect( this.smSession.get( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( new Hashtable( ) );
    	replay( this.smSession );
    	final Map sessionMap = Helper.getArchivioSessionMap( this.smSession );
    	assertEquals( false, ( sessionMap == null ) );
    }

    public void testValidateInput1( )
    {
    	expect( this.requestEvent.getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234455656661" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.CASSETTO_BOX_ID.getValue( ) ) ).andReturn( "" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.IS_VIRTUAL_WB2.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.requestEvent.getAttribute( CONSTANTS.WB2_AT_ARCHIVE.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.TRUE );
    	expect( this.smSession.get( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( new Hashtable( ) );
    	redefineMethod( TracciabilitaPlichiPlichiDataAccess.class, new Object( ){
    		public Long getLastBoxCode( final String plichiType ) throws TracciabilitaException, RemoteException
    		{
    			return Long.valueOf( 1L );
    		}
    	});
    	replay( this.requestEvent );
    	replay( this.smSession );
    	try
		{
        	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
			final String TRANSITION = Helper.validateInput( this.requestEvent, sessionMap );
			assertEquals( CONSTANTS.TR_ERROR.getValue( ), TRANSITION );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.MSG.toString( ) ) );
			assertEquals( true, IErrorCodes.TRPL_1036.equals( sessionMap.get( CONSTANTS.MSG.toString( ) ) ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.LastBoxCode.toString( ) ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.BarCodeStr.toString( ) ) );
			assertEquals( true, "1234455656661".equals( sessionMap.get( CONSTANTS.BarCodeStr.toString( ) ) ) );
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    }
    
    public void testValidateInput2( )
    {
    	expect( this.requestEvent.getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234455656661" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.CASSETTO_BOX_ID.getValue( ) ) ).andReturn( "###" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.IS_VIRTUAL_WB2.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.requestEvent.getAttribute( CONSTANTS.WB2_AT_ARCHIVE.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.TRUE );
    	expect( this.smSession.get( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( new Hashtable( ) );

    	redefineMethod( TracciabilitaPlichiPlichiDataAccess.class, new Object( ){
    		public Long getLastBoxCode( final String plichiType ) throws TracciabilitaException, RemoteException
    		{
    			return Long.valueOf( 1L );
    		}
    	});
    	replay( this.requestEvent );
    	replay( this.smSession );
    	try
		{
        	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
			final String TRANSITION = Helper.validateInput( this.requestEvent, sessionMap );
			assertEquals( CONSTANTS.TR_ERROR.getValue( ), TRANSITION );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.MSG.toString( ) ) );
			assertEquals( IErrorCodes.TRPL_1036, ( ( String ) sessionMap.get( CONSTANTS.MSG.toString( ) ) ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.LastBoxCode.toString( ) ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.BarCodeStr.toString( ) ) );
			assertEquals( true, "1234455656661".equals( sessionMap.get( CONSTANTS.BarCodeStr.toString( ) ) ) );
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    }
    
    public void testValidateInput3( )
    {
    	expect( this.requestEvent.getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( null );
    	expect( this.requestEvent.getAttribute( CONSTANTS.CASSETTO_BOX_ID.getValue( ) ) ).andReturn( "###" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.IS_VIRTUAL_WB2.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.requestEvent.getAttribute( CONSTANTS.WB2_AT_ARCHIVE.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.TRUE );
    	expect( this.smSession.get( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( new Hashtable( ) );

    	redefineMethod( TracciabilitaPlichiPlichiDataAccess.class, new Object( ){
    		public Long getLastBoxCode( final String plichiType ) throws TracciabilitaException, RemoteException
    		{
    			return Long.valueOf( 1L );
    		}
    	});
    	replay( this.requestEvent );
    	replay( this.smSession );
    	try
		{
        	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
			final String TRANSITION = Helper.validateInput( this.requestEvent, sessionMap );
			assertEquals( CONSTANTS.TR_ERROR.getValue( ), TRANSITION );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.LastBoxCode.toString( ) ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.BarCodeStr.toString( ) ) );
			assertEquals( true, "".equals( sessionMap.get( CONSTANTS.BarCodeStr.toString( ) ) ) );
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    }

    public void testValidateInput4( )
    {
    	expect( this.requestEvent.getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( null );
    	expect( this.requestEvent.getAttribute( CONSTANTS.CASSETTO_BOX_ID.getValue( ) ) ).andReturn( "10" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.IS_VIRTUAL_WB2.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.requestEvent.getAttribute( CONSTANTS.WB2_AT_ARCHIVE.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.TRUE );
    	expect( this.smSession.get( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( new Hashtable( ) );

    	replay( this.requestEvent );
    	replay( this.smSession );
    	try
		{
        	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
			final String TRANSITION = Helper.validateInput( this.requestEvent, sessionMap );
			assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), TRANSITION );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.LastBoxCode.toString( ) ) );
			assertEquals( true, Long.valueOf( "10" ).equals( sessionMap.get( CONSTANTS.LastBoxCode.toString( ) ) ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.BarCodeStr.toString( ) ) );
			assertEquals( true, "".equals( sessionMap.get( CONSTANTS.BarCodeStr.toString( ) ) ) );
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    }
    
    public void testValidateInput8( )
    {
    	expect( this.requestEvent.getAttribute( CONSTANTS.BarCodeStr.getValue( ) ) ).andReturn( "1234567891234" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.CASSETTO_BOX_ID.getValue( ) ) ).andReturn( "10" );
    	expect( this.requestEvent.getAttribute( CONSTANTS.IS_VIRTUAL_WB2.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.requestEvent.getAttribute( CONSTANTS.WB2_AT_ARCHIVE.toString( ) ) ).andReturn( Boolean.FALSE.toString( ) );
    	expect( this.smSession.containsKey( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( Boolean.TRUE );
    	expect( this.smSession.get( CONSTANTS.GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION.toString( ) ) ).andReturn( new Hashtable( ) );

    	redefineMethod( Winbox2InputProcessor.class, new Object( ){
    		public void parseBarcodeString( ) throws TracciabilitaException, RemoteException
    		{
    			return;
    		}
    		
    		public Boolean isNeededToShowSiNoPage( )
    		{
    			return Boolean.FALSE;
    		}
    		
    		public Boolean isAnyValidWinBox2ToUpdate ( ) 
    		{
    			return Boolean.FALSE;
    		}
    	});
    	replay( this.requestEvent );
    	replay( this.smSession );
    	try
		{
        	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
			final String TRANSITION = Helper.validateInput( this.requestEvent, sessionMap );
			assertEquals( CONSTANTS.TR_ERROR.getValue( ), TRANSITION );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.MSG.toString( ) ) );
			assertEquals( IErrorCodes.TRPL_1429, ( ( String ) sessionMap.get( CONSTANTS.MSG.toString( ) ) ) );
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    }
    
    public void testSetWinBox2ArchivioPageDetails1( ) 
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
    	sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), new Long( 5 ) );
    	sessionMap.put( CONSTANTS.PlichiReceived.toString( ), new Long( 1 ) );
    	redefineMethod( Winbox2InputProcessor.class, new Object( ){
    		public List<Long> getNoOfWinBox2ToBeArchivedColl ( )
    		{
    			final List<Long> noOfWinBox2ToBeArchivedColl = new ArrayList<Long>( 2 );
    			noOfWinBox2ToBeArchivedColl.add( Long.valueOf( 5L ) );
    			noOfWinBox2ToBeArchivedColl.add( Long.valueOf( 2L ) );
    			return noOfWinBox2ToBeArchivedColl;
    		}
    	});
    	redefineMethod( TracciabilitaPlichiPlichiDataAccess.class, new Object( ){
    		public Long getLastBoxCode( final String plichiType ) throws TracciabilitaException, RemoteException
    		{
    			return Long.valueOf( 1L );
    		}
    	});
    	
    	try
		{
    		
			Helper.setWinBox2ArchivioPageDetails( sessionMap, new Winbox2InputProcessor( null, null ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    	
    }

    public void testSetWinBox2ArchivioPageDetails2( ) 
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
    	sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), new Long( 5 ) );
    	sessionMap.put( CONSTANTS.PlichiReceived.toString( ), new Long( 1 ) );
    	redefineMethod( Winbox2InputProcessor.class, new Object( ){
    		public List<Long> getNoOfWinBox2ToBeArchivedColl ( )
    		{
    			final List<Long> noOfWinBox2ToBeArchivedColl = new ArrayList<Long>( 2 );
    			noOfWinBox2ToBeArchivedColl.add( Long.valueOf( 5L ) );
    			noOfWinBox2ToBeArchivedColl.add( Long.valueOf( 0 ) );
    			return noOfWinBox2ToBeArchivedColl;
    		}
    	});
    	redefineMethod( TracciabilitaPlichiPlichiDataAccess.class, new Object( ){
    		public Long getLastBoxCode( final String plichiType ) throws TracciabilitaException, RemoteException
    		{
    			return Long.valueOf( 1L );
    		}
    	});
    	
    	try
		{
    		
			Helper.setWinBox2ArchivioPageDetails( sessionMap, new Winbox2InputProcessor( null, null ) );
			assertEquals( true, sessionMap.containsKey( CONSTANTS.PlichiToBeReceived.toString( ) ) );
		
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    	
    }
    
    public void testSetWinBox2ArchivioPageDetails3( ) 
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
    	sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), new Long( 5 ) );
    	sessionMap.put( CONSTANTS.PlichiReceived.toString( ), new Long( 1 ) );
    	sessionMap.put( CONSTANTS.OggettoType.toString( ), "WBX2" );
		sessionMap.put( CONSTANTS.LastBoxCode.toString( ), Long.valueOf( 1 ) );
		sessionMap.put( CONSTANTS.WINBOX2_INPUT_PROCESSOR.toString( ), new Winbox2InputProcessor(null, null ) );
		sessionMap.put( CONSTANTS.BarCodeStr.toString( ), "1234567891234" );
		
    	redefineMethod( Winbox2InputProcessor.class, new Object( ){
    		public List<Long> getNoOfWinBox2ToBeArchivedColl ( )
    		{
    			final List<Long> noOfWinBox2ToBeArchivedColl = new ArrayList<Long>( 2 );
    			noOfWinBox2ToBeArchivedColl.add( Long.valueOf( 5L ) );
    			noOfWinBox2ToBeArchivedColl.add( Long.valueOf( 5L ) );
    			return noOfWinBox2ToBeArchivedColl;
    		}
    	});
    	
    	try
		{
			Helper.setWinBox2ArchivioPageDetails( sessionMap, new Winbox2InputProcessor( null, null ) );
		}
		catch ( final RemoteException remoteException )
		{
			remoteException.printStackTrace( );
		}
		catch ( final TracciabilitaException tracciabilitaException )
		{
			tracciabilitaException.printStackTrace( );
		}
    	
    }

    public void testSetExecuteResult1( )
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
	    sessionMap.put( CONSTANTS.OggettoType.toString( ), CONSTANTS.WINBOX2.toString( ) );
	    sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), Long.valueOf( 5L ) );
	    sessionMap.put( CONSTANTS.PlichiReceived.toString( ), Long.valueOf( 2L ) );
	    sessionMap.put( CONSTANTS.IsBarCodeReaderAvailable.toString( ), CONSTANTS.YES.getValue( ) );
	    sessionMap.put( CONSTANTS.TypesOfOggettos.toString( ), "Type" );
	    final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( "TrConferma" );
    	Helper.setExecuteResult( sessionMap, executeResult, Boolean.FALSE );
    	for ( final String pageValue : new String[ ]{ CONSTANTS.OggettoType.toString( ), CONSTANTS.PlichiToBeReceived.toString( ), CONSTANTS.PlichiToBeReceived.toString( ), CONSTANTS.IsBarCodeReaderAvailable.toString( ), CONSTANTS.TypesOfOggettos.toString( ) } )
    	{
    		assertEquals( true, sessionMap.containsKey( pageValue ) );
    	}
    }
    
    public void testSetExecuteResult2( )
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
	    sessionMap.put( CONSTANTS.OggettoType.toString( ), CONSTANTS.WINBOX2.toString( ) );
	    sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), Long.valueOf( 5L ) );
	    sessionMap.put( CONSTANTS.PlichiReceived.toString( ), Long.valueOf( 2L ) );
	    sessionMap.put( CONSTANTS.IsBarCodeReaderAvailable.toString( ), CONSTANTS.YES.getValue( ) );
	    sessionMap.put( CONSTANTS.TypesOfOggettos.toString( ), "Type" );
	    sessionMap.put( CONSTANTS.MSG.toString( ), CONSTANTS.MSG.toString( ) );
	    sessionMap.put( CONSTANTS.SUCCESS.getValue( ), CONSTANTS.YES.getValue( ) );
	    sessionMap.put( CONSTANTS.CASSETTO_ARCHIVIO.toString( ), CONSTANTS.CASSETTO_ARCHIVIO.toString( ) );
	    sessionMap.put( CONSTANTS.LastBoxCode.toString( ), Long.valueOf( 1L ) );
	    final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( "TrConferma" ); 
    	Helper.setExecuteResult( sessionMap, executeResult, Boolean.TRUE );
    	for ( final String pageValue : new String[ ]{ CONSTANTS.OggettoType.toString( ), CONSTANTS.PlichiToBeReceived.toString( ), CONSTANTS.PlichiToBeReceived.toString( ), CONSTANTS.IsBarCodeReaderAvailable.toString( ), CONSTANTS.TypesOfOggettos.toString( ) } )
    	{
    		assertEquals( true, sessionMap.containsKey( pageValue ) );
    	}
    	for ( final String removeValue : new String[ ] { CONSTANTS.MSG.toString( ), CONSTANTS.SUCCESS.getValue( ), CONSTANTS.CASSETTO_ARCHIVIO.toString( ) } )
    	{
    		assertEquals( false, sessionMap.containsKey( removeValue ) );
    	}
    	assertEquals( true, sessionMap.containsKey( CONSTANTS.LastBoxCode.toString( ) ) );
    }

    public void testSetExecuteResult3( )
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
	    sessionMap.put( CONSTANTS.OggettoType.toString( ), CONSTANTS.WINBOX2.toString( ) );
	    sessionMap.put( CONSTANTS.PlichiToBeReceived.toString( ), Long.valueOf( 5L ) );
	    sessionMap.put( CONSTANTS.PlichiReceived.toString( ), Long.valueOf( 2L ) );
	    sessionMap.put( CONSTANTS.IsBarCodeReaderAvailable.toString( ), CONSTANTS.YES.getValue( ) );
	    sessionMap.put( CONSTANTS.TypesOfOggettos.toString( ), "Type" );
	    sessionMap.put( CONSTANTS.MSG.toString( ), CONSTANTS.MSG.toString( ) );
	    sessionMap.put( CONSTANTS.SUCCESS.getValue( ), CONSTANTS.YES.getValue( ) );
	    sessionMap.put( CONSTANTS.CASSETTO_ARCHIVIO.toString( ), CONSTANTS.CASSETTO_ARCHIVIO.toString( ) );
	    sessionMap.put( CONSTANTS.LastBoxCode.toString( ), Long.valueOf( 1L ) );
	    final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( "TrConferma" );
    	Helper.setExecuteResult( sessionMap, executeResult, Boolean.FALSE );
    	for ( final String pageValue : new String[ ]{ CONSTANTS.OggettoType.toString( ), CONSTANTS.PlichiToBeReceived.toString( ), CONSTANTS.PlichiToBeReceived.toString( ), CONSTANTS.IsBarCodeReaderAvailable.toString( ), CONSTANTS.TypesOfOggettos.toString( ) } )
    	{
    		assertEquals( true, sessionMap.containsKey( pageValue ) );
    	}
    	for ( final String removeValue : new String[ ] { CONSTANTS.MSG.toString( ), CONSTANTS.SUCCESS.getValue( ), CONSTANTS.CASSETTO_ARCHIVIO.toString( ) } )
    	{
    		assertEquals( false, sessionMap.containsKey( removeValue ) );
    	}
    	assertEquals( false, sessionMap.containsKey( CONSTANTS.LastBoxCode.toString( ) ) );
    }
    
    public void testProcessWB2Envelopes_1( )
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
    	try
		{
			Helper.processWB2Envelopes( sessionMap );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		assertTrue( !sessionMap.containsKey( CONSTANTS.STAMPE_ID.getValue( ) ) );
		
		sessionMap.put( CONSTANTS.WB2_ARCHIVED_OGID_COLL.toString( ), new ArrayList<String>( 1 ) );
    	try
		{
			Helper.processWB2Envelopes( sessionMap );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		assertTrue( !sessionMap.containsKey( CONSTANTS.STAMPE_ID.getValue( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.WB2_ARCHIVED_OGID_COLL.toString( ) ) );
		
		sessionMap.put( CONSTANTS.WB2_ARCHIVED_OGID_COLL.toString( ), new ArrayList<String>( 1 ) );
		sessionMap.put( CONSTANTS.IS_VIRTUAL_WB2.toString( ), Boolean.FALSE );
    	try
		{
			Helper.processWB2Envelopes( sessionMap );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		assertTrue( !sessionMap.containsKey( CONSTANTS.STAMPE_ID.getValue( ) ) );
		assertTrue( sessionMap.containsKey( CONSTANTS.WB2_ARCHIVED_OGID_COLL.toString( ) ) );
    }
    
    public void testProcessWB2Envelopes_2( )
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
		sessionMap.put( CONSTANTS.WB2_ARCHIVED_OGID_COLL.toString( ), WB2_OGID_COLL );
		sessionMap.put( CONSTANTS.IS_VIRTUAL_WB2.toString( ), Boolean.FALSE );
		sessionMap.put( CONSTANTS.VIRTUAL_WB2_BARCODE.toString( ), VIRTUAL_WB2_BARCODE );
		try
		{
			expect( this.winbox2DataAccess.getVirtualWB2OggettoId( VIRTUAL_WB2_BARCODE ) ).andReturn( 10000L );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		replay( this.winbox2DataAccess );
		mockTPDataWriter( );
    }
  // 
    public void testProcessWB2Envelopes_3( )
    {
    	final Map<String, Object> sessionMap = new Hashtable<String, Object>( );
		sessionMap.put( CONSTANTS.WB2_ARCHIVED_OGID_COLL.toString( ), WB2_OGID_COLL );
		sessionMap.put( CONSTANTS.IS_VIRTUAL_WB2.toString( ), Boolean.FALSE );
		sessionMap.put( CONSTANTS.VIRTUAL_WB2_BARCODE.toString( ), VIRTUAL_WB2_BARCODE );
		try
		{
			expect( this.winbox2DataAccess.getVirtualWB2OggettoId( VIRTUAL_WB2_BARCODE ) ).andReturn( 10000L );
		}
		catch ( final RemoteException remoteException ) { }
		catch ( final TracciabilitaException tracciabilitaException ) { }
		replay( this.winbox2DataAccess );
		mockTPDataWriter( );
    }
    private void mockTPDataWriter( )
    {
    	redefineMethod( TracciabilitaPlichiDataWriter.class, new Object( ) {
    		public void moveFolders( final Collection<Long> fromRefIdCollection, final Long toRefId	) throws TracciabilitaException
    		{
    			return;
    		}
    	} );
    }
    
}
