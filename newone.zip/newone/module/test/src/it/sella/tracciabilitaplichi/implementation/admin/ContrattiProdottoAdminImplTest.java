package it.sella.tracciabilitaplichi.implementation.admin;

import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class ContrattiProdottoAdminImplTest extends BasicJDBCTestCaseAdapter {
	
	ContrattiProdottoAdminImpl contrattiProdottoAdminImpl = new ContrattiProdottoAdminImpl() ;
	
	public void testCancelliOggetto_exception() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		statementHandler.prepareGlobalResultSet(result);
		try {
			contrattiProdottoAdminImpl.cancelliOggetto(getContrattiProdottoView());
		} catch (final TracciabilitaException e) {
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}

	public void testModificaOggetto_success() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CP_ID");
		result.addColumn("CP_COD_PRODCONT");
		result.addColumn("CP_COD_PROD");
		result.addColumn("CP_COD_CONTRATTO");
		result.addColumn("CP_DESC_CONTRATTO");
		result.addColumn("CP_ABI_BANCA");
		result.addColumn("CP_FLAG_OBBL");
		result.addColumn("CP_TIPO_DA_CONTROLLARE");
		result.addColumn("CP_IMAGINI");
		result.addColumn("CP_STARTING_ID");
		result.addRow(new Object[] { 302L ,"1405","14","Derivati OTC","Contrattualistica derivati OTC","03211","F",1L,1L,710373 });
		statementHandler.prepareGlobalResultSet(result);
		try {
			contrattiProdottoAdminImpl.modificaOggetto(getContrattiProdottoView());
			assertEquals(10,result.getColumnCount());
			assertEquals(302L, result.getColumn("CP_ID"));
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
		}
	}
	
	public void testCensitoOggetto_02() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CP_ID");
		result.addColumn("CP_COD_PRODCONT");
		result.addColumn("CP_COD_PROD");
		result.addColumn("CP_COD_CONTRATTO");
		result.addColumn("CP_DESC_CONTRATTO");
		result.addColumn("CP_ABI_BANCA");
		result.addColumn("CP_FLAG_OBBL");
		result.addColumn("CP_TIPO_DA_CONTROLLARE");
		result.addColumn("CP_IMAGINI");
		result.addColumn("CP_STARTING_ID");
		result.addRow(new Object[] { 302L ,"1405","14","Derivati OTC","Contrattualistica derivati OTC","03211","F",1L,1L,710373 });
		statementHandler.prepareGlobalResultSet(result);
		try {
			contrattiProdottoAdminImpl.censitoOggetto(getContrattiProdottoView());
			assertEquals(10,result.getColumnCount());
			assertEquals(302L, result.getColumn("CP_ID"));
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
		}
	}
	
	public void testCensitoOggetto_01() throws SQLException
	{
		final ContrattiProdottoView contrattiProdottoView=new ContrattiProdottoView();
		contrattiProdottoView.setContrattiProdottoId(302L);
		contrattiProdottoView.setAbiBanca("03211");
		contrattiProdottoView.setCodContratto("Derivati OTC");
		contrattiProdottoView.setCodProdotto("14");
		contrattiProdottoView.setCodProdottoContratto("1405");
		contrattiProdottoView.setContrattiProdottoId(1L);
		contrattiProdottoView.setContrattoDaControllare(null);
		contrattiProdottoView.setDescrizioneContratto("Contrattualistica derivati OTC");
		contrattiProdottoView.setFlagObbligatorio("F");
		contrattiProdottoView.setImagini(1L);
		contrattiProdottoView.setStartingBdId(710373L);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CP_ID");
		result.addColumn("CP_COD_PRODCONT");
		result.addColumn("CP_COD_PROD");
		result.addColumn("CP_COD_CONTRATTO");
		result.addColumn("CP_DESC_CONTRATTO");
		result.addColumn("CP_ABI_BANCA");
		result.addColumn("CP_FLAG_OBBL");
		result.addColumn("CP_TIPO_DA_CONTROLLARE");
		result.addColumn("CP_IMAGINI");
		result.addColumn("CP_STARTING_ID");
		result.addRow(new Object[] { 302L ,"1405","14","Derivati OTC","Contrattualistica derivati OTC","03211","F",1L,1L,710373 });
		statementHandler.prepareGlobalResultSet(result);
		try {
			contrattiProdottoAdminImpl.censitoOggetto(getContrattiProdottoView());
			assertEquals(10,result.getColumnCount());
			assertEquals(302L, result.getColumn("CP_ID"));
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
			assertEquals("TRPL-1007",e.getMessage());
		}finally
		{
			connection.close();
		}
	}
	
	private ContrattiProdottoView getContrattiProdottoView()
	{
		final ContrattiProdottoView contrattiProdottoView=new ContrattiProdottoView();
		contrattiProdottoView.setContrattiProdottoId(302L);
		contrattiProdottoView.setAbiBanca("03211");
		contrattiProdottoView.setCodContratto("Derivati OTC");
		contrattiProdottoView.setCodProdotto("14");
		contrattiProdottoView.setCodProdottoContratto("1405");
		contrattiProdottoView.setContrattiProdottoId(1L);
		contrattiProdottoView.setContrattoDaControllare(1L);
		contrattiProdottoView.setDescrizioneContratto("Contrattualistica derivati OTC");
		contrattiProdottoView.setFlagObbligatorio("F");
		contrattiProdottoView.setImagini(1L);
		contrattiProdottoView.setStartingBdId(710373L);
		return contrattiProdottoView;
	}
}
