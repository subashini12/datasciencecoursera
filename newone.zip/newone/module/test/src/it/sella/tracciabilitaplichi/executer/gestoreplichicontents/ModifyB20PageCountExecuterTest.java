package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;


import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.PlichiContentsDefaultB20ProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultB20Processor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.util.Hashtable;

public class ModifyB20PageCountExecuterTest extends AbstractSellaExecuterMock{

	public ModifyB20PageCountExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	ModifyB20PageCountExecuter executer=new ModifyB20PageCountExecuter();
	
	public void testModifyB20PageCountExecuter_01()
	{
		Hashtable hashtable=getHashtable();
		setUpMockMethods(PlichiContentsDefaultB20Processor.class, PlichiContentsDefaultB20ProcessorMock.class);
		expecting(getRequestEvent().getAttribute(CONSTANTS.NUMBER_OF_PAGES.getValue( ))).andReturn("1");
		expecting(getStateMachineSession().get(ITPConstants.PLICHI_CONTENTS_HASH_TABLE)).andReturn(hashtable);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	private static Hashtable getHashtable()
	{
		Hashtable hashTable=new Hashtable();
		TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		hashTable.put(CONSTANTS.TRACCIABILITA_PLICHI_VIEW.getValue( ), tracciabilitaPlichiView);
		hashTable.put(CONSTANTS.NUMBER_OF_PAGES.getValue( ), 1L);
		hashTable.put(CONSTANTS.STAMPE_ID.getValue( ), 2L);
		return hashTable;
		}
	
	public void testModifyB20PageCountExecuter_02()
	{
		PlichiContentsDefaultB20ProcessorMock.setMapValues();
		Hashtable hashtable=getHashtable();
		setUpMockMethods(PlichiContentsDefaultB20Processor.class, PlichiContentsDefaultB20ProcessorMock.class);
		expecting(getRequestEvent().getAttribute(CONSTANTS.NUMBER_OF_PAGES.getValue( ))).andReturn("1");
		expecting(getStateMachineSession().get(ITPConstants.PLICHI_CONTENTS_HASH_TABLE)).andReturn(hashtable);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testModifyB20PageCountExecuter_03()
	{
		PlichiContentsDefaultB20ProcessorMock.setRemoteException();
		Hashtable hashtable=getHashtable();
		setUpMockMethods(PlichiContentsDefaultB20Processor.class, PlichiContentsDefaultB20ProcessorMock.class);
		expecting(getRequestEvent().getAttribute(CONSTANTS.NUMBER_OF_PAGES.getValue( ))).andReturn("1");
		expecting(getStateMachineSession().get(ITPConstants.PLICHI_CONTENTS_HASH_TABLE)).andReturn(hashtable);
		playAll();
		executer.execute(getRequestEvent());
	}
	
}
