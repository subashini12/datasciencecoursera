package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;
import java.util.Hashtable;

import mockit.Mockit;


public class PlichiContentsModificaPBustasProcessorTest extends AbstractSellaExecuterMock{

	public PlichiContentsModificaPBustasProcessorTest(final String name) {
		super(name);
	}

	PlichiContentsModificaPBustasProcessor processor = new PlichiContentsModificaPBustasProcessor() ;
	
	public void testPlichiContentsModificaPBustasProcessor_01()
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ContralisticaId1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyPB10Records(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testPlichiContentsModificaPBustasProcessor_02()
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		TracciabilitaPlichiPlichiContentsDataAccessMock.setExistNonDeletedPlichi();
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ContralisticaId1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyPB10Records(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}

	public void testPlichiContentsModificaPBustasProcessor_03()
	{
		TracciabilitaPlichiImplMock.setCassetto();
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("NumRec")).andReturn("1");
		expecting(getRequestEvent().getAttribute("AltriID1")).andReturn("1");
		expecting(getRequestEvent().getAttribute("barCode1")).andReturn("1478523693214");
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		try {
			processor.modifyPAltriRecords(getRequestEvent(), "1234567896547", getHashtable(), executeResult);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}			
	}
	
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable () ;
		return hashtable;
	}
}
