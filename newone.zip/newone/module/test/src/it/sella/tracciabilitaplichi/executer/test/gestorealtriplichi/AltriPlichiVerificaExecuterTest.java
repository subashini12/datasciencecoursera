package it.sella.tracciabilitaplichi.executer.test.gestorealtriplichi;

import static org.easymock.EasyMock.expect;
import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriplichi.AltriPlichiVerificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;

public class AltriPlichiVerificaExecuterTest extends AbstractSellaExecuterMock
{
    public AltriPlichiVerificaExecuterTest( final String name )
    {
        super( name );
    }

    
   
   /* public void testAltriPlichiVerificaExecuter_01( )
    {
    	setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
        expect( getRequestEvent().getAttribute( "BarCode" ) ).andReturn( "1234567890123" );
        expect( getRequestEvent().getAttribute( "Cdr" ) ).andReturn( "12354" );
        playAll();
        final ExecuteResult actual = new AltriPlichiVerificaExecuter( ).execute( getRequestEvent() );
        assertEquals( "1234567890123", actual.getAttribute( "BarCode" ) );
        assertEquals( "12354", actual.getAttribute( "Cdr" ) );
    }*/
   
    public void testAltriPlichiVerificaExecuter_02( )
    {   DBPersonaleWrapperMock.setValidCdrFalse();
    	setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
        expect( getRequestEvent().getAttribute( "BarCode" ) ).andReturn( "1234567890123" );
        expect( getRequestEvent().getAttribute( "Cdr" ) ).andReturn( "" );
        playAll();
        final ExecuteResult actual = new AltriPlichiVerificaExecuter( ).execute( getRequestEvent() );
        assertEquals( "1234567890123", actual.getAttribute( "BarCode" ) );
        assertEquals( "", actual.getAttribute( "Cdr" ) );
        assertEquals( "TRPL-1051", actual.getAttribute( "MSG" ) );
        assertEquals( "", ( ( String [ ] ) actual.getAttribute( "Argument" ) )[ 0 ] );
        assertEquals( "TrConferma", actual.getTransition( ) );
    }

  /*  public void testAltriPlichiVerificaExecuter_03( )
    {
    	DBPersonaleWrapperMock.setRemoteException();
    	setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
        expect( getRequestEvent().getAttribute( "BarCode" ) ).andReturn( "1234567890123" );
        expect( getRequestEvent().getAttribute( "Cdr" ) ).andReturn( "12354" );
        playAll();
        new AltriPlichiVerificaExecuter( ).execute( getRequestEvent() );

    }
    
    public void testAltriPlichiVerificaExecuter_04( )
    {
    	DBPersonaleWrapperMock.setTracciabilitaException();
    	setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
        expect( getRequestEvent().getAttribute( "BarCode" ) ).andReturn( "1234567890123" );
        expect( getRequestEvent().getAttribute( "Cdr" ) ).andReturn( "12354" );
        playAll();
        new AltriPlichiVerificaExecuter( ).execute( getRequestEvent() );
    }*/
}
