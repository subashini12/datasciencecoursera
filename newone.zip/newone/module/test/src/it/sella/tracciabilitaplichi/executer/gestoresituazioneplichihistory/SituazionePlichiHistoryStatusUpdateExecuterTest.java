package it.sella.tracciabilitaplichi.executer.gestoresituazioneplichihistory;

import it.sella.classificazione.ClassificazioneView;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneViewMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import org.easymock.EasyMock;

public class SituazionePlichiHistoryStatusUpdateExecuterTest extends AbstractSellaExecuterMock {

	public SituazionePlichiHistoryStatusUpdateExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	SituazionePlichiHistoryStatusUpdateExecuter executer = new SituazionePlichiHistoryStatusUpdateExecuter();
	
	public void testExecuter_01(){
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		setUpMockMethods(TPUtil.class,TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true).anyTimes();
		final Map map = new Hashtable();
		map.put("TypesOfOggettos",getOggettoTypes( ));
		map.put("WinboxViewList",getOggettoTypes( ));		
		map.put("BankViewList",getOggettoTypes( ));	
		expecting( getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map).anyTimes();
		final Collection ogCollection = getOggettoTypes( );
		setNeededOggettoTypes( ogCollection );
		expecting( getStateMachineSession().get( "TypesOfOggettos")).andReturn((Serializable) ogCollection).anyTimes();
		expecting(getRequestEvent().getAttribute("fromdd")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("frommm")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("fromyyyy")).andReturn("2012").anyTimes();
		expecting(getRequestEvent().getAttribute("tilldd")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("tillmm")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("tillyyyy")).andReturn("2013").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatusplichiStatus")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("senderBank")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationBank")).andReturn("231").anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("1234").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationCdr")).andReturn("1234").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiBarCode")).andReturn("1234123").anyTimes();
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("1234").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("6900").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("ST_02").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFromdd")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFrommm")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFromyyyy")).andReturn("2012").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTilldd")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTillmm")).andReturn("11").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTillyyyy")).andReturn("2012").anyTimes();
		expecting(getRequestEvent().getAttribute("descritioneArticoli" )).andReturn("2012").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );	
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}
	public void testExecuter_02(){
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		setUpMockMethods(TPUtil.class,TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class,TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,TracciabilitaPlichiStatusDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn(true).anyTimes();
		final Map map = new Hashtable();
		map.put("TypesOfOggettos",getOggettoTypes( ));
		map.put("WinboxViewList",new ArrayList());		
		map.put("BankViewList",getOggettoTypes( ));	
		expecting( getStateMachineSession().get("GESTORE_SITUAZIONE_PLICHI_SESSION")).andReturn((Serializable) map).anyTimes();
		final Collection ogCollection = getOggettoTypes( );
		setNeededOggettoTypes( ogCollection );
		expecting( getStateMachineSession().get( "TypesOfOggettos")).andReturn((Serializable) ogCollection).anyTimes();
		expecting(getRequestEvent().getAttribute("fromdd")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("frommm")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("fromyyyy")).andReturn("2012").anyTimes();
		expecting(getRequestEvent().getAttribute("tilldd")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("tillmm")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("tillyyyy")).andReturn("2013").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatusplichiStatus")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("senderBank")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationBank")).andReturn("231").anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("1234").anyTimes();
		expecting(getRequestEvent().getAttribute("destinationCdr")).andReturn("1234").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiBarCode")).andReturn("1234123").anyTimes();
		expecting(getRequestEvent().getAttribute("senderUserCode")).andReturn("1234").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiType")).andReturn("6900").anyTimes();
		expecting(getRequestEvent().getAttribute("plichiStatus")).andReturn("ST_02").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFromdd")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFrommm")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliFromyyyy")).andReturn("2012").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTilldd")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTillmm")).andReturn("11").anyTimes();
		expecting(getRequestEvent().getAttribute("articoliTillyyyy")).andReturn("2012").anyTimes();
		expecting(getRequestEvent().getAttribute("descritioneArticoli" )).andReturn("2012").anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );	
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
		
	private void setNeededOggettoTypes(final Collection  ogCollection )
	{
		final ArrayList causaleList = new ArrayList();
		causaleList.add( ITPConstants.B5_CAUSALE );
		causaleList.add( ITPConstants.PB5_CAUSALE );
		causaleList.add( ITPConstants.PB10_CAUSALE );
		causaleList.add( ITPConstants.BN_CAUSALE );
		causaleList.add( ITPConstants.PBN_CAUSALE );
		causaleList.add( ITPConstants.PALTRI_CAUSALE );
		final Iterator typeOggettoIterator = ogCollection.iterator();
		for ( int i = ogCollection.size(); i != 0; i-- )
		{
		    final ClassificazioneView classificazioneView = ( ClassificazioneView ) typeOggettoIterator.next();
			if ( !causaleList.contains( classificazioneView.getCausale() ) )
			{
				typeOggettoIterator.remove();
			}
		}
	}
	private Collection  getOggettoTypes( )
	{
		final ClassificazioneViewMock clview1 = new ClassificazioneViewMock();
		clview1.setParentId(1L);
		clview1.setDescrizione("Busta5");
		clview1.setCausale(ITPConstants.PBN_CAUSALE);
		clview1.setDescrizione("descrizione1");
		final ClassificazioneViewMock clview2 = new ClassificazioneViewMock();
		clview2.setDescrizione("Busta10");
		clview2.setParentId(1L);
		clview2.setDescrizione("descrizione2");
		final Collection collection = new ArrayList();
		collection.add(clview1);
		collection.add(clview2);
		return collection;
	}

}
