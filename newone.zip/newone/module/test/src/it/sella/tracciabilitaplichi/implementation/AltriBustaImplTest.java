package it.sella.tracciabilitaplichi.implementation;

import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.PAltriAttributeView;

import java.rmi.RemoteException;
import java.util.Properties;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AltriBustaImplTest {

	AltriBustaImpl altriBustaImpl=new AltriBustaImpl();

	@Before
	public void setUp() {
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_TR_PALTRI_ATTRIBUTE (PD_ID numeric(6))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_TR_PALTRI_ATTRIBUTE values(3)");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_TR_PALTRI_ATTRIBUTE values(1)");
	}
	
	@Test
	public void altriBustaImplTestCase_01() throws	RemoteException, TracciabilitaException {
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final Properties properties=getProperties();
		altriBustaImpl.cancelliOggetto(properties);		
	}
	
	private static PAltriAttributeView getPAltriAttributeView()
	{
		final PAltriAttributeView pAltriAttributeView=new PAltriAttributeView();
		pAltriAttributeView.setId(1L);
		return pAltriAttributeView;
	}
	
	private static Properties getProperties()
	{
		final PAltriAttributeView pAltriAttributeView=getPAltriAttributeView();
		final Properties properties=new Properties();
		properties.put("PAltriAttributeView", pAltriAttributeView);
		return properties;
	}
	
	 @After
	 public void tearDown() {
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_TR_PALTRI_ATTRIBUTE");
	 }
}
