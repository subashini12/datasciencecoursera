package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPControlliDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class TPControlliDataAccessTest extends BasicJDBCTestCaseAdapter{

	TPControlliDataAccess tpControlliDataAccess=new TPControlliDataAccess();
	
	public void testGetControlliViewById_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID", new Object[] { "12684" });
		result.addColumn("CL_DATA", new Object[] { new Timestamp(1L) });
		result.addColumn("CL_COD_DIP", new Object[] { "BSG96" });
		result.addColumn("CL_CONTRATTO_ID", new Object[] { "185333" });
		result.addColumn("CL_ID_ESITO", new Object[] { "30" });
		result.addColumn("CL_NOTE", new Object[] { "" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			final ControlliView controlliView = tpControlliDataAccess.getControlliViewById(1L);
			assertNotNull(controlliView);
			assertEquals(true, result.next());
			assertEquals("",controlliView.getNote());
			assertEquals("BSG96",controlliView.getCodDipControllo());
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetControlliViewById_sqlException() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID", new Object[] { "12684" });
		result.addColumn("CL_DATA", new Object[] { new Timestamp(1L) });
		result.addColumn("CL_COD_DIP", new Object[] { "BSG96" });
		result.addColumn("CL_CONTRATTO_ID", new Object[] { "185333" });
		result.addColumn("CL_NOTE", new Object[] { "" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			final ControlliView controlliView = tpControlliDataAccess.getControlliViewById(1L);
			assertNotNull(controlliView);
			assertEquals(true, result.next());
			assertEquals("",controlliView.getNote());
			assertEquals("BSG96",controlliView.getCodDipControllo());
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetControlliViewByContrattoId_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID", new Object[] { "12684" });
		result.addColumn("CL_DATA", new Object[] { new Timestamp(1L) });
		result.addColumn("CL_COD_DIP", new Object[] { "BSG96" });
		result.addColumn("CL_CONTRATTO_ID", new Object[] { "185333" });
		result.addColumn("CL_ID_ESITO", new Object[] { "30" });
		result.addColumn("CL_NOTE", new Object[] { "" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			final ArrayList controlliViewList = tpControlliDataAccess.getControlliViewByContrattoId(1L);
			assertNotNull(controlliViewList.get(0));
			assertEquals(true, result.next());
			assertEquals(1,controlliViewList.size());
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} catch (final RemoteException e) {
			assertNotNull(e);
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
	
	public void testGetControlliViewByContrattoId_sqlException() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CL_ID", new Object[] { "12684" });
		result.addColumn("CL_DATA", new Object[] { new Timestamp(1L) });
		result.addColumn("CL_COD_DIP", new Object[] { "BSG96" });
		result.addColumn("CL_CONTRATTO_ID", new Object[] { "185333" });
		result.addColumn("CL_ID_ESITO", new Object[] { "30" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			final ArrayList controlliViewList = tpControlliDataAccess.getControlliViewByContrattoId(1L);
			assertNotNull(controlliViewList.get(0));
			assertEquals(true, result.next());
			assertEquals(1,controlliViewList.size());
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		} catch (final RemoteException e) {
			assertNotNull(e);
		}finally
		{
			connection.close();
			verifyConnectionClosed();
		}
	}
}
