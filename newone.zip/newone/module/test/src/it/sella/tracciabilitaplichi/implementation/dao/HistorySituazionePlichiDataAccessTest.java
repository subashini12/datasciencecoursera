/*package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.SqlScriptExecuter;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;

import java.rmi.RemoteException;

import mockit.Mockit;

import org.junit.After;
import org.junit.Before;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;


public class HistorySituazionePlichiDataAccessTest extends BasicJDBCTestCaseAdapter
{
	HistorySituazionePlichiDataAccess historySituazionePlichiDataAccess=new HistorySituazionePlichiDataAccess();
	
	@Override
	@Before
	public void setUp() {
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_PLICHI_ATTRIBUTE(PA_DOC_ID numeric(12),PA_BARCODE varchar(12),PA_CDR_DESTINATION varchar(12),PA_USER_DESTINATION varchar(12),PA_BANK_DESTINATION numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_PLICHI_ATTRIBUTE(PA_DOC_ID,PA_BARCODE) values(1,'1234567890123')");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_OGGETTO (OG_ID numeric(12),OG_TYPE numeric(12),OG_LID varchar(12),OG_OGGETTO_ACTUAL_DATE date,OG_USER varchar(12),OG_CURR_STATUS_ID numeric(12),OG_CURR_REF_ID numeric(12),OG_CDR varchar(12),OG_BANK numeric(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("insert into TP_HS_OGGETTO(OG_BANK,OG_ID) values('1',1)");
		SqlScriptExecuter.executeCommandInHsqlDB("create table TP_HS_BUSTA_CINQUE_ATTRIBUTE (BA_DOC_ID numeric(12),BA_ID numeric(12),BA_ISBANKADMIN varchar(12),BA_DEL_NOTE varchar(12))");
		SqlScriptExecuter.executeCommandInHsqlDB("CREATE ALIAS TRUNC FOR \"it.sella.tracciabilitaplichi.implementation.SqlScriptExecuter.trunc\"");
	}
	
	public void testGetHistoryOggettoIdForBarCode_01()
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(BarcodeValidator.class, BarcodeValidatorMock.class);

		try {
			historySituazionePlichiDataAccess.getHistoryOggettoIdForBarCode("1234567890123");
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testGetHistoryPlichiList_01()
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(BarcodeValidator.class, BarcodeValidatorMock.class);

		try {
			try {
				historySituazionePlichiDataAccess.getHistoryPlichiList("", "", "1", "", "", "", "", "", "", "", "", "", "", "");
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testGetHistoryPlichiList_02()
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(BarcodeValidator.class, BarcodeValidatorMock.class);

		try {
			try {
				historySituazionePlichiDataAccess.getHistoryPlichiList("", "2", "1", "099231", "1234567890123", "1", "12/12/2011", "12/01/2012", "12/01/2012", "12/02/2012", "B10", "", "", "");
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	public void testGetHistoryPlichiList_03()
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(BarcodeValidator.class, BarcodeValidatorMock.class);

		ClassificazioneWrapperMock.setBUST5();
		try {
			try {
				historySituazionePlichiDataAccess.getHistoryPlichiList("ST_11", "1", "099231", "1", "1234567890123", "12/12/2011", "12/12/2011", "12/12/2011", "12/12/2011", "", "", "", "1", "1");
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	
	
		public void testGetHistoryPlichiList_04()
	{
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(BarcodeValidator.class, BarcodeValidatorMock.class);

		try {
			try {
				historySituazionePlichiDataAccess.getHistoryPlichiList("1", "", "", "", "", "", "", "", "", "", "", "", "1", "");
			} catch (final RemoteException e) {
				e.printStackTrace();
			}
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	@Override
	@After
	 public void tearDown() {
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_BUSTA_CINQUE_ATTRIBUTE");
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_PLICHI_ATTRIBUTE");
		 SqlScriptExecuter.executeCommandInHsqlDB("drop table TP_HS_OGGETTO");
	}
	
}
*/