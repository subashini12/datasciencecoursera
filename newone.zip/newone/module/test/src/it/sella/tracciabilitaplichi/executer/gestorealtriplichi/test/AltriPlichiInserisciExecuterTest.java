package it.sella.tracciabilitaplichi.executer.gestorealtriplichi.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriplichi.AltriPlichiInserisciExecuter;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiDataAccessMock;

import java.util.ArrayList;
import java.util.Hashtable;

public class AltriPlichiInserisciExecuterTest extends AbstractSellaExecuterMock{

	public AltriPlichiInserisciExecuterTest(final String name) {
		super(name);
	}

	AltriPlichiInserisciExecuter executer=new AltriPlichiInserisciExecuter(); 
	
	public void testAltriPlichiInserisciExecuter_01() {
		final Hashtable hashtable=new Hashtable();
		hashtable.put("BarCode", "1234567891234");
		hashtable.put("AltriSeqNo", "");
		hashtable.put("AltriMainCollection", "");
		hashtable.put("EnteredCdr", "");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateMM")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateYYYY")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateMM")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateYYYY")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedAltri")).andReturn("21").anyTimes();
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(hashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testAltriPlichiInserisciExecuter_02() {
		final ArrayList list=new ArrayList();
		list.add("A");
		list.add("B");
		list.add("C");
		final Hashtable hashtable=new Hashtable();
		hashtable.put("BarCode", "1234567891234");
		hashtable.put("AltriMainCollection", list);
		hashtable.put("EnteredCdr", "");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("12121212121").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateDD")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateMM")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateYYYY")).andReturn("1999").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateMM")).andReturn("11").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateYYYY")).andReturn("2000").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedAltri")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(hashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public void testAltriPlichiInserisciExecuter_03() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		final Hashtable hashtable=new Hashtable();
		hashtable.put("BarCode", "1234567891234");
		hashtable.put("EnteredCdr", "1");
		hashtable.put("DefaultCdr", "1");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("12121212121").anyTimes();
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("02154").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateDD")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateMM")).andReturn("12").anyTimes();
		expecting(getRequestEvent().getAttribute("fromDateYYYY")).andReturn("1999").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateDD")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateMM")).andReturn("11").anyTimes();
		expecting(getRequestEvent().getAttribute("toDateYYYY")).andReturn("2000").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedAltri")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(hashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
}
