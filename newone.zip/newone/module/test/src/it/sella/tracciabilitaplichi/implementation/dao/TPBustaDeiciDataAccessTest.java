package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.ControlliQueryKey;
import it.sella.tracciabilitaplichi.implementation.mock.util.BindVariableHelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.ConnectionLifeCycleMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.BindVariableHelper;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class TPBustaDeiciDataAccessTest extends BasicJDBCTestCaseAdapter
{

	public TPBustaDeiciDataAccessTest( final String name )
	{
		super( name );
	}

	TPBustaDeiciDataAccess tpBustaDeiciDataAccess = new TPBustaDeiciDataAccess() ;

	public void testTPBustaDeiciDataAccessTest_01()
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		result.addColumn("BD_COD_PRODCONT",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ANAGRAFICA",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_NOTE_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_COD_DIPLASTCONTROL",new Object[]{"1"});
		result.addColumn("BD_DATA_VISTO_FIRMARE",new Object[]{new Timestamp(1)});
		result.addColumn("BD_DATE_LASTCONTROL",new Object[]{new Timestamp(1)});
		result.addColumn("BD_ID_SUCC",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getBustaDeiciViewById(1L);
			connection.close();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		} catch (final SQLException e) {
			e.printStackTrace();
		}
	}

	public void testIsContractExist_01()
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("ST_TYPE",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new Date()});
		result.addColumn("BD_ID_CHANNEL",new Object[]{"1"});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("ST_ID",new Object[]{"1"});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.isContractExist("",new Date(),"","");
			connection.close();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		} catch (final SQLException e) {
			e.printStackTrace();
		}
	}

	public void testIsContractExist_02() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("ST_TYPE",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new Date()});
		result.addColumn("BD_ID_CHANNEL",new Object[]{"1"});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("ST_ID",new Object[]{"1"});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.isContractExist("",new Date(),"XXXX","");
			connection.close();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		} catch (final SQLException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testGetBustaDeiciView_01() throws SQLException
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(Util.class, UtilMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		result.addColumn("BD_COD_PRODCONT",new Object[]{"1"});
		result.addColumn("BD_ID_SUCC",new Object[]{1L});
		result.addColumn("BD_NC",new Object[]{"1"});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ANAGRAFICA",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_NOTE_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_DATA_VISTO_FIRMARE",new Object[]{ new Timestamp(1L)});
		result.addColumn("BD_DATE_LASTCONTROL",new Object[]{ new Timestamp(1L)});
		result.addColumn("BD_COD_DIPLASTCONTROL",new Object[]{ ""});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getBustaDeiciView(1L, "","",new java.sql.Date(1L), "");
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testGetOggettoIdsForB10Ids_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		Mockit.setUpMock(BindVariableHelper.class, BindVariableHelperMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getOggettoIdsForB10Ids(new ArrayList());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testGetOggettoIdsForB10Ids_02() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		Mockit.setUpMock(BindVariableHelper.class, BindVariableHelperMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		final BustaDeiciAttributeView bustaDeiciAttributeView = new BustaDeiciAttributeView() ;
		bustaDeiciAttributeView.setBustaDeiciId(2L);
		final Collection collection = new ArrayList();
		collection.add(bustaDeiciAttributeView);
		collection.add(bustaDeiciAttributeView);
		try {
			tpBustaDeiciDataAccess.getOggettoIdsForB10Ids(collection );
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testIsInPreparataStatus_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("ST_ID",new Object[]{"1"});
		result.addColumn("ST_TYPE",new Object[]{"1"});
		result.addColumn("BD_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.isInPreparataStatus(getMap());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally{
			connection.close();
		}
	}

	private static Map getMap()
	{
		final Map map = new HashMap() ;
		map.put("1", 1L);
		return map ;
	}

	/*public void testGettracciabilitaPlichiView_01() throws SQLException
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(TracciabilitaPlichiHoldingDataAccess.class,TracciabilitaPlichiHoldingDataAccessMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class,it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OG_OGGETTO_ACTUAL_DATE",new Object[]{new Timestamp(1L)});
		result.addColumn("OG_LID",new Object[]{"1"});
		result.addColumn("OG_TYPE",new Object[]{"1"});
		result.addColumn("OG_CDR",new Object[]{"1"});
		result.addColumn("OG_ID",new Object[]{"1"});
		result.addColumn("OG_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("OG_CURR_REF_ID",new Object[]{"1"});
		result.addColumn("OG_USER",new Object[]{"1"});
		result.addColumn("OG_BANK",new Object[]{"1"});
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		result.addColumn("BD_COD_PRODCONT",new Object[]{"1"});
		result.addColumn("BD_ID_SUCC",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ID_CHANNEL",new Object[]{"1"});
		result.addColumn("BD_ANAGRAFICA",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_NOTE_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_DATA_VISTO_FIRMARE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_DATE_LASTCONTROL",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_COD_DIPLASTCONTROL",new Object[]{"1"});
		result.addColumn("CP_IMAGINI",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.gettracciabilitaPlichiView("1234567891235", "", Boolean.TRUE);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally{
			connection.close();
		}
	}*/

	/*public void testGettracciabilitaPlichiView_02() throws SQLException
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(TracciabilitaPlichiHoldingDataAccess.class,TracciabilitaPlichiHoldingDataAccessMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		Mockit.setUpMock(DBPersonaleWrapper.class,it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OG_OGGETTO_ACTUAL_DATE",new Object[]{new Timestamp(1L)});
		result.addColumn("OG_LID",new Object[]{"1"});
		result.addColumn("OG_TYPE",new Object[]{"1"});
		result.addColumn("OG_CDR",new Object[]{"1"});
		result.addColumn("OG_ID",new Object[]{"1"});
		result.addColumn("OG_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("OG_CURR_REF_ID",new Object[]{"1"});
		result.addColumn("OG_USER",new Object[]{"1"});
		result.addColumn("OG_BANK",new Object[]{"1"});
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		result.addColumn("BD_COD_PRODCONT",new Object[]{"1"});
		result.addColumn("BD_ID_SUCC",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		result.addColumn("BD_LID",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_CDR",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ID_CHANNEL",new Object[]{"1"});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_CURR_REF_ID",new Object[]{"1"});
		result.addColumn("BD_ANAGRAFICA",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_BANK",new Object[]{"1"});
		result.addColumn("BD_NOTE_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_DATA_VISTO_FIRMARE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_DATE_LASTCONTROL",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_COD_DIPLASTCONTROL",new Object[]{"1"});
		result.addColumn("CP_IMAGINI",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.gettracciabilitaPlichiView("1234567891235", "", Boolean.FALSE);
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally{
			connection.close();
		}
	}*/

	public void testGetOperationHappendInfo_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OS_DATE_TIME",new Object[]{new Timestamp(1L)});
		result.addColumn("OS_USER",new Object[]{"1"});
		result.addColumn("OS_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getOperationHappendInfo("1234567894125", "", "");
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testIsBustaDeiciExists_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OS_DATE_TIME",new Object[]{new Timestamp(1L)});
		result.addColumn("OS_USER",new Object[]{"1"});
		result.addColumn("OS_ID",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.isBustaDeiciExists("", "");
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testGetOggettoViewForB10Id_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OG_ID",new Object[]{"1"});
		result.addColumn("OG_TYPE",new Object[]{"1"});
		result.addColumn("OG_LID",new Object[]{"1"});
		result.addColumn("OG_OGGETTO_ACTUAL_DATE",new Object[]{new Timestamp(1L)});
		result.addColumn("OG_USER",new Object[]{"1"});
		result.addColumn("OG_CDR",new Object[]{"1"});
		result.addColumn("OG_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("OG_CURR_REF_ID",new Object[]{"1"});
		result.addColumn("OG_BANK",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getOggettoViewForB10Id(1L);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testGetBustaDeiciViewForQueryKey_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		result.addColumn("BD_COD_PRODCONT",new Object[]{"1"});
		result.addColumn("BD_ID_SUCC",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		result.addColumn("BD_LID",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_CDR",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ID_CHANNEL",new Object[]{"1"});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_CURR_REF_ID",new Object[]{"1"});
		result.addColumn("BD_ANAGRAFICA",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_BANK",new Object[]{"1"});
		result.addColumn("BD_NOTE_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_DATA_VISTO_FIRMARE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_DATE_LASTCONTROL",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_COD_DIPLASTCONTROL",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getBustaDeiciViewForQueryKey(new ControlliQueryKey());
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	public void testGetStatusReferenceCount_01() throws SQLException
	{
		Mockit.setUpMock(ConnectionLifecycle.class,ConnectionLifeCycleMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("BD_ID",new Object[]{"1"});
		result.addColumn("BD_OGGETTO_ID",new Object[]{"1"});
		result.addColumn("BD_COD_PRODCONT",new Object[]{"1"});
		result.addColumn("BD_ID_SUCC",new Object[]{"1"});
		result.addColumn("BD_NC",new Object[]{"1"});
		result.addColumn("BD_LID",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_OC",new Object[]{"1"});
		result.addColumn("BD_CDR",new Object[]{"1"});
		result.addColumn("BD_NCD",new Object[]{"1"});
		result.addColumn("BD_ID_CHANNEL",new Object[]{"1"});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_CURR_REF_ID",new Object[]{"1"});
		result.addColumn("BD_ANAGRAFICA",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_BANK",new Object[]{"1"});
		result.addColumn("BD_NOTE_CONTROLLO",new Object[]{"1"});
		result.addColumn("BD_DATA_VISTO_FIRMARE",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_DATE_LASTCONTROL",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_COD_DIPLASTCONTROL",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getStatusReferenceCount(1L);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally{
			connection.close();
		}
	}

	/*public void testGetBustaDieciValues_01() throws SQLException
	{
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class,ConnectionLifeCycleMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CP_COD_CONTRATTO",new Object[]{"1"});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new Date()});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getBustaDieciValues("", new ArrayList());
		} catch (final RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}*/


	/*public void testGetHistory_01() throws SQLException
	{
		Mockit.setUpMock(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OS_DATE_TIME",new Object[]{new Timestamp(1L)});
		result.addColumn("OS_USER",new Object[]{"1"});
		result.addColumn("OS_ID",new Object[]{"1"});
		result.addColumn("OS_CDR",new Object[]{"1"});
		result.addColumn("OS_REF_ID",new Object[]{"1"});
		result.addColumn("ST_TYPE",new Object[]{"1"});
		result.addColumn("ST_DIS_DESC",new Object[]{"1"});
		result.addColumn("OG_ID",new Object[]{"1"});
		result.addColumn("PA_BARCODE",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getHistory("1234567894567", "", new StringBuilder());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	public void testGetHistory_02() throws SQLException
	{
		Mockit.setUpMock(BindVariableHelper.class,BindVariableHelperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class, it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock.class);
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("OS_DATE_TIME",new Object[]{new Timestamp(1L)});
		result.addColumn("OS_USER",new Object[]{"1"});
		result.addColumn("OS_ID",new Object[]{"1"});
		result.addColumn("OS_CDR",new Object[]{"1"});
		result.addColumn("OS_REF_ID",new Object[]{null});
		result.addColumn("ST_TYPE",new Object[]{"1"});
		result.addColumn("ST_DIS_DESC",new Object[]{"1"});
		result.addColumn("OG_ID",new Object[]{"1"});
		result.addColumn("PA_BARCODE",new Object[]{"1"});
		statementHandler.prepareGlobalResultSet(result);
		try {
			tpBustaDeiciDataAccess.getHistory("1234567894567", "", new StringBuilder());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}*/

	/*public void testgetBustaDieciValues_01() throws SQLException
	{
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class,ConnectionLifeCycleMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
            connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CP_COD_CONTRATTO",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new java.sql.Date(1)});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{null});
		statementHandler.prepareGlobalResultSet(result);
		final List list = new ArrayList() ;
		list.add("");
		try {
			tpBustaDeiciDataAccess.getBustaDieciValues("12",list );
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}*/

	public void testgetBustaDieciValues_02() throws SQLException
	{
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class,ConnectionLifeCycleMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CP_COD_CONTRATTO",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new java.sql.Date(1)});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{null});
		statementHandler.prepareGlobalResultSet(result);
		final List list = new ArrayList() ;
		list.add(1L);
		try {
			tpBustaDeiciDataAccess.getBustaDieciValues("12",list );
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}

	public void testgetBustaDieciValues_03() throws SQLException
	{
		Mockit.setUpMock(Util.class,UtilMock.class);
		Mockit.setUpMock(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class,ConnectionLifeCycleMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final PreparedStatementResultSetHandler  statementHandler =
			connection.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CP_COD_CONTRATTO",new Object[]{new Timestamp(1L)});
		result.addColumn("BD_USER",new Object[]{"1"});
		result.addColumn("BD_ACTUAL_DATE",new Object[]{new java.sql.Date(1)});
		result.addColumn("BD_CURR_STATUS_ID",new Object[]{"1"});
		result.addColumn("BD_ID_ESITO_CONTROLLO",new Object[]{null});
		statementHandler.prepareGlobalResultSet(result);
		final List list = new ArrayList() ;
		list.add(new java.sql.Date(1));
		try {
			tpBustaDeiciDataAccess.getBustaDieciValues("12",list );
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}

	/*	public void testGetUltimoEsitoCollection_01() throws SQLException
	{
		Mockit.setUpMock(DBConnector.class,DBConnectorMock.class);
		final MockConnection connection=getJDBCMockObjectFactory().getMockConnection();
		final CallableStatementResultSetHandler statementHandler =
            connection.getCallableStatementResultSetHandler();
		MockRunnerConnection.setConnection(connection);
		final MockResultSet result = statementHandler.createResultSet();
		result.addColumn("CUN",new Object[]{"1"});
		result.addColumn("CUN",new Object[]{"1"});
		statementHandler.prepareResultSet("{? = call scanner_dba.CTRL_PKG_EXTERNAL_INTERFACE.CTRL_FN_GET_TIPO_CONTROLLO( ? )}", result);
		try {
			tpBustaDeiciDataAccess.getUltimoEsitoCollection();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}finally
		{
			connection.close();
		}
	}*/
}
