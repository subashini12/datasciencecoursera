package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestoreCodiceHostCensitoExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPCodiceHostDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPCodiceHostDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;


public class GestoreCodiceHostCensitoExecuterTestCase extends AbstractSellaExecuterMock {
	
	 public GestoreCodiceHostCensitoExecuterTestCase( final String name )
	    {
	        super( name );
	        // TODO Auto-generated constructor stub
	    }
	 @Override
	protected void setUp( ) throws Exception
	    {
	        super.setUp( );
	    }
	 GestoreCodiceHostCensitoExecuter gestoreCodiceHostCensitoExecuter = new GestoreCodiceHostCensitoExecuter();
	 public void testGestoreCodiceHostCensitoExecuterTest_01(){
		 	TPUtilMock.setValidateDate(1);
		 	setUpMockMethods(Util.class, UtilMock.class);
		 	setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 	setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);			
		 	expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12" ).anyTimes();
			expecting( getRequestEvent().getAttribute("bankId") ).andReturn("00" ).anyTimes();
			expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12/12/2010" ).anyTimes();
			expecting( getRequestEvent().getAttribute("toDate") ).andReturn("12/01/2011" ).anyTimes();
			playAll();
	        final ExecuteResult executeResult =	gestoreCodiceHostCensitoExecuter.execute(getRequestEvent());
	        assertNotNull(executeResult.getAttribute("MSG"));
		 }
	 
/*	 public void testGestoreCodiceHostCensitoExecuterTest_02(){
		 	TPUtilMock.setValidateDate(2);
		 	setUpMockMethods(Util.class, UtilMock.class);
		 	setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 	setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);			
		 	expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12" ).anyTimes();
			expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12345678" ).anyTimes();
			expecting( getRequestEvent().getAttribute("bankId") ).andReturn("" ).anyTimes();
			expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12/12/2010" ).anyTimes();
			expecting( getRequestEvent().getAttribute("toDate") ).andReturn("12/01/2011" ).anyTimes();
			playAll();
	        final ExecuteResult executeResult =	gestoreCodiceHostCensitoExecuter.execute(getRequestEvent());
		 }
	 
	 public void testGestoreCodiceHostCensitoExecuterTest_03(){
		 	TPUtilMock.setInValidBankId();
		 	setUpMockMethods(Util.class, UtilMock.class);
		 	setUpMockMethods(TPUtil.class, TPUtilMock.class);
		 	setUpMockMethods(TPCodiceHostDataAccess.class, TPCodiceHostDataAccessMock.class);			
		 	expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("1223236565656" ).anyTimes();
			expecting( getRequestEvent().getAttribute("codiceHost") ).andReturn("12345678" ).anyTimes();
			expecting( getRequestEvent().getAttribute("bankId") ).andReturn("" ).anyTimes();
			expecting( getRequestEvent().getAttribute("fromDate") ).andReturn("12/12/2010" ).anyTimes();
			expecting( getRequestEvent().getAttribute("toDate") ).andReturn("12/01/2011" ).anyTimes();
			playAll();
	        final ExecuteResult executeResult =	gestoreCodiceHostCensitoExecuter.execute(getRequestEvent());
		 }
		 
	 */
}
