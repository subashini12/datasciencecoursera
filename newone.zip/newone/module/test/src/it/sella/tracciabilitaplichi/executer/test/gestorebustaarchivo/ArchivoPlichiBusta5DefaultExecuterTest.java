/*package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoPlichiBusta5DefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.util.Hashtable;

public class ArchivoPlichiBusta5DefaultExecuterTest extends
		AbstractSellaExecuterTest {

	ArchivoPlichiBusta5DefaultExecuter archivoPlichiBusta5DefaultExecuter = new ArchivoPlichiBusta5DefaultExecuter();

	public ArchivoPlichiBusta5DefaultExecuterTest(final String name) {
		super(name);
	}

	public void testArchivoPlichiBusta5DefaultExecuter_01() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class,
				SecurityDBpersonaleWrapperMock.class);
		expecting(
				getStateMachineSession().containsKey(
						"BustaCinqueArchivoSession")).andReturn(false);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		expecting(
				getStateMachineSession().put("BustaCinqueArchivoSession",
						archivoBustaCinqueSession)).andReturn(
				archivoBustaCinqueSession);
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5DefaultExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), ("TrConferma"));

	}

	public void testArchivoPlichiBusta5DefaultExecuter_02() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class,
				SecurityDBpersonaleWrapperMock.class);
		expecting(
				getStateMachineSession().containsKey(
						"BustaCinqueArchivoSession")).andReturn(true);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		expecting(
				getStateMachineSession().put("BustaCinqueArchivoSession",
						archivoBustaCinqueSession)).andReturn(
				archivoBustaCinqueSession);
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5DefaultExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), ("TrConferma"));

	}
	
	public void testArchivoPlichiBusta5DefaultExecuter_04() {
		SecurityWrapperMock.setTracciabilitaException();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class,
				SecurityDBpersonaleWrapperMock.class);
		expecting(
				getStateMachineSession().containsKey(
						"BustaCinqueArchivoSession")).andReturn(true);
		final Hashtable archivoBustaCinqueSession = new Hashtable(15);
		expecting(
				getStateMachineSession().put("BustaCinqueArchivoSession",
						archivoBustaCinqueSession)).andReturn(
				archivoBustaCinqueSession);
		expecting(getStateMachineSession().get("BustaCinqueArchivoSession"))
				.andReturn(archivoBustaCinqueSession);
		playAll();
		final ExecuteResult executeResult = archivoPlichiBusta5DefaultExecuter
				.execute(getRequestEvent());
	}
	
}*/