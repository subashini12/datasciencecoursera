package it.sella.tracciabilitaplichi.executer.gestorechannelelementsadmin.processor;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.rmi.RemoteException;


public class ChannelElementsAdminProcessorTest extends AbstractSellaExecuterMock{

	public ChannelElementsAdminProcessorTest(final String name) {
		super(name);
	}

	ChannelElementsAdminProcessor processor = new ChannelElementsAdminProcessor () ;
	
	public void testChannelElementsAdminProcessor_04() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelElementsId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementFamily")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementValue")).andReturn("1");
		expecting(getRequestEvent().getAttribute("IDBanca")).andReturn("1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelElementsAdminProcessor_05() throws RemoteException, TracciabilitaException {
		TPUtilMock.setInValidBankId();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelElementsId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementFamily")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementValue")).andReturn("1");
		expecting(getRequestEvent().getAttribute("IDBanca")).andReturn("1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelElementsAdminProcessor_06() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelElementsId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementFamily")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementValue")).andReturn("");
		expecting(getRequestEvent().getAttribute("IDBanca")).andReturn("1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
	public void testChannelElementsAdminProcessor_07() throws RemoteException, TracciabilitaException {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute("ChannelElementsId")).andReturn("1");
		expecting(getRequestEvent().getAttribute("ChannelElementFamily")).andReturn("-1");
		expecting(getRequestEvent().getAttribute("ChannelElementValue")).andReturn("1");
		expecting(getRequestEvent().getAttribute("IDBanca")).andReturn("1");
		playAll();
		assertNotNull(processor.validateEvent(getRequestEvent()));
	}
	
}
