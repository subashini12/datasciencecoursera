package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.tracciabilitaplichi.executer.ricezioneplichi.RicezionePlichiClearValues;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.RicezionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.RicezionePlichiCacheUtil;

public class RicezionePlichiClearValuesTest extends AbstractSellaExecuterMock{

	public RicezionePlichiClearValuesTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicezionePlichiClearValues plichiClearValues = new RicezionePlichiClearValues();
	
	public void test_1(){
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		plichiClearValues.execute(getRequestEvent());
	}
	public void test_2(){
		RicezionePlichiCacheUtilMock.setTracciabilitaException();
		setUpMockMethods(RicezionePlichiCacheUtil.class, RicezionePlichiCacheUtilMock.class);
		plichiClearValues.execute(getRequestEvent());
	}
}
