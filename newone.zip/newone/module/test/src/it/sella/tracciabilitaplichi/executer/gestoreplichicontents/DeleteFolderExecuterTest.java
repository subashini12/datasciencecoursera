package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;



public class DeleteFolderExecuterTest extends AbstractSellaExecuterMock{

	public DeleteFolderExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void testDeleteFolderExecuter_01()
	{
		
	}
	
}
