package it.sella.tracciabilitaplichi.executer.test;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;

public class AbstractSellaExecuterMock extends AbstractSellaMock
{
    private RequestEvent requestEvent = null;
    private StateMachineSession stateMachineSession = null;
    public AbstractSellaExecuterMock( final String name )
    {
        super( name );
    }
    @Override
	protected void setUp( ) throws Exception
    {
        super.setUp( );
        this.requestEvent = getMock( RequestEvent.class );
        this.stateMachineSession = getMock( StateMachineSession.class );
        expecting( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession ).anyTimes( );
    }
    protected RequestEvent getRequestEvent( )
    {
        return this.requestEvent;
    }
    protected StateMachineSession getStateMachineSession( )
    {
        return this.stateMachineSession;
    }
    protected void playAll( )
    {
        play( getRequestEvent( ) );
        play( getStateMachineSession( ) );
    }
}
