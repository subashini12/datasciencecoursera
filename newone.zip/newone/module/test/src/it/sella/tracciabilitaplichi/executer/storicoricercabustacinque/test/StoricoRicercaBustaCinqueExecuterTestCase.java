package it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.StoricoRicercaBustaCinqueExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.RicercaView;
import it.sella.tracciabilitaplichi.mock.pdfgenerator.BustaCinqueRicercaPDFGeneratorMock;
import it.sella.tracciabilitaplichi.pdfgenerator.BustaCinqueRicercaPDFGenerator;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.easymock.EasyMock;


public class StoricoRicercaBustaCinqueExecuterTestCase extends AbstractSellaExecuterMock
{
	StoricoRicercaBustaCinqueExecuter storicoRicercaBustaCinqueExecuter = new StoricoRicercaBustaCinqueExecuter();
	public StoricoRicercaBustaCinqueExecuterTestCase(String name) {
		super(name);
	}
 
	
	 public void testStoricoRicercaBustaCinqueExecuter_01(){
			
		 Hashtable views = new Hashtable();
			List arrListRicercaView = new ArrayList();
			RicercaView ricercaView = new RicercaView();
			ricercaView.setBarCode("123456666");
			ricercaView.setCdr("BSA12");
			arrListRicercaView.add(ricercaView);
			
			views.put("CollRicercaList",arrListRicercaView);
			views.put("SearchType","Test");
			
			expecting( getRequestEvent().getEventName()).andReturn( "TrBack" ).anyTimes();
			expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
			expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
			expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
			
	        playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueExecuter.execute(getRequestEvent());
		
	}
	
	 public void testStoricoRicercaBustaCinqueExecuter_02(){
		 	setUpMockMethods(BustaCinqueRicercaPDFGenerator.class, BustaCinqueRicercaPDFGeneratorMock.class);
		 	ArrayList arrayList=new ArrayList();
		 	arrayList.add("");
		 	arrayList.add("");
		 	Hashtable views = new Hashtable();
			List arrListRicercaView = new ArrayList();
			RicercaView ricercaView = new RicercaView();
			ricercaView.setBarCode("123456666");
			ricercaView.setCdr("BSA12");
			arrListRicercaView.add(ricercaView);
			views.put("CollRicercaList",arrListRicercaView);
			views.put("SearchType","Test");
			views.put("FiltraCollRicercaView", arrayList);
			expecting( getRequestEvent().getEventName()).andReturn( "TrStampa" ).anyTimes();
			expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
			expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
			expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	        playAll();
	        ExecuteResult executeResult = storicoRicercaBustaCinqueExecuter.execute(getRequestEvent());
	}
	 
	 public void testStoricoRicercaBustaCinqueExecuter_03(){
		 BustaCinqueRicercaPDFGeneratorMock.setRemoteException();
		 	setUpMockMethods(BustaCinqueRicercaPDFGenerator.class, BustaCinqueRicercaPDFGeneratorMock.class);
		 	ArrayList arrayList=new ArrayList();
		 	arrayList.add("");
		 	arrayList.add("");
		 	Hashtable views = new Hashtable();
			List arrListRicercaView = new ArrayList();
			RicercaView ricercaView = new RicercaView();
			ricercaView.setBarCode("123456666");
			ricercaView.setCdr("BSA12");
			arrListRicercaView.add(ricercaView);
			views.put("CollRicercaList",arrListRicercaView);
			views.put("SearchType","Test");
			views.put("FiltraCollRicercaView", arrayList);
			expecting( getRequestEvent().getEventName()).andReturn( "TrStampa" ).anyTimes();
			expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
			expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
			expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	        playAll();
	        ExecuteResult executeResult = storicoRicercaBustaCinqueExecuter.execute(getRequestEvent());
	}
	 
	 public void testStoricoRicercaBustaCinqueExecuter_04(){
		    BustaCinqueRicercaPDFGeneratorMock.setTracciabilitaException();
		 	setUpMockMethods(BustaCinqueRicercaPDFGenerator.class, BustaCinqueRicercaPDFGeneratorMock.class);
		 	ArrayList arrayList=new ArrayList();
		 	arrayList.add("");
		 	arrayList.add("");
		 	Hashtable views = new Hashtable();
			List arrListRicercaView = new ArrayList();
			RicercaView ricercaView = new RicercaView();
			ricercaView.setBarCode("123456666");
			ricercaView.setCdr("BSA12");
			arrListRicercaView.add(ricercaView);
			views.put("CollRicercaList",arrListRicercaView);
			views.put("SearchType","Test");
			views.put("FiltraCollRicercaView", arrayList);
			expecting( getRequestEvent().getEventName()).andReturn( "TrStampa" ).anyTimes();
			expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
			expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
			expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
			expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	        playAll();
	        ExecuteResult executeResult = storicoRicercaBustaCinqueExecuter.execute(getRequestEvent());
	}
}
