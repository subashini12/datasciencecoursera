package it.sella.tracciabilitaplichi.executer.gestorebustanera.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;


public class BustaNeraConfermaProcessorTest extends AbstractSellaExecuterMock{

	public BustaNeraConfermaProcessorTest(final String name) {
		super(name);
	}

	BustaNeraConfermaProcessor processor = new BustaNeraConfermaProcessor() ;

	public void testSetExecuteResult_01() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("widelyUsedCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("MailMe")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance( ).getExecuteResult( CONSTANTS.TR_CONFERMA.getValue( ) );
		processor.setExecuteResult(getRequestEvent(), executeResult);
		assertTrue(true);
	}

	public void testValidateInputs_01() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("widelyUsedCdr")).andReturn("").anyTimes();
		playAll();
		try {
			final String[] validationError = processor.validateInputs(getRequestEvent());
			assertEquals(validationError[0],"TRPL-1046");
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testValidateInputs_02() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("widelyUsedCdr")).andReturn("-1").anyTimes();
		playAll();
		try {
			final String[] validationError = processor.validateInputs(getRequestEvent());
			assertEquals(validationError[0],"TRPL-1078");
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testValidateInputs_03() {
		ExecutersHelperMock.setCorrectedData();
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("widelyUsedCdr")).andReturn("1").anyTimes();
		playAll();
		try {
			final String[] validationError = processor.validateInputs(getRequestEvent());
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testValidateInputs_04() {
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("widelyUsedCdr")).andReturn("-1").anyTimes();
		playAll();
		try {
			final String[] validationError = processor.validateInputs(getRequestEvent());
			assertEquals(validationError[0],"TRPL-1345");
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}

	public void testValidateInputs_05() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("widelyUsedCdr")).andReturn("").anyTimes();
		playAll();
		try {
			final String[] validationError = processor.validateInputs(getRequestEvent());
			assertEquals(validationError[0],"TRPL-1046");
		} catch (final RemoteException e) {
			assertNotNull(e);
		} catch (final TracciabilitaException e) {
			assertNotNull(e);
		}
	}
}
