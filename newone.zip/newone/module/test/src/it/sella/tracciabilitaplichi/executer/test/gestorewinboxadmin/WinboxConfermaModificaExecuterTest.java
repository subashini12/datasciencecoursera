package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.TracciabilitaPlichiFactory;
import it.sella.tracciabilitaplichi.TracciabilitaPlichiFactoryMock;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxConfermaModificaExecuter;
import it.sella.tracciabilitaplichi.implementation.admin.AltriWinboxAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.AltriWinboxAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Test;

public class WinboxConfermaModificaExecuterTest
{
	WinboxConfermaModificaExecuter winboxConfermaModificaExecuter = new WinboxConfermaModificaExecuter();

	@Test
	public void testWinboxConfermaModificaExecuter_01() {
			Mockit.setUpMock(TracciabilitaPlichiFactory.class,TracciabilitaPlichiFactoryMock.class);
			Mockit.setUpMock(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
			Mockit.setUpMock(AltriWinboxAdminImpl.class, AltriWinboxAdminImplMock.class);
			Mockit.setUpMock(LogEvent.class, LogEventMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			final Map<Long, String> clasificazioneMap = new HashMap<Long, String>();
			clasificazioneMap.put(22L, "test");
			final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
			EasyMock.expect(stateMachineSession.get("CLASSIFICAZIONE_MAP"))
					.andReturn((Serializable) clasificazioneMap).anyTimes();
			final Hashtable altriWinboxTable = new Hashtable();
			altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
			final AltriWinboxView view = new AltriWinboxView();
			view.setNoOfYrs(66L);
			altriWinboxTable.put("OldAltriWinboxView", view);
			EasyMock.expect(stateMachineSession.get("AltriWinboxTable"))
					.andReturn(altriWinboxTable).anyTimes();
			EasyMock.expect(stateMachineSession.remove("AltriWinboxTable"))
					.andReturn(true).anyTimes();
			EasyMock.replay(stateMachineSession);
			final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
			EasyMock.expect(requestEvent.getAttribute("abilitato")).andReturn(
					"22").anyTimes();
			EasyMock.expect(requestEvent.getAttribute("ID")).andReturn("22")
					.anyTimes();
			EasyMock.expect(requestEvent.getAttribute("Desc")).andReturn("22")
					.anyTimes();
			EasyMock.expect(requestEvent.getAttribute("Cdr")).andReturn("22")
					.anyTimes();
			EasyMock.expect(requestEvent.getAttribute("tipoOggetto")).andReturn(
					"22").anyTimes();
			EasyMock.expect(requestEvent.getAttribute("customAccess"))
					.andReturn("22").anyTimes();
			EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
			EasyMock.replay(requestEvent);
			winboxConfermaModificaExecuter
					.execute(requestEvent);
	}

	/*public void testWinboxConfermaModificaExecuter_02() {
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(AltriWinboxAdminImpl.class, AltriWinboxAdminImplMock.class);
			setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
			setUpMockMethods(LogEvent.class, LogEventMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			expecting(getRequestEvent().getAttribute("abilitato")).andReturn(
					"22").anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("22")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("Desc")).andReturn("22")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("Cdr")).andReturn("22")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn(
					"22").anyTimes();
			expecting(getRequestEvent().getAttribute("customAccess"))
					.andReturn("22").anyTimes();
			final Map<Long, String> clasificazioneMap = new HashMap<Long, String>();
			clasificazioneMap.put(22L, "test");
			expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP"))
					.andReturn((Serializable) clasificazioneMap).anyTimes();
			final Hashtable altriWinboxTable = new Hashtable();
			altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
			final AltriWinboxView view = new AltriWinboxView();
			view.setNoOfYrs(66L);
			altriWinboxTable.put("OldAltriWinboxView", view);
			expecting(getStateMachineSession().get("AltriWinboxTable"))
					.andReturn(altriWinboxTable).anyTimes();
			expecting(getStateMachineSession().remove("AltriWinboxTable"))
					.andReturn(true).anyTimes();
			playAll();
			winboxConfermaModificaExecuter
					.execute(getRequestEvent());
	}

	public void testWinboxConfermaModificaExecuter_03() {
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(LogEvent.class, LogEventMock.class);
			setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
			setUpMockMethods(AltriWinboxAdminImpl.class, AltriWinboxAdminImplMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			expecting(getRequestEvent().getAttribute("abilitato")).andReturn(
					"22").anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("22")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("Desc")).andReturn("22")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("Cdr")).andReturn("22")
					.anyTimes();
			expecting(getRequestEvent().getAttribute("tipoOggetto")).andReturn(
					"22").anyTimes();
			expecting(getRequestEvent().getAttribute("customAccess"))
					.andReturn("22").anyTimes();
			final Map<Long, String> clasificazioneMap = new HashMap<Long, String>();
			clasificazioneMap.put(22L, "test");
			expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP"))
					.andReturn((Serializable) clasificazioneMap).anyTimes();
			final Hashtable altriWinboxTable = new Hashtable();
			altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
			final AltriWinboxView view = new AltriWinboxView();
			view.setNoOfYrs(66L);
			altriWinboxTable.put("OldAltriWinboxView", view);
			expecting(getStateMachineSession().get("AltriWinboxTable"))
					.andReturn(altriWinboxTable).anyTimes();
			expecting(getStateMachineSession().remove("AltriWinboxTable"))
					.andReturn(true).anyTimes();
			playAll();
			winboxConfermaModificaExecuter
					.execute(getRequestEvent());
	}
	*/
	/*public void testWinboxConfermaModificaExecuter_04() {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		Mockit.setUpMock(AltriWinboxAdminImpl.class, AltriWinboxAdminImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		expecting(requestEvent().getAttribute("abilitato")).andReturn(
				"22").anyTimes();
		expecting(requestEvent().getAttribute("ID")).andReturn("22")
				.anyTimes();
		expecting(requestEvent().getAttribute("Desc")).andReturn("22")
				.anyTimes();
		expecting(requestEvent().getAttribute("Cdr")).andReturn("22")
				.anyTimes();
		expecting(requestEvent().getAttribute("tipoOggetto")).andReturn(
				"22").anyTimes();
		expecting(requestEvent().getAttribute("customAccess"))
				.andReturn("22").anyTimes();
		final Map<Long, String> clasificazioneMap = new HashMap<Long, String>();
		clasificazioneMap.put(22L, "test");
		expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP"))
				.andReturn((Serializable) clasificazioneMap).anyTimes();
		final Hashtable altriWinboxTable = new Hashtable();
		altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
		final AltriWinboxView view = new AltriWinboxView();
		view.setNoOfYrs(66L);
		altriWinboxTable.put("OldAltriWinboxView", view);
		expecting(getStateMachineSession().get("AltriWinboxTable"))
				.andReturn(altriWinboxTable).anyTimes();
		expecting(getStateMachineSession().remove("AltriWinboxTable"))
				.andReturn(true).anyTimes();
		playAll();
		winboxConfermaModificaExecuter
				.execute(requestEvent());
}
	
	public void testWinboxConfermaModificaExecuter_015() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		Mockit.setUpMock(AltriWinboxAdminImpl.class, AltriWinboxAdminImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		expecting(requestEvent().getAttribute("abilitato")).andReturn(
				"22").anyTimes();
		expecting(requestEvent().getAttribute("ID")).andReturn("22")
				.anyTimes();
		expecting(requestEvent().getAttribute("Desc")).andReturn("22")
				.anyTimes();
		expecting(requestEvent().getAttribute("Cdr")).andReturn("22")
				.anyTimes();
		expecting(requestEvent().getAttribute("tipoOggetto")).andReturn(
				"22").anyTimes();
		expecting(requestEvent().getAttribute("customAccess"))
				.andReturn("22").anyTimes();
		final Map<Long, String> clasificazioneMap = new HashMap<Long, String>();
		clasificazioneMap.put(22L, "test");
		expecting(getStateMachineSession().get("CLASSIFICAZIONE_MAP"))
				.andReturn((Serializable) clasificazioneMap).anyTimes();
		final Hashtable altriWinboxTable = new Hashtable();
		altriWinboxTable.put("NewAltriWinboxView", clasificazioneMap);
		final AltriWinboxView view = new AltriWinboxView();
		view.setNoOfYrs(66L);
		altriWinboxTable.put("OldAltriWinboxView", view);
		expecting(getStateMachineSession().get("AltriWinboxTable"))
				.andReturn(altriWinboxTable).anyTimes();
		expecting(getStateMachineSession().remove("AltriWinboxTable"))
				.andReturn(true).anyTimes();
		playAll();
		winboxConfermaModificaExecuter
				.execute(requestEvent());
}*/
}
