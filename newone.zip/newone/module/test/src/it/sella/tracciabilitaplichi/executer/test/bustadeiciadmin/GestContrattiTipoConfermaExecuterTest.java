package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestContrattiTipoConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;
import it.sella.tracciabilitaplichi.log.ContrattiTipoLogContent;
import it.sella.tracciabilitaplichi.log.ContrattiTipoLogContentMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

public class GestContrattiTipoConfermaExecuterTest extends AbstractSellaExecuterMock
{
	final GestContrattiTipoConfermaExecuter executer = new GestContrattiTipoConfermaExecuter();
	public GestContrattiTipoConfermaExecuterTest(final String name)
	{
		super(name);
	}
	public void testGestContrattiTipoConfermaExecuter_forSuccessCase()
	{
		expecting(getRequestEvent().getAttribute("ContrattiId")).andReturn("08").anyTimes();
		expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("08").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("08").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CONTRATTI_PRODOTTI_VIEW")).andReturn(getContrattiProdottoView()).anyTimes();
		playAll();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(ContrattiTipoLogContent.class,ContrattiTipoLogContentMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		executer.execute(getRequestEvent());
	}
	public void testGestContrattiTipoConfermaExecuter_forTracciabilitaExceptionCase()
	{
		SecurityWrapperMock.setTracciabilitaException();
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("ContrattiId")).andReturn("08").anyTimes();
		expecting(getRequestEvent().getAttribute("contrattoDaControllare")).andReturn("08").anyTimes();
		expecting(getRequestEvent().getAttribute("ContrattiFlagObbl")).andReturn("08").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CONTRATTI_PRODOTTI_VIEW")).andReturn(getContrattiProdottoView()).anyTimes();
		playAll();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class, TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(ContrattiTipoLogContent.class,ContrattiTipoLogContentMock.class);
		executer.execute(getRequestEvent());
	}
	public ContrattiProdottoView getContrattiProdottoView()
	{
		final ContrattiProdottoView contrattiProdottoView = new ContrattiProdottoView();
		contrattiProdottoView.setCodContratto("abc");
		return contrattiProdottoView;
	}

}
