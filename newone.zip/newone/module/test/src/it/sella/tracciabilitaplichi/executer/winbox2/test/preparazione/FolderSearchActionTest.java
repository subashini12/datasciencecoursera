package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.winbox2.AbstractExecuter;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.FolderSearchAction;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

public class FolderSearchActionTest extends TestCase
{
	
    public void testGetLoggerMap( )
    {
        final AbstractExecuter abstractExecuter = new FolderSearchAction( );
        final Map<CONSTANTS,String> actual = abstractExecuter.getLoggerMap( new HashMap<Enum, Object>( 1 ) );
        assertEquals( null, actual );
    }
    
    public void testGetLogger( )
    {
        final Log4Debug expected = Log4DebugFactory.getLog4Debug( FolderSearchAction.class );
        final AbstractExecuter abstractExecuter = new FolderSearchAction( );
        assertEquals(  expected.getClass( ), abstractExecuter.getLogger( ).getClass( ) );
    }

}
