package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.VisualizzaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestoreBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ImageStorageSystemWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ImageStorageSystemWrapperMock;

public class VisualizzaExecuterTest extends  AbstractSellaExecuterMock
{

	public VisualizzaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stubs
	}
	
	VisualizzaExecuter executer = new VisualizzaExecuter();
	
	public void testVisualizzaExecuter_01()
	{
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ncd")).andReturn("9012211212121").anyTimes();
		expecting( getRequestEvent().getAttribute("causale")).andReturn("FOLD").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.SCAN_SOURCE.toString( ))).andReturn("21").anyTimes();
		final Long imageId = 1L;
		expecting(getStateMachineSession().put( CONSTANTS.SLID.getValue( ), imageId  ) ).andReturn( null );
		expecting( getRequestEvent().getAttribute( CONSTANTS.VISIBILITA_PRATICA.getValue( ))).andReturn("FOLD").anyTimes();;
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testVisualizzaExecuter_02()
	{
		ImageStorageSystemWrapperMock.setImgIdAsNull();
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);
		expecting( getRequestEvent().getAttribute("ncd")).andReturn("9012211212121").anyTimes();
		expecting( getRequestEvent().getAttribute("causale")).andReturn("FOLD").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.SCAN_SOURCE.toString( ))).andReturn("21").anyTimes();
		final Long imageId = null;
		expecting(getStateMachineSession().put( CONSTANTS.SLID.getValue( ), imageId  ) ).andReturn( null );
		expecting( getRequestEvent().getAttribute( CONSTANTS.VISIBILITA_PRATICA.getValue( ))).andReturn("FOLD").anyTimes();;
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testVisualizzaExecuter_03()
	{
		setUpMockMethods( GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class );
		expecting( getRequestEvent().getAttribute("ncd")).andReturn("9012211212121").anyTimes();
		expecting( getRequestEvent().getAttribute("causale")).andReturn("NOTFOLD").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.SCAN_SOURCE.toString( ))).andReturn("1").anyTimes();
		final Long imageId = 9012211212121L;		
		expecting( getStateMachineSession().remove( CONSTANTS.SLID.getValue( ) ) ).andReturn(null).anyTimes();
		expecting(getStateMachineSession().put( CONSTANTS.SLID.getValue( ), imageId  ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.SLID.getValue( )  ) ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute( getRequestEvent() );
	}
	
	public void testVisualizzaExecuter_04()
	{
		ImageStorageSystemWrapperMock.setTracciabilitaException();
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);		
		expecting( getRequestEvent().getAttribute("ncd")).andReturn("9012211212121").anyTimes();
		expecting( getRequestEvent().getAttribute("causale")).andReturn("FOLD").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.SCAN_SOURCE.toString( ))).andReturn("21").anyTimes();
		final Long imageId = 1L;
		expecting(getStateMachineSession().put( CONSTANTS.SLID.getValue( ), imageId  ) ).andReturn( null );
		expecting( getRequestEvent().getAttribute( CONSTANTS.VISIBILITA_PRATICA.getValue( ))).andReturn("FOLD").anyTimes();;
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testVisualizzaExecuter_06()
	{
		setUpMockMethods(ImageStorageSystemWrapper.class, ImageStorageSystemWrapperMock.class);		
		setUpMockMethods( GestoreBustaDeiciDataAccess.class, GestoreBustaDeiciDataAccessMock.class );
		expecting( getRequestEvent().getAttribute("ncd")).andReturn("009012211212121").anyTimes();
		expecting( getRequestEvent().getAttribute("causale")).andReturn("FOLD").anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.SCAN_SOURCE.toString( ))).andReturn("21").anyTimes();
		final Long imageId = 1L;
		expecting(getStateMachineSession().put( CONSTANTS.SLID.getValue( ), imageId  ) ).andReturn( null );
		expecting( getRequestEvent().getAttribute( CONSTANTS.VISIBILITA_PRATICA.getValue( ))).andReturn("FOLD").anyTimes();;
		expecting( getStateMachineSession().remove( CONSTANTS.SLID.getValue( ) ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().containsKey( CONSTANTS.SLID.getValue( )  ) ).andReturn( Boolean.FALSE ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}

}
