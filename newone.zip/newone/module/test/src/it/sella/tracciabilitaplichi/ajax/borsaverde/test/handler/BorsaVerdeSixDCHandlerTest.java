package it.sella.tracciabilitaplichi.ajax.borsaverde.test.handler;

import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.ajax.borsaverde.handler.BorsaVerdeSixDCHandler;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.TPAsserts;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;
import it.sella.tracciabilitaplichi.interfaces.dao.IBorsaVerdeDataAccess;
import it.sella.tracciabilitaplichi.log.BorsaVerdeLogContent;
import it.sella.tracciabilitaplichi.log.LogEvent;
import it.sella.tracciabilitaplichi.persistence.dao.AbstractDAOFactory;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;
import it.sella.webutil.ajax.returntypes.AjaxStringBuffer;
import it.sella.webutil.ajax.returntypes.ObjectSizeException;
import it.sella.webutil.ajax.returntypes.StringItemsTreeSet;

import java.rmi.RemoteException;

import mockit.Mockit;

public class BorsaVerdeSixDCHandlerTest extends AbstractSellaMock {
	
	private IBorsaVerdeDataAccess borsaVerdeDataAccess = null;
	
    public BorsaVerdeSixDCHandlerTest( final String name ) {
        super( name );
    }

    @Override
	protected void setUp( ) throws Exception {
        super.setUp( );
        borsaVerdeDataAccess = getMock( IBorsaVerdeDataAccess.class );
 	   redefineMethod( AbstractDAOFactory.class, new Object( ) {
		   public IBorsaVerdeDataAccess getBorsaVerdeDataAccess ( )
		   {
			   return borsaVerdeDataAccess;
		   }
	   });
 	   TPAsserts.assertPojoGetterSetter(BorsaVerdeAttributeView.class);
 	   TPAsserts.assertPojoGetterSetter(BorsaVerdeLogContent.class);
    }

    public void testValidateSixDC_01( ) throws ObjectSizeException {
        final BorsaVerdeSixDCHandler borsaVerdeSixDCHandler = new BorsaVerdeSixDCHandler( );
        final StringItemsTreeSet expected = new StringItemsTreeSet( );
        expected.add( ITPConstants.VALID );
        final StringItemsTreeSet actual = borsaVerdeSixDCHandler.validateSixDC( "R111222333444" );
        assertEquals( expected.toString( ), actual.toString( ) );
    }

    public void testValidateSixDC_02( ) throws ObjectSizeException {
        final BorsaVerdeSixDCHandler borsaVerdeSixDCHandler = new BorsaVerdeSixDCHandler( );
        final StringItemsTreeSet expected = new StringItemsTreeSet( );
        expected.add( ITPConstants.IN_VALID );
        final StringItemsTreeSet actual = borsaVerdeSixDCHandler.validateSixDC( "1111222333444" );
        assertEquals( expected.toString( ), actual.toString( ) );
    }

    public void testGetHtmlResponse_01( ) {
          final String expected = IErrorCodes.TRPL_1026;
          final BorsaVerdeSixDCHandler borsaVerdeSixDCHandler = new BorsaVerdeSixDCHandler( );
          final AjaxStringBuffer actual = borsaVerdeSixDCHandler.getHtmlResponse( "111111111" );
          assertEquals( expected, actual.toString( ) );
    }
    
    public void testGetHtmlResponse_02( ) {
    	  Mockit.setUpMock(LogEvent.class,LogEventMock.class );
    	  final BorsaVerdeAttributeView borsaVerdeAttributeView = new BorsaVerdeAttributeView( );
    	  borsaVerdeAttributeView.setCode( "R111222333444" );
          try {
			expecting( this.borsaVerdeDataAccess.isBorsaVerdeAlreadyExists( borsaVerdeAttributeView ) ).andReturn( Boolean.TRUE );
          }
          catch ( final RemoteException e ) { }
          catch ( final TracciabilitaException e ) { }
          play( this.borsaVerdeDataAccess );
          final String expected = IErrorCodes.TRPL_1510;
          final BorsaVerdeSixDCHandler borsaVerdeSixDCHandler = new BorsaVerdeSixDCHandler( );
          final AjaxStringBuffer actual = borsaVerdeSixDCHandler.getHtmlResponse( "R111222333444" );
          assertNotNull(actual);
    }
    
}
