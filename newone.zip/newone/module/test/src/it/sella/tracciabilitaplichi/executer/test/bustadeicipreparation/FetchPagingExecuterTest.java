package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.FetchPagingExecuter;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.ResourceBundle;

import junit.framework.TestCase;

public class FetchPagingExecuterTest extends TestCase
{

	private RequestEvent requestEvent = null;
	private StateMachineSession session = null;
	private Busta10PreparationPageView pageView = null;
	
	public FetchPagingExecuterTest( final String name )
	{
		super( name );
	}
	
	@Override
	protected void setUp( ) throws Exception
	{
		super.setUp( );
		this.requestEvent = createMock( RequestEvent.class );
		this.session = createMock( StateMachineSession.class );
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		pageView = getPageView( "CTR1" );
		for( int i = 0; i < 11; i++ )
		{
			addContractColl( pageView, "CTR2" );
		}
		expect( this.session.get( "Busta10PreparationPageView" ) ).andReturn( pageView );
	}
	
	@Override
	protected void tearDown( )
	{
		
	}
	
	public void testFetchPagingExecuter1( )
	{
		expect( this.requestEvent.getAttribute( "bustaId" ) ).andReturn( new String[ ] {"3722813","3723020","3723020","3723020","3723020","3723020","3723020","3723020","3723020","3723020","3723020"} );
		expect( this.requestEvent.getAttribute( "PageNo" ) ).andReturn( "2" );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new FetchPagingExecuter( ).execute( this.requestEvent );
		assertEquals( CONSTANTS.TR_CONFERMA.getValue( ), executeResult.getTransition( ) );
		assertEquals( 2, pageView.getCurrentPageNo( ) );
		assertEquals( 2, pageView.getTotalPages( ) );
		assertEquals( 2, pageView.getCurrentPageBustaDeiciAttributeViews( ).size( ) );
		assertEquals( 12, pageView.getAllBustaDeiciAttributeViews( ).size( ) );
	}
	
	private Busta10PreparationPageView getPageView( final String key )
	{
		final Busta10PreparationPageView pageView = new Busta10PreparationPageView( );
		if ( key != null )
		{
			addContractColl( pageView, key );
		}
		return pageView;
	}
	
	private void addContractColl( final Busta10PreparationPageView pageView, final String key )
	{
		final Collection<BustaDeiciAttributeView> contractColl = getContractCollection( key );
		pageView.addBustaDeiciAttributeViewsForBarCode( contractColl, ( ( ArrayList<BustaDeiciAttributeView> ) contractColl ).get( 0 ).getNumeroCodiceDerivati( ) );
	}
	
	private Collection<BustaDeiciAttributeView> getContractCollection( final String key )
	{
		final Collection<BustaDeiciAttributeView> contractColl = new ArrayList<BustaDeiciAttributeView>( );
		final String value = getBundle( ).getString( key );
		final String[ ] contractTokens = value.split( "\\|" );
		BustaDeiciAttributeView attributeView = null;
		for ( int i = 0; i < contractTokens.length; i++ )
		{
			if ( contractTokens[ i ] != "" )
			{
				final String[ ] contractDetails = contractTokens[ i ].split( "," );
				attributeView = new BustaDeiciAttributeView( );
				attributeView.setBustaDeiciId( Long.valueOf( contractDetails[ 0 ] ) );
				attributeView.setCodProdottoContratto( contractDetails[ 1 ] );
				attributeView.setNumeroConto( contractDetails[ 2 ] );
				attributeView.setOttoCifre( contractDetails[ 3 ] );
				attributeView.setNumeroCodiceDerivati( contractDetails[ 4 ] );
				attributeView.setAnagrafica( contractDetails[ 5 ] );
				contractColl.add( attributeView );
			}
		}
		return contractColl;
	}
	
	private ResourceBundle getBundle( )
	{
		return ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.ContractDetails" );
	}

}
