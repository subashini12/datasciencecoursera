package it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.StoricoRicercaBustaCinqueDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;


public class StoricoRicercaBustaCinqueDefaultExecuterTestCase extends AbstractSellaExecuterMock
{
	StoricoRicercaBustaCinqueDefaultExecuter storicoRicercaBustaCinqueDefaultExecuter = new StoricoRicercaBustaCinqueDefaultExecuter();
	public StoricoRicercaBustaCinqueDefaultExecuterTestCase(String name) {
		super(name);
	}
 
	public void testStoricoRicercaBustaCinqueDefaultExecuter_01(){
       
	    Hashtable views = new Hashtable();
		List arrListRicercaView = new ArrayList();
		arrListRicercaView.add("23");
		arrListRicercaView.add("256");
		arrListRicercaView.add("234");
		arrListRicercaView.add("212");
		arrListRicercaView.add("209");
		views.put("FiltraCollRicercaView",arrListRicercaView);
		expecting( getRequestEvent().getEventName()).andReturn( "TrDefault" ).anyTimes();
		expecting(getStateMachineSession().containsKey("PageNo")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("PageNo")).andReturn("12").anyTimes();
		expecting( getStateMachineSession( ).remove( "PageNo" ) ).andReturn( true );
		
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
        playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueDefaultExecuter.execute(getRequestEvent());
		
		
	} 
	public void testStoricoRicercaBustaCinqueDefaultExecuter_02(){
	       
	    Hashtable views = new Hashtable();
		List arrListRicercaView = new ArrayList();
		arrListRicercaView.add("23");
		arrListRicercaView.add("256");
		arrListRicercaView.add("234");
		arrListRicercaView.add("212");
		arrListRicercaView.add("209");
		views.put("FiltraCollRicercaView",arrListRicercaView);
		expecting( getRequestEvent().getEventName()).andReturn( "TrPageLink" ).anyTimes();
		expecting( getRequestEvent().getAttribute("PageNo")).andReturn("234");
		expecting( getStateMachineSession( ).remove( "PageNo" ) ).andReturn( true );
		
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
        playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueDefaultExecuter.execute(getRequestEvent());
		
		
	} 
	
	public void testStoricoRicercaBustaCinqueDefaultExecuter_03(){
	       
	    Hashtable views = new Hashtable();
		List arrListRicercaView = new ArrayList();
		views.put("FiltraCollRicercaView",arrListRicercaView);
		expecting( getRequestEvent().getEventName()).andReturn( "TrPageLink" ).anyTimes();
		expecting( getRequestEvent().getAttribute("PageNo")).andReturn("234");
		expecting( getStateMachineSession( ).remove( "PageNo" ) ).andReturn( true );
		
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
        playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueDefaultExecuter.execute(getRequestEvent());
		
		assertEquals("TRPL-1021" ,executeResult.getAttribute("MSG") );
	} 
}
