package it.sella.tracciabilitaplichi.executer.test.gestorecassetto;

import it.sella.tracciabilitaplichi.executer.gestorecassetto.CassettoDatiRecuperiExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;

import org.easymock.EasyMock;

public class CassettoDatiRecuperiExecuterTest extends AbstractSellaExecuterMock
{

	public CassettoDatiRecuperiExecuterTest(final String name) 
	{
		super(name);
	}
	
	CassettoDatiRecuperiExecuter executer = new CassettoDatiRecuperiExecuter();
	
   /*public void testCassettoDatiRecuperiExecuter_01()
   {
	   setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class );
	   setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
	   expecting(getRequestEvent().getAttribute("cassetto")).andReturn("ab,cd");
	   expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	   playAll();
	   executer.execute(getRequestEvent()); 
   }*/
   public void testCassettoDatiRecuperiExecuter_02()
   {
	   TracciabilitaPlichiCassettoDataAccessMock.setCollLinkedCasettoAsNull();
	   setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class );
	   setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
	   expecting(getRequestEvent().getAttribute("cassetto")).andReturn("ab,cd");
	   expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	   playAll();
	   executer.execute(getRequestEvent()); 
   }
   
   public void testCassettoDatiRecuperiExecuter_03()
   {
	   DBPersonaleWrapperMock.setTracciabilitaException();
	   TracciabilitaPlichiCassettoDataAccessMock.setCollLinkedCasettoAsNull();
	   setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class );
	   setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
	   expecting(getRequestEvent().getAttribute("cassetto")).andReturn("ab,cd");
	   expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	   playAll();
	   executer.execute(getRequestEvent()); 
   }
   public void testCassettoDatiRecuperiExecuter_04()
   {
	   TracciabilitaPlichiCassettoDataAccessMock.setRemoteException();
	   setUpMockMethods( TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class );
	   setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
	   expecting(getRequestEvent().getAttribute("cassetto")).andReturn("ab,cd");
	   expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
	   playAll();
	   executer.execute(getRequestEvent()); 
   }
}
