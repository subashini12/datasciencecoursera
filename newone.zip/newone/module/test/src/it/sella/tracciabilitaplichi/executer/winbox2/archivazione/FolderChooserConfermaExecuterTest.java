/*package it.sella.tracciabilitaplichi.executer.winbox2.archivazione;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.winbox2.archivazione.processor.FolderChooserProcessor;
import it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione.HelperMock;
import it.sella.tracciabilitaplichi.winbox2.archivazione.WinBox2ArchivazioneHelper;
import it.sella.tracciabilitaplichi.winbox2.test.mock.WinBox2ArchivazioneHelperMock;

public class FolderChooserConfermaExecuterTest extends
		AbstractSellaExecuterTest {

	public FolderChooserConfermaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	FolderChooserConfermaExecuter executer = new FolderChooserConfermaExecuter();

	public void testFolderChooserConfermaExecuter_01() {
		HelperMock.setMapWithWINBOX2INPUTPROCESSOR();
		setUpMockMethods(WinBox2ArchivazioneHelper.class, WinBox2ArchivazioneHelperMock.class);
		setUpMockMethods(Helper.class, HelperMock.class);
		setUpMockMethods(FolderChooserProcessor.class, FolderChooserProcessorMock.class);
		executer.execute(getRequestEvent());
	}
}
*/