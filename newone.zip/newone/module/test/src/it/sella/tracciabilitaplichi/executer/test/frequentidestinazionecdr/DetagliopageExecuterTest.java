package it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr;

import it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.DetagliopageExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPFrequentiDestinazioneCdrDataAccessMock;

public class DetagliopageExecuterTest extends AbstractSellaExecuterMock
{

	public DetagliopageExecuterTest(String name) 
	{
		super(name);
	}

	DetagliopageExecuter executer = new DetagliopageExecuter();
	
	public void testDetagliopageExecuter_01()
	{
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class , TPFrequentiDestinazioneCdrDataAccessMock.class);
		expecting(getRequestEvent().getAttribute( "cdrId" )).andReturn("arg0").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDetagliopageExecuter_02()
	{
		TPFrequentiDestinazioneCdrDataAccessMock.setfrequentiDestinazioneCdrExist();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class , TPFrequentiDestinazioneCdrDataAccessMock.class);
		expecting(getRequestEvent().getAttribute( "cdrId" )).andReturn("arg0").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDetagliopageExecuter_03()
	{
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class , TPFrequentiDestinazioneCdrDataAccessMock.class);
		expecting(getRequestEvent().getAttribute( "cdrId" )).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testDetagliopageExecuter_04()
	{
		TPFrequentiDestinazioneCdrDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TPFrequentiDestinazioneCdrDataAccess.class , TPFrequentiDestinazioneCdrDataAccessMock.class);
		expecting(getRequestEvent().getAttribute( "cdrId" )).andReturn(null);
		playAll();
		executer.execute(getRequestEvent());
	}
}
