package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class TPContrattiProdottoDataAccessTest
{
	TPContrattiProdottoDataAccess tpContrattiProdottoDataAccess=null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		tpContrattiProdottoDataAccess = new TPContrattiProdottoDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		tpContrattiProdottoDataAccess = null;
	}

	@Test
	public void getDescConByCodeProdCon() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(getDescConByCodeProdConSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1,1,"11");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertEquals("11", tpContrattiProdottoDataAccess.getDescConByCodeProdCon("1234"));
	}

	private String getDescConByCodeProdConSt(){
		return "SELECT CP_DESC_CONTRATTO FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PRODCONT = ?";
	}

	@Test
	public void getCPViewByCodProdottoContratto() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getProdCodeSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1,1,"1234");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertEquals("1234", tpContrattiProdottoDataAccess.getCPViewByCodProdottoContratto("12"));
	}
	private String getProdCodeSt(){
		return "SELECT CP_COD_PROD FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PRODCONT = ?";
	}
	@Test
	public void getCPViewByCodiceContrattoAndAbiBanca() throws RemoteException, TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getCPViewSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 0, "CP_COD_CONTRATTO","12");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "CP_COD_PRODCONT","1234");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Hashtable resultHashTable = tpContrattiProdottoDataAccess.getCPViewByCodiceContrattoAndAbiBanca("","","");
		Assert.assertEquals(1, resultHashTable.size());
		final String ContrattiprodCode = (String) resultHashTable.get("12");
		Assert.assertEquals("1234", ContrattiprodCode);
	}
	private String getCPViewSt(){
		return "SELECT CP_COD_CONTRATTO,CP_COD_PRODCONT FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PROD = ? AND CP_ABI_BANCA = ? AND CP_FLAG_OBBL = ? " ;
	}

	@Test
	public void getCPViewByAbiBanca() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(getCPViewByAbiBancaSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 2,"2123");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 3,"21");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 4,"21Contract");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1,5,"21ContractProduct");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 6,"BS_IRORGGENERALI");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 7,"T");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,8,3l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection<ContrattiProdottoView> cPViewByAbiBanca = tpContrattiProdottoDataAccess.getCPViewByAbiBanca("03269","T","1236","descrizione",true);
		Assert.assertEquals(1, cPViewByAbiBanca.size());
	}
	private String getCPViewByAbiBancaSt(){
		final StringBuilder query = new StringBuilder( "SELECT CP_ID,CP_COD_PRODCONT,CP_COD_PROD,CP_COD_CONTRATTO,CP_DESC_CONTRATTO,CP_ABI_BANCA,CP_FLAG_OBBL,CP_IMAGINI FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_ABI_BANCA = ? ");
		query.append(" AND CP_FLAG_OBBL = ? ");
		query.append( " AND CP_COD_PROD = ? " );
		query.append( " AND CP_DESC_CONTRATTO = ? " );
		query.append( " AND CP_COD_PROD != '99' " );
		query.append( " ORDER BY UPPER( CP_DESC_CONTRATTO ) " );
		return query.toString();
	}

	@Test
	public void getImaginValue4codeProd() throws NumberFormatException, TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(getImaginValue4codeProdSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR,1, "CP_IMAGINI","12");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Long imaggineValue =tpContrattiProdottoDataAccess.getImaginValue4codeProd("3012");
		Assert.assertEquals(Long.valueOf("12"), imaggineValue);

	}

	private String getImaginValue4codeProdSt(){
		return "SELECT CP_IMAGINI FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PRODCONT = ?";
	}

	@Test
	public void isCodeProdConExists() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(isCodeProdConExistsSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final boolean isCodeProdConExists = tpContrattiProdottoDataAccess.isCodeProdConExists("20");
		Assert.assertTrue(isCodeProdConExists);

	}

	private String isCodeProdConExistsSt(){
		return "SELECT 1 FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PROD = ?";
	}

	@Test
	public void isCodeProdConExist4AbiCode() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(isCodeProdConExist4AbiCodeSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1,1,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final boolean isCodeProdConExists = tpContrattiProdottoDataAccess.isCodeProdConExist4AbiCode("20","03269");
		Assert.assertTrue(isCodeProdConExists);
	}

	private String isCodeProdConExist4AbiCodeSt(){
		return "SELECT 1 FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PRODCONT = ? AND CP_ABI_BANCA = ?";
	}

	@Test
	public void getContractsCollection() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider(ContractsCollectionSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 0, "CP_ID",1l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "CP_COD_PRODCONT","1234");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 2, "CP_COD_PROD","12");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 3, "CP_COD_CONTRATTO","CodContrato");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 4, "CP_DESC_CONTRATTO","ContractDesc");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 5, "CP_ABI_BANCA","03269");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 6, "CP_FLAG_OBBL","T");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 7, "CP_IMAGINI","12");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 8, "CP_TIPO_DA_CONTROLLARE","12");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection<ContrattiProdottoView> ContractsCollection = tpContrattiProdottoDataAccess.getContractsCollection("21","03268");
		Assert.assertNotNull(ContractsCollection);
	}

	private String ContractsCollectionSt(){
		final StringBuilder query = new StringBuilder("SELECT CP_ID,CP_COD_PRODCONT,CP_COD_PROD,CP_COD_CONTRATTO,CP_DESC_CONTRATTO,CP_ABI_BANCA,CP_FLAG_OBBL,CP_TIPO_DA_CONTROLLARE,CP_IMAGINI,CP_STARTING_ID FROM TP_MA_B10_CONTRATTI_PRODOTTO WHERE CP_COD_PROD=?");;
		query.append( "AND CP_ABI_BANCA = ?" );
		return query.toString();
	}
}
