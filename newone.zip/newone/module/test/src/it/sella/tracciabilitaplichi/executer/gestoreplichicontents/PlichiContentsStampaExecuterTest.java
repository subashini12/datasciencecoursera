package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.HistoryPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.HistoryPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.StatusModifierInfoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.mock.pdfgenerator.AltriPlichiContentsPDFGeneratorMock;
import it.sella.tracciabilitaplichi.mock.pdfgenerator.PlichiContentsPDFGeneratorMock;
import it.sella.tracciabilitaplichi.pdfgenerator.AltriPlichiContentsPDFGenerator;
import it.sella.tracciabilitaplichi.pdfgenerator.PlichiContentsPDFGenerator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Stack;

import org.easymock.EasyMock;



public class PlichiContentsStampaExecuterTest extends AbstractSellaExecuterMock{

	public PlichiContentsStampaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiContentsStampaExecuter executer=new PlichiContentsStampaExecuter();
	public void testPlichiContentsStampaExecuter_01()
	{
		setUpMockMethods(AltriPlichiContentsPDFGenerator.class, AltriPlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsStampaExecuter_02()
	{
		ClassificazioneWrapperMock.setPBUST5();
		setUpMockMethods(PlichiContentsPDFGenerator.class, PlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsStampaExecuter_03()
	{
		ClassificazioneWrapperMock.setBUST5();
		setUpMockMethods(PlichiContentsPDFGenerator.class, PlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsStampaExecuter_04()
	{
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods(PlichiContentsPDFGenerator.class, PlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsStampaExecuter_05()
	{
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods(PlichiContentsPDFGenerator.class, PlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsStampaExecuter_06()
	{
		setUpMockMethods(AltriPlichiContentsPDFGenerator.class, AltriPlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiPlichiContentsDataAccess.class, TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPlichiContentsStampaExecuter_07()
	{
		setUpMockMethods(AltriPlichiContentsPDFGenerator.class, AltriPlichiContentsPDFGeneratorMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(HistoryPlichiContentsDataAccess.class, HistoryPlichiContentsDataAccessMock.class);
		final Stack stack=getStack();
		final Hashtable hashtable=getHashtable();
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("History");
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().get("PlichiContentsHashTable")).andReturn(hashtable);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Stack getStack()
	{
		final Stack stack=new Stack();
		stack.push("1");
		return stack;
	}
	private static Hashtable getHashtable()
	{
		final Collection collection=new ArrayList();
		final Hashtable hashtable=new Hashtable();
		final TracciabilitaPlichiView tracciabilitaPlichiView=new TracciabilitaPlichiView();
		final StatusModifierInfoView statusModifierInfoView=new StatusModifierInfoView();
		hashtable.put("TracciabilitaPlichiView",tracciabilitaPlichiView );
		hashtable.put("InviaInfo",statusModifierInfoView );
		hashtable.put("Cassetto", 1L);
		hashtable.put("AltriBustaCollection",collection);
		hashtable.put("BustaCollection", collection);
		return hashtable;
	}
}
