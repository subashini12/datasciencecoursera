package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsDefaultFolderProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsDefaultProcessorMock;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultFolderProcessor;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor.PlichiContentsDefaultProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiContentsDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ImageStorageSystemWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiPlichiContentsDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ImageStorageSystemWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.HelperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.test.view.OggettoViewMock;
import it.sella.tracciabilitaplichi.implementation.test.view.PlichiAttributeViewMock;
import it.sella.tracciabilitaplichi.implementation.test.view.TracciabilitaPlichiViewMock;
import it.sella.tracciabilitaplichi.implementation.util.Helper;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.StatusModifierInfoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Stack;

import mockit.Mockit;

import org.easymock.classextension.EasyMock;

public class RiepilogoPlichiContentsDefaultExecuterTest extends AbstractSellaExecuterMock{
	
	public RiepilogoPlichiContentsDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RiepilogoPlichiContentsDefaultExecuter contentsDefaultExecuter = new RiepilogoPlichiContentsDefaultExecuter();
	
	public void testContentsDefaultExecuter_01(){
		ClassificazioneWrapperMock.setPBUST10();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_02(){
		ClassificazioneWrapperMock.setPBUSTN();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_03(){
		ClassificazioneWrapperMock.setBUSTN();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_031(){
		ClassificazioneWrapperMock.setBUSTN();
		TPUtilMock.setTracciabilitaException();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_032(){
		ClassificazioneWrapperMock.setBUSTN();
		TPUtilMock.setRemoteException();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	public void testContentsDefaultExecuter_04(){
		ClassificazioneWrapperMock.setPBUST5();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_05(){
		ClassificazioneWrapperMock.setPBUSTA20();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_06(){
		ClassificazioneWrapperMock.setBUST10();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_07(){
		ClassificazioneWrapperMock.setBUST5();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);				
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_08(){
		ClassificazioneWrapperMock.setFOLD();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(PlichiContentsDefaultFolderProcessor.class,PlichiContentsDefaultFolderProcessorMock.class);
		Mockit.setUpMock(ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);		
		Mockit.setUpMock(Helper.class,HelperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	public void testContentsDefaultExecuter_081(){
		ClassificazioneWrapperMock.setFOLD();
		ImageStorageSystemWrapperMock.setTracciabilitaException();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(PlichiContentsDefaultFolderProcessor.class,PlichiContentsDefaultFolderProcessorMock.class);
		Mockit.setUpMock(ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);		
		Mockit.setUpMock(Helper.class,HelperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_082(){
		ClassificazioneWrapperMock.setFOLD();
		ImageStorageSystemWrapperMock.setRemoteException();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(PlichiContentsDefaultFolderProcessor.class,PlichiContentsDefaultFolderProcessorMock.class);
		Mockit.setUpMock(ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);		
		Mockit.setUpMock(Helper.class,HelperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	public void testContentsDefaultExecuter_09(){
		ClassificazioneWrapperMock.setPBUSTV();
		final Stack stack = new Stack();
		stack.add("BV123456");		
		expecting( getStateMachineSession( ).get(  "BarCodeStack" ) ).andReturn(stack).anyTimes();
		expecting( getStateMachineSession( ).get(  "SearchFrom" ) ).andReturn("abc").anyTimes();
		expecting( getStateMachineSession( ).get(  "PlichiContentsHashTable" )).andReturn(getHashtable()).anyTimes();
		Mockit.setUpMock(PlichiContentsDefaultFolderProcessor.class,PlichiContentsDefaultFolderProcessorMock.class);
		Mockit.setUpMock(ImageStorageSystemWrapper.class,ImageStorageSystemWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class, SecurityWrapperMock.class);
		Mockit.setUpMock(ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(OggettoView.class,OggettoViewMock.class);
		Mockit.setUpMock(SecurityDBPersonaleWrapper.class,SecurityDBpersonaleWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(PlichiAttributeView.class,PlichiAttributeViewMock.class);
		Mockit.setUpMock(TracciabilitaPlichiView.class,TracciabilitaPlichiViewMock.class);		
		Mockit.setUpMock(Helper.class,HelperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiPlichiContentsDataAccess.class,TracciabilitaPlichiPlichiContentsDataAccessMock.class);
		Mockit.setUpMock(PlichiContentsDefaultProcessor.class,PlichiContentsDefaultProcessorMock.class);
		expecting(getStateMachineSession().containsKey("BV123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("123456")).andReturn(Boolean.FALSE).anyTimes();
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(Boolean.FALSE).anyTimes();
		expecting( getStateMachineSession( ).get(  "123456" ) ).andReturn("123456").anyTimes();
		expecting( getStateMachineSession( ).get(  "ConPageNo" ) ).andReturn(null).anyTimes();
		expecting(getRequestEvent().getEventName()).andReturn("DefaultEvent").anyTimes() ;
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		contentsDefaultExecuter.execute(getRequestEvent());
	}
	
	
	
	private Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable();
		hashtable.put("InviaInfo", getStatusModifierInfoView());
		hashtable.put("TracciabilitaPlichiView", getTracciabilitaPlichiView());
		hashtable.put("Cassetto", 1L);
		hashtable.put("RecievaInfo", getStatusModifierInfoView());
		hashtable.put("Contrattidellasuccursale","099231");
		final List list = new ArrayList();
		list.add("abc");
		hashtable.put("PlicoBustaDeiceCollection",list);
		hashtable.put("PlicoBustaNeraCollection",list);
		hashtable.put("BustaNeraCollection",list);
		hashtable.put("StatusCollection",list);
		hashtable.put("COD_PROD_CONT_LIST",list);
		hashtable.put("PLICHI_COLLECTION",list);
		hashtable.put("BV_CODE","abc");
		hashtable.put("BustaCollection",list);
		hashtable.put("stampeId","123456789123");
		hashtable.put("NoOfPages",3);
		hashtable.put("ConPageNo","5");
		hashtable.put("IS_ENDORSER_VISIBLE","yes");
		hashtable.put("ENDORSER","4");
		hashtable.put(CONSTANTS.IS_CONTRACT_REPRINT_ALLOWED,"yes");
		hashtable.put("IS_DATA_CERTA_AVAILABLE","yes");
		hashtable.put("ISSKeyID",1L);
		hashtable.put("IS_APT_CONTRACT","yes");
		hashtable.put("IS_IMMAGINI_VISIBLE","yes");
		hashtable.put("IS_DOCUMENT_SCANNED","yes");
		hashtable.put(CONSTANTS.FOLDER_TYPES_MAP.toString( ),"abc" );
		hashtable.put(CONSTANTS.GBS_COMPANY.toString( ),"gbs03094");
		hashtable.put(CONSTANTS.WINBOX2_PREPARAZIONE_MAP.toString( ),"abc" );
		hashtable.put("IS_CDR_VISIBILITY","yes");
		return hashtable;
	}

	private TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		return tracciabilitaPlichiView ;
	}
	
	private OggettoView getOggettoView()
	{
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setUserId("");
		return oggettoView ;
	}
	public StatusModifierInfoView getStatusModifierInfoView() {
		final StatusModifierInfoView statusModifierInfoView = new StatusModifierInfoView();
		statusModifierInfoView.setUserId("");
		return statusModifierInfoView;
	}
	
}
