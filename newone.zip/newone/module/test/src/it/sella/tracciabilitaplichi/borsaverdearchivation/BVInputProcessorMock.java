package it.sella.tracciabilitaplichi.borsaverdearchivation;

import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class BVInputProcessorMock {
	@Mock
	public Boolean isAnyInvalidGbCodesEntered() {
		final Boolean flag = Boolean.TRUE;
		return flag;
	}

	@Mock
	public Boolean isAnyValidGbCodesEntered() {
		final Boolean flag = Boolean.TRUE;
		return flag;
	}

	@Mock
	public Collection getInvalidGBCodesCollection() {
		final Collection collection = new ArrayList();
		collection.add("1");
		return collection;
	}
	
	@Mock
	public Boolean isAnyValidEmptyGBCodesEntered( )
	{
		final Boolean flag = Boolean.TRUE;
		return flag;
	}
	
	@Mock
	public Boolean isAnyValidNonEmtpyGBCodesEntered( )
	{
		final Boolean flag = Boolean.TRUE;
		return flag;	
	}
}
