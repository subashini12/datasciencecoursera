/*package it.sella.tracciabilitaplichi.executer.test.gestoreborsaverdeadmin;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestoreborsaverdeadmin.BorsaVerdeModificaConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

import mockit.Mockit;

public class BorsaVerdeModificaConfermaExecuterTest extends AbstractSellaExecuterTest {

    BorsaVerdeModificaConfermaExecuter  borsaVerdeModificaConfermaExecuter = new  BorsaVerdeModificaConfermaExecuter();

   public  BorsaVerdeModificaConfermaExecuterTest(final String name) {
       super(name);
   }

   public void testBorsaVerdeModificaConfermaExecuter_01() {
       final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW , new BorsaVerdeAttributeView() );
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW_NEW, new BorsaVerdeAttributeView() );
       expecting(getStateMachineSession( ).get( ITPConstants.BORSA_VERDE_MAP )).andReturn(
               ( Serializable ) archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "") ;
       playAll();
       borsaVerdeModificaConfermaExecuter
               .execute(getRequestEvent());
   }

   public void testBorsaVerdeModificaConfermaExecuter_02() throws RemoteException, TracciabilitaException {
	   Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	   setUpMockMethods(Util.class, UtilMock.class);
       final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
       final BorsaVerdeAttributeView view = new BorsaVerdeAttributeView();
       view.setId( 22L );
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW ,view);
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW_NEW, new BorsaVerdeAttributeView() );
       expecting(getStateMachineSession( ).get( ITPConstants.BORSA_VERDE_MAP )).andReturn(
               ( Serializable ) archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "") ;
       playAll();
       final ExecuteResult executeResult =  borsaVerdeModificaConfermaExecuter
               .execute(getRequestEvent());
   }
   
   public void testBorsaVerdeModificaConfermaExecuter_03() throws RemoteException, TracciabilitaException {
	   Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	   Mockit.setUpMock(Util.class, UtilMock.class);
       final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
       final BorsaVerdeAttributeView view = new BorsaVerdeAttributeView();
       view.setId( 22L );
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW ,view);
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW_NEW, new BorsaVerdeAttributeView() );
       expecting(getStateMachineSession( ).get( ITPConstants.BORSA_VERDE_MAP )).andReturn(
               ( Serializable ) archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "").anyTimes();
       playAll();
       borsaVerdeModificaConfermaExecuter
               .execute(getRequestEvent());
   }
   
   public void testBorsaVerdeModificaConfermaExecuter_04() throws RemoteException, TracciabilitaException {
	   Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	   Mockit.setUpMock(Util.class, UtilMock.class);
       final Map  archivoBustaCinqueSession =  new Hashtable( 15 );
       final BorsaVerdeAttributeView view = new BorsaVerdeAttributeView();
       view.setId( 22L );
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW ,view);
       archivoBustaCinqueSession.put( ITPConstants.BORSA_VERDE_ATTRIBUTE_VIEW_NEW, new BorsaVerdeAttributeView() );
       expecting(getStateMachineSession( ).get( ITPConstants.BORSA_VERDE_MAP )).andReturn(
               ( Serializable ) archivoBustaCinqueSession).anyTimes( ) ;
       expecting(getRequestEvent( ).getAttribute(  "id" )).andReturn(
               "") ;
       playAll();
       borsaVerdeModificaConfermaExecuter
               .execute(getRequestEvent());
   }
   
   }
*/