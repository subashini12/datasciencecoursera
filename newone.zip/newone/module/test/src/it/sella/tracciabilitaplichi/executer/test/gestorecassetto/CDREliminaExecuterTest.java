package it.sella.tracciabilitaplichi.executer.test.gestorecassetto;

import it.sella.tracciabilitaplichi.executer.gestorecassetto.CDREliminaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import org.easymock.EasyMock;

public class CDREliminaExecuterTest extends AbstractSellaExecuterMock
{

	public CDREliminaExecuterTest(String name) 
	{
		super(name);	 
	}
	
	CDREliminaExecuter executer = new CDREliminaExecuter();
	
	public void testCDREliminaExecuter_01()
	{
		Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		Collection collCDRElimina = new ArrayList();
		expecting( getRequestEvent().getAttribute( "codiceCDRId" )).andReturn( "ABCD" ).anyTimes();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) getCollLinkedCasetto() ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCDREliminaExecuter_02()
	{
		String  arraylist[] = { "abc","cde","def" };
		Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		Collection collCDRElimina = new ArrayList();
		expecting( getRequestEvent().getAttribute( "codiceCDRId" )).andReturn( arraylist).anyTimes();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) getCollLinkedCasetto() ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCDREliminaExecuter_03()
	{
		Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		Collection collCDRElimina = new ArrayList();
		collCDRElimina.add("abc");
		expecting( getRequestEvent().getAttribute( "codiceCDRId" )).andReturn( "ABCD" ).anyTimes();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) getCollLinkedCasetto() ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.FALSE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRElimina ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		//expecting( getStateMachineSession().put( "collCDRElimina" ,(Serializable)collCDRElimina ) ).andReturn( (Serializable) collCDRElimina ).anyTimes();
     	playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCDREliminaExecuter_04()
	{
		Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		expecting( getRequestEvent().getAttribute( "codiceCDRId" )).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get( "collLinkedCassetto" ) ).andReturn( (Serializable) getCollLinkedCasetto() ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRElimina" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().containsKey( "collCDRInserisci" ) ).andReturn( Boolean.TRUE ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRInserisci" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().get( "collCDRElimina" ) ).andReturn( (Serializable) collCDRInserisci ).anyTimes();
		expecting( getStateMachineSession().put( "collCDRElimina" ,(Serializable)collCDRInserisci ) ).andReturn( null ).anyTimes();
     	playAll();
		executer.execute(getRequestEvent());
	}

	private Collection getCollLinkedCasetto()
	{
		Collection collLinkedCasetto = new Vector();
		LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		return collLinkedCasetto;
	}
}
