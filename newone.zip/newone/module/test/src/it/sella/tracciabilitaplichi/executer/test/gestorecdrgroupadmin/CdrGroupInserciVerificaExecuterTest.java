package it.sella.tracciabilitaplichi.executer.test.gestorecdrgroupadmin;

import it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin.CdrGroupInserciVerificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;

public class CdrGroupInserciVerificaExecuterTest extends AbstractSellaExecuterMock
{

	public CdrGroupInserciVerificaExecuterTest(final String name) 
	{
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	CdrGroupInserciVerificaExecuter executer = new CdrGroupInserciVerificaExecuter();
	
/*	public void testCdrGroupInserciVerificaExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
*/
	public void testCdrGroupInserciVerificaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	/*public void testCdrGroupInserciVerificaExecuter_03()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupInserciVerificaExecuter_04()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setisCdrAdded2Group();
		TracciabilitaPlichiAdminMasterDataAccessMock.setcdrGroupViewTestNull();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupInserciVerificaExecuter_forTracciabilitaException()
	{
		DBPersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}
	public void testCdrGroupInserciVerificaExecuter_forRemoteException()
	{
		DBPersonaleWrapperMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting( getRequestEvent().getAttribute("Cdr")).andReturn("IT").anyTimes();
		expecting( getRequestEvent().getAttribute("Group")).andReturn("BANCA SELLA").anyTimes();
		playAll();
		executer.execute(getRequestEvent());	
	}*/
}
