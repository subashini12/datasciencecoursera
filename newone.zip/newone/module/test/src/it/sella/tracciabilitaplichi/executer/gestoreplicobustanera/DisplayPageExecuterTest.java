package it.sella.tracciabilitaplichi.executer.gestoreplicobustanera;

import java.util.Hashtable;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;


public class DisplayPageExecuterTest extends AbstractSellaExecuterMock{

	public DisplayPageExecuterTest(String name) {
		super(name);
	}

	DisplayPageExecuter displayPageExecuter = new DisplayPageExecuter() ;
	
	public void testDisplayPageExecuter_01()
	{
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("PreparazioneBustaNeraHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		displayPageExecuter.execute(getRequestEvent());
	}
	
	public void testDisplayPageExecuter_02()
	{
		expecting(getRequestEvent().getAttribute("checkedIds")).andReturn(null).anyTimes();
		expecting(getRequestEvent().getAttribute("pageNumber")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("PreparazioneBustaNeraHashTable")).andReturn(getHashtable()).anyTimes();
		playAll() ;
		displayPageExecuter.execute(getRequestEvent());
	}
	
	private static Hashtable getHashtable()
	{
		Hashtable hashtable = new Hashtable();
		hashtable.put("PageNo","1");
		hashtable.put("pageInfo",getPageInfoHashtable() );
		return hashtable ;
	}
	
	private static Hashtable getPageInfoHashtable()
	{
		Hashtable hashtable = new Hashtable();
		return hashtable ;
	}
	
}
