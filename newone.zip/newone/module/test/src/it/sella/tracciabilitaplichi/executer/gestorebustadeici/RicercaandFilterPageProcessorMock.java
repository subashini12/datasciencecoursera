package it.sella.tracciabilitaplichi.executer.gestorebustadeici;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciRicercaView;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import mockit.Mock;

public class RicercaandFilterPageProcessorMock {
	private static Boolean remoteException = false;
	private static Boolean tracciabilitaException = false;
	public  static void setTracciabilitaException() 
	{
		tracciabilitaException = true;
	}

	 public  static void setRemoteException()
	 {
	    	remoteException = true;
	 }
	@Mock
	public static Map processFilterData( RequestEvent rqEvent ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) 
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}
		if (remoteException) 
		{
			remoteException = false;
			throw new RemoteException() ;
		}
		BustaDeiciRicercaView bustaDeiciRicercaView=new BustaDeiciRicercaView();
		Hashtable hashtable=new Hashtable();
		Map map=new HashMap();
		map.put("finalQuery", bustaDeiciRicercaView);
		map.put("datiRicerca", hashtable);
		map.put("errorMessage", "");
		return map;
	}
}
