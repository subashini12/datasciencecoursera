package it.sella.tracciabilitaplichi.executer.gestoreplichi;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.PreparazionePlichiCacheUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.PreparazionePlichiCacheUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;

public class RiepilogoPlichiExecuterTest extends AbstractSellaExecuterMock {

	public RiepilogoPlichiExecuterTest(final String name) {
		super(name);
	}

	RiepilogoPlichiExecuter executer = new RiepilogoPlichiExecuter();

	public void testRiepilogoPlichiExecuter_01() {
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("1234567894561").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

	public void testRiepilogoPlichiExecuter_02() {
		setUpMockMethods(PreparazionePlichiCacheUtil.class, PreparazionePlichiCacheUtilMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFail",executeResult.getTransition());
	}

}
