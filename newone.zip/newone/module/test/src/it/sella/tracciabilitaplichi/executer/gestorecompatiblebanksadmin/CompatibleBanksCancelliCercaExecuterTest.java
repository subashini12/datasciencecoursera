package it.sella.tracciabilitaplichi.executer.gestorecompatiblebanksadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

public class CompatibleBanksCancelliCercaExecuterTest extends AbstractSellaExecuterMock {

	public CompatibleBanksCancelliCercaExecuterTest(final String name) {
		super(name);
	}
	
	CompatibleBanksCancelliCercaExecuter executer = new CompatibleBanksCancelliCercaExecuter();
	
	public void testExecuter_01() {
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("21").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	
	public void testExecuter_02() {
		TracciabilitaPlichiAdminMasterDataAccessMock.setcompatibleBanksViewNull();
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("21").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testExecuter_03() {
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testExecuter_04() {
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("ac").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrError",executeResult.getTransition());
	}
	
	public void testExecuter_05() {
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException();
		setUpMockMethods( TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class );
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("12").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

}
