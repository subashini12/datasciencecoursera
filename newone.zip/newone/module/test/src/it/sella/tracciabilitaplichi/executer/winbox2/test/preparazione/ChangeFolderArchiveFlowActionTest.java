package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.ChangeFolderArchiveFlowAction;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.Helper;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.HelperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.HashMap;

import mockit.Mockit;


public class ChangeFolderArchiveFlowActionTest extends AbstractSellaExecuterMock
{
	
	public ChangeFolderArchiveFlowActionTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ChangeFolderArchiveFlowAction folderArchiveFlowAction = new ChangeFolderArchiveFlowAction() ;
	
   public void testExecuteAction_01()
   {
	   Mockit.setUpMock(Helper.class, HelperMock.class);
	   try {
		folderArchiveFlowAction.executeAction(getRequestEvent());
	} catch (final RemoteException e) {
		e.printStackTrace();
	} catch (final TracciabilitaException e) {
		e.printStackTrace();
	}
   }
   
   public void testgetLoggerMap()
   {
	   assertNull( folderArchiveFlowAction.getLoggerMap(new HashMap<Enum, Object>()) );
   }
   
   
   public void testGetLogger()
   {
	   assertNotNull(folderArchiveFlowAction.getLogger());
   }
}
