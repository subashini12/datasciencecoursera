package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio.processor;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ArchivationHistoryProcessorMock 
{
   private static Boolean tracciabilitaException = false;	
   private static Boolean remoteException = false;
   private static Boolean isEndorserSetted = false;
	
		public  static void setTracciabilitaException() 
		{  
			tracciabilitaException = true;
		}
		public  static void setRemoteException() 
		{  
			remoteException = true;
		}
		
		public  static void setEndorser() 
		{  
			isEndorserSetted = true;
		}

	@Mock
	public static Map<Enum<CONSTANTS>, Object> getArchivationHistory( final String barcode ) throws RemoteException, TracciabilitaException
	{
		if( tracciabilitaException )
   	    {
   		 tracciabilitaException = false; 
   		 throw new TracciabilitaException();    		 
   	    }
   	 
   	    if( remoteException )
   	    {
   		 remoteException = false; 
   		 throw new RemoteException();    		 
   	    }
		final Map<Enum<CONSTANTS>, Object> resultMap = new HashMap<Enum<CONSTANTS>, Object>( );
	    resultMap.put( CONSTANTS.ERROR_MESSAGE, "def" );
	    if( isEndorserSetted )
	    {
	       isEndorserSetted = false ;
	       resultMap.put( CONSTANTS.ENDORSER, "abc" );
	    }
		
		return resultMap ;
	}
}
