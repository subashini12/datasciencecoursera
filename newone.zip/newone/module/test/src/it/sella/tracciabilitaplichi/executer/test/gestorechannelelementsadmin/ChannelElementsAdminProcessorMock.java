package it.sella.tracciabilitaplichi.executer.test.gestorechannelelementsadmin;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ChannelElementsView;

import java.rmi.RemoteException;
import java.util.HashMap;

import mockit.Mock;

public class ChannelElementsAdminProcessorMock {

	@Mock
	public static HashMap validateEvent(final RequestEvent requestEvent)
			throws TracciabilitaException, RemoteException {
		final HashMap hashMap = new HashMap();
		final ChannelElementsView channelElementsView = new ChannelElementsView() ;
		channelElementsView.setChannelElementId(1L);
		hashMap.put("View", channelElementsView );
		return hashMap;
	}
}
