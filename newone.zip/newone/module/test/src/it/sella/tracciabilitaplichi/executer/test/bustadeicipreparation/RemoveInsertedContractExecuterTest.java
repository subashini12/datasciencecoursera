package it.sella.tracciabilitaplichi.executer.test.bustadeicipreparation;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustadeicipreparation.RemoveInsertedContractExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.ContractsInB10Impl;
import it.sella.tracciabilitaplichi.implementation.mock.ContractsInB10ImplMock;
import it.sella.tracciabilitaplichi.implementation.test.view.Busta10PreparationPageViewMock;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;
import java.util.ArrayList;
import java.util.Collection;

public class RemoveInsertedContractExecuterTest extends AbstractSellaExecuterMock 
{
   
	RemoveInsertedContractExecuter removeInsertedContractExecuter = new RemoveInsertedContractExecuter();
	
	public RemoveInsertedContractExecuterTest(String name) 
	{
		super(name);
	}
	
	public void testRemoveInsertedContractExecuter_forSuccessCase()
	{
		setUpMockMethods(Busta10PreparationPageView.class, Busta10PreparationPageViewMock.class);
		setUpMockMethods(ContractsInB10Impl.class, ContractsInB10ImplMock.class);
		expecting( getStateMachineSession().get("Busta10PreparationPageView")).andReturn( (Busta10PreparationPageView )getBusta10PreparationPageView()).anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.CONTRACT_INDEX.getValue( ))).andReturn("0").anyTimes();
		playAll();
		removeInsertedContractExecuter.execute(getRequestEvent());
	}
	public void testRemoveInsertedContractExecuter_forTracciabilitaException()
	{
		ContractsInB10ImplMock.setTracciabilitaException();
		setUpMockMethods(Busta10PreparationPageView.class, Busta10PreparationPageViewMock.class);
		setUpMockMethods(ContractsInB10Impl.class, ContractsInB10ImplMock.class);
		expecting( getStateMachineSession().get("Busta10PreparationPageView")).andReturn( (Busta10PreparationPageView )getBusta10PreparationPageView()).anyTimes();
		expecting( getRequestEvent().getAttribute(CONSTANTS.CONTRACT_INDEX.getValue( ))).andReturn("0").anyTimes();
		playAll();
		removeInsertedContractExecuter.execute(getRequestEvent());		
	}

	public Busta10PreparationPageView getBusta10PreparationPageView()
	{
		Busta10PreparationPageView view = new Busta10PreparationPageView();
		Collection coll= new ArrayList();
		view.setCdrName("cdrName");
		return view ;
	}
	
}
