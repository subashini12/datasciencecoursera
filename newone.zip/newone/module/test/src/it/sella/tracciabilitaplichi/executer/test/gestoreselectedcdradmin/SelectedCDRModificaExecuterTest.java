package it.sella.tracciabilitaplichi.executer.test.gestoreselectedcdradmin;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestoreselectedcdradmin.SelectedCDRModificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.admin.SelectedCDRAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.admin.SelectedCDRAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.view.TpMaSelectedCdrViewMock;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectedCDRModificaExecuterTest extends AbstractSellaExecuterMock {

	SelectedCDRModificaExecuter selectedCDRModificaExecuter = new SelectedCDRModificaExecuter();

	public SelectedCDRModificaExecuterTest(final String name) {
		super(name);
	}

	public void testSelectedCDRModificaExecuter_01()
	{
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		setUpMockMethods(TpMaSelectedCdrView.class, TpMaSelectedCdrViewMock.class);
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bancaId")).andReturn("1").anyTimes();
		final TpMaSelectedCdrView tpMaSelectedCdrView = new TpMaSelectedCdrView();
		tpMaSelectedCdrView.setScBankId("");
		tpMaSelectedCdrView.setScCdr("");
		tpMaSelectedCdrView.setScId("");
		final List list = new ArrayList() ;
		list.add(1);
		list.add(2);
		final Map map = new HashMap();
		map.put(ITPConstants.SELECTED_CDR_VIEW , list);
		map.put(ITPConstants.SELECTED_CDR_VIEW_MODIFY, tpMaSelectedCdrView );
		map.put(ITPConstants.INDEX, 1);
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn((Serializable) map).anyTimes();
		playAll();
		selectedCDRModificaExecuter.execute(getRequestEvent());
	}
	
	public void testSelectedCDRModificaExecuter_02()
	{
		TpMaSelectedCdrViewMock.setNonEmptyMap();
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		setUpMockMethods(TpMaSelectedCdrView.class, TpMaSelectedCdrViewMock.class);
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bancaId")).andReturn("1").anyTimes();
		final TpMaSelectedCdrView tpMaSelectedCdrView = new TpMaSelectedCdrView();
		tpMaSelectedCdrView.setScBankId("");
		tpMaSelectedCdrView.setScCdr("");
		tpMaSelectedCdrView.setScId("");
		final List list = new ArrayList() ;
		list.add(1);
		list.add(2);
		final Map map = new HashMap();
		map.put(ITPConstants.SELECTED_CDR_VIEW , list);
		map.put(ITPConstants.SELECTED_CDR_VIEW_MODIFY, tpMaSelectedCdrView );
		map.put(ITPConstants.INDEX, 1);
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn((Serializable) map).anyTimes();
		playAll();
		selectedCDRModificaExecuter.execute(getRequestEvent());
	}

	public void testSelectedCDRModificaExecuter_03()
	{
		SelectedCDRAdminImplMock.setTracciabilitaException();
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		setUpMockMethods(TpMaSelectedCdrView.class, TpMaSelectedCdrViewMock.class);
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("bancaId")).andReturn("1").anyTimes();
		final TpMaSelectedCdrView tpMaSelectedCdrView = new TpMaSelectedCdrView();
		tpMaSelectedCdrView.setScBankId("");
		tpMaSelectedCdrView.setScCdr("");
		tpMaSelectedCdrView.setScId("");
		final List list = new ArrayList() ;
		list.add(1);
		list.add(2);
		final Map map = new HashMap();
		map.put(ITPConstants.SELECTED_CDR_VIEW , list);
		map.put(ITPConstants.SELECTED_CDR_VIEW_MODIFY, tpMaSelectedCdrView );
		map.put(ITPConstants.INDEX, 1);
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn((Serializable) map).anyTimes();
		playAll();
		selectedCDRModificaExecuter.execute(getRequestEvent());
	}
	
}
