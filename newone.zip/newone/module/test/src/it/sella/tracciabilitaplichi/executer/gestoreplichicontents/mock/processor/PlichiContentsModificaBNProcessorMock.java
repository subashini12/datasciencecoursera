package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.Hashtable;

import mockit.Mock;

public class PlichiContentsModificaBNProcessorMock {
	@Mock
	public static ExecuteResult modifyBNRecords(RequestEvent rqEvent,
			String barCode, Hashtable restoreMap, ExecuteResult executeResult)
			throws TracciabilitaException, RemoteException {
		return executeResult;
	}
}
