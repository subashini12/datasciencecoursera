package it.sella.tracciabilitaplichi.executer.gestorebustadeici.test.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;

import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ChangePageProcessorMock 
{
    @Mock
	public static Map mapChangePageData( final RequestEvent requestEvent, final StateMachineSession session )
	{
		 final Map mapChangePageData = new HashMap();
		 mapChangePageData.put( "pageNo", "1" );		 
		 return mapChangePageData;
	}
	
}
