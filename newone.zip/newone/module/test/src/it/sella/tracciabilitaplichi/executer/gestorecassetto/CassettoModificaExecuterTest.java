package it.sella.tracciabilitaplichi.executer.gestorecassetto;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class CassettoModificaExecuterTest extends AbstractSellaExecuterMock {

	public CassettoModificaExecuterTest(final String name) {
		super(name);
	}

	CassettoModificaExecuter executer = new CassettoModificaExecuter();

	public void testCassettoModificaExecuter_02() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult  executeResult  = executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_03() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult  executeResult  = executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_01() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult  executeResult  = executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoModificaExecuter_04() {
		TracciabilitaPlichiImplMock.setCassetto();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) getCollection()).anyTimes();
		playAll();
		final ExecuteResult  executeResult  = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testCassettoModificaExecuter_05() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) getCollection()).anyTimes();
		playAll();
		final ExecuteResult  executeResult  = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testCassettoModificaExecuter_06() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) getCollection()).anyTimes();
		playAll();
		final ExecuteResult  executeResult  = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	private Collection getCollection() {
		final LinkedCasettoView linkedCasettoView = new LinkedCasettoView() ;
		final Collection collection = new ArrayList();
		collection.add(linkedCasettoView);
		return collection ;
	}
	
}
