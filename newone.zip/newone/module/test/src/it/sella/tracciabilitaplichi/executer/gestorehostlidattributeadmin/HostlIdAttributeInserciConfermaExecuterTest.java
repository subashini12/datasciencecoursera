package it.sella.tracciabilitaplichi.executer.gestorehostlidattributeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.HostlIdAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.HostlIdAttributeAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.view.HostlIdAttributeView;
import mockit.Mockit;

public class HostlIdAttributeInserciConfermaExecuterTest extends
		AbstractSellaExecuterMock {

	public HostlIdAttributeInserciConfermaExecuterTest(final String name) {
		super(name);
	}

	HostlIdAttributeInserciConfermaExecuter executer = new HostlIdAttributeInserciConfermaExecuter();

	public void testHostlIdAttributeInserciConfermaExecuter_02() {
		TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		setUpMockMethods(HostlIdAttributeAdminImpl.class, HostlIdAttributeAdminImplMock.class);
		expecting(getStateMachineSession().get("HostlIdAttributeView")).andReturn(getHostlIdAttributeView()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TRPL-1056",executeResult.getAttribute(ITPConstants.MSG));
		assertEquals("yes",executeResult.getAttribute(ITPConstants.SUCCESS));
	}

	public void testHostlIdAttributeInserciConfermaExecuter_03() {
	    TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		setUpMockMethods(HostlIdAttributeAdminImpl.class, HostlIdAttributeAdminImplMock.class);
		expecting(getStateMachineSession().get("HostlIdAttributeView")).andReturn(getHostlIdAttributeView()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getAttribute(ITPConstants.MSG));
		assertEquals(null,executeResult.getAttribute(ITPConstants.SUCCESS));
	}
	
	public void testHostlIdAttributeInserciConfermaExecuter_04() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(HostlIdAttributeAdminImpl.class, HostlIdAttributeAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		expecting(getStateMachineSession().get("HostlIdAttributeView")).andReturn(getHostlIdAttributeView()).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getAttribute(ITPConstants.MSG));
		assertEquals(null,executeResult.getAttribute(ITPConstants.SUCCESS));
	}
	
	public HostlIdAttributeView getHostlIdAttributeView() {
		final HostlIdAttributeView hostlIdAttributeView = new HostlIdAttributeView();
		hostlIdAttributeView.setHaId( "1" );
		hostlIdAttributeView.setHaLid( "1" );
		return hostlIdAttributeView ;
	}

}
