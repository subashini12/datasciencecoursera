package it.sella.tracciabilitaplichi.executer.test.sollecitiheaderadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.sollecitiheaderadmin.SollecitiHeaderCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.SollecitiHeaderDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.SollecitiHeaderDataAccessMock;

import java.util.HashMap;
import java.util.Map;

public class SollecitiHeaderCercaExecuterTest  extends AbstractSellaExecuterMock {
	
	SollecitiHeaderCercaExecuter sollecitiHeaderCercaExecuterTest =  new SollecitiHeaderCercaExecuter(); 
	public SollecitiHeaderCercaExecuterTest(String name) {
		super(name);
	}

	 public void testSollecitiHeaderCercaExecuter_01(){
	        final Map sollecitiHeaderMap = new HashMap( 1 );
			expecting(getStateMachineSession().put("SOLLECITI_HEADER_MAP", sollecitiHeaderMap)).andReturn(true);
			expecting(getRequestEvent().getAttribute("id")).andReturn("id").anyTimes();
			playAll();
			ExecuteResult executeResult =sollecitiHeaderCercaExecuterTest.execute(getRequestEvent());
			assertEquals(executeResult.getAttribute("MESSAGE"), "TRPL-1060");
			assertEquals(executeResult.getAttribute("Argument"), "id");
	 }
	 public void testSollecitiHeaderCercaExecuter_02(){
	       
		    setUpMockMethods( SollecitiHeaderDataAccess.class, SollecitiHeaderDataAccessMock.class );
		    final Map sollecitiHeaderMap = new HashMap( 1 );
			expecting(getStateMachineSession().put("SOLLECITI_HEADER_MAP", sollecitiHeaderMap)).andReturn(true);
			expecting(getRequestEvent().getAttribute("id")).andReturn("343").anyTimes();
			playAll();
			ExecuteResult executeResult = sollecitiHeaderCercaExecuterTest.execute(getRequestEvent());
			assertEquals(executeResult.getTransition(), "Success");
	 }
	 public void testSollecitiHeaderCercaExecuter_03(){
		    
		    SollecitiHeaderDataAccessMock.setTpTrSollecitiHeaderViewNull();
		    setUpMockMethods( SollecitiHeaderDataAccess.class, SollecitiHeaderDataAccessMock.class );   
		    final Map sollecitiHeaderMap = new HashMap( 1 );
			expecting(getStateMachineSession().put("SOLLECITI_HEADER_MAP", sollecitiHeaderMap)).andReturn(true);
			expecting(getRequestEvent().getAttribute("id")).andReturn("343").anyTimes();
			playAll();
			ExecuteResult executeResult =	 sollecitiHeaderCercaExecuterTest.execute(getRequestEvent());
			assertEquals(executeResult.getAttribute("MESSAGE"), "TRPL-1379");
			assertEquals(executeResult.getAttribute("Argument"), "343");
	 }
	 public void testSollecitiHeaderCercaExecuter_04(){
	        final Map sollecitiHeaderMap = new HashMap( 1 );
			expecting(getStateMachineSession().put("SOLLECITI_HEADER_MAP", sollecitiHeaderMap)).andReturn(true);
			expecting(getRequestEvent().getAttribute("id")).andReturn("343").anyTimes();
			playAll();
			ExecuteResult executeResult = sollecitiHeaderCercaExecuterTest.execute(getRequestEvent());
			
	 }
	 
}
