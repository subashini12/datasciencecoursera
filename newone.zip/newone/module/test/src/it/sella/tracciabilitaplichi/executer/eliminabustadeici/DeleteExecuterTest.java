package it.sella.tracciabilitaplichi.executer.eliminabustadeici;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriter;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiDataWriterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPBustaDeiciDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPBustaDeiciDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.HashMap;

import mockit.Mockit;

public class DeleteExecuterTest extends AbstractSellaExecuterMock {

	public DeleteExecuterTest(final String name) {
		super(name);
	}

	DeleteExecuter executer = new DeleteExecuter();

	public void testDeleteExecuter_01() {
		TracciabilitaPlichiImplMock.setStatus();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class,TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		expecting(getStateMachineSession().get("finalData")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.COD_CONTRATTO_COLL)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.COD_CONTRATTO_COLL)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("usrgc")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testDeleteExecuter_06() {
		TPBustaDeiciDataAccessMock.setOggettoColl();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class,TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		expecting(getStateMachineSession().get("finalData")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.COD_CONTRATTO_COLL)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.COD_CONTRATTO_COLL)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("usrgc")).andReturn("").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testDeleteExecuter_02() {
		TPBustaDeiciDataAccessMock.setPreparataStatus();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class,TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		expecting(getStateMachineSession().get("finalData")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.COD_CONTRATTO_COLL)).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().remove(ITPConstants.COD_CONTRATTO_COLL)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("usrgc")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}

	public void testDeleteExecuter_05() {
		TPBustaDeiciDataAccessMock.setPreparataStatus();
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		expecting(getStateMachineSession().get("finalData")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().get("usrgc")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrFail");
	}

	public void testDeleteExecuter_03() {
		TPBustaDeiciDataAccessMock.setTracciabilitaException();
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		expecting(getStateMachineSession().get("finalData")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().get("usrgc")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}

	public void testDeleteExecuter_04() {
		TPBustaDeiciDataAccessMock.setRemoteException();
		Mockit.setUpMock(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPBustaDeiciDataAccess.class,TPBustaDeiciDataAccessMock.class);
		expecting(getStateMachineSession().get("finalData")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().get("usrgc")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}

	private static HashMap getHashMap() {
		final HashMap hashMap = new HashMap();
		hashMap.put("1", "1");
		return hashMap;
	}

}
