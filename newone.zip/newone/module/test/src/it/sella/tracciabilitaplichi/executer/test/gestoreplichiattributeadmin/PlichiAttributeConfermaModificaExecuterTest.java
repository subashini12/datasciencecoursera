package it.sella.tracciabilitaplichi.executer.test.gestoreplichiattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestoreplichiattributeadmin.PlichiAttributeConfermaModificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.PlichiAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.PlichiAttributeAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;

import java.util.Hashtable;

import mockit.Mockit;

public class PlichiAttributeConfermaModificaExecuterTest extends
		AbstractSellaExecuterMock {

	PlichiAttributeConfermaModificaExecuter plichiAttributeConfermaModificaExecuter = new PlichiAttributeConfermaModificaExecuter();

	public PlichiAttributeConfermaModificaExecuterTest(final String name) {
		super(name);
	}

	public void testBustaAssegniDefaultExecuter_01() {
			TracciabilitaPlichiImplMock.setStatus();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(PlichiAttributeAdminImpl.class, PlichiAttributeAdminImplMock.class);
			expecting(getStateMachineSession().get("PlichiTable")).andReturn(getHashtable()).anyTimes();
			playAll();
			plichiAttributeConfermaModificaExecuter.execute(getRequestEvent());
	}

	public void testBustaAssegniDefaultExecuter_02() {
			TracciabilitaPlichiImplMock.setTracciabilitaException();
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(PlichiAttributeAdminImpl.class, PlichiAttributeAdminImplMock.class);
			expecting(getStateMachineSession().get("PlichiTable")).andReturn(getHashtable()).anyTimes();
			playAll();
			plichiAttributeConfermaModificaExecuter.execute(getRequestEvent());
	}
	
	public void testBustaAssegniDefaultExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(PlichiAttributeAdminImpl.class, PlichiAttributeAdminImplMock.class);
		expecting(getStateMachineSession().get("PlichiTable")).andReturn(getHashtable()).anyTimes();
		playAll();
		plichiAttributeConfermaModificaExecuter.execute(getRequestEvent());
	}
	
	public Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable();
		hashtable.put("NewPlichiAttributeView", getPlichiAttributeView());
		return hashtable;
	}
	
	public PlichiAttributeView getPlichiAttributeView()
	{
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView() ;
		return plichiAttributeView ;
	}
}
