package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TpMaEsitiView;
import it.sella.tracciabilitaplichi.implementation.view.TpMaPropertiesView;

import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class GestioneSollecitiDataAccessMock
{
	private static Boolean isTpMaPropertiesViewNull = false;
	private static Boolean tracciabilitaException = false;
	private static Boolean propertyValueGivenForCdrs = false;

	public  static void setTpMaPropertiesViewNull()
	{
		isTpMaPropertiesViewNull = true;
	}

	public  static void setTracciabilitaException()
	{
		tracciabilitaException = true;
	}

	public  static void setPropertyValueGivenForCdrs()
	{
		propertyValueGivenForCdrs = true;
	}

	@Mock
	public TpMaPropertiesView getTpMaPropertiesView( final TpMaPropertiesView tpMaPropertiesTO ) throws TracciabilitaException
	{
		TpMaPropertiesView tpMaPropertiesView = new TpMaPropertiesView("SOLL_SWITCH_1",null);

		if (tracciabilitaException)
		{
			tracciabilitaException = false;
			throw new TracciabilitaException() ;
		}

		if(isTpMaPropertiesViewNull)
		{
			isTpMaPropertiesViewNull= false;
			tpMaPropertiesView = null;
		}

		return tpMaPropertiesView;
	}

	@Mock
	public Collection getAllEsiti( ) throws TracciabilitaException
	{
		final Collection tpMaEsitiViewCollection = new ArrayList( 1 );
		final TpMaEsitiView transferObject = new TpMaEsitiView( 1L, "Ravi", "description", 1L, 123L );
		tpMaEsitiViewCollection.add( transferObject );
		return tpMaEsitiViewCollection;
	}

	@Mock
	public Collection getAllTipocontrollo( ) throws TracciabilitaException
	{
		final Collection tpMaEsTOCollection = new ArrayList( 1 );
		final TpMaEsitiView transferObject = new TpMaEsitiView( null, "code", "description", null, null );
		tpMaEsTOCollection.add(transferObject);
		return tpMaEsTOCollection;
	}

	@Mock
	public Collection getTpMaPropertiesViewCollection( final TpMaPropertiesView tpMaPropertiesTO ) throws TracciabilitaException
	{
		final Collection collection = new ArrayList();
		return collection ;
	}

	@Mock
	public String getValue( final String key ) throws TracciabilitaException
	{
		String value = CONSTANTS.TRUE.toString( );
		if(propertyValueGivenForCdrs){
			propertyValueGivenForCdrs = false;
			value = "099361,099231";
		}
		return  value;
	}
}
