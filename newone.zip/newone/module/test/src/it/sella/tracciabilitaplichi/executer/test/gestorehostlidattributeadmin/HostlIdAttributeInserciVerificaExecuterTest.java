package it.sella.tracciabilitaplichi.executer.test.gestorehostlidattributeadmin;

import java.io.Serializable;

import org.easymock.EasyMock;

import it.sella.tracciabilitaplichi.executer.gestorehostlidattributeadmin.HostlIdAttributeInserciVerificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiISEDataAccessMock;

public class HostlIdAttributeInserciVerificaExecuterTest  extends AbstractSellaExecuterMock
{

		public HostlIdAttributeInserciVerificaExecuterTest(String name) 
		{
			super(name);
		}
		
		HostlIdAttributeInserciVerificaExecuter executer = new HostlIdAttributeInserciVerificaExecuter();
		
		
		public void testExecuter_01()
		{
			setUpMockMethods(TracciabilitaPlichiISEDataAccess.class ,TracciabilitaPlichiISEDataAccessMock.class );
			expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("02").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		}
		public void testExecuter_02()
		{
			TracciabilitaPlichiISEDataAccessMock.setRequiedToSendBustaCinqueTrue();
			setUpMockMethods(TracciabilitaPlichiISEDataAccess.class ,TracciabilitaPlichiISEDataAccessMock.class );
			expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (Serializable)EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
			expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("02").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		}
		public void testExecuter_03()
		{
			setUpMockMethods(TracciabilitaPlichiISEDataAccess.class ,TracciabilitaPlichiISEDataAccessMock.class );
			expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		}
		public void testExecuter_04()
		{
			TracciabilitaPlichiISEDataAccessMock.setTracciabilitaException() ;
			setUpMockMethods(TracciabilitaPlichiISEDataAccess.class ,TracciabilitaPlichiISEDataAccessMock.class );
			expecting(getRequestEvent().getAttribute("ha_lid")).andReturn("02").anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		}
		
		
}
