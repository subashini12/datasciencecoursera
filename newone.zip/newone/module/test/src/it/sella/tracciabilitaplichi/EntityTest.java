package it.sella.tracciabilitaplichi;


import it.sella.tracciabilitaplichi.bustacinque.HostLidView;
import it.sella.tracciabilitaplichi.implementation.view.AltriAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.AltriDocumentView;
import it.sella.tracciabilitaplichi.implementation.view.AltriView;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.Busta10PreparationPageView;
import it.sella.tracciabilitaplichi.implementation.view.BustaCinqueAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciContrattiView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciRicercaView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciView;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraErrorCodeView;
import it.sella.tracciabilitaplichi.implementation.view.CdrGroupView;
import it.sella.tracciabilitaplichi.implementation.view.ChannelDefinitionView;
import it.sella.tracciabilitaplichi.implementation.view.ChannelElementsView;
import it.sella.tracciabilitaplichi.implementation.view.ClassificationView;
import it.sella.tracciabilitaplichi.implementation.view.CodiceHostView;
import it.sella.tracciabilitaplichi.implementation.view.CompatibleBanksView;
import it.sella.tracciabilitaplichi.implementation.view.ContractsInB10View;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoDescriptionView;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;
import it.sella.tracciabilitaplichi.implementation.view.ControlliView;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.HostlIdAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.InvioPlichiView;
import it.sella.tracciabilitaplichi.implementation.view.LIDBookKeepingView;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PAltriAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.PBustaNeraAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiView;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;
import it.sella.tracciabilitaplichi.implementation.view.RicercaView;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiDetailView;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiHeaderView;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiProrogheListView;
import it.sella.tracciabilitaplichi.implementation.view.SollecitiProrogheView;
import it.sella.tracciabilitaplichi.implementation.view.StatisticheDiInviareView;
import it.sella.tracciabilitaplichi.implementation.view.StatusModifierInfoView;
import it.sella.tracciabilitaplichi.implementation.view.StatusView;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;
import it.sella.tracciabilitaplichi.implementation.view.TpTrSollecitiHeaderView;
import it.sella.tracciabilitaplichi.mock.commonmock.CommonEntityMock;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

public class EntityTest {

	private static CommonEntityMock commonEntityMock = new CommonEntityMock() ;

	@Test
	public void commonEntityTest_01()
	{
		final List list= new ArrayList();
		list.add("abc");
		commonEntityMock.getMethod(AltriAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(AltriDocumentView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(AltriView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(AltriWinboxView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BorsaVerdeAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(Busta10PreparationPageView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		//commonEntityMock.getMethod(BustaAssegniPreparazioneView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaCinqueAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaDeiciAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaDeiciContrattiView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaDeiciRicercaView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaDeiciView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaNeraAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(BustaNeraErrorCodeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		//commonEntityMock.getMethod(BustaVentiPreparazioneView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(CdrGroupView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ChannelDefinitionView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ChannelElementsView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ClassificationView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(CodiceHostView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		//commonEntityMock.getMethod(ComboView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(CompatibleBanksView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ContractsInB10View.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ContrattiProdottoDescriptionView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ContrattiProdottoView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ControlliView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(FrequentiDestinazioneCdrView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(HistoryView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(HostlIdAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(HostLidView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(InvioPlichiView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(LIDBookKeepingView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(LinkedCasettoView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(OggettoView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(PAltriAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(PBustaNeraAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(PlichiAttributeView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(PlichiView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(ProdottiView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(RicercaView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(SollecitiDetailView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(SollecitiHeaderView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(SollecitiProrogheListView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(SollecitiProrogheView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(StatisticheDiInviareView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(StatusModifierInfoView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(StatusView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		//commonEntityMock.getMethod(TpMaEsitiView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		//commonEntityMock.getMethod(TpMaPropertiesView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(TpMaSelectedCdrView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		commonEntityMock.getMethod(TpTrSollecitiHeaderView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
		//commonEntityMock.getMethod(TracciabilitaPlichiView.class,"abc",1L,new Date(),1,new BigDecimal(1),new Timestamp(new Date().getTime()),true,new Byte((byte) 100),list);
	}
}
