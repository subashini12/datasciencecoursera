/*package it.sella.tracciabilitaplichi.executer.test.gestorealtriattributeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriattributeadmin.AltriAttributeConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.AltriAttributeView;

import java.util.Hashtable;

public class AltriAttributeConfermaExecuterTest extends
		AbstractSellaExecuterTest {

	AltriAttributeConfermaExecuter altriAttributeConfermaExecuterTest = new AltriAttributeConfermaExecuter();

	public AltriAttributeConfermaExecuterTest(final String name) {
		super(name);
	}

	public void testAltriAttributeConfermaExecuter_01() {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				new Hashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("123654")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("123654")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("BoxNum")).andReturn("BoxNum")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("CdrDest"))
				.andReturn("123654").anyTimes();
		final Hashtable altriAttributeHashtable = new Hashtable();
		expecting(
				getStateMachineSession().put("AltriTable",
						altriAttributeHashtable)).andReturn(
				altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeConfermaExecuterTest
				.execute(getRequestEvent());
		assertEquals("TRPL-1050", executeResult.getAttribute("MSG"));
	}

	public void testAltriAttributeConfermaExecuter_02() {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				new Hashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("sfdfdf")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("dfg")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("BoxNum")).andReturn("BoxNum")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("CdrDest"))
				.andReturn("123654").anyTimes();
		final Hashtable altriAttributeHashtable = new Hashtable();
		expecting(
				getStateMachineSession().put("AltriTable",
						altriAttributeHashtable)).andReturn(
				altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeConfermaExecuterTest
				.execute(getRequestEvent());
		assertEquals("TRPL-1081", executeResult.getAttribute("MSG"));
	}

	public void testAltriAttributeConfermaExecuter_03() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,TracciabilitaPlichiCommonDataAccessMock.class);
		final Hashtable altriAttributeHashtable = new Hashtable();
		altriAttributeHashtable.put("OldAltriAttributeView",
				new AltriAttributeView());
		altriAttributeHashtable.put("OldAltriAttributeView",
				new AltriAttributeView());
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				altriAttributeHashtable).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1235")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("34343")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("BoxNum")).andReturn("1234")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("CdrDest"))
				.andReturn("123654").anyTimes();
		expecting(
				getStateMachineSession().put("AltriTable",
						altriAttributeHashtable)).andReturn(
				altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeConfermaExecuterTest
				.execute(getRequestEvent());

	}

	public void testAltriAttributeConfermaExecuter_04() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		final Hashtable altriAttributeHashtable = new Hashtable();
		altriAttributeHashtable.put("OldAltriAttributeView",
				new AltriAttributeView());
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				altriAttributeHashtable).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("1235")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("34343")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("BoxNum")).andReturn("1234")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("CdrDest"))
				.andReturn("123654").anyTimes();
		expecting(
				getStateMachineSession().put("AltriTable",
						altriAttributeHashtable)).andReturn(
				altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeConfermaExecuterTest
				.execute(getRequestEvent());
	}

	public void testAltriAttributeConfermaExecuter_05() {
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				new Hashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("123654")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("123654")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("BoxNum")).andReturn("BoxNum")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("CdrDest"))
				.andReturn("123654").anyTimes();
		final Hashtable altriAttributeHashtable = new Hashtable();
		expecting(
				getStateMachineSession().put("AltriTable",
						altriAttributeHashtable)).andReturn(
				altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeConfermaExecuterTest
				.execute(getRequestEvent());
	}

	public void testAltriAttributeConfermaExecuter_06() {
		setUpMockMethods(TracciabilitaPlichiFactory.class,TracciabilitaPlichiFactoryMock.class);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class,
				TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				new Hashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("sfdfdf")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("DocId")).andReturn("dfg")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("BoxNum")).andReturn("BoxNum")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("CdrDest"))
				.andReturn("123654").anyTimes();
		final Hashtable altriAttributeHashtable = new Hashtable();
		expecting(
				getStateMachineSession().put("AltriTable",
						altriAttributeHashtable)).andReturn(
				altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeConfermaExecuterTest
				.execute(getRequestEvent());
	}

}
*/