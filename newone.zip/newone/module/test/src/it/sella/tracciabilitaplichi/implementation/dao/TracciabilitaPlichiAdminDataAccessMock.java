package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;

import java.rmi.RemoteException;

import mockit.Mock;

public class TracciabilitaPlichiAdminDataAccessMock {

	private static boolean isAltriDocNotInUse = false ;
	
	private static Boolean tracciabilitaException = false;
	
	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setAltriDocNotInUse() {
		isAltriDocNotInUse = true;
	}
	
	@Mock
	
	public boolean isAltriDocInUse( final AltriWinboxView altriWinboxView ) throws TracciabilitaException, RemoteException
	{
		boolean flag = true ;
		
		if(isAltriDocNotInUse)
		{
			flag = false ;
		}
		
		if(tracciabilitaException)
		{
			throw new TracciabilitaException();
		}
		
		return flag ;
	}
}
