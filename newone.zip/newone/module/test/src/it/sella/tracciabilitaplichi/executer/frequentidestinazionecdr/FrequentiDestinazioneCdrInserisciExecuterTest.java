package it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr.processor.FrequentiDestinazioneCdrProcessorMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.FrequentiDestinazioneCdrAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.FrequentiDestinazioneCdrAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import mockit.Mockit;


public class FrequentiDestinazioneCdrInserisciExecuterTest extends AbstractSellaExecuterMock{

	public FrequentiDestinazioneCdrInserisciExecuterTest(final String name) {
		super(name);
	}

	FrequentiDestinazioneCdrInserisciExecuter executer = new FrequentiDestinazioneCdrInserisciExecuter() ;
	
	public void testFrequentiDestinazioneCdrInserisciExecuter_01() {
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrError");
	}
	
	public void testFrequentiDestinazioneCdrInserisciExecuter_02() {
		TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		FrequentiDestinazioneCdrProcessorMock.setNullData();
		setUpMockMethods(FrequentiDestinazioneCdrAdminImpl.class, FrequentiDestinazioneCdrAdminImplMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testFrequentiDestinazioneCdrInserisciExecuter_03() {
		TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		FrequentiDestinazioneCdrProcessorMock.setNullData();
		setUpMockMethods(FrequentiDestinazioneCdrAdminImpl.class, FrequentiDestinazioneCdrAdminImplMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testFrequentiDestinazioneCdrInserisciExecuter_04() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		FrequentiDestinazioneCdrProcessorMock.setNullData();
		setUpMockMethods(FrequentiDestinazioneCdrAdminImpl.class, FrequentiDestinazioneCdrAdminImplMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public void testFrequentiDestinazioneCdrInserisciExecuter_05() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		FrequentiDestinazioneCdrProcessorMock.setNullData();
		setUpMockMethods(FrequentiDestinazioneCdrAdminImpl.class, FrequentiDestinazioneCdrAdminImplMock.class);
		setUpMockMethods(FrequentiDestinazioneCdrProcessor.class, FrequentiDestinazioneCdrProcessorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
}
