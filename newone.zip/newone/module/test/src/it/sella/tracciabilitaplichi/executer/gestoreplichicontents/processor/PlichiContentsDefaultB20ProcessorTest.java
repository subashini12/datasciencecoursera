package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.processor;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor.PlichiContentsDefaultProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class PlichiContentsDefaultB20ProcessorTest extends
		AbstractSellaExecuterMock {

	public PlichiContentsDefaultB20ProcessorTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PlichiContentsDefaultB20Processor executer = new PlichiContentsDefaultB20Processor();

	public void testPlichiContentsDefaultB20Processor_01() {
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class,
				TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(PlichiContentsDefaultProcessor.class,
				PlichiContentsDefaultProcessorMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class,
				TracciabilitaPlichiCommonDataAccessMock.class);
		final Hashtable hashtable = getHashtable();
		expecting(
				getStateMachineSession().get(
						ITPConstants.PLICHI_CONTENTS_HASH_TABLE)).andReturn(
				hashtable);
		expecting(
				getStateMachineSession().put((String) EasyMock.anyObject(),
						(Long) EasyMock.anyObject())).andReturn(2L).anyTimes();
		playAll();
		try {
			executer.processB20Records(getRequestEvent(), "1234567891236");
		} catch (final RemoteException e) {
			fail(e.getMessage());
		} catch (final TracciabilitaException e) {
			fail(e.getMessage());
		}
	}

	/*public void testPlichiContentsDefaultB20Processor_02() {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		setUpMockMethods(TracciabilitaPlichiDataWriter.class,
				TracciabilitaPlichiDataWriterMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		TracciabilitaPlichiView tracciabilitaPlichiView = getTracciabilitaPlichiView();
		try {
			executer.updateBustaVentiPageCount("", 1L, tracciabilitaPlichiView);
		} catch (RemoteException e) {
			fail(e.getMessage());
		} catch (TracciabilitaException e) {
			fail(e.getMessage());
		}
	}*/

	private static Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable();
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView();
		final OggettoView oggettoView = new OggettoView();
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		hashtable.put(ITPConstants.TRACCIABILITA_PLICHI_VIEW,
				tracciabilitaPlichiView);
		return hashtable;
	}

	private static TracciabilitaPlichiView getTracciabilitaPlichiView() {
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView();
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView();
		plichiAttributeView.setBarCode("12345678912334");
		final OggettoView oggettoView = new OggettoView();
		oggettoView.setCdrName("");
		oggettoView.setUserId("");
		oggettoView.setId(2L);
		tracciabilitaPlichiView.setOggettoView(oggettoView);
		tracciabilitaPlichiView.setPlichiAttributeView(plichiAttributeView);
		return tracciabilitaPlichiView;
	}

	public void testPlichiContentsDefaultB20Processor_03() {
		setUpMockMethods(Util.class, UtilMock.class);
		executer.validatePageNum("1");
	}

	public void testPlichiContentsDefaultB20Processor_04() {
		UtilMock.setCheckNullFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		executer.validatePageNum("178");
	}

	public void testPlichiContentsDefaultB20Processor_05() {
		UtilMock.setCheckNullFalse();
		UtilMock.setNumericFalse();
		setUpMockMethods(Util.class, UtilMock.class);
		executer.validatePageNum("88");
	}
}
