package it.sella.tracciabilitaplichi.executer.test.gestorealtriattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestorealtriattributeadmin.AltriAttributeConfermaModificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.admin.AltriAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.AltriAttributeAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;

import java.util.Hashtable;

import mockit.Mockit;

public class AltriAttributeConfermaModificaExecuterTest extends
		AbstractSellaExecuterMock {

	AltriAttributeConfermaModificaExecuter altriAttributeConfermaModificaExecuter = new AltriAttributeConfermaModificaExecuter();

	public AltriAttributeConfermaModificaExecuterTest(final String name) {
		super(name);
	}

	public void testAltriAttributeConfermaModificaExecuter_01() {
		    TracciabilitaPlichiImplMock.setCdr();
			Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
			setUpMockMethods(TracciabilitaPlichiManagerBean.class,
					TracciabilitaPlichiManagerBeanMock.class);
			setUpMockMethods(AltriAttributeAdminImpl.class,
					AltriAttributeAdminImplMock.class);
			Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
			Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
			expecting(getStateMachineSession().containsKey("AltriTable"))
					.andReturn(Boolean.TRUE).anyTimes();
			expecting(getStateMachineSession().get("AltriTable")).andReturn(
					new Hashtable()).anyTimes();
			playAll();
			altriAttributeConfermaModificaExecuter
					.execute(getRequestEvent());
	}

	public void testAltriAttributeConfermaModificaExecuter_tracciabilitaException() {
	    TracciabilitaPlichiImplMock.setTracciabilitaException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,
				TracciabilitaPlichiManagerBeanMock.class);
		setUpMockMethods(AltriAttributeAdminImpl.class,
				AltriAttributeAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				new Hashtable()).anyTimes();
		playAll();
		altriAttributeConfermaModificaExecuter
				.execute(getRequestEvent());
	}

	public void testAltriAttributeConfermaModificaExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,
				TracciabilitaPlichiManagerBeanMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(AltriAttributeAdminImpl.class,
				AltriAttributeAdminImplMock.class);
		expecting(getStateMachineSession().containsKey("AltriTable"))
				.andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(
				new Hashtable()).anyTimes();
		playAll();
		altriAttributeConfermaModificaExecuter
				.execute(getRequestEvent());
}
	
}
