package it.sella.tracciabilitaplichi.executer.gestorealtriplichi.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriplichi.AltriPlichiDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiPlichiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import org.easymock.EasyMock;


public class AltriPlichiDefaultExecuterTest extends AbstractSellaExecuterMock{

	public AltriPlichiDefaultExecuterTest(final String name) {
		super(name);
	}

	AltriPlichiDefaultExecuter executer=new AltriPlichiDefaultExecuter();
	
	public void testAltriPlichiDefaultExecuter_01() {
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		expecting(getStateMachineSession().containsKey("AltriPlichiHashTable")).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertTrue(true);
	}
	
	public void testAltriPlichiDefaultExecuter_02() {
		final Collection collection=new ArrayList();
		collection.add("");
		final Hashtable hashtable=new Hashtable();
		hashtable.put("RestoreCdr", "");
		hashtable.put("MSG", "");
		hashtable.put("Success", "");
		hashtable.put("PageNo","12");
		hashtable.put("tickedlist", "");
		hashtable.put("AltriMainCollection", collection);
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		expecting(getStateMachineSession().containsKey("AltriPlichiHashTable")).andReturn(true);
		expecting(getStateMachineSession().get("AltriPlichiHashTable")).andReturn(hashtable);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testAltriPlichiDefaultExecuter_03() {
		DBPersonaleWrapperMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		expecting(getStateMachineSession().containsKey("AltriPlichiHashTable")).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
	public void testAltriPlichiDefaultExecuter_04() {
		DBPersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiPlichiDataAccess.class, TracciabilitaPlichiPlichiDataAccessMock.class);
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
		expecting(getStateMachineSession().containsKey("AltriPlichiHashTable")).andReturn(false);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
}
