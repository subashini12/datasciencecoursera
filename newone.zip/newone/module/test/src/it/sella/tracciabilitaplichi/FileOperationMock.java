package it.sella.tracciabilitaplichi;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import mockit.Mock;

public class FileOperationMock {

	@Mock
	public byte[] getFile(final String ftpPoolName, final String fileName, final String filePath) throws TracciabilitaException {
		return null;
	}
}
