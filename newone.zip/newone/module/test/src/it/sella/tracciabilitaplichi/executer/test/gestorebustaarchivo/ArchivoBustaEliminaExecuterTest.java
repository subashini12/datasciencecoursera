package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoBustaEliminaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.util.ArrayList;
import java.util.Hashtable;

public class ArchivoBustaEliminaExecuterTest  extends AbstractSellaExecuterMock {

    ArchivoBustaEliminaExecuter  archivoBustaEliminaExecuter = new  ArchivoBustaEliminaExecuter();

   public  ArchivoBustaEliminaExecuterTest(String name) {
       super(name);
   }

   public void testArchivoBustaEliminaExecuter_01() {
 
       expecting(getRequestEvent( ).getAttribute( "checkbox" ) ).andReturn(
                null) ;
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );

       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession" )).andReturn(
               archivoBustaCinqueSession) ;
       playAll();
       ExecuteResult executeResult =  archivoBustaEliminaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrFail"));
       assertEquals(executeResult.getAttribute( "MSG" ), ("TRPL-1003"));
        
   }
   public void testArchivoBustaEliminaExecuter_02() {
       
       expecting(getRequestEvent( ).getAttribute( "checkbox" ) ).andReturn(
                "") ;
       ArrayList arrayListnew = new ArrayList();
       TracciabilitaPlichiView  trView =  new TracciabilitaPlichiView() ;
       PlichiAttributeView plView = new PlichiAttributeView();
       plView.setBarCode("90109874663");
       trView.setPlichiAttributeView( plView );
       arrayListnew.add( trView );
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       archivoBustaCinqueSession.put( "Busta5List", arrayListnew );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession" )).andReturn(
               archivoBustaCinqueSession) ;
       playAll();
       ExecuteResult executeResult =  archivoBustaEliminaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrConferma"));
       assertEquals(executeResult.getAttribute( "BustaCinqueArchivoSession" ),archivoBustaCinqueSession);
        
   }
public void testArchivoBustaEliminaExecuter_03() {
       
       expecting(getRequestEvent( ).getAttribute( "checkbox" ) ).andReturn(
                new String[]{"90109874663"}) ;
       ArrayList arrayListnew = new ArrayList();
       TracciabilitaPlichiView  trView =  new TracciabilitaPlichiView() ;
       PlichiAttributeView plView = new PlichiAttributeView();
       plView.setBarCode("90109874663");
       trView.setPlichiAttributeView( plView );
       arrayListnew.add( trView );
       Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       archivoBustaCinqueSession.put( "Busta5List", arrayListnew );
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession" )).andReturn(
               archivoBustaCinqueSession) ;
       playAll();
       ExecuteResult executeResult =  archivoBustaEliminaExecuter
               .execute(getRequestEvent());
       assertEquals(executeResult.getTransition( ), ("TrConferma"));
       assertEquals(executeResult.getAttribute( "BustaCinqueArchivoSession" ),archivoBustaCinqueSession);
        
   }
}
