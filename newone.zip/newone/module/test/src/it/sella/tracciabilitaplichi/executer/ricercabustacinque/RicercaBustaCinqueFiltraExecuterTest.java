package it.sella.tracciabilitaplichi.executer.ricercabustacinque;

import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.processor.ExecutersHelperMock;
import it.sella.tracciabilitaplichi.implementation.view.RicercaView;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class RicercaBustaCinqueFiltraExecuterTest extends
		AbstractSellaExecuterMock {

	public RicercaBustaCinqueFiltraExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	RicercaBustaCinqueFiltraExecuter executer = new RicercaBustaCinqueFiltraExecuter();

	public void testRicercaBustaCinqueFiltraExecuter_01() {
		ExecutersHelperMock.setCheckNullDate();
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("lid")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("senderDenominazione")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("barCodePlico")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	
	public void testRicercaBustaCinqueFiltraExecuter_02() {
		ExecutersHelperMock.setCheckNullDate();
		setUpMockMethods(ExecutersHelper.class, ExecutersHelperMock.class);
		expecting(getRequestEvent().getAttribute("lid")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("userCode")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("senderCdr")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("senderDenominazione")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barCode")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barCodePlico")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("boxId")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(getHashtable()).anyTimes();
		expecting(getStateMachineSession().containsKey("RICERCA_BUSTA_CHINQUE_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Hashtable getHashtable()
	{
		final Hashtable hashtable = new Hashtable() ;
		hashtable.put("RicercaCollRicercaView",getRicercaViewCollection() );
		return hashtable ;
	}
 
	private static Collection getRicercaViewCollection()
	{
		final Collection collection = new ArrayList();
		collection.add(getRicercaView());
		return collection ;
	}
	
	private static RicercaView getRicercaView()
	{
		final RicercaView ricercaView = new RicercaView() ;
		ricercaView.setActualDate(new Timestamp(1L));
		ricercaView.setLid("2");
		ricercaView.setUserId("2");
		ricercaView.setCdrDesc("Banca Sella S.p.a");
		ricercaView.setBarCode("1234567812345");
		ricercaView.setBarCodePlico("a");
		ricercaView.setBoxNumber(3L);
		ricercaView.setStatusDesc("Invio");
		return ricercaView ;
	}
}
