/*package it.sella.tracciabilitaplichi.executer.test.frequentidestinazionecdr;

import it.sella.tracciabilitaplichi.executer.frequentidestinazionecdr.DefaultFrequentiDestinazioneCdrExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;

import org.easymock.EasyMock;

public class DefaultFrequentiDestinazioneCdrExecuterTest extends AbstractSellaExecuterTest
{

	public DefaultFrequentiDestinazioneCdrExecuterTest(final String name) 
	{
		super(name);
	}

	DefaultFrequentiDestinazioneCdrExecuter executer = new DefaultFrequentiDestinazioneCdrExecuter();
	
	public void testDefaultFrequentiDestinazioneCdrExecuter_01()
	{
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class , TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null );
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	public void testDefaultFrequentiDestinazioneCdrExecuter_02()
	{
		SecurityDBpersonaleWrapperMock.setTracciabilitaException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class , TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null );
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
	public void testDefaultFrequentiDestinazioneCdrExecuter_03()
	{
		SecurityDBpersonaleWrapperMock.setRemoteException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods( SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods( TracciabilitaPlichiCommonDataAccess.class , TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods( TPUtil.class, TPUtilMock.class);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), (String ) EasyMock.anyObject() ) ).andReturn( null );
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		playAll();
		executer.execute( getRequestEvent());
	}
}
*/