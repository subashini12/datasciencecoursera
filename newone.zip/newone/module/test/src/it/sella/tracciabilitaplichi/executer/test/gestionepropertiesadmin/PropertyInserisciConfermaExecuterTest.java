package it.sella.tracciabilitaplichi.executer.test.gestionepropertiesadmin;


import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.PropertyInserisciConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.processor.PropertyInserisciProcessor;
import it.sella.tracciabilitaplichi.executer.gestionepropertiesadmin.test.processor.PropertyInserisciProcessorMock;

import java.util.HashMap;

import mockit.Mockit;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;

public class PropertyInserisciConfermaExecuterTest 
{

	PropertyInserisciConfermaExecuter executer = new PropertyInserisciConfermaExecuter();
	
	@Test
	public void propertyInserisciConfermaExecuter_01()
	{
		Mockit.setUpMock( PropertyInserisciProcessor.class, PropertyInserisciProcessorMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(stateMachineSession.get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		EasyMock.expect(stateMachineSession.put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( "" ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = executer.execute( requestEvent );
		Assert.assertEquals(executeResult.getAttribute(ITPConstants.MSG), "abc");
		Assert.assertEquals(executeResult.getTransition(), "TrFail");
	}
	
	@Test
	public void propertyInserisciConfermaExecuter_02()
	{
		Mockit.setUpMock( PropertyInserisciProcessor.class, PropertyInserisciProcessorMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(stateMachineSession.get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		EasyMock.expect(stateMachineSession.put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( "" ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = executer.execute( requestEvent );
		Assert.assertEquals(executeResult.getAttribute(ITPConstants.MSG), "abc");
		Assert.assertEquals(executeResult.getTransition(), "TrFail");
	}
	
	@Test
	public void propertyInserisciConfermaExecuter_04()
	{
		PropertyInserisciProcessorMock.setTracciabilitaException();
		Mockit.setUpMock( PropertyInserisciProcessor.class, PropertyInserisciProcessorMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(stateMachineSession.get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = executer.execute( requestEvent );
		Assert.assertEquals(executeResult.getAttribute(ITPConstants.MSG), null );
		Assert.assertEquals(executeResult.getTransition(), null);
	}
	
	@Test
	public void propertyInserisciConfermaExecuter_05()
	{
		PropertyInserisciProcessorMock.setRemoteException();
		Mockit.setUpMock( PropertyInserisciProcessor.class, PropertyInserisciProcessorMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.TRUE).anyTimes();
		EasyMock.expect(stateMachineSession.get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = executer.execute( requestEvent );
		Assert.assertEquals(executeResult.getAttribute(ITPConstants.MSG), null);
		Assert.assertEquals(executeResult.getTransition(), null);
	}
	
	@Test
	public void propertyInserisciConfermaExecuter_03()
	{
		PropertyInserisciProcessorMock.setMessageRemove();
		Mockit.setUpMock( PropertyInserisciProcessor.class, PropertyInserisciProcessorMock.class);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		EasyMock.expect(stateMachineSession.put( (String ) EasyMock.anyObject(),  EasyMock.anyObject() ) ).andReturn( null );
		EasyMock.expect(stateMachineSession.containsKey(ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP)).andReturn(Boolean.FALSE).anyTimes();
		EasyMock.expect(stateMachineSession.get( ITPConstants.GESTIONE_PROPERTIES_ADMIN_MAP )).andReturn(  new HashMap()  ).anyTimes();
		EasyMock.replay(stateMachineSession);
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		EasyMock.expect(requestEvent.getStateMachineSession()).andReturn(stateMachineSession).anyTimes();
		EasyMock.replay(requestEvent);
		final ExecuteResult executeResult = executer.execute( requestEvent );
		Assert.assertEquals(executeResult.getAttribute(ITPConstants.MSG), null);
		Assert.assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	
}
