package it.sella.tracciabilitaplichi.executer.test.processor;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.processor.ExecutersHelper;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import junit.framework.TestCase;

public class ExecutersHelperTest extends TestCase
{

	private LazyFetchCollection situazioneRicercaDataColl = null;
	private RequestEvent requestEvent = null;
	
	public ExecutersHelperTest ( final String name )
	{
		super( name );
	}
	
	@Override
	public void setUp( )
	{
		this.situazioneRicercaDataColl = createMock( LazyFetchCollection.class );
		this.requestEvent = createMock( RequestEvent.class );
	}
	
	@Override
	public void tearDown( )
	{
		 situazioneRicercaDataColl = null;
		 requestEvent = null;		 
	}
	
	public void testSetSituazionePlichiListExcelData1( )
	{
		final Boolean isBustaNeraWithCdrMittSearch = Boolean.FALSE;
		final Boolean isBorsaVerde = Boolean.FALSE;
		final Boolean isFolder = Boolean.FALSE;
		final List<TracciabilitaPlichiView> bustaNeraColl = getOtherObjectsTPViewCollection( isBustaNeraWithCdrMittSearch );
		expect( this.situazioneRicercaDataColl.iterator( ) ).andReturn( bustaNeraColl.iterator( ) );
		replay( this.situazioneRicercaDataColl );
		
		final Hashtable<String, Vector> mapSituazioneListData = new Hashtable< String, Vector>( );
		final Vector<String> orderOfColumnHeading = new Vector<String>( );
		
		ExecutersHelper.setSituazionePlichiListExcelData( this.situazioneRicercaDataColl, mapSituazioneListData, orderOfColumnHeading, isBustaNeraWithCdrMittSearch, new HashMap<Long, String>( 1) );
		assertSituazionePlicihExcelData( orderOfColumnHeading, mapSituazioneListData, bustaNeraColl, isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder );
	}

	public void testSetSituazionePlichiListExcelData2( )
	{
		final Boolean isBustaNeraWithCdrMittSearch = Boolean.TRUE;
		final Boolean isBorsaVerde = Boolean.FALSE;
		final Boolean isFolder = Boolean.FALSE;
		final List<TracciabilitaPlichiView> bustaNeraColl = getOtherObjectsTPViewCollection( isBustaNeraWithCdrMittSearch );
		expect( this.situazioneRicercaDataColl.iterator( ) ).andReturn( bustaNeraColl.iterator( ) );
		replay( this.situazioneRicercaDataColl );
		
		final Hashtable<String, Vector> mapSituazioneListData = new Hashtable< String, Vector>( );
		final Vector<String> orderOfColumnHeading = new Vector<String>( );
		
		ExecutersHelper.setSituazionePlichiListExcelData( this.situazioneRicercaDataColl, mapSituazioneListData, orderOfColumnHeading, isBustaNeraWithCdrMittSearch, new HashMap<Long, String>( 1 )  );
		assertSituazionePlicihExcelData( orderOfColumnHeading, mapSituazioneListData, bustaNeraColl, isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder );
	}

	public void testSetSituazionePlichiListExcelData3( )
	{
		final Boolean isBustaNeraWithCdrMittSearch = Boolean.FALSE;
		final Boolean isBorsaVerde = Boolean.FALSE;
		final Boolean isFolder = Boolean.FALSE;
		final List<TracciabilitaPlichiView> bustaCinqueColl = new ArrayList<TracciabilitaPlichiView>( 2 );
		bustaCinqueColl.add( getTPView( "Busta Cinque", "SSILQ40", "Da Fare", "IN2030", "TECHNICUL", isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder, Boolean.TRUE ) );
		bustaCinqueColl.add( getTPView( "Busta Cinque", "SSILQ40", "Da Fare", "IN2030", "TECHNICUL", isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder, Boolean.FALSE ) );
		expect( this.situazioneRicercaDataColl.iterator( ) ).andReturn( bustaCinqueColl.iterator( ) );
		replay( this.situazioneRicercaDataColl );
		
		final Hashtable<String, Vector> mapSituazioneListData = new Hashtable< String, Vector>( );
		final Vector<String> orderOfColumnHeading = new Vector<String>( );
		
		ExecutersHelper.setSituazionePlichiListExcelData( this.situazioneRicercaDataColl, mapSituazioneListData, orderOfColumnHeading, isBustaNeraWithCdrMittSearch, new HashMap<Long, String>( 1 ) );
		assertSituazionePlicihExcelData( orderOfColumnHeading, mapSituazioneListData, bustaCinqueColl, isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder );
	}
	
	public void testSetSituazionePlichiListExcelData4( )
	{
		final Boolean isBustaNeraWithCdrMittSearch = Boolean.FALSE;
		final Boolean isBorsaVerde = Boolean.TRUE;
		final Boolean isFolder = Boolean.FALSE;
		final List<TracciabilitaPlichiView> borsaVerdeTPViewColl = getBorsaVerdeTPViewCollection( );
		expect( this.situazioneRicercaDataColl.iterator( ) ).andReturn( borsaVerdeTPViewColl.iterator( ) );
		replay( this.situazioneRicercaDataColl );
		
		final Hashtable<String, Vector> mapSituazioneListData = new Hashtable< String, Vector>( );
		final Vector<String> orderOfColumnHeading = new Vector<String>( );
		
		ExecutersHelper.setSituazionePlichiListExcelData( this.situazioneRicercaDataColl, mapSituazioneListData, orderOfColumnHeading, isBustaNeraWithCdrMittSearch, new HashMap<Long, String>( 1 ) );
		assertSituazionePlicihExcelData( orderOfColumnHeading, mapSituazioneListData, borsaVerdeTPViewColl, isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder );
	}

	public void testSetSituazionePlichiListExcelData5( )
	{
		final Boolean isBustaNeraWithCdrMittSearch = Boolean.FALSE;
		final Boolean isBorsaVerde = Boolean.FALSE;
		final Boolean isFolder = Boolean.TRUE;
		final List<TracciabilitaPlichiView> folderTPViewColl = getFolderTPViewCollection( );
		expect( this.situazioneRicercaDataColl.iterator( ) ).andReturn( folderTPViewColl.iterator( ) );
		replay( this.situazioneRicercaDataColl );
		
		final Hashtable<String, Vector> mapSituazioneListData = new Hashtable< String, Vector>( );
		final Vector<String> orderOfColumnHeading = new Vector<String>( );
		final Map<Long, String> folderTypesMap = new HashMap<Long, String>( 1 );
		folderTypesMap.put( 1L, "" );
		ExecutersHelper.setSituazionePlichiListExcelData( this.situazioneRicercaDataColl, mapSituazioneListData, orderOfColumnHeading, isBustaNeraWithCdrMittSearch, folderTypesMap );
		assertSituazionePlicihExcelData( orderOfColumnHeading, mapSituazioneListData, folderTPViewColl, isBustaNeraWithCdrMittSearch, isBorsaVerde, isFolder );
	}

	public void testGetDateFromReqEvent1( )
	{
		final String strDD = "dd"; final String strMM = "mm"; final String strYY = "yyyy";
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( "01" );
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( "01" );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( null );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( null );
		replay( this.requestEvent );
		final String dateString = ExecutersHelper.getDateFromReqEvent( this.requestEvent, strDD, strMM, strYY );
		assertNotNull( dateString );
		assertEquals( "01//", dateString );
	}

	public void testGetDateFromReqEvent2( )
	{
		final String strDD = "dd"; final String strMM = "mm"; final String strYY = "yyyy";
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( null );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( "01" );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( "01" );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( null );
		replay( this.requestEvent );
		final String dateString = ExecutersHelper.getDateFromReqEvent( this.requestEvent, strDD, strMM, strYY );
		assertNotNull( dateString );
		assertEquals( "/01/", dateString );
	}

	public void testGetDateFromReqEvent3( )
	{
		final String strDD = "dd"; final String strMM = "mm"; final String strYY = "yyyy";
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( null );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( null );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( "2009" );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( "2009" );
		replay( this.requestEvent );
		final String dateString = ExecutersHelper.getDateFromReqEvent( this.requestEvent, strDD, strMM, strYY );
		assertNotNull( dateString );
		assertEquals( "//2009", dateString );
	}
	
	public void testGetDateFromReqEvent4( )
	{
		final String strDD = "dd"; final String strMM = "mm"; final String strYY = "yyyy";
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( "" );
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( "" );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( "" );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( "" );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( "" );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( "" );
		replay( this.requestEvent );
		final String dateString = ExecutersHelper.getDateFromReqEvent( this.requestEvent, strDD, strMM, strYY );
		assertNull( dateString );
	}
	
	public void testGetDateFromReqEvent5( )
	{
		final String strDD = "dd"; final String strMM = "mm"; final String strYY = "yyyy";
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( null );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( null );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( null );
		replay( this.requestEvent );
		final String dateString = ExecutersHelper.getDateFromReqEvent( this.requestEvent, strDD, strMM, strYY );
		assertNull( dateString );
	}

	public void testGetDateFromReqEvent6( )
	{
		final String strDD = "dd"; final String strMM = "mm"; final String strYY = "yyyy";
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( "01" );
		expect( this.requestEvent.getAttribute( strDD ) ).andReturn( "01" );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( "12" );
		expect( this.requestEvent.getAttribute( strMM ) ).andReturn( "12" );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( "2009" );
		expect( this.requestEvent.getAttribute( strYY ) ).andReturn( "2009" );
		replay( this.requestEvent );
		final String dateString = ExecutersHelper.getDateFromReqEvent( this.requestEvent, strDD, strMM, strYY );
		assertNotNull( dateString );
		assertEquals( "01/12/2009", dateString );
	}
	
	public void testGetCorrectedData1( )
	{
		final String objectName = "name";
		expect( this.requestEvent.getAttribute( objectName ) ).andReturn( "busta" );
		replay( this.requestEvent );
		assertEquals( "BUSTA", ExecutersHelper.getCorrectedData( this.requestEvent, objectName ) );
	}

	public void testGetCorrectedData2( )
	{
		final String objectName = "name";
		expect( this.requestEvent.getAttribute( objectName ) ).andReturn( "BUSTA" );
		replay( this.requestEvent );
		assertEquals( "BUSTA", ExecutersHelper.getCorrectedData( this.requestEvent, objectName ) );
	}

	public void testGetCorrectedData3( )
	{
		final String objectName = "name";
		expect( this.requestEvent.getAttribute( objectName ) ).andReturn( "    busta    " );
		replay( this.requestEvent );
		assertEquals( "BUSTA", ExecutersHelper.getCorrectedData( this.requestEvent, objectName ) );
	}	
	
	public void testGetCorrectedData4( )
	{
		final String objectName = "name";
		expect( this.requestEvent.getAttribute( objectName ) ).andReturn( null );
		replay( this.requestEvent );
		assertNull( ExecutersHelper.getCorrectedData( this.requestEvent, objectName ) );
	}	
	
	public void testGetCorrectedData5( )
	{
		final String objectName = "name";
		expect( this.requestEvent.getAttribute( objectName ) ).andReturn( "  " );
		replay( this.requestEvent );
		assertEquals( "", ExecutersHelper.getCorrectedData( this.requestEvent, objectName ) );
	}	
	
	private void assertSituazionePlicihExcelData( final Vector orderOfColumnHeading, final Hashtable<String, Vector> mapSituazioneListData, final List<TracciabilitaPlichiView> tpViewColl, final Boolean isBustaNeraWithCdrMittSearch, final Boolean isBorsaVerde, final Boolean isFolder )
	{
		final String[ ] columnHeading = getColumnHeading( isBustaNeraWithCdrMittSearch );
		final Map<Long, String> folderTypesMap = new HashMap<Long, String>( 1 );
        folderTypesMap.put( 1L, "" );
		int i = 0;
		for ( final String heading : columnHeading )
		{
			
			assertTrue( orderOfColumnHeading.contains( heading ) );
			assertTrue( orderOfColumnHeading.indexOf( heading ) == i++ );
			assertTrue( mapSituazioneListData.containsKey( heading ) );
			assertEquals( tpViewColl.size( ), ( mapSituazioneListData.get( heading ).size( ) - 1 ) );
			assertEquals( heading, mapSituazioneListData.get( heading ).get( 0 ) );
			
			for ( int j = 0; j < tpViewColl.size( ); j++ )
			{
			    final String actualValue = mapSituazioneListData.get( heading ).get( j + 1 ).toString( );
				final TracciabilitaPlichiView tracciabilitaPlichiView = tpViewColl.get( j );
				if ( ITPConstants.DATA.equals( heading ) )
				{
					assertEquals( Util.formatDate( tracciabilitaPlichiView.getOggettoView( ).getOggettoDate( ) ), actualValue );
				}
				else if ( ITPConstants.TIPO.equals( heading ) )
				{
				    assertEquals(  new StringBuilder( tracciabilitaPlichiView.getOggettoView( ).getOggettoTypeDesc( ) ).append( isFolder ? "(".concat( folderTypesMap.get( 1L ) ).concat( ")"  ) : ""  ).toString( ) , actualValue );
				}
				else if ( ITPConstants.CDR_DESTINARIO.equals( heading ) ||  ITPConstants.CDR_MITTENTE.equals( heading ) )
				{
					final String expectedCDR = isBustaNeraWithCdrMittSearch ? tracciabilitaPlichiView.getPlichiAttributeView( ).getCdrDestination( ) : tracciabilitaPlichiView.getOggettoView( ).getCdrName( );
					assertEquals( expectedCDR, actualValue );
				}
				else if ( ITPConstants.DESTINARIO.equals( heading ) || ITPConstants.MITTENTE.equals( heading ) )
				{
					final String expectedCDRDesc =  isBustaNeraWithCdrMittSearch ? tracciabilitaPlichiView.getPlichiAttributeView( ).getCdrDestDesc( ) : tracciabilitaPlichiView.getOggettoView( ).getCdrNameDesc( );
					assertEquals( expectedCDRDesc, actualValue );
				}
				else if ( ITPConstants.NCD_OR_LID.equals( heading ) )
				{
					final String expectedNCDorLID = ( isBorsaVerde ? tracciabilitaPlichiView.getBorsaVerdeAttributeView( ).getCode( ) : ( isFolder ? tracciabilitaPlichiView.getFolderAttributes( ).getBarcode( ) : ( Util.checkNull( tracciabilitaPlichiView.getPlichiAttributeView( ).getBarCode( ) ) ? tracciabilitaPlichiView.getOggettoView( ).getLid( ) : tracciabilitaPlichiView.getPlichiAttributeView( ).getBarCode( ) ) ) );
					assertEquals( expectedNCDorLID, actualValue );
				}
				else if ( ITPConstants.UTENTE.equals( heading ) )
				{
					assertEquals( tracciabilitaPlichiView.getOggettoView( ).getUserId( ), actualValue );
				}
				else if ( ITPConstants.STATO.equals( heading ) )
				{
					assertEquals( tracciabilitaPlichiView.getOggettoView( ).getStatusDispDesc( ), actualValue );
				}
			}
		}
	}
	
	private TracciabilitaPlichiView getTPView( final String oggettoTypeDesc, final String userId, final String statusDispDesc, final String cdrName, final String cdrNameDesc, final Boolean isBustaNeraWithCdrMittSearch, final Boolean isBorsaVerde, final Boolean isFolder, final Boolean isLid )
	{
		final TracciabilitaPlichiView plichiView = new TracciabilitaPlichiView( );
		plichiView.setOggettoView( new OggettoView( ) );
		plichiView.getOggettoView( ).setOggettoDate( new Timestamp( Calendar.getInstance( ).getTimeInMillis( ) ) );
		plichiView.getOggettoView( ).setOggettoTypeDesc( oggettoTypeDesc );
		plichiView.getOggettoView( ).setUserId( userId );
		plichiView.getOggettoView( ).setStatusDispDesc( statusDispDesc );
		plichiView.getOggettoView( ).setCdrName( cdrName );
		plichiView.getOggettoView( ).setCdrNameDesc( cdrNameDesc );
		plichiView.setPlichiAttributeView( new PlichiAttributeView( ) );
		if ( isBorsaVerde )
		{
			plichiView.setBorsaVerdeAttributeView( new BorsaVerdeAttributeView( ) );
			plichiView.getBorsaVerdeAttributeView( ).setCode( "R111111111111" );
		}
		else if ( isFolder )
		{
		    final FolderAttributes folderAttributes = new FolderAttributes( );
		    folderAttributes.setBarcode( "1021232425262" );
		    folderAttributes.setTipoPratica( 1L );
			plichiView.setFolderAttributes( folderAttributes );
		}
		else
		{
			if ( isLid )
			{
				plichiView.getOggettoView( ).setLid( "904" );
			}
			else
			{
				plichiView.getPlichiAttributeView( ).setBarCode( "1001012345671" );
			}
			if ( isBustaNeraWithCdrMittSearch )
			{
				plichiView.getPlichiAttributeView( ).setCdrDestination( "099505" );
				plichiView.getPlichiAttributeView( ).setCdrDestDesc( "ARCHIVIO DEPT" );
			}
		}
		
		return plichiView;
	}
	
	private List<TracciabilitaPlichiView> getOtherObjectsTPViewCollection( final Boolean isBustaNeraWithCdrMittSearch )
	{
		final String oggettoTypeDesc = "Busta nera";
		final List<TracciabilitaPlichiView> otherObjectsTPViewColl = new ArrayList<TracciabilitaPlichiView>( 3 );
		otherObjectsTPViewColl.add( getTPView( oggettoTypeDesc, "SSILQ40", "Preparata", "IN2030", "TECHNICUL", isBustaNeraWithCdrMittSearch, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE ) );
		otherObjectsTPViewColl.add( getTPView( oggettoTypeDesc, "SSILQ74", "Preparata", "099288", "SELLA SYNERGY", isBustaNeraWithCdrMittSearch, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE ) );
		otherObjectsTPViewColl.add( getTPView( oggettoTypeDesc, "SSILH17", "Preparata", "IN2030", "TECHNICUL", isBustaNeraWithCdrMittSearch, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE ) );
		return otherObjectsTPViewColl;
	}
	
	private List<TracciabilitaPlichiView> getBorsaVerdeTPViewCollection( )
	{
		final String oggettoTypeDesc = "Borsa Verde";
		final List<TracciabilitaPlichiView> bvTPViewColl = new ArrayList<TracciabilitaPlichiView>( 3 );
		bvTPViewColl.add( getTPView( oggettoTypeDesc, "SSILQ40", "Preparata", "IN2030", "TECHNICUL", Boolean.FALSE, Boolean.TRUE, Boolean.FALSE, Boolean.FALSE ) );
		bvTPViewColl.add( getTPView( oggettoTypeDesc, "SSILQ74", "Preparata", "099288", "SELLA SYNERGY", Boolean.FALSE, Boolean.TRUE, Boolean.FALSE, Boolean.FALSE ) );
		bvTPViewColl.add( getTPView( oggettoTypeDesc, "SSILH17", "Preparata", "IN2030", "TECHNICUL", Boolean.FALSE, Boolean.TRUE, Boolean.FALSE, Boolean.FALSE ) );
		return bvTPViewColl;
	}

	private List<TracciabilitaPlichiView> getFolderTPViewCollection( )
	{
		final String oggettoTypeDesc = "Pratica";
		final List<TracciabilitaPlichiView> folderTPViewColl = new ArrayList<TracciabilitaPlichiView>( 3 );
		folderTPViewColl.add( getTPView( oggettoTypeDesc, "SSILQ40", "Preparata", "IN2030", "TECHNICUL", Boolean.FALSE, Boolean.FALSE, Boolean.TRUE, Boolean.FALSE ) );
		folderTPViewColl.add( getTPView( oggettoTypeDesc, "SSILQ74", "Preparata", "099288", "SELLA SYNERGY", Boolean.FALSE, Boolean.FALSE, Boolean.TRUE, Boolean.FALSE ) );
		folderTPViewColl.add( getTPView( oggettoTypeDesc, "SSILH17", "Preparata", "IN2030", "TECHNICUL", Boolean.FALSE, Boolean.FALSE, Boolean.TRUE, Boolean.FALSE ) );
		return folderTPViewColl;
	}
	
	private String[ ] getColumnHeading( final Boolean isBustaNeraWithCdrMittSearch )
	{
		return new String[ ]{ ITPConstants.DATA, ITPConstants.TIPO, isBustaNeraWithCdrMittSearch ? ITPConstants.CDR_DESTINARIO : ITPConstants.CDR_MITTENTE, isBustaNeraWithCdrMittSearch ? ITPConstants.DESTINARIO : ITPConstants.MITTENTE, ITPConstants.NCD_OR_LID, ITPConstants.UTENTE, ITPConstants.STATO };
	}
}
