/*package it.sella.tracciabilitaplichi.executer.test.ricezioneplichiarchivio;

import it.sella.classificazione.ClassificazioneView;
import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.ricezioneplichiarchivio.RicezionePlichiArchivioFiltraExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.interfaces.dao.IBorsaVerdeDataAccess;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class RicezionePlichiArchivioFiltraExecuterTest extends AbstractSellaExecuterTest
{

	private final ClassificazioneView classificazioneView = null;
	private final IBorsaVerdeDataAccess borsaVerdeDataAccess = null;
	
	public RicezionePlichiArchivioFiltraExecuterTest ( final String name )
	{
		super( name );
	}
	
	
	public void testFiltraExecuter_1( )
	{
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods( SecurityWrapper.class,SecurityWrapperMock.class );
		//setUpMockMethods( BorsaVerdeDataAccess
		final Map sessionMap = new HashMap( );
		sessionMap.put( "OggettoType", "5903" );
		sessionMap.put( "PUSHING_FROM_BV_ARCHIVATION",Boolean.TRUE );
		sessionMap.put( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ), Boolean.TRUE );
		expecting( getStateMachineSession( ).containsKey( "GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION") ).andReturn( Boolean.TRUE );
		expecting(getStateMachineSession().containsKey("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn(Boolean.TRUE).anyTimes();
		expecting( getStateMachineSession( ).get( "GESTORE_RICEZIONE_PLICHI_ARCHIVIO_SESSION") ).andReturn((Serializable) sessionMap );
		expecting( getRequestEvent().getAttribute( "oggettoTypeId" ) ).andReturn("5903").anyTimes();  
		expecting( getStateMachineSession( ).put( ITPConstants.RICEZIONE_PLICHI_ARCHIVIO_SESSION, sessionMap ) ).andReturn( sessionMap );
		playAll( );		
		final ExecuteResult executeResult = new RicezionePlichiArchivioFiltraExecuter( ).execute( this.getRequestEvent( ) );
		assertEquals( ITPConstants.TR_CONFERMA, executeResult.getTransition( ) );
		assertEquals( IErrorCodes.TRPL_1360, executeResult.getAttribute( ITPConstants.MSG ) );
		assertTrue( ( Boolean ) executeResult.getAttribute( CONSTANTS.IS_ENDORSER_VISIBLE.toString( ) ) );
		assertNotNull( executeResult.getAttribute( ITPConstants.TYPES_OF_OGGETTOS ) );
		
	}
	
}
*/