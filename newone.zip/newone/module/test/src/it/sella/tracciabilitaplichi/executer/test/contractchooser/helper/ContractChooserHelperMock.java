package it.sella.tracciabilitaplichi.executer.test.contractchooser.helper;

import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class ContractChooserHelperMock 
{
  private static Boolean isSelectedBustaDeiciNull = false ;
  
    public  static void setSelectedBustaDeiciNull() 
  	{
	  isSelectedBustaDeiciNull = true;
  	}

  
	@Mock
	public static Collection getSelectedBustaDeici(Object obj)
	{
		Collection collection = new ArrayList();
		collection.add("abc");
		if( isSelectedBustaDeiciNull )
		{
			isSelectedBustaDeiciNull = false;
			collection = null;
		}
		return collection;
	}
	@Mock
	public static Collection getBustaDeiciAttributeViews(Collection bustaDeiciId, Collection allBustaDeiciAttributeViews)
	{
		Collection collection = new ArrayList();
		collection.add("abc");
		return collection;
	}
}
