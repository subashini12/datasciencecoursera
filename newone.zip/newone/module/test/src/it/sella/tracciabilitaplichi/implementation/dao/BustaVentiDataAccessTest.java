package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;

import java.util.Collection;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BustaVentiDataAccessTest {

	BustaVentiDataAccess commonDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;

	@Before
	public void setUp() throws Exception {
		commonDataAccess = new BustaVentiDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
	}

	@After
	public void tearDown() throws Exception {
		commonDataAccess = null;
	}

	@Test
	public void getBarcodesCreatedToday() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(getBarcodesCreatedTodaySt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, "PA_BARCODE",1l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection<String> barcodesCreated = commonDataAccess.getBarcodesCreatedToday(getOggettoView());
		Assert.assertEquals(barcodesCreated.size(), 1);
	}

	@Test
	public void getStampeId() throws TracciabilitaException {
		mockStatementProvider = new MockStatementProvider(getStampeIdSt());
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, "BS_STAMPE_ID",1l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Long barcodesCreated = commonDataAccess.getStampeId("123");
		Assert.assertEquals(barcodesCreated, Long.valueOf("1"));
	}

	private OggettoView getOggettoView(){
		final OggettoView oggettoView = new OggettoView();
		oggettoView.setUserId( "BSZI212");
		oggettoView.setCdrName( "It-ORG");
		oggettoView.setStatusId(Long.valueOf("1") );
		oggettoView.setBankId(Long.valueOf("1") );
		return oggettoView;
	}

	private String getStampeIdSt(){
		final StringBuilder query = new StringBuilder( "SELECT BS.BS_STAMPE_ID FROM TP_TR_PLICHI_ATTRIBUTE PA, TP_TR_B20_STAMPE BS " )
		.append(  "WHERE PA.PA_DOC_ID = BS.BS_OG_ID " )
		.append( "AND PA.PA_BARCODE = ? " );
		return query.toString();
	}

	private String getBarcodesCreatedTodaySt(){
		final StringBuilder query = new StringBuilder( "SELECT PA.PA_BARCODE FROM TP_TR_PLICHI_ATTRIBUTE PA, TP_TR_OGGETTO OG " )
		.append(  "WHERE PA.PA_DOC_ID = OG.OG_ID " )
		.append( "AND OG.OG_OGGETTO_ACTUAL_DATE = TRUNC(SYSDATE) " )
		.append( "AND OG.OG_USER = ? " )
		.append( "AND OG.OG_CDR = ? " )
		.append( "AND OG.OG_CURR_STATUS_ID = ? " )
		.append( "AND OG.OG_BANK = ? " )
		.append( "ORDER BY OG.OG_ID DESC" );
		return query.toString();
	}
}
