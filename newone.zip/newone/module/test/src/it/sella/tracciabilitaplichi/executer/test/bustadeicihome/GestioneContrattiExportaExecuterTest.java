/*package it.sella.tracciabilitaplichi.executer.test.bustadeicihome;

import it.sella.ejb.collections.LazyFetchCollection;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.GestioneContrattiExportaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.util.BustaDeiciPagging;

import org.easymock.classextension.EasyMock;

public class GestioneContrattiExportaExecuterTest extends AbstractSellaExecuterMock
{

	public GestioneContrattiExportaExecuterTest(final String name)
	{
		super(name);
	}

	GestioneContrattiExportaExecuter executer = new GestioneContrattiExportaExecuter();

	public void testGestioneContrattiExportaExecuter_forSuccessCase()
	{
		expecting( getStateMachineSession().get( "Pagging" )).andReturn(getLazyFetchList()).anyTimes();
		executer.execute(getRequestEvent());
	}

	private LazyFetchCollection<BustaDeiciPagging> getLazyFetchList()  {

		final LazyFetchCollection lazyFetchCollection = EasyMock.createMock(LazyFetchCollection.class);

		EasyMock.expect(lazyFetchCollection.size()).andReturn(1).anyTimes();

		EasyMock.replay(lazyFetchCollection);

		return lazyFetchCollection;

	}

}
 */