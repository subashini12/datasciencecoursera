package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;


import java.util.Stack;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

public class PopBarCodeExecuterTest extends AbstractSellaExecuterMock{

	public PopBarCodeExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PopBarCodeExecuter executer=new PopBarCodeExecuter();
	
	public void testPopBarCodeExecuter_01()
	{
		Stack stack=getStack();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(true);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getStateMachineSession().remove("1")).andReturn("");
		expecting(getStateMachineSession().remove("PlichiContentsHashTable")).andReturn("");
		expecting(getStateMachineSession().remove("ConPageNo")).andReturn("");
		expecting(getStateMachineSession().remove(CONSTANTS.STAMPE_ID.getValue( ))).andReturn("");
		expecting(getStateMachineSession().remove("PageNo")).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("Indietro");
		expecting(getStateMachineSession().remove("BarCodeStack")).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getStateMachineSession().remove("SearchFrom")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Stack getStack()
	{
		Stack stack=new Stack();
		stack.push("1");
		return stack;
	}
}
