package it.sella.tracciabilitaplichi.executer.bustaventi.test.preparazione;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.bustaventi.preparazione.ShowPlichiExecuter;

import java.io.Serializable;
import java.util.List;
import java.util.Stack;

import junit.framework.TestCase;

public class ShowPlichiExecuterTest extends TestCase {
	
    RequestEvent requestEvent = null;
    StateMachineSession stateMachineSession = null; 
    
    public ShowPlichiExecuterTest( final String name ) {
        super( name );
    }

    @Override
	public void setUp( ) throws Exception {
        this.requestEvent = createMock( RequestEvent.class );
        this.stateMachineSession = createMock( StateMachineSession.class );
    }
    
    public void testShowPlichiExecuter_01( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.requestEvent.getAttribute( CONSTANTS.BARCODE.getValue( ) ) ).andReturn( "1234567890123" );
        final List stack = new Stack( );
        expect( this.stateMachineSession.get( CONSTANTS.BARCODE_STACK.getValue( ) ) ).andReturn( ( Serializable ) stack );
        expect( this.stateMachineSession.containsKey( CONSTANTS.BARCODE_STACK.getValue( ) ) ).andReturn( Boolean.TRUE );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        new ShowPlichiExecuter( ).execute( this.requestEvent );
        assertEquals( "1234567890123",stack.get( 0 ) ); 
    }
    
    public void testShowPlichiExecuter_02( ) {
        expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.stateMachineSession );
        expect( this.requestEvent.getAttribute( CONSTANTS.BARCODE.getValue( ) ) ).andReturn( "1234567890123" );
        expect( this.stateMachineSession.containsKey( CONSTANTS.BARCODE_STACK.getValue( ) ) ).andReturn( Boolean.FALSE );
        expect( this.stateMachineSession.put( CONSTANTS.BARCODE_STACK.getValue( ), new Stack( ) ) ).andReturn( new Stack( ) );
        replay( this.requestEvent );
        replay( this.stateMachineSession );
        final ExecuteResult actual = new ShowPlichiExecuter( ).execute( this.requestEvent );
        final ExecuteResult expected = ExecuteResultFactory.getInstance( ).getExecuteResult( );
        assertEquals( expected.getTransition( ), actual.getTransition( ) ); 
    }
    
    @Override
	public void tearDown( ) throws Exception {
    	requestEvent = null;
    	stateMachineSession = null; 
    }

}
