package it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione;

import it.sella.tracciabilitaplichi.executer.winbox2.AbstractExecuter;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.DeleteWinBox2Action;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;
import junit.framework.TestCase;

public class DeleteWinBox2ActionTest extends TestCase
{

    public void testGetLogger( )
    {
        final Log4Debug expected = Log4DebugFactory.getLog4Debug( DeleteWinBox2Action.class );
        final AbstractExecuter abstractExecuter = new DeleteWinBox2Action( );
        assertEquals(  expected.getClass( ), abstractExecuter.getLogger( ).getClass( ) );
    }

}
