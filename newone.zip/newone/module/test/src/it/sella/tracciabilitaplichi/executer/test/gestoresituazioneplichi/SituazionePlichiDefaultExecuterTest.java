package it.sella.tracciabilitaplichi.executer.test.gestoresituazioneplichi;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoresituazioneplichi.SituazionePlichiDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.log.LogEvent;
import mockit.Mockit;

public class SituazionePlichiDefaultExecuterTest extends
		AbstractSellaExecuterMock {

	final SituazionePlichiDefaultExecuter executer = new SituazionePlichiDefaultExecuter();

	public SituazionePlichiDefaultExecuterTest(final String name) {
		super(name);
	}

	public void testExecuter_01() {
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		expecting(getStateMachineSession().containsKey(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn(Boolean.TRUE).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testExecuter_02() {
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getStateMachineSession().containsKey(CONSTANTS.SEARCH_MAP.getValue( ))).andReturn(Boolean.FALSE).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
}
