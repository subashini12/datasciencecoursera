package it.sella.tracciabilitaplichi.executer.gestorecompatiblebanksadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;

public class CompatibleBanksCancelliConfermaExecuterTest extends AbstractSellaExecuterMock {

	public CompatibleBanksCancelliConfermaExecuterTest(final String name) {
		super(name);
	}

	CompatibleBanksCancelliConfermaExecuter executer = new CompatibleBanksCancelliConfermaExecuter();

	public void testExecuter_01() {
		TracciabilitaPlichiImplMock.setStatus();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("21").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TRPL-1057",executeResult.getAttribute(ITPConstants.MSG));
		assertEquals("yes",executeResult.getAttribute(ITPConstants.SUCCESS));
	}

	public void testExecuter_02() {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("21").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getAttribute(ITPConstants.MSG));
		assertEquals(null,executeResult.getAttribute(ITPConstants.SUCCESS));
	}

	public void testExecuter_03() {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("cbId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("bankId")).andReturn("21").anyTimes();
		expecting(getRequestEvent().getAttribute("otherBankId")).andReturn("21").anyTimes();
		setUpMockMethods(TracciabilitaPlichiManagerBean.class,TracciabilitaPlichiManagerBeanMock.class);
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getAttribute(ITPConstants.MSG));
		assertEquals(null,executeResult.getAttribute(ITPConstants.SUCCESS));
	}

}
