package it.sella.tracciabilitaplichi.executer.test.gestionesolleciti;

import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.ISEsitiConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.GestioneSollecitiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.IGestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TpMaEsitiView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ISEsitiConfermaExecuterTest extends AbstractSellaExecuterMock {
	private IGestioneSollecitiDataAccess igestioneSollecitiDataAccess = null;

	@Override
	public void setUp() throws Exception {
		super.setUp();
		igestioneSollecitiDataAccess = getMock(IGestioneSollecitiDataAccess.class);
		redefineMethod(TracciabilitaPlichiImpl.class, new Object() {
			public IGestioneSollecitiDataAccess getGestioneSollecitiDataAccess() {
				return igestioneSollecitiDataAccess;
			}
		});
		setUpMockMethods(GestioneSollecitiDataAccess.class, GestioneSollecitiDataAccessMock.class);
	}

	final ISEsitiConfermaExecuter ISEsitiConfermaExecuterTest = new ISEsitiConfermaExecuter();

	public ISEsitiConfermaExecuterTest(final String name) {
		super(name);
	}
/*
	public void testISEsitiConfermaExecuter_01() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn("").anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				new ArrayList());
		final List esiti = new ArrayList();
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION, esiti);
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});

		final ExecuteResult executeResult = ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}*/

	public void testISEsitiConfermaExecuter_02() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(null).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}

	/*public void testISEsitiConfermaExecuter_03() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] {}).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				new ArrayList());
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}*/

	public void testISEsitiConfermaExecuter_04() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "code" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "code", "desc", 22L,
				1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION, esiti);
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(esiti)
				.anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(esiti).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}

	/*public void testISEsitiConfermaExecuter_05() throws TracciabilitaException {
		setUpMockMethods(InvioSollecitiEsitiImpl.class, InvioSollecitiEsitiImplmock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "cde" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "code", "desc", 22L,
				1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION, esiti);
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(esiti)
				.anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(esiti).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		redefineMethod(TracciabilitaPlichiManagerBean.class, new Object() {
			public void cancelliOggetto(final Properties properties)
					throws TracciabilitaException, RemoteException {

			}
		});
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}

	public void testISEsitiConfermaExecuter_06() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "ram" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "ram", "desc", 22L, 1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		redefineMethod(TracciabilitaPlichiManagerBean.class, new Object() {
			public Long censitoOggetto(final Properties properties)
					throws TracciabilitaException, RemoteException {
				return 1L;
			}
		});
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}

	public void testISEsitiConfermaExecuter_07() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "ram" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "ram", "desc", 22L, 1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		redefineMethod(TracciabilitaPlichiManagerBean.class, new Object() {
			public Long censitoOggetto(final Properties properties)
					throws TracciabilitaException, RemoteException {
				throw new TracciabilitaException();
			}
		});
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}

	public void testISEsitiConfermaExecuter_08() throws TracciabilitaException {
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "ram" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "ram", "desc", 22L, 1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		redefineMethod(TracciabilitaPlichiManagerBean.class, new Object() {
			public Long censitoOggetto(final Properties properties)
					throws TracciabilitaException, RemoteException {
				throw new RemoteException();
			}
		});
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}
	
	public void testISEsitiConfermaExecuter_09() throws TracciabilitaException {
		TracciabilitaPlichiImplMock.setRemoteException();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "ram" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "ram", "desc", 22L, 1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		redefineMethod(TracciabilitaPlichiManagerBean.class, new Object() {
			public Long censitoOggetto(final Properties properties)
					throws TracciabilitaException, RemoteException {
				throw new RemoteException();
			}
		});
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}
	
	public void testISEsitiConfermaExecuter_10() throws TracciabilitaException {
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.SELECTED_ESITI))
				.andReturn(new String[] { "ram" }).anyTimes();
		final Map GESTIONE_SOLLECITI_MAP = new HashMap(1);
		final List esiti = new ArrayList();
		final TpMaEsitiView view = new TpMaEsitiView(1L, "ram", "desc", 22L, 1L);
		esiti.add(view);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_TIPO_CONTROLLO_COLLECTION,
				esiti);
		GESTIONE_SOLLECITI_MAP.put(ITPConstants.IS_ESITI_COLLECTION,
				new ArrayList());
		expecting(
				getStateMachineSession().get(
						ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(
				(Serializable) GESTIONE_SOLLECITI_MAP).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllEsiti()).andReturn(
				new ArrayList()).anyTimes();
		expecting(igestioneSollecitiDataAccess.getAllTipocontrollo())
				.andReturn(new ArrayList()).anyTimes();
		playAll();
		play(igestioneSollecitiDataAccess);
		redefineMethod(InvioSollecitiLogContent.class, new Object() {
			public String getLogXMLForEsiti() {
				return "";
			}
		});
		redefineMethod(TracciabilitaPlichiManagerBean.class, new Object() {
			public Long censitoOggetto(final Properties properties)
					throws TracciabilitaException, RemoteException {
				throw new RemoteException();
			}
		});
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		ISEsitiConfermaExecuterTest
				.execute(getRequestEvent());
	}*/
}
