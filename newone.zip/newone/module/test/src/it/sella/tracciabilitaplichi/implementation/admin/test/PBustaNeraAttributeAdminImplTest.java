/*package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.msg.MsgManager;
import it.sella.tracciabilitaplichi.implementation.admin.PBustaNeraAttributeAdminImpl;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.PBustaNeraAttributeView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.Date;
import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

public class PBustaNeraAttributeAdminImplTest extends BasicJDBCTestCaseAdapter {

	PBustaNeraAttributeAdminImpl pBustaNeraAttributeAdminImpl = new PBustaNeraAttributeAdminImpl();

	public void testCensitoOggetto_01() throws SQLException {
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("PBN_ID", new Object[] { "1" });
		result.addColumn("PBN_DOC_ID", new Object[] { "1" });
		result.addColumn("PBN_DATE", new Object[] { "1" });
		result.addColumn("PBN_DESC", new Object[] { "1" });
		result.addColumn("PBN_IMPORTO", new Object[] { "1" });
		result.addColumn("PBN_NOTE", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		final PBustaNeraAttributeView pBustaNeraAttributeView = getPBustaNeraAttributeView();
		try {
			pBustaNeraAttributeAdminImpl
					.censitoOggetto(pBustaNeraAttributeView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}
	}

	public void testModificaOggetto_01() throws SQLException {
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("PBN_ID", new Object[] { "1" });
		result.addColumn("PBN_DOC_ID", new Object[] { "1" });
		result.addColumn("PBN_DATE", new Object[] { "1" });
		result.addColumn("PBN_DESC", new Object[] { "1" });
		result.addColumn("PBN_IMPORTO", new Object[] { "1" });
		result.addColumn("PBN_NOTE", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		final PBustaNeraAttributeView pBustaNeraAttributeView = getPBustaNeraAttributeView();
		try {
			pBustaNeraAttributeAdminImpl
					.modificaOggetto(pBustaNeraAttributeView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally {
			connection.close();
		}
	}

	public void testCancelliOggetto_01() throws SQLException {
		Mockit.setUpMock(MsgManagerWrapper.class, MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("PBN_ID", new Object[] { "1" });
		result.addColumn("PBN_DOC_ID", new Object[] { "1" });
		result.addColumn("PBN_DATE", new Object[] { "1" });
		result.addColumn("PBN_DESC", new Object[] { "1" });
		result.addColumn("PBN_IMPORTO", new Object[] { "1" });
		result.addColumn("PBN_NOTE", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		final PBustaNeraAttributeView pBustaNeraAttributeView = getPBustaNeraAttributeView();
		try {
			pBustaNeraAttributeAdminImpl
					.cancelliOggetto(pBustaNeraAttributeView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally {
			connection.close();
		}
	}

	private PBustaNeraAttributeView getPBustaNeraAttributeView() {
		final PBustaNeraAttributeView pBustaNeraAttributeView = new PBustaNeraAttributeView();
		final Date date = new Date(2011, 10, 20);
		pBustaNeraAttributeView.setDate(date);
		pBustaNeraAttributeView.setDescription("");
		pBustaNeraAttributeView.setDocId(1L);
		pBustaNeraAttributeView.setId(1L);
		pBustaNeraAttributeView.setImporto("");
		pBustaNeraAttributeView.setNote("Note");
		return pBustaNeraAttributeView;
	}

}*/