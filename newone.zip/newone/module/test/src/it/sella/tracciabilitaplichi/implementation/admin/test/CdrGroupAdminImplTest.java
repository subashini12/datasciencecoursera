/*package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.msg.MsgManager;
import it.sella.tracciabilitaplichi.implementation.admin.CdrGroupAdminImpl;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CdrGroupView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class CdrGroupAdminImplTest extends BasicJDBCTestCaseAdapter {

	CdrGroupAdminImpl cdrGroupAdminImpl=new CdrGroupAdminImpl();
	
	
	
	public void testCensitoOggetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CG_ID", new Object[] { "1" });
		result.addColumn("CG_CDR", new Object[] { "1" });
		result.addColumn("CG_GROUP", new Object[] { "1" });
		result.addColumn("CG_BANK", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			cdrGroupAdminImpl.censitoOggetto(getCdrGroupView());
		} catch (final TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	
	public void testCancelliOggetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CG_ID", new Object[] { "1" });
		result.addColumn("CG_CDR", new Object[] { "1" });
		result.addColumn("CG_GROUP", new Object[] { "1" });
		result.addColumn("CG_BANK", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			cdrGroupAdminImpl.cancelliOggetto(getCdrGroupView());
		} catch (final TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testModificaOggetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("CG_ID", new Object[] { "1" });
		result.addColumn("CG_CDR", new Object[] { "1" });
		result.addColumn("CG_GROUP", new Object[] { "1" });
		result.addColumn("CG_BANK", new Object[] { "1" });
		statementHandler.prepareGlobalResultSet(result);
		try {
			cdrGroupAdminImpl.modificaOggetto(getCdrGroupView());
		} catch (final TracciabilitaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	private CdrGroupView getCdrGroupView()
	{
		final CdrGroupView cdrGroupView=new CdrGroupView();
		cdrGroupView.setGroup("");
		cdrGroupView.setCdr("099213");
		cdrGroupView.setId(1L);
		return cdrGroupView;
	}
}*/