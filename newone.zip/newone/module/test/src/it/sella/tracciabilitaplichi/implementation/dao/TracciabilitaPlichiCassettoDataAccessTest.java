package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaDataAccessException;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

import java.rmi.RemoteException;
import java.util.Collection;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class TracciabilitaPlichiCassettoDataAccessTest
{
	TracciabilitaPlichiCassettoDataAccess dataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		dataAccess = new TracciabilitaPlichiCassettoDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		dataAccess = null;
	}

	@Test
	public void listaLinkedCassettoView4Cassetto_01( ) throws TracciabilitaDataAccessException, RemoteException
	{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		mockStatementProvider = new MockStatementProvider(" SELECT LC_ID, LC_CDR, LC_CASETTO, LC_BANK_ID, LC_DESCRIPTION, LC_PRINCIPALE_ID FROM TP_MA_LINKED_CASETTO WHERE LC_CASETTO = ? AND LC_BANK_ID = ? ");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 1,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 2,"CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 3,"CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 4,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 5,"CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 6,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection collection = dataAccess.listaLinkedCassettoView4Cassetto("12",null);
		Assert.assertEquals(1, collection.size());
	}

	@Test(expected=TracciabilitaDataAccessException.class)
	public void listaLinkedCassettoView4Cassetto_02( ) throws TracciabilitaDataAccessException, RemoteException
	{
		Mockit.setUpMock(TPUtil.class,TPUtilMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(" SELECT LC_ID, LC_CDR, LC_CASETTO, LC_BANK_ID, LC_DESCRIPTION, LC_PRINCIPALE_ID FROM TP_MA_LINKED_CASETTO WHERE LC_CASETTO = ? AND LC_BANK_ID = ? ");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 1,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 2,"CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 3,"CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 4,2l);
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 5,"CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 6,2l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		dataAccess.listaLinkedCassettoView4Cassetto(null,"1");
	}


	@Test
	public void getLinkedCasettoView( ) throws TracciabilitaDataAccessException
	{
		mockStatementProvider = new MockStatementProvider(" SELECT LC_CDR, LC_CASETTO, LC_BANK_ID FROM TP_MA_LINKED_CASETTO WHERE LC_ID = ? ");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 0, "LC_CDR","CDR");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, "LC_CASETTO","CASETTO");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 2, "LC_BANK_ID",1l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final LinkedCasettoView linkedCasettoView = dataAccess.getLinkedCasettoView(1l);
		Assert.assertEquals("CDR",linkedCasettoView.getCdr() );
	}

	@Test
	public void getCasettoDescForCasetto( ) throws TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider("SELECT  DISTINCT LC_DESCRIPTION FROM TP_MA_LINKED_CASETTO WHERE LC_CASETTO = ?");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.VARCHAR, 1, 1,"DESCRIPTION");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final String descr = dataAccess.getCasettoDescForCasetto("123");
		Assert.assertEquals("DESCRIPTION",descr );

	}
	@Test
	public void getPrincipaleIdForCasetto_01( ) throws TracciabilitaException
	{
		mockStatementProvider = new MockStatementProvider("SELECT DISTINCT LC.LC_PRINCIPALE_ID FROM TP_MA_LINKED_CASETTO LC WHERE LC.LC_CASETTO = ? ");
		mockStatementProvider.setPreparedStatementResultSet(
				java.sql.Types.NUMERIC, 1, 1,12l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection<Long> principaleIdForCasetto = dataAccess.getPrincipaleIdForCasetto("123");
		Assert.assertEquals(1, principaleIdForCasetto.size());

	}
}
