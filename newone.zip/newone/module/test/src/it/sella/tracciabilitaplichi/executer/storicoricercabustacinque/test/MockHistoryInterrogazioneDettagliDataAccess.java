package it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.test;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;


public class MockHistoryInterrogazioneDettagliDataAccess {
	@Mock
	public Collection getRicercaView( final java.sql.Date datacomp, final String searchKey, final String searchType ) throws TracciabilitaException, RemoteException
	{
		final Collection  col = new ArrayList();
		return col;
	}
}
