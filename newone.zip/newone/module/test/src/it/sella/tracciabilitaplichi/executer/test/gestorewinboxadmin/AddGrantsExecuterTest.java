package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.AddGrantsExecuter;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.winbox2.preparazione.GrantsValidator;
import it.sella.tracciabilitaplichi.executer.winbox2.test.preparazione.GrantsValidatorMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;
import mockit.Mockit;

public class AddGrantsExecuterTest extends AbstractSellaExecuterMock 
{
	
	final AddGrantsExecuter addGrantExecuter = new AddGrantsExecuter();

	public AddGrantsExecuterTest(final String name) 
	{
		super(name);
	}
	public void testAddGrantsExecuter_forSuccessCase()
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(GrantsValidator.class, GrantsValidatorMock.class);
		expecting( getRequestEvent().getAttribute(CONSTANTS.CDR.getValue( ))).andReturn("0").anyTimes();
		playAll();
		addGrantExecuter.execute(getRequestEvent());		
	}
	public void testAddGrantsExecuter_forTracciabilitaException()
	{
		GrantsValidatorMock.setTracciabilitaException();
		Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		setUpMockMethods(GrantsValidator.class, GrantsValidatorMock.class);
		expecting( getRequestEvent().getAttribute(CONSTANTS.CDR.getValue( ))).andReturn("0").anyTimes();
		playAll();
		addGrantExecuter.execute(getRequestEvent());
	}
	
	
}
