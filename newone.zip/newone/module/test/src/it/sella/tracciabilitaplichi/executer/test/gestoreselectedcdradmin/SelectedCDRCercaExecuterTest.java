package it.sella.tracciabilitaplichi.executer.test.gestoreselectedcdradmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestoreselectedcdradmin.SelectedCDRCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.admin.SelectedCDRAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.admin.SelectedCDRAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectedCDRCercaExecuterTest extends AbstractSellaExecuterMock {

	SelectedCDRCercaExecuter selectedCDRCercaExecuter = new SelectedCDRCercaExecuter();

	public SelectedCDRCercaExecuterTest(final String name) {
		super(name);
	}

	public void testSelectedCDRCercaExecuter_01() {
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		final Map bancaMap = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("037837")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) bancaMap).anyTimes();		
		playAll();
		final ExecuteResult executeResult = selectedCDRCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("MESSAGE"), "TRPL-1379");
	}

	public void testSelectedCDRCercaExecuter_02() {
		setUpMockMethods( SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class );
		final Map bancaMap = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("037837")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) bancaMap).anyTimes();
		final List list = new ArrayList();
		list.add("add list");
		playAll();
		final ExecuteResult executeResult = selectedCDRCercaExecuter
				.execute(getRequestEvent());
	}

	public void testSelectedCDRCercaExecuter_03() {
		final Map bancaMap = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("34?")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) bancaMap).anyTimes();
		playAll();
		final ExecuteResult executeResult = selectedCDRCercaExecuter
				.execute(getRequestEvent());
		assertEquals(executeResult.getAttribute("MESSAGE"), "TRPL-1399");
	}

	public void testSelectedCDRCercaExecuter_04() {
		final Map bancaMap = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("037837")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) bancaMap).anyTimes();
		final List list = new ArrayList();
		list.add("add list");
		redefineMethod(SelectedCDRAdminImpl.class, new Object() {
			public Collection search(
					final TpMaSelectedCdrView tpMaSelectedCdrView)
					throws TracciabilitaException {
				throw new TracciabilitaException();
			}
		});
		playAll();
		final ExecuteResult executeResult = selectedCDRCercaExecuter
				.execute(getRequestEvent());
	}

	public void testSelectedCDRCercaExecuter_05() {
		SelectedCDRAdminImplMock.setCollection() ;
		setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		final Map bancaMap = new HashMap();
		expecting(getRequestEvent().getAttribute("scCdr")).andReturn("037837")
				.anyTimes();
		expecting(getRequestEvent().getAttribute("scBankId")).andReturn(
				"scBankId").anyTimes();
		expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn(
				(Serializable) bancaMap).anyTimes();
		playAll();
		final ExecuteResult executeResult = selectedCDRCercaExecuter
				.execute(getRequestEvent());
	}
	
}
