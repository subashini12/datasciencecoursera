package it.sella.tracciabilitaplichi.executer.ricezioneplichi.processor;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.ExecuteResultFactory;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.processor.RicezionePlichiProcessor;
import it.sella.tracciabilitaplichi.processor.mock.RicezionePlichiProcessorMock;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;

public class RicezionePlichiConfermaFinalProcessorTest extends
		AbstractSellaExecuterMock {

	public RicezionePlichiConfermaFinalProcessorTest(final String name) {
		super(name);
	}

	RicezionePlichiConfermaFinalProcessor processor = new RicezionePlichiConfermaFinalProcessor();

	public void testRicezionePlichiConfermaFinalProcessor_01() {
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		final ExecuteResult executeResult = ExecuteResultFactory.getInstance().getExecuteResult( "TrFail" );
		setUpMockMethods(RicezionePlichiProcessor.class, RicezionePlichiProcessorMock.class);
		try {
			processor.processPlichiView(getHashMap(), executeResult , getArrayList());
		} catch (final RemoteException e) {
			e.printStackTrace();
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
	}
	
	private HashMap getHashMap()
	{
		final HashMap hashMap = new HashMap() ;
		hashMap.put("PageNoRP","");
		hashMap.put("IsArchivoDept","");
		hashMap.put("IsBarCodeReaderAvailable","Yes");
		hashMap.put("TypesOfOggettos","");
		return hashMap ;
	}
	
	private ArrayList getArrayList()
	{
		final ArrayList arrayList = new ArrayList() ;
		arrayList.add(getTracciabilitaPlichiView());
		return arrayList ;
	}
	
	private TracciabilitaPlichiView getTracciabilitaPlichiView()
	{
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView();
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		return tracciabilitaPlichiView ;
	}
	
	private OggettoView getOggettoView()
	{
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setCausale(null);
		oggettoView.setOggettoType(1L);
		oggettoView.setStatusId(1L);
		oggettoView.setStatusType(null);
		return oggettoView ;
	}
	
	
}
