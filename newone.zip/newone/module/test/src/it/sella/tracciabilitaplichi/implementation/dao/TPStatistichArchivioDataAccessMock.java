package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.StatisticheDiInviareView;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

import mockit.Mock;

public class TPStatistichArchivioDataAccessMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;
	private static Boolean isNullResponsible = false;
	private static Boolean isStatisticheDiInviareViewCollNull = false;

	public static void setNullResponsible() {
		isNullResponsible = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}
	public static void setStatisticheDiInviareViewCollAsNull() {
		isStatisticheDiInviareViewCollNull  = true;
	}

	@Mock
	public Integer getStatisticheDiPreparatiBusta5(final String preparatiFromDate,
			final String preparatiTillDate, final String ricezioneFromD1ate,
			final String ricezioneTillDate) throws TracciabilitaException,
			RemoteException {
		return new Integer("1");
	}

	@Mock
	public Integer getStatisticheDiPreparatiPBusta5(final String preparatiFromDate,
			final String preparatiTillDate, final String ricezioneFromDate,
			final String ricezioneTillDate) throws TracciabilitaException,
			RemoteException {
		return new Integer("1");
	}

	@Mock
	public Integer getStatisticheDiRicezioneBusta5(final String preparatiFromDate,
			final String preparatiTillDate, final String ricezioneFromDate,
			final String ricezioneTillDate) throws TracciabilitaException,
			RemoteException {
		return new Integer("1");
	}

	@Mock
	public Integer getStatisticheDiRicezionePBusta5(final String preparatiFromDate,
			final String preparatiTillDate, final String ricezioneFromDate,
			final String ricezioneTillDate) throws TracciabilitaException,
			RemoteException {
		return new Integer("1");
	}

	@Mock
	public String getResponsibile(final String cdr) throws TracciabilitaException,
			RemoteException {
		String department = "099239";
		if (isNullResponsible) {
			isNullResponsible = false;
			department = null;
		}
		return department;

	}

	@Mock
	public Collection listPendingLids(final String cdr, final String fromDate,
			final String tillDate) throws TracciabilitaException, RemoteException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		final Date date = new Date("2011,jan,9");
		final Timestamp timeStamp = new Timestamp(date.getDate());
		final Vector vector = new Vector();
		final Vector bustaViewColl = new Vector();
		final OggettoView oggettoView = new OggettoView();
		oggettoView.setBankDescription("BankDescription");
		oggettoView.setBankId(1L);
		oggettoView.setOggettoDate(timeStamp);
		bustaViewColl.add(oggettoView);
		final Vector plichiBustaColl = new Vector();
		final OggettoView oggettoView1 = new OggettoView();
		oggettoView1.setBankDescription("BankDescription");
		oggettoView1.setBankId(1L);
		oggettoView1.setOggettoDate(timeStamp);
		plichiBustaColl.add(oggettoView1);
		vector.add(bustaViewColl);
		vector.add(plichiBustaColl);
		return vector;
	}
	
	@Mock
	
	public Collection getListStatisticheDiPreparatiBusta5( final String preparatiFromDate, final String preparatiTillDate, final String ricezioneFromD1ate, final String ricezioneTillDate ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final Collection collection=new ArrayList();
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setCdrName("");
		final Date date = new Date("2012,jan,9");
		final Timestamp oggettoDate = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(oggettoDate);
		oggettoView.setUserId("");
		oggettoView.setStatusId(1L);
		collection.add(oggettoView);
		return collection;
	}
	
	@Mock 
	
	public Collection getListStatisticheDiPreparatiPBusta5( final String preparatiFromDate, final String preparatiTillDate, final String ricezioneFromDate, final String ricezioneTillDate ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final Collection collection=new ArrayList();
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setCdrName("");
		final Date date = new Date("2012,jan,9");
		final Timestamp oggettoDate = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(oggettoDate);
		oggettoView.setUserId("");
		oggettoView.setStatusId(1L);
		collection.add(oggettoView);
		return collection;
	}
	
	@Mock
	
	public Collection getListStatisticheDiRicezioneBusta5( final String preparatiFromDate, final String preparatiTillDate, final String ricezioneFromDate, final String ricezioneTillDate ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final Collection collection=new ArrayList();
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setCdrName("");
		final Date date = new Date("2012,jan,9");
		final Timestamp oggettoDate = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(oggettoDate);
		oggettoView.setUserId("");
		oggettoView.setStatusId(1L);
		collection.add(oggettoView);
		return collection;
	}
	
	@Mock
	
	public Collection getListStatisticheDiRicezionePBusta5( final String preparatiFromDate, final String preparatiTillDate, final String ricezioneFromDate, final String ricezioneTillDate ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		final Collection collection=new ArrayList();
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setCdrName("");
		final Date date = new Date("2012,jan,9");
		final Timestamp oggettoDate = new Timestamp(date.getDate());
		oggettoView.setOggettoDate(oggettoDate);
		oggettoView.setUserId("");
		oggettoView.setStatusId(1L);
		collection.add(oggettoView);
		return collection;
	}
	@Mock
	public Collection getStatisticheDiInviareViewColl( final String fromDate, final String tillDate ) throws TracciabilitaException, RemoteException
	{
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
		if (remoteException) {
			remoteException = false;
			throw new RemoteException();
		}
		Vector statisticheDiInviareViewColl = new Vector();
		final Hashtable htstatisticheDiInviareViewColl = new Hashtable();
		final StatisticheDiInviareView statisticheDiInviareView1 = new StatisticheDiInviareView();
		statisticheDiInviareView1.setCdr( "099231" );
		statisticheDiInviareView1.setCdrDesc( "IT-Generali" );
		final StatisticheDiInviareView statisticheDiInviareView2 = new StatisticheDiInviareView();
		statisticheDiInviareView2.setCdr( "099921" );
		statisticheDiInviareView2.setCdrDesc( "IT-Generalia" );
		final StatisticheDiInviareView statisticheDiInviareView3 = new StatisticheDiInviareView();
		statisticheDiInviareView3.setCdr( "099666" );
		statisticheDiInviareView3.setCdrDesc( "IT-Generalib" );
		final StatisticheDiInviareView statisticheDiInviareView4 = new StatisticheDiInviareView();
		statisticheDiInviareView4.setCdr( "099222" );
		statisticheDiInviareView4.setCdrDesc( "IT-Generalib" );
		final StatisticheDiInviareView statisticheDiInviareView5 = new StatisticheDiInviareView();
		statisticheDiInviareView5.setCdr( "099333" );
		statisticheDiInviareView5.setCdrDesc( "IT-Generalid" );
		htstatisticheDiInviareViewColl.put("099231",statisticheDiInviareView1);
		htstatisticheDiInviareViewColl.put("099921",statisticheDiInviareView2);
		htstatisticheDiInviareViewColl.put("099666",statisticheDiInviareView3);
		htstatisticheDiInviareViewColl.put("099222",statisticheDiInviareView4);
		htstatisticheDiInviareViewColl.put("099333",statisticheDiInviareView5);
		statisticheDiInviareViewColl.add(htstatisticheDiInviareViewColl.get(1));
		statisticheDiInviareViewColl.add(htstatisticheDiInviareViewColl.get(2));
		statisticheDiInviareViewColl.add(htstatisticheDiInviareViewColl.get(3));
		statisticheDiInviareViewColl.add(htstatisticheDiInviareViewColl.get(4));
		statisticheDiInviareViewColl.add(htstatisticheDiInviareViewColl.get(5));
		if(isStatisticheDiInviareViewCollNull){
			isStatisticheDiInviareViewCollNull  = false;
			statisticheDiInviareViewColl = null;
		}
		return statisticheDiInviareViewColl;
	}
}
