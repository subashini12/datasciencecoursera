/*package it.sella.tracciabilitaplichi.executer.gestorecassetto;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.admin.LinkedCasettoAdminImpl;
import it.sella.tracciabilitaplichi.implementation.admin.LinkedCasettoAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactory;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ExternalServicesFactoryMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.MsgManagerWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.MsgManagerWrapperMock;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import mockit.Mockit;

public class CDRConfermaExecuterTest extends AbstractSellaExecuterTest {

	public CDRConfermaExecuterTest(final String name) {
		super(name);
	}

	CDRConfermaExecuter cdrConfermaExecuter = new CDRConfermaExecuter();

	public void testCDRConfermaExecuter_01() {
		TracciabilitaPlichiImplMock.setBusta20();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(LinkedCasettoAdminImpl.class,LinkedCasettoAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final Collection cdrCollection = new ArrayList();
		cdrCollection.add("099231");
		cdrCollection.add("099231");
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) getLinkedCassettoCollection()).anyTimes();
		expecting(getStateMachineSession().get("collCDRElimina")).andReturn((Serializable) cdrCollection).anyTimes();
		expecting(getStateMachineSession().get("collCDRInserisci")).andReturn((Serializable) cdrCollection).anyTimes();
		expecting(getRequestEvent().getAttribute("bankid")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = cdrConfermaExecuter.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public void testCDRConfermaExecuter_02() {
		LinkedCasettoAdminImplMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiImpl.class, TracciabilitaPlichiImplMock.class);
		setUpMockMethods(LinkedCasettoAdminImpl.class,LinkedCasettoAdminImplMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final Collection cdrCollection = new ArrayList();
		cdrCollection.add("099231");
		cdrCollection.add("099231");
		expecting(getStateMachineSession().get("collLinkedCassetto")).andReturn((Serializable) getLinkedCassettoCollection()).anyTimes();
		expecting(getStateMachineSession().get("collCDRElimina")).andReturn((Serializable) cdrCollection).anyTimes();
		expecting(getStateMachineSession().get("collCDRInserisci")).andReturn((Serializable) cdrCollection).anyTimes();
		expecting(getRequestEvent().getAttribute("bankid")).andReturn("1").anyTimes();
		playAll();
		final ExecuteResult executeResult = cdrConfermaExecuter.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}

	public Collection<LinkedCasettoView> getLinkedCassettoCollection() {
		final LinkedCasettoView linkedCasettoView = new LinkedCasettoView();
		linkedCasettoView.setBankId(2L);
		linkedCasettoView.setCdr("");
		final Collection<LinkedCasettoView> linkedCassettoColl = new ArrayList<LinkedCasettoView>();
		return linkedCassettoColl;
	}

}
 */