package it.sella.tracciabilitaplichi.executer.test.gestorealtriattributeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorealtriattributeadmin.AltriAttributeCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Hashtable;

public class AltriAttributeCercaExecuterTest  extends AbstractSellaExecuterMock {
	
	AltriAttributeCercaExecuter altriAttributeCercaExecuterTest =  new AltriAttributeCercaExecuter(); 
	public AltriAttributeCercaExecuterTest(final String name) {
		super(name);
	}

	 public void testAltriAttributeCercaExecuter_01(){
		expecting(getStateMachineSession().containsKey("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
		expecting(getStateMachineSession().get("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
		final Hashtable altriAttributeHashtable = new Hashtable();
		expecting(getStateMachineSession().put("AltriTable",  altriAttributeHashtable)).andReturn(altriAttributeHashtable).anyTimes();
		playAll();
		final ExecuteResult executeResult = altriAttributeCercaExecuterTest.execute(getRequestEvent());
		assertEquals(true ,executeResult.getAttribute("AltriTable") );
	} 

	 public void testAltriAttributeCercaExecuter_02(){
			expecting(getStateMachineSession().containsKey("AltriTable")).andReturn(Boolean.FALSE).anyTimes();
			expecting(getStateMachineSession().get("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("id").anyTimes();
			final Hashtable altriAttributeHashtable = new Hashtable();
			expecting(getStateMachineSession().put("AltriTable",  altriAttributeHashtable)).andReturn(altriAttributeHashtable).anyTimes();
			playAll();
			final ExecuteResult executeResult = altriAttributeCercaExecuterTest.execute(getRequestEvent());
			assertEquals("TRPL-1060" ,executeResult.getAttribute("MSG") );
		} 
	 
	 public void testAltriAttributeCercaExecuter_03(){
			expecting(getStateMachineSession().containsKey("AltriTable")).andReturn(Boolean.FALSE).anyTimes();
			expecting(getStateMachineSession().get("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
			final Hashtable altriAttributeHashtable = new Hashtable();
			expecting(getStateMachineSession().put("AltriTable",  altriAttributeHashtable)).andReturn(altriAttributeHashtable).anyTimes();
			playAll();
			final ExecuteResult executeResult = altriAttributeCercaExecuterTest.execute(getRequestEvent());
			assertEquals("TRPL-1059" ,executeResult.getAttribute("MSG") );
		} 
	 
	/* public void testAltriAttributeCercaExecuter_04(){
			expecting(getStateMachineSession().containsKey("AltriTable")).andReturn(Boolean.FALSE).anyTimes();
			expecting(getStateMachineSession().get("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("5698").anyTimes();
			Hashtable altriAttributeHashtable = new Hashtable();
			final AltriAttributeView altriAttributeView = new AltriAttributeView();
			redefineMethod(TracciabilitaPlichiAdminTransactionDataAccess.class,new Object(){
				@Mock
				public AltriAttributeView getAltriAttributeView( long id ) throws TracciabilitaException {
					return altriAttributeView ;
				}
			});
			altriAttributeHashtable.put( "OldAltriAttributeView", altriAttributeView );
			altriAttributeHashtable.put( "NewAltriAttributeView", altriAttributeView );
			expecting(getStateMachineSession().put("AltriTable",  altriAttributeHashtable)).andReturn(altriAttributeHashtable).anyTimes();
			playAll();
			ExecuteResult executeResult = altriAttributeCercaExecuterTest.execute(getRequestEvent());
			//assertEquals(altriAttributeHashtable ,executeResult.getAttribute("AltriTable") );
		}
	 
	 public void testAltriAttributeCercaExecuter_06(){
			expecting(getStateMachineSession().containsKey("AltriTable")).andReturn(Boolean.FALSE).anyTimes();
			expecting(getStateMachineSession().get("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("5698").anyTimes();
			Hashtable altriAttributeHashtable = new Hashtable();
			final AltriAttributeView altriAttributeView = new AltriAttributeView();
			redefineMethod(TracciabilitaPlichiAdminTransactionDataAccess.class,new Object(){
				@Mock
				public AltriAttributeView getAltriAttributeView( long id ) throws TracciabilitaException {
					throw new TracciabilitaException();
				}
			});
			altriAttributeHashtable.put( "OldAltriAttributeView", altriAttributeView );
			altriAttributeHashtable.put( "NewAltriAttributeView", altriAttributeView );
			expecting(getStateMachineSession().put("AltriTable",  altriAttributeHashtable)).andReturn(altriAttributeHashtable).anyTimes();
			playAll();
			ExecuteResult executeResult = altriAttributeCercaExecuterTest.execute(getRequestEvent());
			assertEquals("it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException" ,executeResult.getException().toString());
		} 

	 public void testAltriAttributeCercaExecuter_05(){
			expecting(getStateMachineSession().containsKey("AltriTable")).andReturn(Boolean.FALSE).anyTimes();
			expecting(getStateMachineSession().get("AltriTable")).andReturn(Boolean.TRUE).anyTimes();
			expecting(getRequestEvent().getAttribute("ID")).andReturn("5698").anyTimes();
			Hashtable altriAttributeHashtable = new Hashtable();
			final AltriAttributeView altriAttributeView = new AltriAttributeView();
			redefineMethod(TracciabilitaPlichiAdminTransactionDataAccess.class,new Object(){
				@Mock
				public AltriAttributeView getAltriAttributeView( long id ) throws TracciabilitaException {
					return altriAttributeView ;
				}
			});
			redefineMethod(TracciabilitaPlichiFactory.class,new Object(){@Mock
				public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException {
				throw new RemoteException();
			}
			});
			altriAttributeHashtable.put( "OldAltriAttributeView", altriAttributeView );
			altriAttributeHashtable.put( "NewAltriAttributeView", altriAttributeView );
			expecting(getStateMachineSession().put("AltriTable",  altriAttributeHashtable)).andReturn(altriAttributeHashtable).anyTimes();
			playAll();
			ExecuteResult executeResult = altriAttributeCercaExecuterTest.execute(getRequestEvent());
			assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );
		} */

}
