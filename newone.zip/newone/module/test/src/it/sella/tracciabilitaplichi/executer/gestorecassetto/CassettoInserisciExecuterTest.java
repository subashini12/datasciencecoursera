package it.sella.tracciabilitaplichi.executer.gestorecassetto;


import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCassettoDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCassettoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;

import java.util.Map;

public class CassettoInserisciExecuterTest extends AbstractSellaExecuterMock {

	public CassettoInserisciExecuterTest(final String name) {
		super(name);
	}

	CassettoInserisciExecuter executer=new CassettoInserisciExecuter();
	
	public void testCassettoInserisciExecuter_12() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
		final Map map=(Map) executeResult.getAttribute("mapCassettoMain");
		assertEquals("C099699", map.get("codiceCassetto"));
		assertEquals("GBS RACCOLTA", map.get("descrizioneCassetto"));
		assertEquals("6692", map.get("centroDiAppartenenza"));
		assertEquals("1", map.get("codiceCDR"));
	}
	
	public void testCassettoInserisciExecuter_11() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("000").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCassettoInserisciExecuter_10() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("099699").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoInserisciExecuter_09() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1483455").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoInserisciExecuter_01() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
		final Map map=(Map) executeResult.getAttribute("mapCassettoMain");
		assertEquals("", map.get("codiceCassetto"));
		assertEquals("", map.get("descrizioneCassetto"));
		assertEquals("", map.get("centroDiAppartenenza"));
		assertEquals("", map.get("codiceCDR"));
	}

	public void testCassettoInserisciExecuter_02() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("099699").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
		final Map map=(Map) executeResult.getAttribute("mapCassettoMain");
		assertEquals("C099699", map.get("codiceCassetto"));
		assertEquals("", map.get("descrizioneCassetto"));
		assertEquals("6692", map.get("centroDiAppartenenza"));
		assertEquals("099699", map.get("codiceCDR"));
	}
	
	public void testCassettoInserisciExecuter_03() {
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("-1").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("099699").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1483455").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
		final Map map=(Map) executeResult.getAttribute("mapCassettoMain");
		assertEquals("C099699", map.get("codiceCassetto"));
		assertEquals("GBS RACCOLTA", map.get("descrizioneCassetto"));
		assertEquals("-1", map.get("centroDiAppartenenza"));
		assertEquals("099699", map.get("codiceCDR"));
	}
	
	public void testCassettoInserisciExecuter_04() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1483455").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoInserisciExecuter_05() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("1483455").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoInserisciExecuter_06() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("C099699").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("GBS RACCOLTA").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("6692").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("099699").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCassettoInserisciExecuter_07() {
		setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}
	
	public void testCassettoInserisciExecuter_08() {
		setUpMockMethods(TracciabilitaPlichiCassettoDataAccess.class, TracciabilitaPlichiCassettoDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("codiceCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("descrizioneCassetto")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("centroDiAppartenenza")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("codiceCDR")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("SelectedBankId")).andReturn("-1").anyTimes();
		playAll();
		final ExecuteResult executeResult=executer.execute(getRequestEvent());
		assertEquals("TrError", executeResult.getTransition());
	}

}
