package it.sella.tracciabilitaplichi.executer.eliminabustadeici;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor.HomePageProcessorMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;

import java.util.Hashtable;
import java.util.Map;

import org.easymock.EasyMock;


public class EliminaDefaultPageExecuterTest extends AbstractSellaExecuterMock{

	public EliminaDefaultPageExecuterTest(final String name) {
		super(name);
	}

	EliminaDefaultPageExecuter executer = new EliminaDefaultPageExecuter() ;
	
	public void testEliminaDefaultPageExecuter_01() {
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class,TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);	
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), "TrConferma");
	}
	
	public void testEliminaDefaultPageExecuter_02() {
		TracciabilitaPlichiStatusDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class,TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);	
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(),null);
	}
	

	public void testEliminaDefaultPageExecuter_03() {
		TPContrattiProdottoDataAccessMock.setRemoteException();
		TracciabilitaPlichiStatusDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class,TPContrattiProdottoDataAccessMock.class);
		setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);	
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Hashtable) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(executeResult.getTransition(), null);
	}
	
}
