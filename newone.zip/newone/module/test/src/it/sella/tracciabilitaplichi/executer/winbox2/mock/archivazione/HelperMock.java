package it.sella.tracciabilitaplichi.executer.winbox2.mock.archivazione;

import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.HistoryView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.persistence.dto.Folder;
import it.sella.tracciabilitaplichi.persistence.dto.FolderAttributes;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;
import it.sella.tracciabilitaplichi.winbox2.archivazione.Winbox2InputProcessor;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class HelperMock {
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;
	private static Boolean isMapWithTrWBX2PartialConferma = false;
	private static Boolean isMapWithOutWINBOX2INPUTPROCESSOR = false;
	private static Boolean isMapWithWINBOX2INPUTPROCESSOR = false;

	public static void setMapWithWINBOX2INPUTPROCESSOR() {
		isMapWithWINBOX2INPUTPROCESSOR = true;
	}

	public static void setMapWithOutWINBOX2INPUTPROCESSOR() {
		isMapWithOutWINBOX2INPUTPROCESSOR = true;
	}

	public static void setMapWithTrWBX2PartialConferma() {
		isMapWithTrWBX2PartialConferma = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setRemoteException() {
		remoteException = true;
	}

	/*
	 * @Mock public static Map getMapControlloFromCache() throws
	 * TracciabilitaException, RemoteException { if(tracciabilitaException) {
	 * tracciabilitaException=false; throw new TracciabilitaException(); }
	 * if(remoteException) { remoteException=false; throw new RemoteException();
	 * } Map map=new HashMap();
	 * 
	 * return map; }
	 */
	@Mock
	public static Map getArchivioSessionMap(final StateMachineSession session) {
		Map map = null;
		final Map<String, Collection<Folder>> folderMap = new HashMap<String, Collection<Folder>>();
		final Folder folder = new Folder() ;
		final OggettoView oggettoView = new OggettoView() ;
		folder.setOggettoView(oggettoView);
		final Collection<Folder> foldercoll = new ArrayList<Folder>();
		foldercoll.add(folder);
		
		
		if (isMapWithWINBOX2INPUTPROCESSOR) {
			isMapWithWINBOX2INPUTPROCESSOR =  false;
			final Winbox2InputProcessor winbox2InputProcessor = new Winbox2InputProcessor(
					"", 2L);
			map = new HashMap();
			map.put(CONSTANTS.WINBOX2_INPUT_PROCESSOR.toString(),
					winbox2InputProcessor);
			map.put(CONSTANTS.TR_WINBOX2_NEED_CONFIRMATION.getValue(), "");
			
			final Map<String, Collection<Folder>> originalConfirmationNeededMap  = new HashMap<String, Collection<Folder>>();
			
			originalConfirmationNeededMap.put("1", new HelperMock().getFolderList());
			map.put(CONSTANTS.CONFIRMATION_NEEDED_MAP.toString(), originalConfirmationNeededMap);
		}

		if (isMapWithTrWBX2PartialConferma) {
			isMapWithTrWBX2PartialConferma = false;
			map = new HashMap();
			final Winbox2InputProcessor winbox2InputProcessor1 = new Winbox2InputProcessor(
					"", 2L);
			map.put(CONSTANTS.WINBOX2_INPUT_PROCESSOR.toString(),
					winbox2InputProcessor1);
			map.put(CONSTANTS.TR_WINBOX2_PARTIAL_CONFERMA.getValue(), "");
			map.put(CONSTANTS.SUCCESS.getValue(), "");
		}
		if (isMapWithOutWINBOX2INPUTPROCESSOR) {
			isMapWithOutWINBOX2INPUTPROCESSOR = false;
			map = new HashMap();
			map.put(CONSTANTS.TR_WINBOX2_PARTIAL_CONFERMA.getValue(), "");
			map.put(CONSTANTS.SUCCESS.getValue(), "");
		}
		return map;

	}

	@Mock
	public static String validateInput( final RequestEvent requestEvent, final Map<String, Object> sessionMap ) throws TracciabilitaException, RemoteException 
	{
		return "TrStampe" ;
	}
	
	@Mock
	public static void setExecuteResult(final Map<String, Object> sessionMap,
			final ExecuteResult executeResult, final Boolean isTrError) {
		return ;
	}
	
	private Collection getFolderList() {
		final Collection folderList = new ArrayList();
		final Folder folder1 = new Folder();
		final OggettoView oggettoView = new OggettoView();
		oggettoView.setBankDescription("BSE");
	    final HistoryView historyView = new HistoryView();
	    historyView.setCdr("09999");
	    final FolderAttributes folderAttributes = new FolderAttributes();
	    folderAttributes.setBarcode("1243");
	    final Collection<Grants> grants = new ArrayList<Grants>();
	    final Grants grants1 = new Grants();
	    grants1.setId(1L);	
	    grants1.setCdrCode("BSSC6");
	    grants.add(grants1);
		return folderList;
	}
}
