package it.sella.tracciabilitaplichi.executer.gestoreeliminabustacinque;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiBustasDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiBustasDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Collection;

import org.easymock.EasyMock;



public class EliminaRicercaExecuterTest extends AbstractSellaExecuterMock{

	public EliminaRicercaExecuterTest(final String name) {
		super(name);
	}

	EliminaRicercaExecuter executer=new EliminaRicercaExecuter();

	public void testEliminaRicercaExecuter_02() {
		new TPUtilMock().setValidateDate(1);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertTrue(true);
	}

	public void testEliminaRicercaExecuter_03() {
		new TPUtilMock().setValidateDate(1);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFailure",executeResult.getTransition());
	}

	public void testEliminaRicercaExecuter_04() {
		new TPUtilMock().setValidateDate(1);
		new TracciabilitaPlichiBustasDataAccessMock().setRicercaViewNotNull();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFailure",executeResult.getTransition());
	}

	public void testEliminaRicercaExecuter_05() {
		new TPUtilMock().setValidateDate(1);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrFailure",executeResult.getTransition());
	}

	public void testEliminaRicercaExecuter_06() {
		new TPUtilMock().setValidateDate(1);
		new TracciabilitaPlichiBustasDataAccessMock().setValidLid(1);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Collection) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrRicerca",executeResult.getTransition());
	}

	public void testEliminaRicercaExecuter_07() {
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(true);
		expecting(getStateMachineSession().get("RicercaCollection")).andReturn("");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrRicerca",executeResult.getTransition());
	}

	public void testEliminaRicercaExecuter_08() {
		new TPUtilMock().setValidateDate(1);
		new TracciabilitaPlichiBustasDataAccessMock().setTracciabilitaException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

	public void testEliminaRicercaExecuter_09() {
		new TracciabilitaPlichiBustasDataAccessMock().setRemoteException();
		new TPUtilMock().setValidateDate(1);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiBustasDataAccess.class, TracciabilitaPlichiBustasDataAccessMock.class);
		expecting(getStateMachineSession().containsKey("RicercaCollection")).andReturn(false);
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("07");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2012");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		expecting(getRequestEvent().getAttribute( "day" )).andReturn("02");
		expecting(getRequestEvent().getAttribute( "month" )).andReturn("08");
		expecting(getRequestEvent().getAttribute("year")).andReturn("2011");
		expecting(getRequestEvent().getAttribute("oggettoLid")).andReturn("12");
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals(null,executeResult.getTransition());
	}

}
