package it.sella.tracciabilitaplichi.implementation.dao;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import mockit.Mock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaDataAccessException;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;

public class TracciabilitaPlichiCassettoDataAccessMock 
{
   
	private static Boolean isCDRInLinkedCassetto = false;	
	private static Boolean remoteException = false;
	private static Boolean isCollLinkedCasettoNull = false;
	private static Boolean tracciabilitaException = false;
		
	    public  static void setCDRInLinkedCassetto() 
	    {
	    	isCDRInLinkedCassetto = true;
		}
	    public  static void setRemoteException()
	    {
	    	remoteException = true;
	    }
	    public  static void setCollLinkedCasettoAsNull()
	    {
	    	isCollLinkedCasettoNull = true;
	    }
	    
		public static void setTracciabilitaException() {
			tracciabilitaException = true;
		}
	    
	@Mock
	public boolean isCDRInLinkedCassetto( String cdr, Long bankId ) throws TracciabilitaDataAccessException, RemoteException
	{
		Boolean flag = false;
		if(cdr=="000")
		{
			remoteException = false;
			throw new RemoteException();
		}
		if(cdr=="1")
		{
			flag=true;
		}
		if( isCDRInLinkedCassetto )
		{
			isCDRInLinkedCassetto = false;
			flag = true ;
		}
		
		return flag ;
	}

	@Mock
	public Collection listaLinkedCassettoView4Cassetto( String cassetto, String bankID ) throws TracciabilitaDataAccessException, RemoteException
	{
		if( remoteException )
		{
			remoteException = false;
			throw new RemoteException();
		}
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaDataAccessException("");
		}
		Collection collLinkedCasetto = new Vector();
		LinkedCasettoView	linkedCasettoView1 = new LinkedCasettoView();
		linkedCasettoView1.setId( 1L ) ;
		linkedCasettoView1.setCdr( "abc" );
		LinkedCasettoView	linkedCasettoView2 = new LinkedCasettoView();
		linkedCasettoView2.setId( 2L ) ;
		linkedCasettoView2.setCdr( "dff" );
		collLinkedCasetto.add( linkedCasettoView1 );
		collLinkedCasetto.add( linkedCasettoView2 );
		Collection collCDRInserisci = new ArrayList();
		collCDRInserisci.add("ABCD");
		if( isCollLinkedCasettoNull )
		{
			collLinkedCasetto = null ;
		}
		return collLinkedCasetto;
	}
}
