package it.sella.tracciabilitaplichi.ajax.inserimentocontratti.handler;

import org.junit.Assert;
import org.junit.Test;


public class ContractDescriptionsComparatorTest {
	
	ContractDescriptionsComparator contractDescriptionsComparator = new ContractDescriptionsComparator() ;

	@Test
	public void compare_01() {
		final int result = contractDescriptionsComparator.compare("Busta10", "Busta10");
		Assert.assertEquals(result,0);
	}
	
}
