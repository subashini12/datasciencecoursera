package it.sella.tracciabilitaplichi.implementation.borsaverde;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;

import mockit.Mock;

public class BorsaVerdeHelperMock {

	@Mock
	public void archiveGB( final Long bvId, final Boolean isAlreadyInScaricoState, final TracciabilitaPlichiView modifiedTPView ) throws TracciabilitaException, RemoteException{
		return ;
	}
}
