package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.CompatibleBanksView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.RicercaView;

import java.rmi.RemoteException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import mockit.Mock;

public class TracciabilitaPlichiBustasDataAccessMock 
{
	 private static Boolean tracciabilitaException = false;	
	 
	 public static void setTracciabilitaException() 
	 {
		 tracciabilitaException = true;
     }
	@Mock
	public boolean isExistOggettoForUser( final OggettoView oggettoView ) throws TracciabilitaException
	{
		return true;
	}
	@Mock
	public boolean isBusta5FromGestoreBusta5( final OggettoView oggettoView, final String st1, final String st2 ) throws TracciabilitaException, RemoteException
	{
		return true;
	}
	@Mock
	public Collection listBusta5PendingDates( final String lid ) throws TracciabilitaException
	{
		final Collection arrayList = new ArrayList();
		arrayList.add("10/05/1985");
		arrayList.add("30/10/1986");
		return arrayList;
	}
	@Mock
	public Collection getRicercaView( final Date datacomp, final String searchKey, final String searchType ) throws TracciabilitaException, RemoteException
	{
		final Collection ricercaViewColl=new ArrayList();
		final RicercaView ricercaView1 = new RicercaView();
		ricercaView1.setId(1L);
		ricercaViewColl.add( ricercaView1 );
		
		final RicercaView ricercaView2 = new RicercaView();
		ricercaView1.setId(2L);
		ricercaViewColl.add( ricercaView2 );
		return ricercaViewColl;
	}


	@Mock
	public boolean isCompatibleBanksExist( final CompatibleBanksView compatibleBanksView ) throws TracciabilitaException
	{
		if(tracciabilitaException)
		  {
	    	tracciabilitaException = false;
	    	throw new TracciabilitaException();
		  }
		return true;
	}
}
