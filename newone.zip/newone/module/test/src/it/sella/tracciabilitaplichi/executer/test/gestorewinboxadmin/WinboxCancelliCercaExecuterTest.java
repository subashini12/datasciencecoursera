package it.sella.tracciabilitaplichi.executer.test.gestorewinboxadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxAdminHelper;
import it.sella.tracciabilitaplichi.executer.gestorewinboxadmin.WinboxCancelliCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;

public class WinboxCancelliCercaExecuterTest extends AbstractSellaExecuterMock {

	WinboxCancelliCercaExecuter winboxCancelliCercaExecuter =  new WinboxCancelliCercaExecuter(); 
	
	public WinboxCancelliCercaExecuterTest(final String name) {
		super(name);
	}
	
	 public void testWinboxCancelliCercaExecuter_01(){
		expecting(getRequestEvent().getAttribute("ID")).andReturn("22").anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
		playAll();
		redefineMethod(TracciabilitaPlichiAdminMasterDataAccess.class, new Object(){
			public boolean isValidWinboxId( final String id ) throws TracciabilitaException{
				return true;
			}
		});
		redefineMethod(TracciabilitaPlichiAdminMasterDataAccess.class, new Object(){
			public AltriWinboxView getAltriWinboxView( final String id ) throws TracciabilitaException{
				return new AltriWinboxView();
			}
		});
		final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
	}
	 public void testWinboxCancelliCercaExecuter_02(){
		expecting(getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
		playAll();
		final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		assertEquals(executeResult.getAttribute("MSG"), "TRPL-1060");
	}
	 public void testWinboxCancelliCercaExecuter_03(){
		expecting(getRequestEvent().getAttribute("ID")).andReturn("dd").anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
		playAll();
		final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		assertEquals(executeResult.getAttribute("MSG"), "TRPL-1060");
	}
	 
	 public void testWinboxCancelliCercaExecuter_04(){
		expecting(getRequestEvent().getAttribute("ID")).andReturn(null).anyTimes();
		expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
		expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
		playAll();
		final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		assertEquals(executeResult.getAttribute("MSG"), "TRPL-1003");
	}
	
	 public void testWinboxCancelliCercaExecuter_06(){
		    setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		 	setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		 	setUpMockMethods(Util.class, UtilMock.class);
			expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
			expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
			expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
			playAll();
			final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		}
	 
	 public void testWinboxCancelliCercaExecuter_07(){
		 	WinboxAdminHelperMock.setRemoteException();
		    setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		 	setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		 	setUpMockMethods(Util.class, UtilMock.class);
			expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
			expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
			expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
			playAll();
			final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		}
	 
	 public void testWinboxCancelliCercaExecuter_08(){
		 	WinboxAdminHelperMock.setTracciabilitaException();
		    setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		 	setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		 	setUpMockMethods(Util.class, UtilMock.class);
			expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
			expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
			expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
			playAll();
			final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		}
	 
	 public void testWinboxCancelliCercaExecuter_09(){
		    TracciabilitaPlichiAdminMasterDataAccessMock.setInValidWinboxId();
		    setUpMockMethods(WinboxAdminHelper.class, WinboxAdminHelperMock.class);
		 	setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		 	setUpMockMethods(Util.class, UtilMock.class);
			expecting(getRequestEvent().getAttribute("ID")).andReturn("1").anyTimes();
			expecting(getStateMachineSession().get("WinboxList")).andReturn("22").anyTimes();
			expecting(getStateMachineSession().containsKey("WinboxList")).andReturn(true);
			playAll();
			final ExecuteResult executeResult =  winboxCancelliCercaExecuter.execute(getRequestEvent())	 ;
		}
}
