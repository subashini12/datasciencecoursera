package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.dbhelper.ConnectionLifecycleMock;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockConnectionProvider;
import it.sella.tracciabilitaplichi.implementation.dbhelper.MockStatementProvider;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorrMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.AltriWinboxView;
import it.sella.tracciabilitaplichi.implementation.view.CdrGroupView;
import it.sella.tracciabilitaplichi.implementation.view.CompatibleBanksView;
import it.sella.tracciabilitaplichi.implementation.view.HostlIdAttributeView;
import it.sella.tracciabilitaplichi.persistence.dto.Grants;

import java.util.Collection;

import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TracciabilitaPlichiAdminMasterDataAccessTest {

	TracciabilitaPlichiAdminMasterDataAccess tracciabilitaPlichiAdminMasterDataAccess = null;
	private MockConnectionProvider mockConnectionProvider;
	private MockStatementProvider mockStatementProvider;
	private ConnectionLifecycleMock connectionMock;
	DBConnectorrMock dbConnectionMock;

	@Before
	public void setUp() throws Exception {
		tracciabilitaPlichiAdminMasterDataAccess = new TracciabilitaPlichiAdminMasterDataAccess();
		mockConnectionProvider = new MockConnectionProvider();
		connectionMock = new ConnectionLifecycleMock();
		dbConnectionMock = new DBConnectorrMock();
		connectionMock.setConnection(mockConnectionProvider.getMockConnection());
		dbConnectionMock.setConnection(mockConnectionProvider.getMockConnection());
		Mockit.setUpMock(ConnectionLifecycle.class, connectionMock);
		Mockit.setUpMock(DBConnector.class, dbConnectionMock);
	}

	@After
	public void tearDown() throws Exception {
		tracciabilitaPlichiAdminMasterDataAccess = null;
	}

	@Test
	public void getCompatibleBanksView() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider("SELECT CB.CB_ID,CB.CB_BANK,CB.CB_OTHER_BANK FROM TP_MA_COMPATIBLE_BANKS CB WHERE CB.CB_ID=?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 0,"CB_ID","2");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,"CB_BANK","3");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 2,"CB_OTHER_BANK","4");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final CompatibleBanksView compatibleBanksView = tracciabilitaPlichiAdminMasterDataAccess.getCompatibleBanksView("5");
		Assert.assertEquals(Long.valueOf("3"), compatibleBanksView.getBankId());
	}
	@Test
	public void getTailoredGrants() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider("SELECT TG_ID, TG_AW_ID, TG_ID_SOGGETTO FROM TP_MA_TAILORED_GRANTS WHERE TG_AW_ID = ?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 0,"TG_ID",2l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,"TG_ID_SOGGETTO",4l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection<Grants> tailoredGrants = tracciabilitaPlichiAdminMasterDataAccess.getTailoredGrants(3l);
		Assert.assertEquals(1, tailoredGrants.size());
	}
	@Test
	public void getAltriWinboxView() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		final byte enabled = 10;
		final byte customAccess = 12;
		mockStatementProvider = new MockStatementProvider("SELECT AW.AW_ID, AW.AW_DESC, AW.AW_NO_YEARS, AW.AW_CDR, AW.AW_BANK,AW_OBJECT_TYPE,AW_ENABLED,AW_CUSTOM_ACCESS  FROM TP_MA_ALTRI_WINBOX AW WHERE AW.AW_ID=? AND AW.AW_BANK=?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 0,"AW_ID","10");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,"AW_DESC","3");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 2,"AW_NO_YEARS","4");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 3,"AW_CDR","099231");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 4,"AW_BANK","3");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 5,"AW_OBJECT_TYPE",5l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.TINYINT, 6,"AW_ENABLED",enabled );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.TINYINT, 7,"AW_CUSTOM_ACCESS",customAccess);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final AltriWinboxView altriWinboxView = tracciabilitaPlichiAdminMasterDataAccess.getAltriWinboxView("2");
		Assert.assertEquals("099231",altriWinboxView.getCdr());
	}
	@Test
	public void isValidWinboxId() throws TracciabilitaException{
		mockStatementProvider = new MockStatementProvider("SELECT AW.AW_ID  FROM TP_MA_ALTRI_WINBOX AW WHERE AW.AW_ID=?" );
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,1,"10");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertTrue(tracciabilitaPlichiAdminMasterDataAccess.isValidWinboxId("12"));
	}
	@Test
	public void getRicercaCdrGroupList() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT CG_ID, CG_CDR, CG_GROUP FROM TP_MA_CDR_GROUP WHERE CG_CDR LIKE ? AND CG_GROUP LIKE ?  AND CG_BANK = ? ");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,5l);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,2,"09923");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"IT-ORG-GEN");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final Collection cdrGrouoList =tracciabilitaPlichiAdminMasterDataAccess.getRicercaCdrGroupList("cdr", "group");
		Assert.assertEquals(1,cdrGrouoList.size() );
	}
	@Test
	public void isValidCdrGroupId() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT CG_ID  FROM TP_MA_CDR_GROUP WHERE CG_ID=? AND CG_BANK = ?");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.NUMERIC, 1,1,5l);
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		Assert.assertTrue(tracciabilitaPlichiAdminMasterDataAccess.isValidCdrGroupId("2"));
	}
	@Test
	public void getCdrGroupView() throws TracciabilitaException{
		final String query = "SELECT CG_ID,CG_CDR,CG_GROUP  FROM TP_MA_CDR_GROUP WHERE CG_ID=? AND CG_BANK = ? ";
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(query);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,1,"4");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,2,"09923");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"IT-ORG-GEN");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final CdrGroupView cdrGroupView = tracciabilitaPlichiAdminMasterDataAccess.getCdrGroupView("23");
		Assert.assertEquals("09923", cdrGroupView.getCdr());
	}
	@Test
	public void isCdrExists() throws TracciabilitaException{
		final String query = "SELECT CG_ID,CG_CDR,CG_GROUP FROM TP_MA_CDR_GROUP WHERE CG_CDR=? AND CG_BANK = ? ";
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider(query);
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,1,"4");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,2,"09923");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,3,"IT-ORG-GEN");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final CdrGroupView cdrGroupView = tracciabilitaPlichiAdminMasterDataAccess.isCdrExists("23");
		Assert.assertEquals("09923", cdrGroupView.getCdr());
	}
	@Test
	public void getHostlIdAttributeView() throws TracciabilitaException{
		Mockit.setUpMock(SecurityWrapper.class,SecurityWrapperMock.class);
		mockStatementProvider = new MockStatementProvider("SELECT HA_ID,HA_LID FROM TP_MA_HOSTLID_ATTRIBUTE WHERE HA_ID=? AND HA_BANK = ?");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,1,"4");
		mockStatementProvider.setPreparedStatementResultSet( java.sql.Types.VARCHAR, 1,2,"V099");
		mockConnectionProvider.setPreparedStatementQuery(mockStatementProvider);
		mockConnectionProvider.replay();
		final HostlIdAttributeView hostlIdAttributeView = tracciabilitaPlichiAdminMasterDataAccess.getHostlIdAttributeView("12");
		Assert.assertEquals("V099", hostlIdAttributeView.getHaLid());
	}


}
