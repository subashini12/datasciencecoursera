package it.sella.tracciabilitaplichi.executer.test.gestorebustanera;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import it.sella.statemachine.ExecuteResult;
import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.gestorebustanera.BustaNeraEliminaExecuter;
import it.sella.tracciabilitaplichi.implementation.view.BustaNeraAttributeView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import junit.framework.TestCase;

public class BustaNeraEliminaExecuterTest extends TestCase
{

	private RequestEvent requestEvent = null;
	private StateMachineSession session = null;
	
	public BustaNeraEliminaExecuterTest( final String name )
	{
		super( name );
	}
	
	@Override
	public void setUp( ) throws Exception
	{
		this.requestEvent = createMock( RequestEvent.class );
		this.session = createMock( StateMachineSession.class );
	}
	
	@Override
	public void tearDown( )
	{
		requestEvent = null;
		 session = null;
	}
	
	public void testBNEliminaExecuter1( )
	{
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		mockRequestParams( null, "AA11234567", "SBAI08", "Note for Destination", "yes", "1", "-1" );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( new Hashtable( ) );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraEliminaExecuter( ).execute( this.requestEvent );
		assertTrue( executeResult.getAttribute( "MSG" ) != null );
		assertEquals( "TRPL-1003", executeResult.getAttribute( "MSG" ).toString( ) );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "SBAI08".equals( executeResult.getAttribute( "UserOrCdr" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".equals( executeResult.getAttribute( "NoteForDest" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "UserSelectedBankId" ) != null && "1".equals( executeResult.getAttribute( "UserSelectedBankId" ).toString( ) ) );
	}

	public void testBNEliminaExecuter2( )
	{
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		mockRequestParams( "1", "AA11234567", "SBAI08", "Note for Destination", "yes", "1", "-1" );
		Hashtable bustaNeraHashTable = new Hashtable( );
		bustaNeraHashTable.put( "BustaNeraMainCollection", getBNMainCollection( ) );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( bustaNeraHashTable );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraEliminaExecuter( ).execute( this.requestEvent );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "SBAI08".equals( executeResult.getAttribute( "UserOrCdr" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".equals( executeResult.getAttribute( "NoteForDest" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "UserSelectedBankId" ) != null && "1".equals( executeResult.getAttribute( "UserSelectedBankId" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );	
		bustaNeraHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		final Collection bnMainCollection = ( Collection ) bustaNeraHashTable.get( "BustaNeraMainCollection" );
		assertTrue( bnMainCollection.size( ) == 2 );
		for( final Object obj : bnMainCollection )
		{
			final BustaNeraAttributeView attributeView = ( BustaNeraAttributeView ) obj;
			assertTrue( attributeView.getId( ) != 1 );
		}
	}

	public void testBNEliminaExecuter3( )
	{
		expect( this.requestEvent.getStateMachineSession( ) ).andReturn( this.session );
		mockRequestParams( new String[]{"1","3"}, "AA11234567", "SBAI08", "Note for Destination", "yes", "1", "-1" );
		Hashtable bustaNeraHashTable = new Hashtable( );
		bustaNeraHashTable.put( "BustaNeraMainCollection", getBNMainCollection( ) );
		expect( this.session.get( "BustaNeraHashTable" ) ).andReturn( bustaNeraHashTable );
		replay( this.requestEvent );
		replay( this.session );
		final ExecuteResult executeResult = new BustaNeraEliminaExecuter( ).execute( this.requestEvent );
		assertTrue( executeResult.getAttribute( "BarCode" ) != null && "AA11234567".equals( executeResult.getAttribute( "BarCode" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "UserOrCdr" ) != null && "SBAI08".equals( executeResult.getAttribute( "UserOrCdr" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "NoteForDest" ) != null && "Note for Destination".equals( executeResult.getAttribute( "NoteForDest" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "MailMe" ) != null && "yes".equals( executeResult.getAttribute( "MailMe" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "UserSelectedBankId" ) != null && "1".equals( executeResult.getAttribute( "UserSelectedBankId" ).toString( ) ) );
		assertTrue( executeResult.getAttribute( "BustaNeraHashTable" ) != null );	
		bustaNeraHashTable = ( Hashtable ) executeResult.getAttribute( "BustaNeraHashTable" );
		final Collection bnMainCollection = ( Collection ) bustaNeraHashTable.get( "BustaNeraMainCollection" );
		assertTrue( bnMainCollection.size( ) == 1 );
		for( final Object obj : bnMainCollection )
		{
			final BustaNeraAttributeView attributeView = ( BustaNeraAttributeView ) obj;
			assertTrue( attributeView.getId( ) == 2 );
		}
	}

	
	private void mockRequestParams( final Object cheObj, final String barCode , final String userOrCdr, final String noteForDest, final String mailMe, final String bank, final String widelyCdr )
	{
		mockRequestParam( "checkbox", cheObj );
		mockRequestParam( "BarCode", barCode );
		mockRequestParam( "UserOrCdr", userOrCdr );
		mockRequestParam( "NoteForDest", noteForDest );
		mockRequestParam( "MailMe", mailMe );
		mockRequestParam( "SelectedBankId", bank );
		mockRequestParam( "widelyUsedCdr", widelyCdr );
	}
	
	private void mockRequestParam( final String attributeName, final Object value )
	{
		expect( this.requestEvent.getAttribute( attributeName ) ).andReturn( value );
	}
	
	private Collection getBNMainCollection( )
	{
		final BustaNeraAttributeView attributeView = new BustaNeraAttributeView( );
		attributeView.setId( 1L );
		final BustaNeraAttributeView attributeView1 = new BustaNeraAttributeView( );
		attributeView1.setId( 2L );
		final BustaNeraAttributeView attributeView2 = new BustaNeraAttributeView( );
		attributeView2.setId( 3L );
		final Collection bnMainColl = new ArrayList( 2 );
		bnMainColl.add( attributeView );
		bnMainColl.add( attributeView1 );
		bnMainColl.add( attributeView2 );
		return bnMainColl;
	}
}
