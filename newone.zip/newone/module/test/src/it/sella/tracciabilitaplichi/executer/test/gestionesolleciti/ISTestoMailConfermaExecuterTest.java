package it.sella.tracciabilitaplichi.executer.test.gestionesolleciti;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.ISTestoMailConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.dao.IGestioneSollecitiDataAccess;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TpMaPropertiesView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ISTestoMailConfermaExecuterTest    extends AbstractSellaExecuterMock {
private IGestioneSollecitiDataAccess igestioneSollecitiDataAccess = null ;
    
    @Override
	public void setUp( ) throws Exception
    {
        super.setUp( );
        igestioneSollecitiDataAccess = getMock( IGestioneSollecitiDataAccess.class );
        redefineMethod( TracciabilitaPlichiImpl.class, new Object( ) {
            public IGestioneSollecitiDataAccess getGestioneSollecitiDataAccess( )
            {
                return igestioneSollecitiDataAccess;
            }
        });
    }
    
    final ISTestoMailConfermaExecuter ISTestoMailConfermaExecuterTest =  new ISTestoMailConfermaExecuter(); 
    
    
    public ISTestoMailConfermaExecuterTest(final String name) {
        super(name);
    }

   
 
     public void testISTestoMailConfermaExecuter_01() throws TracciabilitaException{
 
        expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("").anyTimes();
        expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("").anyTimes();
        final Map GESTIONE_SOLLECITI_MAP = new HashMap( 1 );
        GESTIONE_SOLLECITI_MAP.put( ITPConstants.TP_MA_PROPERTIES_VIEW  , new TpMaPropertiesView( "1", "val"));
       

        expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(( Serializable ) GESTIONE_SOLLECITI_MAP).anyTimes();
        expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
        playAll();
        play( igestioneSollecitiDataAccess );
      
        final ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
        assertEquals("TRPL-1534" ,executeResult.getAttribute("MESSAGE") );
        assertEquals(ITPConstants.FAILURE ,executeResult.getTransition( ));
    }
     
     public void testISTestoMailConfermaExecuter_02() throws TracciabilitaException{
         
         expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test this is test this is test this is test this is test this is test this is test this is test this is test this is test this is test this is test this is test this is test ").anyTimes();
         expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("").anyTimes();
         final Map GESTIONE_SOLLECITI_MAP = new HashMap( 1 );
         GESTIONE_SOLLECITI_MAP.put( ITPConstants.TP_MA_PROPERTIES_VIEW  , new TpMaPropertiesView( "1", "this is test"));
         expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(( Serializable ) GESTIONE_SOLLECITI_MAP).anyTimes();
         expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
         playAll();
         play( igestioneSollecitiDataAccess );
         final ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
         assertEquals("TRPL-1535" ,executeResult.getAttribute("MESSAGE") );
         assertEquals(ITPConstants.FAILURE ,executeResult.getTransition( ));
     }
     
     public void testISTestoMailConfermaExecuter_03() throws TracciabilitaException{
         
         expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is ttest").anyTimes();
         expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("").anyTimes();
         final Map GESTIONE_SOLLECITI_MAP = new HashMap( 1 );
         GESTIONE_SOLLECITI_MAP.put( ITPConstants.TP_MA_PROPERTIES_VIEW  , new TpMaPropertiesView( "1", "val"));
         expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn(( Serializable ) GESTIONE_SOLLECITI_MAP).anyTimes();
         expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
         playAll();
         play( igestioneSollecitiDataAccess );
       
         final ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
         assertEquals("TRPL-1536" ,executeResult.getAttribute("MESSAGE") );
         assertEquals(ITPConstants.FAILURE ,executeResult.getTransition( ));
     }
     
    /* public void testISTestoMailConfermaExecuter_04() throws TracciabilitaException{
         
         expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test").anyTimes();
         expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("TESTO").anyTimes();
         final Map testoMap = new HashMap( 1 );
          testoMap.put( ITPConstants.SOLL_MAIL_SUBJECT , new TpMaPropertiesView ("1","this is test"));
          testoMap.put( ITPConstants.SOLL_MAIL_BODY , new TpMaPropertiesView ("1","val"));
          //TracciabilitaPlichiManagerMock.mockEJB( );
          mockEJB( );
         expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_TESTO_MAP)).andReturn(( Serializable ) testoMap).anyTimes();
         expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
         playAll();
         play( igestioneSollecitiDataAccess );
         redefineMethod( InvioSollecitiLogContent.class, new Object( ){
             public String getLogXMLForTestoMail( )
             {
                 return "";
             }
         });
         redefineMethods( SecurityWrapper.class, SecurityWrapperMock.class );
         redefineMethods( TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class );
         redefineMethod( LogEvent.class, new Object( ){
             public void log( final String operationCode, final boolean operationResult, final String operationXml )
             {
                 return;
             }
         });
         ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
         assertEquals("TRPL-1435" ,executeResult.getAttribute("MESSAGE") );
         assertEquals(ITPConstants.SUCCESS ,executeResult.getTransition( ));
 
     }
     
    public void testISTestoMailConfermaExecuter_05() throws TracciabilitaException{
         expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test").anyTimes();
         expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("TESTO").anyTimes();
         final Map testoMap = new HashMap( 1 );
         TracciabilitaPlichiManagerMock.mockEJB( );
         expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_TESTO_MAP)).andReturn(( Serializable ) testoMap).anyTimes();
         expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
         playAll();
         play( igestioneSollecitiDataAccess );
         redefineMethod( InvioSollecitiLogContent.class, new Object( ){
             @Mock
             public String getLogXMLForTestoMail( )
             {
                 return "";
             }
         });
         redefineMethod( SecurityWrapper.class, new Object( ){
             @Mock
             public Long getBankId() throws TracciabilitaException
             {
                 return 1L;
             }
         });
         redefineMethod( TracciabilitaPlichiManagerBean.class, new Object( ){
             @Mock
             public Long censitoOggetto( Properties properties ) throws TracciabilitaException, RemoteException
             {
                 return  1L;
             }
         });
         redefineMethod( LogEvent.class, new Object( ){
             @Mock
             public void log( final String operationCode, final boolean operationResult, final String operationXml )
             {
                 return;
             }
         });
         ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
         assertEquals("TRPL-1376" ,executeResult.getAttribute("MESSAGE") );
         assertEquals(ITPConstants.SUCCESS ,executeResult.getTransition( ));
 
     }


    public void testISTestoMailConfermaExecuter_06() throws TracciabilitaException{
         
         expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test").anyTimes();
         expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("TESTO").anyTimes();
         final Map testoMap = new HashMap( 1 );
         TracciabilitaPlichiManagerMock.mockEJB( );
         expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_TESTO_MAP)).andReturn(( Serializable ) testoMap).anyTimes();
         expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
         playAll();
         play( igestioneSollecitiDataAccess );
         redefineMethod( InvioSollecitiLogContent.class, new Object( ){
             @Mock
             public String getLogXMLForTestoMail( )
             {
                 return "";
             }
         });
         redefineMethod( SecurityWrapper.class, new Object( ){
             @Mock
             public Long getBankId() throws TracciabilitaException
             {
                 return 1L;
             }
         });
         redefineMethod( TracciabilitaPlichiManagerBean.class, new Object( ){
             @Mock
             public Long censitoOggetto( Properties properties ) throws TracciabilitaException, RemoteException
             {
                 throw new TracciabilitaException();
             }
         });
         redefineMethod( LogEvent.class, new Object( ){
             @Mock
             public void log( final String operationCode, final boolean operationResult, final String operationXml )
             {
                 return;
             }
         });
 
         ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
         assertEquals("it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException" ,executeResult.getException().toString() );
 
     }


    public void testISTestoMailConfermaExecuter_07() throws TracciabilitaException{
         
         expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test").anyTimes();
         expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("TESTO").anyTimes();
         final Map testoMap = new HashMap( 1 );
         TracciabilitaPlichiManagerMock.mockEJB( );
         expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_TESTO_MAP)).andReturn(( Serializable ) testoMap).anyTimes();
         expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
         playAll();
         play( igestioneSollecitiDataAccess );
 
         redefineMethod( InvioSollecitiLogContent.class, new Object( ){
             @Mock
             public String getLogXMLForTestoMail( )
             {
                 return "";
             }
         });
         redefineMethod( SecurityWrapper.class, new Object( ){
             @Mock
             public Long getBankId() throws TracciabilitaException
             {
                 return 1L;
             }
         });
         
 
         redefineMethod( TracciabilitaPlichiManagerBean.class, new Object( ){
             @Mock
             public Long censitoOggetto( Properties properties ) throws TracciabilitaException, RemoteException
             {
                 throw new RemoteException();
             }
         });
         redefineMethod( LogEvent.class, new Object( ){
             @Mock
             public void log( final String operationCode, final boolean operationResult, final String operationXml )
             {
                 return;
             }
         });
 
         ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
         assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );
     } 
    
    public void testISTestoMailConfermaExecuter_08() throws TracciabilitaException{
        
        expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test").anyTimes();
        expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("this is test").anyTimes();
        final Map testoMap = new HashMap( 1 );
         testoMap.put( ITPConstants.SOLL_MAIL_SUBJECT , new TpMaPropertiesView ("SOLL_MAIL_SUBJECT_1","this is test"));
         testoMap.put( ITPConstants.SOLL_MAIL_BODY , new TpMaPropertiesView ("SOLL_MAIL_BODY_1","this is test"));
         TracciabilitaPlichiManagerMock.mockEJB( );
        expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_TESTO_MAP)).andReturn(( Serializable ) testoMap).anyTimes();
        expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
        playAll();
        play( igestioneSollecitiDataAccess );
        redefineMethod( SecurityWrapper.class, new Object( ){
            @Mock
            public Long getBankId() throws TracciabilitaException
            {
                return 1L;
            }
        });
        ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
        assertEquals("TRPL-1540" ,executeResult.getAttribute("MESSAGE") );
        assertEquals(ITPConstants.FAILURE ,executeResult.getTransition( ));

    }
    
    
    public void testISTestoMailConfermaExecuter_09() throws TracciabilitaException{
        
        expecting(getRequestEvent( ).getAttribute( ITPConstants.OGGETTO )).andReturn("this is test").anyTimes();
        expecting(getRequestEvent( ).getAttribute( ITPConstants.TESTO )).andReturn("TESTO").anyTimes();
        final Map testoMap = new HashMap( 1 );
         testoMap.put( ITPConstants.SOLL_MAIL_SUBJECT , new TpMaPropertiesView ("SOLL_MAIL_SUBJECT_1","this test"));
         testoMap.put( ITPConstants.SOLL_MAIL_BODY , new TpMaPropertiesView ("SOLL_MAIL_SUBJECT_1","val"));
         TracciabilitaPlichiManagerMock.mockEJB( );
        expecting(getStateMachineSession().get( ITPConstants.GESTIONE_SOLLECITI_TESTO_MAP)).andReturn(( Serializable ) testoMap).anyTimes();
        expecting(igestioneSollecitiDataAccess.getAllEsiti( )).andReturn( new ArrayList() ).anyTimes(   );
        playAll();
        play( igestioneSollecitiDataAccess );
        redefineMethod( InvioSollecitiLogContent.class, new Object( ){
            @Mock
            public String getLogXMLForTestoMail( )
            {
                return "";
            }
        });
        redefineMethod( SecurityWrapper.class, new Object( ){
            @Mock
            public Long getBankId() throws TracciabilitaException
            {
                return 1L;
            }
        });
        redefineMethod( TracciabilitaPlichiManagerBean.class, new Object( ){
            @Mock
            public void modificaOggetto( Properties properties ) throws TracciabilitaException, RemoteException
            {
                return  ;
            }
        });
        redefineMethod( LogEvent.class, new Object( ){
            @Mock
            public void log( final String operationCode, final boolean operationResult, final String operationXml )
            {
                return;
            }
        });
        ExecuteResult executeResult = ISTestoMailConfermaExecuterTest.execute(getRequestEvent());
        assertEquals("TRPL-1435" ,executeResult.getAttribute("MESSAGE") );
        assertEquals(ITPConstants.SUCCESS ,executeResult.getTransition( ));

    }*/
}
