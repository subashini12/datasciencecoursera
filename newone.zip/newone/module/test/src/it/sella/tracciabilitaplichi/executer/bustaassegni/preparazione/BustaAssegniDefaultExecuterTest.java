package it.sella.tracciabilitaplichi.executer.bustaassegni.preparazione;


import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.bustadeicihome.processor.HomePageProcessor;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.bustadeicihome.processor.HomePageProcessorMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.util.HashMap;

import org.easymock.classextension.EasyMock;

public class BustaAssegniDefaultExecuterTest extends AbstractSellaExecuterMock {

	BustaAssegniDefaultExecuter bustaAssegniDefaultExecuterTest =  new BustaAssegniDefaultExecuter(); 
	
	public BustaAssegniDefaultExecuterTest(final String name) {
		super(name);
	}
	
	public void testBustaAssegniDefaultExecuter_01(){
		 expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(Boolean.TRUE).anyTimes();
		 expecting(getStateMachineSession().get(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(new HashMap()).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER_DETAILS)).andReturn(Boolean.FALSE).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER)).andReturn(Boolean.TRUE).anyTimes();
		 setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
		 setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 playAll();
		 final ExecuteResult executeResult = bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
		 assertEquals(null, executeResult.getTransition());
	}
	 
	public void testBustaAssegniDefaultExecuter_02(){
		 expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(Boolean.FALSE).anyTimes();
		 expecting( getStateMachineSession().put( (String)EasyMock.anyObject(), EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		 expecting(getStateMachineSession().get(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(new HashMap()).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER_DETAILS)).andReturn(Boolean.FALSE).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER)).andReturn(Boolean.TRUE).anyTimes();
		 setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
		 setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 playAll();
		 final ExecuteResult executeResult = bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
		 assertEquals(null, executeResult.getTransition());
	}
	
	public void testBustaAssegniDefaultExecuter_03(){
		SecurityDBpersonaleWrapperMock.setTracciabilitaException();
		 expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(Boolean.TRUE).anyTimes();
		 expecting(getStateMachineSession().get(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(new HashMap()).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER_DETAILS)).andReturn(Boolean.FALSE).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER)).andReturn(Boolean.TRUE).anyTimes();
		 setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
		 setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 playAll();
		 final ExecuteResult executeResult = bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
		 assertEquals( "it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException", executeResult.getException( ).toString() );
	}
	public void testBustaAssegniDefaultExecuter_04(){
		SecurityDBpersonaleWrapperMock.setRemoteException();
		 expecting(getStateMachineSession().containsKey(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(Boolean.TRUE).anyTimes();
		 expecting(getStateMachineSession().get(ITPConstants.BUSTA_ASSEGNI_PREPARAZIONE_MAP)).andReturn(new HashMap()).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER_DETAILS)).andReturn(Boolean.FALSE).anyTimes();
		 expecting(getStateMachineSession().containsKey(ITPConstants.USER)).andReturn(Boolean.TRUE).anyTimes();
		 setUpMockMethods(HomePageProcessor.class, HomePageProcessorMock.class);
		 setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		 setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
		 setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		 playAll();
		 final ExecuteResult executeResult = bustaAssegniDefaultExecuterTest.execute(getRequestEvent());
		 assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );
	}	
	 
}
