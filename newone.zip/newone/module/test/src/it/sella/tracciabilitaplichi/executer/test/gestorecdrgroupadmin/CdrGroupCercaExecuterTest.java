package it.sella.tracciabilitaplichi.executer.test.gestorecdrgroupadmin;

import it.sella.tracciabilitaplichi.executer.gestorecdrgroupadmin.CdrGroupCercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminMasterDataAccessMock;

import java.io.Serializable;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class CdrGroupCercaExecuterTest extends AbstractSellaExecuterMock
{

	public CdrGroupCercaExecuterTest(String name) 
	{
		super(name);
	}
	CdrGroupCercaExecuter executer = new CdrGroupCercaExecuter();

	public void testCdrGroupCercaExecuter_01()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupCercaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("").anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupCercaExecuter_03()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("ab").anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupCercaExecuter_04()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setAsInValidCdrGroupId();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testCdrGroupCercaExecuter_05()
	{
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.TRUE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting( getStateMachineSession().get("CdrGroupTable" )).andReturn((Serializable)new Hashtable()).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testCdrGroupCercaExecuter_forTracciabilitaException()
	{
		TracciabilitaPlichiAdminMasterDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TracciabilitaPlichiAdminMasterDataAccess.class, TracciabilitaPlichiAdminMasterDataAccessMock.class);
		expecting( getRequestEvent().getAttribute("ID")).andReturn("01").anyTimes();
		expecting( getStateMachineSession().containsKey( "CdrGroupTable") ).andReturn( Boolean.FALSE ).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )EasyMock.anyObject() ) ).andReturn( null ).anyTimes();		
		playAll();
		executer.execute(getRequestEvent());
	}
}
