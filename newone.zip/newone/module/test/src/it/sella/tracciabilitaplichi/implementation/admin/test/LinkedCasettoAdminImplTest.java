/*package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.msg.MsgManager;
import it.sella.tracciabilitaplichi.implementation.admin.LinkedCasettoAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.DBConnectorMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.view.TPViewMock;
import it.sella.tracciabilitaplichi.implementation.util.DBConnector;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.LinkedCasettoView;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.sql.SQLException;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;

*//**
 * @author gbs03134
 *
 *//*

public class LinkedCasettoAdminImplTest extends BasicJDBCTestCaseAdapter {

	LinkedCasettoAdminImpl linkedCasettoAdminImpl=new LinkedCasettoAdminImpl();
	
	public void testCensitoOggetto_02() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final TPView tpView=null;
		try {
			linkedCasettoAdminImpl.censitoOggetto(tpView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	
	public void testCensitoOggetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=getLinkedCasettoView();
		try {
			linkedCasettoAdminImpl.censitoOggetto(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testModificaOggetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=getLinkedCasettoView();
		try {
			linkedCasettoAdminImpl.modificaOggetto(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}

	public void testModificaOggetto_02() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final TPView tpView=null;
		try {
			linkedCasettoAdminImpl.modificaOggetto(tpView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliCassetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=getLinkedCasettoView();
		try {
			linkedCasettoAdminImpl.cancelliCassetto(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliCassetto_02() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=null;
		try {
			linkedCasettoAdminImpl.cancelliCassetto(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	
	public void testCancelliId_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=null;
		try {
			linkedCasettoAdminImpl.cancelliId(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliCDR_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=getLinkedCasettoView();
		try {
			linkedCasettoAdminImpl.cancelliCDR(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliCDR_02() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=null;
		try {
			linkedCasettoAdminImpl.cancelliCDR(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliOggetto_01() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final LinkedCasettoView linkedCasettoView=getLinkedCasettoView();
		try {
			linkedCasettoAdminImpl.cancelliOggetto(linkedCasettoView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}
	
	public void testCancelliOggetto_02() throws SQLException
	{
		Mockit.setUpMock(LogEvent.class,LogEventMock.class);
		Mockit.setUpMock(DBConnector.class, DBConnectorMock.class);
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("LC_ID");
		result.addColumn("LC_CDR");
		result.addColumn("LC_CASETTO");
		result.addColumn("LC_BANK_ID");
		result.addColumn("LC_DESCRIPTION");
		result.addColumn("LC_PRINCIPALE_ID");
		statementHandler.prepareGlobalResultSet(result);
		final TPView tpView=null;
		try {
			linkedCasettoAdminImpl.cancelliOggetto(tpView);
		} catch (final TracciabilitaException e) {
			e.printStackTrace();
		}
		finally
		{
			connection.close();
		}
	}

	private LinkedCasettoView getLinkedCasettoView() {
		final LinkedCasettoView linkedCasettoView=new LinkedCasettoView();
		linkedCasettoView.setBankDescription("");
		linkedCasettoView.setBankId(1L);
		linkedCasettoView.setCasetto("");
		linkedCasettoView.setCdr("");
		linkedCasettoView.setDescription("");
		linkedCasettoView.setId(1L);
		linkedCasettoView.setPrincipaleId(1L);
		return linkedCasettoView;
	}
	
}*/