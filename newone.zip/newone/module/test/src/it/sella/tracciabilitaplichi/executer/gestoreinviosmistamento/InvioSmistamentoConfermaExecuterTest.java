package it.sella.tracciabilitaplichi.executer.gestoreinviosmistamento;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiCommonDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiSmistamentoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiCommonDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.validator.BarcodeValidatorMock;
import it.sella.tracciabilitaplichi.implementation.test.view.StatusViewMock;
import it.sella.tracciabilitaplichi.implementation.validator.BarcodeValidator;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.implementation.view.PlichiAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.StatusView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.easymock.EasyMock;

public class InvioSmistamentoConfermaExecuterTest extends AbstractSellaExecuterMock {

	public InvioSmistamentoConfermaExecuterTest(final String name) {
		super(name);
	}

	InvioSmistamentoConfermaExecuter executer = new InvioSmistamentoConfermaExecuter();

	public void testInvioSmistamentoConfermaExecuter_01() {
		TracciabilitaPlichiImplMock.setHost();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		setUpMockMethods(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		expecting(getRequestEvent().getAttribute("plichiAttributeId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barcodes")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("confermaPageNumber")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrConferma",executeResult.getTransition());
	}
	public void testInvioSmistamentoConfermaExecuter_03() {
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		TracciabilitaPlichiSmistamentoDataAccessMock.setExistsPlichiForBarcode();
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("plichiAttributeId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barcodes")).andReturn("1234567894568").anyTimes();
		expecting(getRequestEvent().getAttribute("confermaPageNumber")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrInvalidBarCode",executeResult.getTransition());
	}

	public void testInvioSmistamentoConfermaExecuter_04() {
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		ClassificazioneWrapperMock.setBUSTN();
		ClassificazioneWrapperMock.setPBUSTN();
		TracciabilitaPlichiSmistamentoDataAccessMock.setExistsPlichiForBarcode();
		setUpMockMethods(StatusView.class, StatusViewMock.class);
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		setUpMockMethods(ClassificazioneWrapper.class, ClassificazioneWrapperMock.class);
		setUpMockMethods(TracciabilitaPlichiCommonDataAccess.class, TracciabilitaPlichiCommonDataAccessMock.class);
		setUpMockMethods(TracciabilitaPlichiSmistamentoDataAccess.class, TracciabilitaPlichiSmistamentoDataAccessMock.class);
		setUpMockMethods(BarcodeValidator.class, BarcodeValidatorMock.class);
		expecting(getRequestEvent().getAttribute("plichiAttributeId")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("barcodes")).andReturn("1234567894568").anyTimes();
		expecting(getRequestEvent().getAttribute("confermaPageNumber")).andReturn("1").anyTimes();
		expecting(getRequestEvent().getAttribute("CassettoCodeDesc")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().get("GESTORE_INVIO_SMISTAMENTO_SESSION")).andReturn((Serializable) getMap()).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("TrInvalidBarCode",executeResult.getTransition());
	}

	private static Map getMap() {
		final Map map = new HashMap();
		map.put("mapIdBustaNeraView",getBustaNeraViewMap());
		map.put("SelectedBustaNeraViewCollection", getButaNeraCollection());
		map.put("mapPageListaBustaNeraView", getPageListaBustaNeraViewMap());
		map.put("smistamentoId", "");
		map.put("LastSentBustaNeraView","");
		map.put("ValidBarCodeButNotInRequiredState", "1");
		map.put("PBarcode","1");
		map.put("StateOfPlichi","1");
		return map ;
	}

	private static Map getPageListaBustaNeraViewMap() {
		final Map bustaNeraViewListMap = new HashMap();
		bustaNeraViewListMap.put("1", "1");
		return bustaNeraViewListMap ;
	}

	private static Map getBustaNeraViewMap() {
		final Map bustaNeraViewMap = new HashMap();
		bustaNeraViewMap.put("1", getTracciabilitaPlichiView());
		return bustaNeraViewMap ;
	}

	private static TracciabilitaPlichiView getTracciabilitaPlichiView() {
		final TracciabilitaPlichiView tracciabilitaPlichiView = new TracciabilitaPlichiView() ;
		tracciabilitaPlichiView.setOggettoView(getOggettoView());
		tracciabilitaPlichiView.setPlichiAttributeView(getPlichiAttributeView());
		return tracciabilitaPlichiView ;
	}

	private static OggettoView getOggettoView() {
		final OggettoView oggettoView = new OggettoView() ;
		oggettoView.setOggettoType(1L);
		oggettoView.setId(1L);
		return oggettoView ;
	}

	private static PlichiAttributeView getPlichiAttributeView() {
		final PlichiAttributeView plichiAttributeView = new PlichiAttributeView() ;
		plichiAttributeView.setBarCode("1234567891236");
		return plichiAttributeView ;
	}

	private static Collection getButaNeraCollection() {
		final Collection bustaNeraCollection = new ArrayList() ;
		bustaNeraCollection.add(getTracciabilitaPlichiView());
		return bustaNeraCollection ;
	}

}

