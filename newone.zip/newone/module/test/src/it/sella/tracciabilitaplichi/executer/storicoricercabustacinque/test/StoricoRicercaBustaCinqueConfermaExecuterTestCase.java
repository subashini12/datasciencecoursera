package it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.storicoricercabustacinque.StoricoRicercaBustaCinqueConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;


public class StoricoRicercaBustaCinqueConfermaExecuterTestCase extends AbstractSellaExecuterMock
{
    StoricoRicercaBustaCinqueConfermaExecuter storicoRicercaBustaCinqueConfermaExecuter = new StoricoRicercaBustaCinqueConfermaExecuter();
	public StoricoRicercaBustaCinqueConfermaExecuterTestCase(String name) {
		super(name);
	}
 
	public void testStoricoRicercaBustaCinqueConfermaExecuter_01(){
        Hashtable views = new Hashtable();
		List ricercaList = new ArrayList();
		ricercaList.add("01/05/2011");
		ricercaList.add("12345677");
		views.put("CollRicercaList",ricercaList);
		views.put( "SearchType", "Test" );
		expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(views).anyTimes();
		expecting( getRequestEvent().getAttribute("Day")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Month")).andReturn( "05" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Year")).andReturn( "2011" ).anyTimes();
        expecting( getRequestEvent().getAttribute("NrTerminale")).andReturn( "12345677" ).anyTimes();
        expecting( getRequestEvent().getAttribute("SearchType")).andReturn( "Test" ).anyTimes();
		expecting(getStateMachineSession().put("STORICO_RICERCA_BUSTA5_SESSION",  views)).andReturn(views).anyTimes();
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueConfermaExecuter.execute(getRequestEvent());
		
		//assertEquals("TRPL-1017" ,executeResult.getAttribute("MSG") );
	} 
	
	public void testStoricoRicercaBustaCinqueConfermaExecuter_02(){
     	expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.FALSE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(new HashMap()).anyTimes();
		expecting( getRequestEvent().getAttribute("Day")).andReturn( "34" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Month")).andReturn( "23" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Year")).andReturn( "3009" ).anyTimes();
        expecting( getRequestEvent().getAttribute("NrTerminale")).andReturn( "12345677" ).anyTimes();
        expecting( getRequestEvent().getAttribute("SearchType")).andReturn( "Test" ).anyTimes();
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueConfermaExecuter.execute(getRequestEvent());
		assertEquals("TRPL-1016" ,executeResult.getAttribute("MSG") );
	} 
	public void testStoricoRicercaBustaCinqueConfermaExecuter_03(){
     	expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.FALSE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(new HashMap()).anyTimes();
		expecting( getRequestEvent().getAttribute("Day")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Month")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Year")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("NrTerminale")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("SearchType")).andReturn( "Test" ).anyTimes();
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueConfermaExecuter.execute(getRequestEvent());
		assertEquals("TRPL-1016" ,executeResult.getAttribute("MSG") );
	} 
	public void testStoricoRicercaBustaCinqueConfermaExecuter_04(){
     	expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.FALSE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(new HashMap()).anyTimes();
		expecting( getRequestEvent().getAttribute("Day")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Month")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Year")).andReturn( "1899" ).anyTimes();
        expecting( getRequestEvent().getAttribute("NrTerminale")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("SearchType")).andReturn( "Test" ).anyTimes();
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueConfermaExecuter.execute(getRequestEvent());
		assertEquals("TRPL-1072" ,executeResult.getAttribute("MSG") );
	}
	
	public void testStoricoRicercaBustaCinqueConfermaExecuter_05(){
     	expecting(getStateMachineSession().containsKey("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(Boolean.FALSE);
		expecting(getStateMachineSession().get("STORICO_RICERCA_BUSTA5_SESSION")).andReturn(new HashMap()).anyTimes();
		expecting( getRequestEvent().getAttribute("Day")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Month")).andReturn( "01" ).anyTimes();
        expecting( getRequestEvent().getAttribute("Year")).andReturn( "2012" ).anyTimes();
        expecting( getRequestEvent().getAttribute("NrTerminale")).andReturn( "" ).anyTimes();
        expecting( getRequestEvent().getAttribute("SearchType")).andReturn( "Test" ).anyTimes();
		playAll();
		ExecuteResult executeResult = storicoRicercaBustaCinqueConfermaExecuter.execute(getRequestEvent());
	}
}
