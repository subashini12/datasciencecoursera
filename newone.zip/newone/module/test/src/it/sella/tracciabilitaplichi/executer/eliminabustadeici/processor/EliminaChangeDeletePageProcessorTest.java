package it.sella.tracciabilitaplichi.executer.eliminabustadeici.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.statemachine.StateMachineSession;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

import org.easymock.EasyMock;


public class EliminaChangeDeletePageProcessorTest extends AbstractSellaExecuterMock{

	public EliminaChangeDeletePageProcessorTest(final String name) {
		super(name);
	}

	EliminaChangeDeletePageProcessor processor = new EliminaChangeDeletePageProcessor();
	
	public void testEliminaChangeDeletePageProcessor_01() {
		expecting(getRequestEvent().getAttribute("currentPageNo")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("plichIds")).andReturn(false);
		expecting(getStateMachineSession().containsKey("plichDatas")).andReturn(false);
		expecting(getStateMachineSession().get("contrattiuc")).andReturn(getHashtable());
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn(getStringArray());
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn(getStringArray());
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn("1");
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn("1");
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn(null);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		processor.mapDeletePageProcessor(getRequestEvent(), getStateMachineSession());
		assertTrue(true);
	}
	
	public void testEliminaChangeDeletePageProcessor_02() {
		expecting(getRequestEvent().getAttribute("currentPageNo")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("plichIds")).andReturn(false);
		expecting(getStateMachineSession().containsKey("plichDatas")).andReturn(false);
		expecting(getStateMachineSession().get("contrattiuc")).andReturn(getHashtable());
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn(null).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		processor.mapDeletePageProcessor(getRequestEvent(), getStateMachineSession());
		assertTrue(true);
	}
	
	public void testEliminaChangeDeletePageProcessor_03() {
		expecting(getRequestEvent().getAttribute("currentPageNo")).andReturn("1").anyTimes();
		expecting(getStateMachineSession().containsKey("plichIds")).andReturn(true).anyTimes();
		expecting(getStateMachineSession().get("plichIds")).andReturn(getHashMap()).anyTimes();
		expecting(getStateMachineSession().containsKey("plichDatas")).andReturn(false).anyTimes();;
		expecting(getStateMachineSession().get("contrattiuc")).andReturn(getHashtable()).anyTimes();
		expecting(getRequestEvent().getAttribute("chkBusta10")).andReturn(null).anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		processor.mapDeletePageProcessor(getRequestEvent(), getStateMachineSession());
		assertTrue(true);
	}
	
	
	public void testEliminaChangeDeletePageProcessor_04() {
		final RequestEvent requestEvent = EasyMock.createMock(RequestEvent.class);
		expecting(requestEvent.getAttribute("currentPageNo")).andReturn("1").anyTimes();
		expecting(requestEvent.getAttribute("chkBusta10")).andReturn(null).anyTimes();
		EasyMock.replay(requestEvent);
		final StateMachineSession stateMachineSession = EasyMock.createMock(StateMachineSession.class);
		expecting(stateMachineSession.containsKey("plichIds")).andReturn(true).anyTimes();
		expecting(stateMachineSession.get("plichIds")).andReturn(getHashMap()).anyTimes();
		expecting(stateMachineSession.containsKey("plichDatas")).andReturn(false).anyTimes();;
		expecting(stateMachineSession.get("contrattiuc")).andReturn(getHashtable()).anyTimes();
		expecting(stateMachineSession.put( (String)EasyMock.anyObject(),( ArrayList) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		EasyMock.replay(stateMachineSession);
		processor.mapDeletePageProcessor(requestEvent, stateMachineSession );
		assertTrue(true);
	}
	
	private static Hashtable getHashtable() {
		final Hashtable hashtable = new Hashtable();
		hashtable.put("plichIds","1");
		hashtable.put("currentPageNo","1");
		return hashtable ;
	}
	
	private HashMap getHashMap() {
		final HashMap hashMap = new HashMap() ;
		hashMap.put("currentPageNo","1");
		return hashMap ;
	}
	
	private static String[] getStringArray() {
		final String[] strArr = new String[2];
		strArr[0]="1";
		strArr[1]="2";
		return strArr ;
	}
	
}
