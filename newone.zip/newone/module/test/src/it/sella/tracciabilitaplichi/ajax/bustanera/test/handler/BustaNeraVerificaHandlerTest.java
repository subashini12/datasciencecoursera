package it.sella.tracciabilitaplichi.ajax.bustanera.test.handler;

import it.sella.tracciabilitaplichi.ajax.bustanera.handler.BustaNeraVerificaHandler;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiHoldingDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.DBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.DBPersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TracciabilitaPlichiHoldingDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPAsserts;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.FrequentiDestinazioneCdrView;
import it.sella.tracciabilitaplichi.interfaces.dao.IBorsaVerdeDataAccess;
import it.sella.tracciabilitaplichi.test.AbstractSellaMock;
import it.sella.webutil.ajax.returntypes.ObjectSizeException;
import it.sella.webutil.ajax.returntypes.StringItemsTreeSet;

import java.util.Iterator;


public class BustaNeraVerificaHandlerTest extends AbstractSellaMock 
{
	private final IBorsaVerdeDataAccess borsaVerdeDataAccess = null;
	
    public BustaNeraVerificaHandlerTest( final String name ) {
        super( name );
    }

    final BustaNeraVerificaHandler bustaNeraVerificaHandler = new BustaNeraVerificaHandler( );
    
    @Override
	protected void setUp( ) throws Exception {
        super.setUp( );
        TPAsserts.assertPojoGetterSetter(FrequentiDestinazioneCdrView.class);
        setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class );
    	setUpMockMethods(DBPersonaleWrapper.class, DBPersonaleWrapperMock.class);
    	setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
    	setUpMockMethods(TPUtil.class, TPUtilMock.class);
    	setUpMockMethods(Util.class, UtilMock.class);
    	setUpMockMethods(TracciabilitaPlichiHoldingDataAccess.class, TracciabilitaPlichiHoldingDataAccessMock.class);
    }
    
    public void testGetUserOrCdrDescription( ) throws ObjectSizeException {
    	final StringItemsTreeSet actual = bustaNeraVerificaHandler.getUserOrCdrDescription("1","BAS91","BSA80");
    	final String expected = "ERROR_MESSAGE:TRPL-1089";
        for (final Iterator i = actual.iterator(); i.hasNext(); ){
        	final String actuals = (String)i.next();
        	if("ERROR_MESSAGE:TRPL-1089".equals(actuals )){
        		assertEquals(expected, actuals);
        	}
        }
    }
    
    public void testGetUserOrCdrDescription_01() {
    	UtilMock.setNotSelectedCdr();
    	assertNotNull(bustaNeraVerificaHandler.getUserOrCdrDescription("1"));
    }

    public void testGetUserOrCdrDescription_02() {
    	UtilMock.setNotSelectedCdr();
    	assertNotNull(bustaNeraVerificaHandler.getUserOrCdrDescription("1"));
    }

    public void testGetUserOrCdrDescription_03() {
    	UtilMock.setNotSelectedCdr();
    	UtilMock.setCheckNullFalse();
    	assertNotNull(bustaNeraVerificaHandler.getUserOrCdrDescription("1"));
    }
    
}
