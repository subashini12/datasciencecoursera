/*
package it.sella.tracciabilitaplichi.implementation.admin.test;

import it.sella.sql.ConnectionLifecycle;
import it.sella.tracciabilitaplichi.implementation.admin.SollecitiHeaderAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.util.MockRunnerConnection;
import it.sella.tracciabilitaplichi.implementation.mock.view.TPViewMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TPView;
import it.sella.tracciabilitaplichi.implementation.view.TpTrSollecitiHeaderView;

import java.util.Date;

import mockit.Mockit;

import com.mockrunner.jdbc.BasicJDBCTestCaseAdapter;
import com.mockrunner.jdbc.PreparedStatementResultSetHandler;
import com.mockrunner.mock.jdbc.MockConnection;
import com.mockrunner.mock.jdbc.MockResultSet;


public class SollecitiHeaderAdminImplTest extends BasicJDBCTestCaseAdapter {
	SollecitiHeaderAdminImpl sollecitiHeaderAdminImpl=new SollecitiHeaderAdminImpl();
	
	public void testModificaSollecitiHeader_01()
	{
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		Mockit.setUpMock(ConnectionLifecycle.class, ConnectionLifecycle.class);
		final MockConnection connection = getJDBCMockObjectFactory()
				.getMockConnection();
		final PreparedStatementResultSetHandler statementHandler = connection
				.getPreparedStatementResultSetHandler();
		final MockResultSet result = statementHandler.createResultSet();
		MockRunnerConnection.setConnection(connection);
		result.addColumn("SH_SM_ID" ,new Object[] { "1" });
		result.addColumn("SH_SENDER");
		result.addColumn("SH_RECIPIENT");
		result.addColumn("SH_CC");
		result.addColumn("SH_MAIL_TYPE");
		result.addColumn("SH_STATUS");
		result.addColumn("SH_DATE");
		result.addColumn("SH_BANK_ID");
		result.addColumn("SH_DISABLED");
		result.addColumn("SH_ID");
		statementHandler.prepareGlobalResultSet(result);
		final TpTrSollecitiHeaderView tpTrSollecitiHeaderView = new TpTrSollecitiHeaderView();
		tpTrSollecitiHeaderView.setShId(2L);
		try {
			sollecitiHeaderAdminImpl.modificaSollecitiHeader(tpTrSollecitiHeaderView);
			
		} catch (final TracciabilitaException e) {
		}
	}
	
	public void testCensitoOggetto_01()
	{
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final TpTrSollecitiHeaderView tpTrSollecitiHeaderView = getTpTrSollecitiHeaderView();
		sollecitiHeaderAdminImpl.censitoOggetto(tpTrSollecitiHeaderView);
	}
	

	public void testCancelliOggetto_02()
	{
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final TpTrSollecitiHeaderView tpTrSollecitiHeaderView = getTpTrSollecitiHeaderView();
		sollecitiHeaderAdminImpl.cancelliOggetto(tpTrSollecitiHeaderView);
	}
	
	public void testModificaOggetto_02()
	{
		Mockit.setUpMock(TPView.class, TPViewMock.class);
		final TpTrSollecitiHeaderView tpTrSollecitiHeaderView = getTpTrSollecitiHeaderView();
		sollecitiHeaderAdminImpl.modificaOggetto(tpTrSollecitiHeaderView);
	}
	
	
	private static TpTrSollecitiHeaderView getTpTrSollecitiHeaderView()
	{
		final TpTrSollecitiHeaderView tpTrSollecitiHeaderView = new TpTrSollecitiHeaderView();
		tpTrSollecitiHeaderView.setShBankId(2L);
		tpTrSollecitiHeaderView.setShSmId(2L);
		tpTrSollecitiHeaderView.setShId(2L);
		tpTrSollecitiHeaderView.setShSender("");
		tpTrSollecitiHeaderView.setShRecipient("");
		tpTrSollecitiHeaderView.setShCc("");
		tpTrSollecitiHeaderView.setShMailType(2L);
		tpTrSollecitiHeaderView.setShStatus("2");
		tpTrSollecitiHeaderView.setShDisabled("N");
		final Date date=new Date(2012, 02, 02);
		tpTrSollecitiHeaderView.setShDate(date);
		return tpTrSollecitiHeaderView;
	}
	
}*/