package it.sella.tracciabilitaplichi.implementation.bustadieci.test.inserimento;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.implementation.bustadieci.inserimento.InserimentoContrattiViewHelper;

import java.util.Map;

import mockit.Mock;

public class InserimentoContrattiViewHelperMock {
	@Mock
	public InserimentoContrattiViewHelper flattenResponse( final Map<Enum<CONSTANTS>, Object> sessionMap )
	{
		return new InserimentoContrattiViewHelper( );
	}

}
