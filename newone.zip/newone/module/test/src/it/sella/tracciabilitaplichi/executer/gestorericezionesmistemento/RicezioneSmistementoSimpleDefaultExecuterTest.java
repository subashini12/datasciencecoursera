package it.sella.tracciabilitaplichi.executer.gestorericezionesmistemento;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ClassificazioneWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.ClassificazioneWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;

import java.io.Serializable;
import java.util.Hashtable;

import org.easymock.EasyMock;

public class RicezioneSmistementoSimpleDefaultExecuterTest extends AbstractSellaExecuterMock{

	public RicezioneSmistementoSimpleDefaultExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	RicezioneSmistementoSimpleDefaultExecuter executer =  new RicezioneSmistementoSimpleDefaultExecuter();
	
	public void testExecuter_01(){
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(false).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().remove( "BustaNeraBackUpCollection" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "BustaNeraMainCollection" ) ).andReturn(null).anyTimes();
		playAll();
		final ExecuteResult actual = executer.execute(getRequestEvent());
		assertEquals( "TrConferma", actual.getTransition( ) );
	}
	public void testExecuter_02(){
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(true).anyTimes();
		expecting( getStateMachineSession().get("RicezioneSmistementoHashTable")).andReturn(new Hashtable()).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );
		expecting( getStateMachineSession().remove( "BustaNeraBackUpCollection" ) ).andReturn(null).anyTimes();
		expecting( getStateMachineSession().remove( "BustaNeraMainCollection" ) ).andReturn(null).anyTimes();
		playAll();
		final ExecuteResult actual = executer.execute(getRequestEvent());
		assertEquals( "TrConferma", actual.getTransition( ) );
	}
	
	public void testExecuter_03(){
		ClassificazioneWrapperMock.setTracciabilitaException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(false).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );	
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
        assertEquals( "it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException", executeResult.getException( ).toString() );
		
	}
	public void testExecuter_04(){
		ClassificazioneWrapperMock.setRemoteException();
		setUpMockMethods( SecurityWrapper.class, SecurityWrapperMock.class );
		setUpMockMethods( ClassificazioneWrapper.class,ClassificazioneWrapperMock.class);
		expecting(getStateMachineSession().containsKey("RicezioneSmistementoHashTable")).andReturn(false).anyTimes();
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(), ( Serializable )  EasyMock.anyObject() ) ).andReturn( null );	
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );
	}
}
