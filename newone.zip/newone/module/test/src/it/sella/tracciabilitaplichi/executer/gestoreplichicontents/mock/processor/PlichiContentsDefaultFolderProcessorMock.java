package it.sella.tracciabilitaplichi.executer.gestoreplichicontents.mock.processor;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;

import java.rmi.RemoteException;
import java.util.List;

import mockit.Mock;

public class PlichiContentsDefaultFolderProcessorMock {
	
	@Mock
	public static void removeNotAllowedStatuses( final List statusList, final TracciabilitaPlichiView tracciabilitaPlichiView ) throws TracciabilitaException, RemoteException
    {
		return ;
    }

}
