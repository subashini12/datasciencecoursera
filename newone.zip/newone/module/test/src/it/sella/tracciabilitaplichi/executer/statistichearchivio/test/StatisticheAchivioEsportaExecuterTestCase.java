package it.sella.tracciabilitaplichi.executer.statistichearchivio.test;

import it.sella.tracciabilitaplichi.executer.statistichearchivio.StatisticheAchivioEsportaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.executer.test.pdfgenerator.SecurityDBpersonaleWrapperMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityDBPersonaleWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiStatusDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.log.LogEvent;

import org.easymock.EasyMock;


public class StatisticheAchivioEsportaExecuterTestCase extends AbstractSellaExecuterMock
{
	StatisticheAchivioEsportaExecuter statisticheAchivioEsportaExecuter = new StatisticheAchivioEsportaExecuter();
	public StatisticheAchivioEsportaExecuterTestCase(final String name) {
		super(name);
	}
 
	public void testStatisticheAchivioEsportaExecuter_01()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		setUpMockMethods(TracciabilitaPlichiStatusDataAccess.class, TracciabilitaPlichiStatusDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("CreazioneFromDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("CreazioneTillDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("RicezioneFromDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("RicezioneTillDate"))
				.andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		statisticheAchivioEsportaExecuter.execute(getRequestEvent());
	}
	
	public void testStatisticheAchivioEsportaExecuter_02()
	{
		TPStatistichArchivioDataAccessMock.setTracciabilitaException();
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("CreazioneFromDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("CreazioneTillDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("RicezioneFromDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("RicezioneTillDate"))
				.andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		statisticheAchivioEsportaExecuter.execute(getRequestEvent());
	}
	
	public void testStatisticheAchivioEsportaExecuter_03()
	{
		TPStatistichArchivioDataAccessMock.setRemoteException();
		setUpMockMethods(SecurityDBPersonaleWrapper.class, SecurityDBpersonaleWrapperMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		expecting(getRequestEvent().getAttribute("CreazioneFromDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("CreazioneTillDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("RicezioneFromDate"))
				.andReturn("");
		expecting(getRequestEvent().getAttribute("RicezioneTillDate"))
				.andReturn("");
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		statisticheAchivioEsportaExecuter.execute(getRequestEvent());
	}

	
}


