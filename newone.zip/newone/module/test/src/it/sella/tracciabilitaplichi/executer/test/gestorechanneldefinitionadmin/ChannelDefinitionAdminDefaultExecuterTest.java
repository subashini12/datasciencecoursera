package it.sella.tracciabilitaplichi.executer.test.gestorechanneldefinitionadmin;

import it.sella.tracciabilitaplichi.executer.gestorechanneldefinitionadmin.ChannelDefinitionAdminDefaultExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPMultiChannelDataAccessMock;

import java.util.Map;

import org.easymock.EasyMock;

public class ChannelDefinitionAdminDefaultExecuterTest extends AbstractSellaExecuterMock
{
	
	ChannelDefinitionAdminDefaultExecuter executer = new ChannelDefinitionAdminDefaultExecuter();

    public ChannelDefinitionAdminDefaultExecuterTest( final String name )
    {
        super( name );
    }
    
    public void testChannelDefinitionAdminDefaultExecuter_01()
    {
    	setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
    	expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
    	playAll();
    	executer.execute(getRequestEvent());
    }
    
    public void testChannelDefinitionAdminDefaultExecuter_02s()
    {
    	TPMultiChannelDataAccessMock.setTracciabilitaException();
    	setUpMockMethods(TPMultiChannelDataAccess.class, TPMultiChannelDataAccessMock.class);
    	expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
    	playAll();
    	executer.execute(getRequestEvent());
    }
    
}
