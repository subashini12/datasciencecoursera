package it.sella.tracciabilitaplichi.executer.test.bustadeiciadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.bustadeiciadmin.GestProdottiAdminExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPProdottiDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.view.ProdottiView;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class GestProdottiAdminExecuterTest extends AbstractSellaExecuterMock {

    public GestProdottiAdminExecuterTest( String name )
    {
        super( name );
    }
    GestProdottiAdminExecuter gestProdottiAdminExecuter =  new GestProdottiAdminExecuter(); 
 
    public void testGestProdottiAdminDefaultExecuterTest_01(){
        expecting(getRequestEvent().getEventName( )).andReturn("ShowProdottiDetails").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("123");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(123), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","123")).andReturn("123").anyTimes();
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( null, executeResult.getAttribute( "PR_FLAG" ) );
        assertEquals( "123", executeResult.getAttribute( "selectedProdottiId" ) );
    }

    public void testGestProdottiAdminDefaultExecuterTest_02(){
        expecting(getRequestEvent().getEventName( )).andReturn("ShowProdottiDetails").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("-1");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( "-1", executeResult.getAttribute( "selectedProdottiId" ) );
    }
    
    public void testGestProdottiAdminDefaultExecuterTest_03(){
        expecting(getRequestEvent().getEventName( )).andReturn("Conferma").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("-1");
        expecting(getRequestEvent().getAttribute("ProdottiCode")).andReturn("");
        expecting(getRequestEvent().getAttribute("ProdottiDesc")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiFlag")).andReturn("22");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().get("prodottiSelectedView")).andReturn(view).anyTimes();
        expecting(getStateMachineSession().get("selectedProdottiId")).andReturn("22").anyTimes();
        expecting(getStateMachineSession().containsKey( "ProdottiCollection" )).andReturn(true).anyTimes();
        expecting(getStateMachineSession().containsKey( "selectedProdottiId" )).andReturn(true).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( "TRPL-1060", executeResult.getAttribute( "MSG" ) );
    }
    
    public void testGestProdottiAdminDefaultExecuterTest_04(){
        expecting(getRequestEvent().getEventName( )).andReturn("Conferma").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("-1");
        expecting(getRequestEvent().getAttribute("ProdottiCode")).andReturn("35");
        expecting(getRequestEvent().getAttribute("ProdottiDesc")).andReturn("");
        expecting(getRequestEvent().getAttribute("ProdottiFlag")).andReturn("22");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().get("prodottiSelectedView")).andReturn(view).anyTimes();
        expecting(getStateMachineSession().get("selectedProdottiId")).andReturn("22").anyTimes();
        expecting(getStateMachineSession().containsKey( "ProdottiCollection" )).andReturn(true).anyTimes();
        expecting(getStateMachineSession().containsKey( "selectedProdottiId" )).andReturn(true).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( "TRPL-1080", executeResult.getAttribute( "MSG" ) );
    }
    public void testGestProdottiAdminDefaultExecuterTest_05(){
        expecting(getRequestEvent().getEventName( )).andReturn("Conferma").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("-1");
        expecting(getRequestEvent().getAttribute("ProdottiCode")).andReturn("-22");
        expecting(getRequestEvent().getAttribute("ProdottiDesc")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiFlag")).andReturn("");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().get("prodottiSelectedView")).andReturn(view).anyTimes();
        expecting(getStateMachineSession().get("selectedProdottiId")).andReturn("22").anyTimes();
        expecting(getStateMachineSession().containsKey( "ProdottiCollection" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().containsKey( "selectedProdottiId" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
    }
    public void testGestProdottiAdminDefaultExecuterTest_06(){
        expecting(getRequestEvent().getEventName( )).andReturn("Conferma").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("-1");
        expecting(getRequestEvent().getAttribute("ProdottiCode")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiDesc")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiFlag")).andReturn("-1");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().get("prodottiSelectedView")).andReturn(view).anyTimes();
        expecting(getStateMachineSession().get("selectedProdottiId")).andReturn("22").anyTimes();
        expecting(getStateMachineSession().containsKey( "ProdottiCollection" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().containsKey( "selectedProdottiId" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( "TRPL-1403", executeResult.getAttribute( "MSG" ) );
    }
    
    public void testGestProdottiAdminDefaultExecuterTest_07(){
        expecting(getRequestEvent().getEventName( )).andReturn("Conferma").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("-1");
        expecting(getRequestEvent().getAttribute("ProdottiCode")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiDesc")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiFlag")).andReturn("");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().get("prodottiSelectedView")).andReturn(view).anyTimes();
        expecting(getStateMachineSession().get("selectedProdottiId")).andReturn("22").anyTimes();
        expecting(getStateMachineSession().containsKey( "ProdottiCollection" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().containsKey( "selectedProdottiId" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( "TRPL-1340", executeResult.getAttribute( "MSG" ) );
    }
    public void testGestProdottiAdminDefaultExecuterTest_08(){
        expecting(getRequestEvent().getEventName( )).andReturn("Conferma").anyTimes( );
        expecting(getRequestEvent().getAttribute("ProdottiID")).andReturn("33");
        expecting(getRequestEvent().getAttribute("ProdottiCode")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiDesc")).andReturn("22");
        expecting(getRequestEvent().getAttribute("ProdottiFlag")).andReturn("");
        Map prodottiCollection =  new HashMap();
        ProdottiView view = new ProdottiView();
        prodottiCollection.put( new Long(-1), new ProdottiView());
        expecting(getStateMachineSession().get("ProdottiCollection")).andReturn((Serializable)prodottiCollection).anyTimes();
        expecting(getStateMachineSession().get("prodottiSelectedView")).andReturn(view).anyTimes();
        expecting(getStateMachineSession().get("selectedProdottiId")).andReturn("22").anyTimes();
        expecting(getStateMachineSession().containsKey( "ProdottiCollection" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().containsKey( "selectedProdottiId" )).andReturn(false).anyTimes();
        expecting(getStateMachineSession().put("prodottiSelectedView",view)).andReturn(view).anyTimes();
        expecting(getStateMachineSession().put("selectedProdottiId","-1")).andReturn("-1").anyTimes();
        setUpMockMethods(TPProdottiDataAccess.class, TPProdottiDataAccessMock.class);
        playAll( );
        ExecuteResult executeResult = gestProdottiAdminExecuter.execute(getRequestEvent());
        assertEquals( "TRPL-1340", executeResult.getAttribute( "MSG" ) );
    }
    
}
