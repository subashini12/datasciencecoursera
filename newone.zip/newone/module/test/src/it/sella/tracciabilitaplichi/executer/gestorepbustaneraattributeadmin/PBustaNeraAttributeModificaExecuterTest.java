package it.sella.tracciabilitaplichi.executer.gestorepbustaneraattributeadmin;

import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiAdminTransactionDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.dao.TracciabilitaPlichiAdminTransactionDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.implementation.util.Util;

import java.util.Map;

import org.easymock.EasyMock;



public class PBustaNeraAttributeModificaExecuterTest extends AbstractSellaExecuterMock{

	public PBustaNeraAttributeModificaExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	PBustaNeraAttributeModificaExecuter executer=new PBustaNeraAttributeModificaExecuter();
	

	public void testPBustaNeraAttributeModificaExecuter_01()
	{
		TPUtilMock.setValidateDate(1);
		UtilMock.setNotValidAmountFalse();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("2");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("4");
		expecting(getRequestEvent().getAttribute("date")).andReturn("12/05/2012");
		expecting(getRequestEvent().getAttribute("description")).andReturn("A");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("2");
		expecting(getRequestEvent().getAttribute("note")).andReturn("Hai");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPBustaNeraAttributeModificaExecuter_07()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("2");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("4");
		expecting(getRequestEvent().getAttribute("date")).andReturn("12/05/2012");
		expecting(getRequestEvent().getAttribute("description")).andReturn("A");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("2");
		expecting(getRequestEvent().getAttribute("note")).andReturn("Hai");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPBustaNeraAttributeModificaExecuter_06()
	{
		TracciabilitaPlichiAdminTransactionDataAccessMock.setValidRefIdFalse();
		TPUtilMock.setValidateDate(1);
		UtilMock.setNotValidAmountFalse();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("2");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("4");
		expecting(getRequestEvent().getAttribute("date")).andReturn("12/05/2012");
		expecting(getRequestEvent().getAttribute("description")).andReturn("A");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("2");
		expecting(getRequestEvent().getAttribute("note")).andReturn("Hai");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPBustaNeraAttributeModificaExecuter_05()
	{
		TPUtilMock.setValidateDate(2);
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("2");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("4");
		expecting(getRequestEvent().getAttribute("date")).andReturn("12/05/2012");
		expecting(getRequestEvent().getAttribute("description")).andReturn("A");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("2");
		expecting(getRequestEvent().getAttribute("note")).andReturn("Hai");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPBustaNeraAttributeModificaExecuter_02()
	{
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("2");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("4");
		expecting(getRequestEvent().getAttribute("date")).andReturn("12/05/2012");
		expecting(getRequestEvent().getAttribute("description")).andReturn("");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("2");
		expecting(getRequestEvent().getAttribute("note")).andReturn("Hai");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPBustaNeraAttributeModificaExecuter_03()
	{
		setUpMockMethods(Util.class, UtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("A");
		expecting(getRequestEvent().getAttribute("date")).andReturn("");
		expecting(getRequestEvent().getAttribute("description")).andReturn("");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("");
		expecting(getRequestEvent().getAttribute("note")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testPBustaNeraAttributeModificaExecuter_04()
	{
		UtilMock.setNumericFalse();
		setUpMockMethods(TracciabilitaPlichiAdminTransactionDataAccess.class, TracciabilitaPlichiAdminTransactionDataAccessMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( Map) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("id")).andReturn("2");
		expecting(getRequestEvent().getAttribute("docId")).andReturn("4");
		expecting(getRequestEvent().getAttribute("date")).andReturn("12/05/2012");
		expecting(getRequestEvent().getAttribute("description")).andReturn("");
		expecting(getRequestEvent().getAttribute("importo")).andReturn("2");
		expecting(getRequestEvent().getAttribute("importoDec")).andReturn("2");
		expecting(getRequestEvent().getAttribute("note")).andReturn("Hai");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	}
