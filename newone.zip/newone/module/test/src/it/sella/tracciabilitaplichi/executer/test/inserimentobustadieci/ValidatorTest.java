/*package it.sella.tracciabilitaplichi.executer.test.inserimentobustadieci;

import it.sella.tracciabilitaplichi.IErrorCodes;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.enumaration.STATUS;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.InputHandler;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.InputHandlerMock;
import it.sella.tracciabilitaplichi.executer.inserimentobustadieci.Validator;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.externalsystem.ACFWWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.AnagraficiWrapper;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaExternalServicesException;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciContrattiView;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;
import it.sella.tracciabilitaplichi.implementation.view.OggettoView;
import it.sella.tracciabilitaplichi.interfaces.dao.IBustaDieciDataAccess;
import it.sella.tracciabilitaplichi.persistence.dao.AbstractDAOFactory;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import mockit.Mock;

public class ValidatorTest extends AbstractSellaExecuterTest 
{
	
	private static final String BARCODE = "1044000000720";
	private static final String distinctCP = "2826";
	private IBustaDieciDataAccess b10DAO = null;
	
	public ValidatorTest( final String name )
	{
		super( name );
	}
	
	@Override
	protected void setUp( ) throws Exception
	{
		super.setUp( );
		b10DAO = getMock( IBustaDieciDataAccess.class );
		redefineMethod( AbstractDAOFactory.class, new Object( ) { 
			public IBustaDieciDataAccess getBustaDieciDataAccess( )
			{
				return b10DAO;
			}
		} );
		setUpMockMethods(InputHandler.class, InputHandlerMock.class);
		setUpMockMethods(SecurityWrapper.class,SecurityWrapperMock.class);
	}
	
	
	public void testValidateContratti(){
		Validator.getInstance( ).validateContratti();
	}
	
	public void testValidateBarcode_1( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		playAll( );
		try 
		{
			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertFalse( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
		
	}

	public void testValidateBarcode_2( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		playAll( );
		try 
		{
			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertFalse( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
		
	}
	
	public void testValidateBarcode_2A( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		playAll( );
		try 
		{
			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertFalse( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( "9010000000024", ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1687, ( String ) sessionMap.get( CONSTANTS.MSG ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
		
	}

	public void testValidateBarcode_2B( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		playAll( );
		try 
		{
			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertFalse( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( "9011000000038", ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1687, ( String ) sessionMap.get( CONSTANTS.MSG ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
		
	}
	
	public void testValidateBarcode_3( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.FALSE, null, null, null, null, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1683, ( String ) sessionMap.get( CONSTANTS.MSG ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}
	
	// fuori sede case
	public void testValidateBarcode_4( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, null, Boolean.TRUE ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1681, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}
	
	
	// preparata and nil automated case (TRPL-1686)
	public void testValidateBarcode_5( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, null, null, Boolean.TRUE, null, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertFalse( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1686, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}
	
	// Inserito in Plico case -- need to change it
	public void testValidateBarcode_6( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, null, null, null, Boolean.TRUE, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1682, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}
	
	// distinct tipologia and one automated contract case
	public void testValidateBarcode_7( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, null, null, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
			final BustaDeiciContrattiView b10View = ( BustaDeiciContrattiView ) sessionMap.get( CONSTANTS.B10_CONTRATTI_ATTR_VIEW  );
			assertEquals( Long.valueOf( 3L ), b10View.getBustaDeiciAttributeView( ).getBustaDeiciId( ) );
			assertEquals( distinctCP, b10View.getBustaDeiciAttributeView( ).getCodProdottoContratto( ) );
			assertEquals( Long.valueOf( -1L ), b10View.getBustaDeiciAttributeView( ).getIdCanale( ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}
	
	// distinct tipologia and automated empty case
	public void testValidateBarcode_8( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, Boolean.TRUE, null, null, null, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
			final BustaDeiciContrattiView b10View = ( BustaDeiciContrattiView ) sessionMap.get( CONSTANTS.B10_CONTRATTI_ATTR_VIEW  );
			assertEquals( Long.valueOf( 3L ), b10View.getBustaDeiciAttributeView( ).getBustaDeiciId( ) );
			assertEquals( distinctCP, b10View.getBustaDeiciAttributeView( ).getCodProdottoContratto( ) );
			assertEquals( Long.valueOf( 0L ), b10View.getBustaDeiciAttributeView( ).getIdCanale( ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}

	// different tipologia and one automated case
	public void testValidateBarcode_9( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, Boolean.FALSE, Boolean.TRUE, null, null, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
			final BustaDeiciContrattiView b10View = ( BustaDeiciContrattiView ) sessionMap.get( CONSTANTS.B10_CONTRATTI_ATTR_VIEW  );
			assertEquals( Long.valueOf( 3L ), b10View.getBustaDeiciAttributeView( ).getBustaDeiciId( ) );
			assertEquals( "2810", b10View.getBustaDeiciAttributeView( ).getCodProdottoContratto( ) );
			assertEquals( Long.valueOf( -1L ), b10View.getBustaDeiciAttributeView( ).getIdCanale( ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}
	
	// different tipologia and empty automated case	
	public void testValidateBarcode_10( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		try 
		{
			expecting( b10DAO.getBustaDieciContrattiViewColl( BARCODE, Long.valueOf( 1L ) ) ).andReturn( getB10ContrattiColl( Boolean.TRUE, Boolean.FALSE, null, null, null, null ) );
			playAll( );
			play( b10DAO );

			Validator.getInstance( ).validateBarcode( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VALID_BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertEquals( IErrorCodes.TRPL_1681, sessionMap.get( CONSTANTS.MSG ) );
			assertFalse( sessionMap.containsKey( CONSTANTS.B10_CONTRATTI_ATTR_VIEW ) );
		} 
		catch ( final RemoteException remoteException ) 
		{

		} 
		catch ( final TracciabilitaException tracciabilitaException ) 
		{

		}
	}

	public void testValidateContratti_1( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		playAll( );
		
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1625, ( String ) sessionMap.get( CONSTANTS.MSG ) ); 
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}
	
	public void testValidateContratti_2( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		playAll( );
		
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1396, ( String ) sessionMap.get( CONSTANTS.MSG ) ); 
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}
	

	public void testValidateContratti_3( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockACFWWrapper( null, null, Boolean.TRUE );
		playAll( );
		
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1396, ( String ) sessionMap.get( CONSTANTS.MSG ) ); 
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}

	public void testValidateContratti_4( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockACFWWrapper( Long.valueOf( 1L ), Boolean.FALSE, Boolean.FALSE );
		playAll( );
		
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1396, ( String ) sessionMap.get( CONSTANTS.MSG ) ); 
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );	
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}

	public void testValidateContratti_5( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockAnagraficiWrapper( null );
		playAll( );
		
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1561, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}


	public void testValidateContratti_6( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockACFWWrapper( Long.valueOf( 1L ), Boolean.TRUE, Boolean.FALSE );
		playAll( );
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1624, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}

	public void testValidateContratti_7( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockAnagraficiWrapper(  Long.valueOf( 1l ) );
		playAll( );
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1506, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}

	public void testValidateContratti_7A( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockAnagraficiWrapper(  Long.valueOf( 1l ) );
		mockTpCpDAO( Boolean.FALSE );
		playAll( );
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1365, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}

	public void testValidateContratti_8( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockAnagraficiWrapper(  Long.valueOf( 1l ) );
		mockTpCpDAO( Boolean.TRUE );
		playAll( );
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.MSG ) );
			assertEquals( IErrorCodes.TRPL_1372, ( String ) sessionMap.get( CONSTANTS.MSG ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}
	
	public void testValidateContratti_9( )
	{
		final Map<Enum<CONSTANTS>, Object> sessionMap = new HashMap<Enum<CONSTANTS>, Object>( );
		sessionMap.put( CONSTANTS.BARCODE, BARCODE );
		expecting( getStateMachineSession( ).containsKey( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( Boolean.TRUE ).anyTimes( );
		expecting( getStateMachineSession( ).get( CONSTANTS.CONTRATTI_INSERIMENTO_MAP.toString( ) ) ).andReturn( ( Serializable ) sessionMap ).anyTimes( );
		mockAnagraficiWrapper(  Long.valueOf( 1l ) );
		mockTpCpDAO( Boolean.TRUE );
		playAll( );
		try
		{
			Validator.getInstance( ).validateContratti( getRequestEvent( ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.BARCODE ) );
			assertEquals( BARCODE, ( String ) sessionMap.get( CONSTANTS.BARCODE ) );
			assertTrue( ( Boolean ) sessionMap.get( CONSTANTS.VALID_BARCODE ) );
			assertTrue( sessionMap.containsKey( CONSTANTS.VIEW_MAP ) );
			final Map<Enum<CONSTANTS>, String> viewMap = ( Map<Enum<CONSTANTS>, String> ) sessionMap.get( CONSTANTS.VIEW_MAP );
			assertTrue( viewMap.containsKey( CONSTANTS.TIPO_CONTRATTI ) );
			assertEquals( "2810", viewMap.get( CONSTANTS.TIPO_CONTRATTI ) );
			
		}
		catch ( final RemoteException remoteException )	{ }
		catch ( final TracciabilitaException tracciabilitaException ) { }
	}


	private void mockInputHandler_1( final Boolean isValid, final Boolean isEmpty )
	{
		redefineMethod( InputHandler.class, new Object( ) { 
		    @Mock
			public String getBarcode( final RequestEvent requestEvent )
			{
				return isValid ? BARCODE :  isEmpty ? "" : "1234453232234";
			}
		} );
	}
	
	private void mockInputHandler_1A( final String barcodePrefix )
	{
		redefineMethod( InputHandler.class, new Object( ) { 
		    @Mock
			public String getBarcode( final RequestEvent requestEvent )
			{
				return CONSTANTS.APT_BARCODE_PREFIX1.getValue( ).equals( barcodePrefix ) ? "9010000000024" : "9011000000038";
			}
		} );
	}
	
	private void mockInputHandler_2( final Boolean isNC, final Boolean isValidCifre, final Boolean isMacroCategoria, final Boolean isTipoContratti, final Boolean isAnagrafica )
	{
		final CONSTANTS[ ] formParams = new CONSTANTS[ ] { CONSTANTS.BARCODE, CONSTANTS.BRANCH_CODE, CONSTANTS.TIPO_CONTO, CONSTANTS.OTTOCIFRE, CONSTANTS.MILLESIMO, CONSTANTS.CONTRATTI_MACRO_CATEGORIA, CONSTANTS.TIPO_CONTRATTI, CONSTANTS.ANAGRAFICA };
		redefineMethod( InputHandler.class, new Object( ) { 
		    @Mock
			public Map<Enum<CONSTANTS>, String> getInserimentoContrattiInputParams( final RequestEvent requestEvent )
			{
				final Map<Enum<CONSTANTS>, String> inputMap = new HashMap<Enum<CONSTANTS>, String>( );
				inputMap.put( CONSTANTS.BARCODE, BARCODE );
				inputMap.put( CONSTANTS.BRANCH_CODE, "" );
				inputMap.put( CONSTANTS.TIPO_CONTO, "" );
				inputMap.put( CONSTANTS.OTTOCIFRE, "" );
				inputMap.put( CONSTANTS.MILLESIMO, "" );
				inputMap.put( CONSTANTS.CONTRATTI_MACRO_CATEGORIA, "-1" );
				inputMap.put( CONSTANTS.TIPO_CONTRATTI, CONSTANTS.SELEZIONA.getValue( ) );
				inputMap.put( CONSTANTS.ANAGRAFICA, "" );
				if ( isNC )
				{
					if ( isValidCifre )
					{
						inputMap.put( CONSTANTS.BRANCH_CODE, "T1" );
						inputMap.put( CONSTANTS.TIPO_CONTO, "A9" );
						inputMap.put( CONSTANTS.OTTOCIFRE, "67983767" );
						inputMap.put( CONSTANTS.MILLESIMO, "0" );
					}
					else
					{
						inputMap.put( CONSTANTS.BRANCH_CODE, "T1" );
						inputMap.put( CONSTANTS.TIPO_CONTO, "A9" );
						inputMap.put( CONSTANTS.OTTOCIFRE, "67983767" );
						inputMap.put( CONSTANTS.MILLESIMO, "" );
					}
				}
				else if ( isValidCifre )
				{
					inputMap.put( CONSTANTS.OTTOCIFRE, "67983767" );
				}
				if ( isMacroCategoria ) 
				{
					inputMap.put( CONSTANTS.CONTRATTI_MACRO_CATEGORIA, "26" );
				}
				if ( isTipoContratti )
				{
					inputMap.put( CONSTANTS.TIPO_CONTRATTI, "10" );
				}
				if ( isAnagrafica )
				{
					inputMap.put( CONSTANTS.ANAGRAFICA, "ANAGRAFE" );
				}
				inputMap.put( CONSTANTS.NUMEROCONTO, inputMap.get( CONSTANTS.BRANCH_CODE ).concat( inputMap.get( CONSTANTS.TIPO_CONTO ) ).concat( inputMap.get( CONSTANTS.OTTOCIFRE ) ).concat( inputMap.get( CONSTANTS.MILLESIMO ) ) );
				return inputMap;
			}
		} );
	}

	
	private void mockSecurityWrapper( )
	{
		redefineMethod( SecurityWrapper.class, new Object( ) { 
		    @Mock
			public String getBankABICode( )
			{
				return "03268";
			}
		    @Mock
			public String getDenominazioneCdr( )
			{
				return "099361";
			}
		    @Mock
			public String getLid( )
			{
				return "859";
			}
		    @Mock
			public String getUserId( )
			{
				return "BSQI78";
			}
		    @Mock
			public Long getBankId( ) 
			{
				return Long.valueOf( 1L );
			}
		} );
	}

	private Collection<BustaDeiciContrattiView> getB10ContrattiColl( final Boolean isNotEmtpy, final Boolean isDistincTipologia, final Boolean isAutomatedAvailable, final Boolean isInPreparata, final Boolean isInseritoInPlico, final Boolean isMoreAutomated )
	{
		final Collection<BustaDeiciContrattiView> b10ContrattiColl = new ArrayList<BustaDeiciContrattiView>( );
		if ( isNotEmtpy )
		{
			if ( Boolean.TRUE.equals( isInPreparata ) )
			{
				b10ContrattiColl.add( getB10View( STATUS.B10.PREPARATO.getValue( ), Boolean.TRUE.equals( isAutomatedAvailable ) ? Long.valueOf( -1L ) : Long.valueOf( 0L ), Boolean.TRUE.equals( isDistincTipologia ) ? distinctCP : "2822", Long.valueOf( 1L ) ) );
			}
			if ( Boolean.TRUE.equals( isInseritoInPlico ) )
			{
				b10ContrattiColl.add( getB10View( STATUS.B10.INSERITO_IN_PB10.getValue( ), Boolean.TRUE.equals( isAutomatedAvailable ) ? Long.valueOf( -1L ) : Long.valueOf( 0L ), Boolean.TRUE.equals( isDistincTipologia ) ? distinctCP : "2821", Long.valueOf( 2L ) ) );
			}
			if ( Boolean.TRUE.equals( isMoreAutomated ) )
			{
				b10ContrattiColl.add( getB10View( STATUS.B10.ARCHIVIATO.getValue( ), Boolean.TRUE.equals( isAutomatedAvailable ) ? Long.valueOf( -1L ) : Long.valueOf( 0L ), Boolean.TRUE.equals( isDistincTipologia ) ? distinctCP : "2811", Long.valueOf( 4L ) ) );				
			}
			b10ContrattiColl.add( getB10View( STATUS.B10.ARCHIVIATO.getValue( ), Boolean.TRUE.equals( isAutomatedAvailable ) ? Long.valueOf( -1L ) : Long.valueOf( 0L ), Boolean.TRUE.equals( isDistincTipologia ) ? distinctCP : "2810", Long.valueOf( 3L ) ) );
			b10ContrattiColl.add( getB10View( STATUS.B10.ARCHIVIATO.getValue( ), Long.valueOf( 0L ), Boolean.TRUE.equals( isDistincTipologia ) ? distinctCP : "2815", Long.valueOf( 6L ) ) );

		}
		return b10ContrattiColl;
	}
	
	private BustaDeiciContrattiView getB10View( final String statusType, final Long idCanale, final String codProdCont, final Long bdId )
	{
		final BustaDeiciContrattiView b10ContrattiView = new BustaDeiciContrattiView( );
		final BustaDeiciAttributeView b10AttrView = new BustaDeiciAttributeView( );
		b10AttrView.setBustaDeiciId( bdId );
		b10AttrView.setNumeroCodiceDerivati( BARCODE );
		b10AttrView.setIdCanale( idCanale );
		b10AttrView.setCodProdottoContratto( codProdCont );
		b10ContrattiView.setBustaDeiciAttributeView( b10AttrView );
		b10ContrattiView.setOggettoView( new OggettoView( ) );
		b10ContrattiView.getOggettoView( ).setStatusType( statusType );
		return b10ContrattiView;
	}
	
	private void mockACFWWrapper( final Long idConto, final Boolean isValidConto, final Boolean isException )
	{
		redefineMethod( ACFWWrapper.class, new Object( ) { 
		    @Mock
			public Long getIdConto( final String codiceConto ) throws TracciabilitaExternalServicesException, RemoteException
			{
				if ( isException ) { throw new TracciabilitaExternalServicesException( "" ); }
				return idConto;
			}
		    @Mock
			public Boolean isValidConto( final Long contoId ) {
				return isValidConto; 
			}
		} );
	}
	
	private void mockAnagraficiWrapper ( final Long soggettoId )
	{
		redefineMethod( AnagraficiWrapper.class, new Object( ) { 
		    @Mock
			public Long getSoggettoId(final String ottoCifre )
			{
				return soggettoId;
			}
		} );
	}

	private void mockTpCpDAO ( final Boolean isNotEmpty )
	{
		redefineMethod( TPContrattiProdottoDataAccess.class, new Object( ) {  
		    @Mock
			public Collection<ContrattiProdottoView> getCPViewByAbiBanca( final String abiBanca, final String flag, final String codProd, final String descrizione, final Boolean isNeededToAvoidDummy )
			{
				final Collection<ContrattiProdottoView> cpViewColl = new ArrayList<ContrattiProdottoView>( 0 );
				if ( isNotEmpty ) {
					final ContrattiProdottoView cpView = new ContrattiProdottoView( );
					cpView.setCodProdottoContratto( "2810" );
					cpViewColl.add( cpView );
				}
				return cpViewColl;
			}
		} );
	}

}
*/