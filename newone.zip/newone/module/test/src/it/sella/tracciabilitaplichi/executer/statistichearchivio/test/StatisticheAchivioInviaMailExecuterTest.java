package it.sella.tracciabilitaplichi.executer.statistichearchivio.test;


import it.sella.tracciabilitaplichi.executer.statistichearchivio.StatisticheAchivioInviaMailExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.MailHandlerMock;
import it.sella.tracciabilitaplichi.implementation.util.MailHandler;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class StatisticheAchivioInviaMailExecuterTest extends AbstractSellaExecuterMock{

	public StatisticheAchivioInviaMailExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	StatisticheAchivioInviaMailExecuter executer=new StatisticheAchivioInviaMailExecuter();
	
	public void testStatisticheAchivioInviaMailExecuter_01()
	{
		final Collection collection=getCollection();
		expecting(getRequestEvent().getAttribute("tillDate")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn(null);
		expecting(getRequestEvent().getAttribute("fromDate")).andReturn("");
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testStatisticheAchivioInviaMailExecuter_02()
	{
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(MailHandler.class, MailHandlerMock.class);
		final Collection collection=getCollection();
		expecting(getRequestEvent().getAttribute("tillDate")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("fromDate")).andReturn("");
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testStatisticheAchivioInviaMailExecuter_03()
	{
		TPStatistichArchivioDataAccessMock.setRemoteException();
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(MailHandler.class, MailHandlerMock.class);
		final Collection collection=getCollection();
		expecting(getRequestEvent().getAttribute("tillDate")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("fromDate")).andReturn("");
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testStatisticheAchivioInviaMailExecuter_04()
	{
		TPStatistichArchivioDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(MailHandler.class, MailHandlerMock.class);
		final Collection collection=getCollection();
		expecting(getRequestEvent().getAttribute("tillDate")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("fromDate")).andReturn("");
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testStatisticheAchivioInviaMailExecuter_05()
	{
		TPStatistichArchivioDataAccessMock.setNullResponsible();
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(MailHandler.class, MailHandlerMock.class);
		final Collection collection=getCollection();
		expecting(getRequestEvent().getAttribute("tillDate")).andReturn("");
		expecting(getRequestEvent().getAttribute("Cdr")).andReturn("");
		expecting(getRequestEvent().getAttribute("fromDate")).andReturn("");
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		expecting(getStateMachineSession().get("statisticheDiInviareViewColl")).andReturn((Serializable) collection);
		playAll();
		executer.execute(getRequestEvent());
	}
	private Collection getCollection()
	{
		final Collection collection=new ArrayList();
		collection.add("1");
		return collection;
	}
}
