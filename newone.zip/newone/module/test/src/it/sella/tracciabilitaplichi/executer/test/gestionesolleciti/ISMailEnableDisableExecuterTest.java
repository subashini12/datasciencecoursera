/*package it.sella.tracciabilitaplichi.executer.test.gestionesolleciti;

import it.sella.msg.MsgManager;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.executer.gestionesolleciti.ISMailEnableDisableExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.InvioSollecitiPropertiesImpl;
import it.sella.tracciabilitaplichi.implementation.InvioSollecitiPropertiesImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.UtilMock;
import it.sella.tracciabilitaplichi.implementation.util.Util;
import it.sella.tracciabilitaplichi.implementation.view.TpMaPropertiesView;
import it.sella.tracciabilitaplichi.log.InvioSollecitiLogContent;
import it.sella.tracciabilitaplichi.log.InvioSollecitiLogContentMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

public class ISMailEnableDisableExecuterTest extends AbstractSellaExecuterTest {
	public ISMailEnableDisableExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	private final ISMailEnableDisableExecuter iSMailEnableDisableExecuter = new ISMailEnableDisableExecuter();

	public void testISMailEnableDisableExecuter_01()
	{
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(InvioSollecitiLogContent.class, InvioSollecitiLogContentMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.CHECK_BOX)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		iSMailEnableDisableExecuter.execute(getRequestEvent());
	}
	
	public void testISMailEnableDisableExecuter_02()
	{
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(InvioSollecitiPropertiesImpl.class, InvioSollecitiPropertiesImplMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(InvioSollecitiLogContent.class, InvioSollecitiLogContentMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.CHECK_BOX)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		iSMailEnableDisableExecuter.execute(getRequestEvent());
	}
	
	public void testISMailEnableDisableExecuter_03()
	{
		TracciabilitaPlichiImplMock.setTracciabilitaException();
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(InvioSollecitiPropertiesImpl.class, InvioSollecitiPropertiesImplMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(InvioSollecitiLogContent.class, InvioSollecitiLogContentMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.CHECK_BOX)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		iSMailEnableDisableExecuter.execute(getRequestEvent());
	}
	
	public void testISMailEnableDisableExecuter_04()
	{
		TracciabilitaPlichiImplMock.setRemoteException();
		UtilMock.setCheckNullFalse();
		Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
		setUpMockMethods(InvioSollecitiPropertiesImpl.class, InvioSollecitiPropertiesImplMock.class);
		setUpMockMethods(LogEvent.class,LogEventMock.class );
		Mockit.setUpMock(ExternalServicesFactory.class,ExternalServicesFactoryMock.class);
		Mockit.setUpMock(MsgManagerWrapper.class,MsgManagerWrapperMock.class);
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(InvioSollecitiLogContent.class, InvioSollecitiLogContentMock.class);
		setUpMockMethods(Util.class, UtilMock.class);
		expecting(getRequestEvent().getAttribute(ITPConstants.CHECK_BOX)).andReturn("").anyTimes();
		expecting(getStateMachineSession().get(ITPConstants.GESTIONE_SOLLECITI_MAP)).andReturn((Serializable) getMap()).anyTimes();
		playAll();
		iSMailEnableDisableExecuter.execute(getRequestEvent());
	}
	private Map getMap()
	{
		final TpMaPropertiesView tpMaPropertiesView = new TpMaPropertiesView("","");
		tpMaPropertiesView.setValue(ITPConstants.DO_SEND);
		final Map map =new HashMap();
		map.put(ITPConstants.TP_MA_PROPERTIES_VIEW , tpMaPropertiesView );
		return map ;
	}
}
*/