package it.sella.tracciabilitaplichi.executer.statistichearchivio.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.statistichearchivio.StatisticheAchivioExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.util.Vector;



public class StatisticheAchivioExecuterTestCase extends AbstractSellaExecuterMock
{
	StatisticheAchivioExecuter statisticheAchivioExecuter = new StatisticheAchivioExecuter();
	public StatisticheAchivioExecuterTestCase(final String name) {
		super(name);
	}
 
	public void testStatisticheAchivioExecuter_01(){
		final String creaString = "01/01/2011";
		setUpMockMethods( LogEvent.class, LogEventMock.class);		
		expecting( getRequestEvent().getEventName()).andReturn( "PageLink" ).anyTimes();
		expecting( getRequestEvent().getAttribute("pageNo")).andReturn( "12" ).anyTimes();
		expecting( getRequestEvent().getAttribute("fromDate")).andReturn( "12/12/2009" ).anyTimes();
		expecting( getRequestEvent().getAttribute("tillDate")).andReturn( "12/12/2009" ).anyTimes();
		final Vector statisticheDiInviareViewColl = new Vector();
		expecting( getStateMachineSession().get("statisticheDiInviareViewColl") ).andReturn(statisticheDiInviareViewColl).anyTimes();
		expecting( getStateMachineSession().put("CreazioneFromDate", creaString) ).andReturn(creaString).anyTimes();
		expecting( getStateMachineSession().put("CreazioneTillDate", "12/12/2011") ).andReturn("12/12/2011").anyTimes();
		expecting( getStateMachineSession().put("RicezioneFromDate", "04/02/2011") ).andReturn("04/02/2011").anyTimes();
		expecting( getStateMachineSession().put("RicezioneTillDate", "14/02/2011") ).andReturn("14/02/2011").anyTimes();
  		playAll();
		final ExecuteResult executeResult = statisticheAchivioExecuter.execute(getRequestEvent());
		
		
	} 
	
	public void testStatisticheAchivioExecuter_02(){
		final String creaString = "01/01/2011";
		setUpMockMethods( LogEvent.class, LogEventMock.class);
		expecting( getRequestEvent().getEventName()).andReturn( "Default" ).anyTimes();		
		expecting( getStateMachineSession().get("CreazioneFromDate") ).andReturn("12/12/2011").anyTimes();
		expecting( getStateMachineSession().get("CreazioneTillDate") ).andReturn("12/12/2011").anyTimes();
		expecting( getStateMachineSession().get("RicezioneFromDate") ).andReturn("04/02/2011").anyTimes();
		expecting( getStateMachineSession().get("RicezioneTillDate") ).andReturn("14/02/2011").anyTimes();
		expecting( getStateMachineSession().get("PreparatiBusta5Size") ).andReturn(2).anyTimes();
		expecting( getStateMachineSession().get("RicezioneBusta5Size") ).andReturn(3).anyTimes();
		expecting( getStateMachineSession().get("PreparatiPBusta5Size") ).andReturn(4).anyTimes();
		expecting( getStateMachineSession().get("RicezionePBusta5Size") ).andReturn(5).anyTimes();		
		expecting( getStateMachineSession().remove("CreazioneFromDate")).andReturn( true );
		expecting( getStateMachineSession().remove("CreazioneTillDate")).andReturn( true );
		expecting( getStateMachineSession().remove("RicezioneFromDate")).andReturn( true );
		expecting( getStateMachineSession().remove("RicezioneTillDate")).andReturn( true );
		expecting( getStateMachineSession().remove("preparatiBusta5Size")).andReturn( true );
		expecting( getStateMachineSession().remove("ricezioneBusta5Size")).andReturn( true );
		expecting( getStateMachineSession().remove("preparatiPBusta5Size")).andReturn( true );
		expecting( getStateMachineSession().remove("ricezionePBusta5Size")).andReturn( true );		
  		playAll();
		final ExecuteResult executeResult = statisticheAchivioExecuter.execute(getRequestEvent());
		
		
	} 
}