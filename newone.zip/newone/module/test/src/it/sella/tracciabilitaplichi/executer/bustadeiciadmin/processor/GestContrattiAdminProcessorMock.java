package it.sella.tracciabilitaplichi.executer.bustadeiciadmin.processor;

import it.sella.statemachine.RequestEvent;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;

import java.rmi.RemoteException;
import java.util.HashMap;

import mockit.Mock;

public class GestContrattiAdminProcessorMock {

	private static Boolean viewHashMap = false;
	private static Boolean errorHashMap = false;
	private static Boolean tracciabilitaException = false;
	private static Boolean remoteException = false;

	public static void setRemoteException() {
		remoteException = true;
	}

	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}

	public static void setViewHashMap() {
		viewHashMap = true;
	}

	public static void setErrorHashMap() {
		errorHashMap = true;
	}
	
	@Mock
	public static HashMap validateEvent(final RequestEvent rqEvent,
			final String abiBanca) throws TracciabilitaException,
			RemoteException {
		if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}

		if (remoteException) {
			throw new RemoteException();
		}

		HashMap hashMap = null;
		if (viewHashMap) {
			hashMap = new HashMap();
			hashMap.put(ITPConstants.VIEW, getContrattiProdottoView());
		}
		if(errorHashMap)
		{
		hashMap = new HashMap();
		hashMap.put(ITPConstants.ERROR, "");
		hashMap.put(ITPConstants.ARGUMENT, "");
		}
		return hashMap;
	}

	public static ContrattiProdottoView getContrattiProdottoView() {
		final ContrattiProdottoView contrattiProdottoView = new ContrattiProdottoView();
		return contrattiProdottoView;
	}

}
