package it.sella.tracciabilitaplichi.executer.test.gestorebustaarchivo;

import it.sella.tracciabilitaplichi.executer.gestorebustaarchivo.ArchivoBustaInsersciConfermaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImpl;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiImplMock;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBean;
import it.sella.tracciabilitaplichi.implementation.TracciabilitaPlichiManagerBeanMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Hashtable;

import mockit.Mockit;

public class ArchivoBustaInsersciConfermaExecuterTest  extends AbstractSellaExecuterMock {

    ArchivoBustaInsersciConfermaExecuter  archivoBustaInsersciConfermaExecuter = new  ArchivoBustaInsersciConfermaExecuter();

   public  ArchivoBustaInsersciConfermaExecuterTest(final String name) {
       super(name);
   }

   /*public void testArchivoBustaInsersciConfermaExecuter_01() throws RemoteException, TracciabilitaException {
	   Mockit.setUpMock(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
	   Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	   setUpMockMethods(LogEvent.class, LogEventMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       archivoBustaCinqueSession.put( "TracciabilitaPlichiView", new TracciabilitaPlichiView() );
       archivoBustaCinqueSession.put( "Busta5List" , new ArrayList());
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession" )).andReturn(
               archivoBustaCinqueSession) ;
       playAll();
       archivoBustaInsersciConfermaExecuter
               .execute(getRequestEvent());
        
   }*/
   
   public void testArchivoBustaInsersciConfermaExecuter_02() throws RemoteException, TracciabilitaException {
	   TracciabilitaPlichiImplMock.setTracciabilitaException();
	   Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	   setUpMockMethods(LogEvent.class, LogEventMock.class);
	   setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       archivoBustaCinqueSession.put( "TracciabilitaPlichiView", new TracciabilitaPlichiView() );
       archivoBustaCinqueSession.put( "Busta5List" , new ArrayList());
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession" )).andReturn(
               archivoBustaCinqueSession) ;
       playAll();
       archivoBustaInsersciConfermaExecuter
               .execute(getRequestEvent());
        
   }
   public void testArchivoBustaInsersciConfermaExecuter_03() throws RemoteException, TracciabilitaException {
	   TracciabilitaPlichiImplMock.setRemoteException();
	   Mockit.setUpMock(TracciabilitaPlichiImpl.class,TracciabilitaPlichiImplMock.class);
	   setUpMockMethods(LogEvent.class, LogEventMock.class);
       final Hashtable archivoBustaCinqueSession =  new Hashtable( 15 );
       setUpMockMethods(TracciabilitaPlichiManagerBean.class, TracciabilitaPlichiManagerBeanMock.class);
       archivoBustaCinqueSession.put( "TracciabilitaPlichiView", new TracciabilitaPlichiView() );
       archivoBustaCinqueSession.put( "Busta5List" , new ArrayList());
       expecting(getStateMachineSession().get(  "BustaCinqueArchivoSession" )).andReturn(
               archivoBustaCinqueSession) ;
       playAll();
       archivoBustaInsersciConfermaExecuter
               .execute(getRequestEvent());
   }

}
