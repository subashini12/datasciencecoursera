package it.sella.tracciabilitaplichi.implementation.dao;

import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;

import java.util.Hashtable;

import mockit.Mock;

public class TPMultiChannelDataAccessMock 
{
	private static Boolean tracciabilitaException = false;
	
	public static void setTracciabilitaException() {
		tracciabilitaException = true;
	}
	
    @Mock
	public Hashtable getAllChannelElements() throws TracciabilitaException 
	{
		Hashtable hashtable = new Hashtable();		
		hashtable.put(1, "abc");
		return  hashtable;
	}
    
    @Mock
    public Hashtable getAllChannelDefinition() throws TracciabilitaException
    {
    	if (tracciabilitaException) {
			tracciabilitaException = false;
			throw new TracciabilitaException();
		}
    	
    	Hashtable hashtable = new Hashtable();
    	hashtable.put(1, "abc");
    	return  hashtable;
    }
}
