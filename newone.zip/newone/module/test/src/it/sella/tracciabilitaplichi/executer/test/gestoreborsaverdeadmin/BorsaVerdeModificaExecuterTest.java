/*package it.sella.tracciabilitaplichi.executer.test.gestoreborsaverdeadmin;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.ITracciabilitaPlichi;
import it.sella.tracciabilitaplichi.TracciabilitaPlichiFactory;
import it.sella.tracciabilitaplichi.executer.gestoreborsaverdeadmin.BorsaVerdeModificaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterTest;
import it.sella.tracciabilitaplichi.implementation.dao.TracciabilitaPlichiStatusDataAccess;
import it.sella.tracciabilitaplichi.implementation.mock.TracciabilitaPlichiManagerMock;
import it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException;
import it.sella.tracciabilitaplichi.implementation.view.BorsaVerdeAttributeView;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BorsaVerdeModificaExecuterTest extends AbstractSellaExecuterTest {

	BorsaVerdeModificaExecuter borsaVerdeModificaExecuter =  new BorsaVerdeModificaExecuter(); 
	
	public BorsaVerdeModificaExecuterTest(final String name) {
		super(name);
	}
	
	 public void testBorsaVerdeModificaExecuter_01(){
		TracciabilitaPlichiManagerMock.mockEJB();
		expecting(getRequestEvent().getAttribute("code")).andReturn("22");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("rr22");
		expecting(getRequestEvent().getAttribute("currStatusId")).andReturn("rr22");
		expecting(getRequestEvent().getAttribute("creationDateDD")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateMM")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateYYYY")).andReturn("2010").anyTimes();
 
		final Map borsaVerde = new HashMap();
		final BorsaVerdeAttributeView borsaVerdeAttributeView =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView.setId(1L);
		borsaVerdeAttributeView.setStatusId(455L);
		borsaVerdeAttributeView.setId(4L);
		final BorsaVerdeAttributeView borsaVerdeAttributeView1 =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView1.setId(2L);
		borsaVerdeAttributeView1.setStatusId(45L);
		borsaVerde.put("BORSA_VERDE_ATTRIBUTE_VIEW",borsaVerdeAttributeView);
		borsaVerde.put("BORSA_VERDE_ATTRIBUTE_VIEW_NEW", borsaVerdeAttributeView1);
		expecting(getStateMachineSession().get("BORSA_VERDE_MAP")).andReturn((Serializable)borsaVerde).anyTimes();
		redefineMethod( TracciabilitaPlichiStatusDataAccess.class, new Object( ) {
			public Long getStatusId( final String statusType )
			{
				return Long.valueOf( 16l );
			}
		} );
		playAll();		
		final ExecuteResult executeResult = borsaVerdeModificaExecuter.execute(getRequestEvent())	 ;
	} 
	
	public void testBorsaVerdeModificaExecuter_02(){
		TracciabilitaPlichiManagerMock.mockEJB();
		expecting(getRequestEvent().getAttribute("code")).andReturn("r221236547895");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("rr22");
		expecting(getRequestEvent().getAttribute("currStatusId")).andReturn("22");
		expecting(getRequestEvent().getAttribute("creationDateDD")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateMM")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateYYYY")).andReturn("2010").anyTimes();
 
		final Map borsaVerde = new HashMap();
		final BorsaVerdeAttributeView borsaVerdeAttributeView =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView.setId(1L);
		borsaVerdeAttributeView.setStatusId(455L);
		borsaVerdeAttributeView.setId(4L);
		final BorsaVerdeAttributeView borsaVerdeAttributeView1 =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView1.setId(2L);
		borsaVerdeAttributeView1.setStatusId(45L);
		borsaVerde.put("BORSA_VERDE_ATTRIBUTE_VIEW",borsaVerdeAttributeView);
		borsaVerde.put("BORSA_VERDE_ATTRIBUTE_VIEW_NEW", borsaVerdeAttributeView1);
		borsaVerde.put("BORSA_VERDE_STATUS_COLLECTION", new ArrayList(10));
		borsaVerde.put("NEW_STATUS_DESC","") ;
		expecting(getStateMachineSession().get("BORSA_VERDE_MAP")).andReturn((Serializable)borsaVerde).anyTimes();
		redefineMethod( TracciabilitaPlichiStatusDataAccess.class, new Object( ) {
			public Long getStatusId( final String statusType )
			{
				return Long.valueOf( 16l );
			}
		} );
	     expecting(getStateMachineSession().put("BORSA_VERDE_MAP" , borsaVerde)).andReturn(borsaVerde);
		playAll();	
		final ExecuteResult executeResult = borsaVerdeModificaExecuter.execute(getRequestEvent())	 ;

	}
	
	public void testBorsaVerdeModificaExecuter_03(){
		TracciabilitaPlichiManagerMock.mockEJB();
		expecting(getRequestEvent().getAttribute("code")).andReturn("r221236547895");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("rr22");
		expecting(getRequestEvent().getAttribute("currStatusId")).andReturn("22");
		expecting(getRequestEvent().getAttribute("creationDateDD")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateMM")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateYYYY")).andReturn("2010").anyTimes();
 
		final Map borsaVerde = new HashMap();
		final BorsaVerdeAttributeView borsaVerdeAttributeView =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView.setId(1L);
		borsaVerdeAttributeView.setStatusId(455L);
		borsaVerdeAttributeView.setId(4L);
		final BorsaVerdeAttributeView borsaVerdeAttributeView1 =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView1.setId(2L);
		borsaVerdeAttributeView1.setStatusId(45L);
		expecting(getStateMachineSession().get("BORSA_VERDE_MAP")).andReturn((Serializable)borsaVerde).anyTimes();
		redefineMethod(TracciabilitaPlichiFactory.class,new Object(){
			public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException {
			 throw new TracciabilitaException();
		}
		}); 
	     expecting(getStateMachineSession().put("BORSA_VERDE_MAP" , borsaVerde)).andReturn(borsaVerde);
		playAll();	
		final ExecuteResult executeResult = borsaVerdeModificaExecuter.execute(getRequestEvent())	 ;
	}
	public void testBorsaVerdeModificaExecuter_04(){
		TracciabilitaPlichiManagerMock.mockEJB();
		expecting(getRequestEvent().getAttribute("code")).andReturn("r221236547895");
		expecting(getRequestEvent().getAttribute("cdr")).andReturn("rr22");
		expecting(getRequestEvent().getAttribute("currStatusId")).andReturn("22");
		expecting(getRequestEvent().getAttribute("creationDateDD")).andReturn("22").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateMM")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("creationDateYYYY")).andReturn("2010").anyTimes();
 
		final Map borsaVerde = new HashMap();
		final BorsaVerdeAttributeView borsaVerdeAttributeView =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView.setId(1L);
		borsaVerdeAttributeView.setStatusId(455L);
		borsaVerdeAttributeView.setId(4L);
		final BorsaVerdeAttributeView borsaVerdeAttributeView1 =  new BorsaVerdeAttributeView();
		borsaVerdeAttributeView1.setId(2L);
		borsaVerdeAttributeView1.setStatusId(45L);
		expecting(getStateMachineSession().get("BORSA_VERDE_MAP")).andReturn((Serializable)borsaVerde).anyTimes();
		redefineMethod(TracciabilitaPlichiFactory.class,new Object(){
			public ITracciabilitaPlichi getTracciabilitaPlichi() throws TracciabilitaException, RemoteException {
				throw new RemoteException();
		}
		}); 
	     expecting(getStateMachineSession().put("BORSA_VERDE_MAP" , borsaVerde)).andReturn(borsaVerde);
		playAll();	
		final ExecuteResult executeResult = borsaVerdeModificaExecuter.execute(getRequestEvent())	 ;

	}

}
*/