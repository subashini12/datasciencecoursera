package it.sella.tracciabilitaplichi.executer.statistichearchivio.test;

import it.sella.statemachine.ExecuteResult;
import it.sella.tracciabilitaplichi.executer.statistichearchivio.StatisticheAchivioInviareRicercaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPStatistichArchivioDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.mock.util.TPUtilMock;
import it.sella.tracciabilitaplichi.implementation.util.TPUtil;
import it.sella.tracciabilitaplichi.log.LogEvent;

import org.easymock.classextension.EasyMock;

public class StatisticheAchivioInviareRicercaExecuterTest extends AbstractSellaExecuterMock{

	public StatisticheAchivioInviareRicercaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	StatisticheAchivioInviareRicercaExecuter executer = null;	
	
	
	public void testExecuter_01(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue( true );
	}

	public void testExecuter_02(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue( true );
	}
	public void testExecuter_03(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue( true );
	}
	public void testExecuter_04(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("1866").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_05(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("1906").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("1866").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue( true );
	}
	public void testExecuter_06(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2002").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue( true );
	}
	public void testExecuter_07(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		TPStatistichArchivioDataAccessMock.setStatisticheDiInviareViewCollAsNull();
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
		assertTrue( true );
	}
	public void testExecuter_08(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		TPStatistichArchivioDataAccessMock.setTracciabilitaException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals( "it.sella.tracciabilitaplichi.implementation.util.TracciabilitaException", executeResult.getException( ).toString() );
	}
	public void testExecuter_09(){
		executer = new StatisticheAchivioInviareRicercaExecuter();
		TPStatistichArchivioDataAccessMock.setRemoteException();
		setUpMockMethods(TPUtil.class, TPUtilMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPStatistichArchivioDataAccess.class, TPStatistichArchivioDataAccessMock.class);
		expecting(getRequestEvent().getAttribute("invioFromDay")).andReturn("01").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromMonth")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioFromYear")).andReturn("2003").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToDay")).andReturn("02").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToMonth")).andReturn("03").anyTimes();
		expecting(getRequestEvent().getAttribute("invioToYear")).andReturn("2004").anyTimes();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		playAll();
		final ExecuteResult executeResult = executer.execute(getRequestEvent());
		assertEquals("java.rmi.RemoteException" ,executeResult.getException().toString() );
	}

}

