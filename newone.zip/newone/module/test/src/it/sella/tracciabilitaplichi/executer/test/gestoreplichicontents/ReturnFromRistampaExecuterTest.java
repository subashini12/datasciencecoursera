package it.sella.tracciabilitaplichi.executer.test.gestoreplichicontents;

import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.gestoreplichicontents.ReturnFromRistampaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccess;
import it.sella.tracciabilitaplichi.implementation.dao.TPContrattiProdottoDataAccessMock;
import it.sella.tracciabilitaplichi.implementation.externalsystem.SecurityWrapper;
import it.sella.tracciabilitaplichi.implementation.mock.externalsystem.SecurityWrapperMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.BustaDeiciAttributeView;
import it.sella.tracciabilitaplichi.implementation.view.ContrattiProdottoView;
import it.sella.tracciabilitaplichi.implementation.view.TracciabilitaPlichiView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

public class ReturnFromRistampaExecuterTest extends AbstractSellaExecuterMock
{

	public ReturnFromRistampaExecuterTest(final String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	ReturnFromRistampaExecuter executer = new ReturnFromRistampaExecuter();
	public void testReturnFromRistampaExecuter_01()
	{
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		expecting( getStateMachineSession().get( "PlichiContentsHashTable" )).andReturn((Serializable) getPlichiContentsHashTable());
		try {
			expecting( getStateMachineSession().get( CONSTANTS.IS_STAMPA.getValue( ) )).andReturn(Boolean.FALSE).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void testReturnFromRistampaExecuter_02()
	{
		setUpMockMethods( LogEvent.class, LogEventMock.class );
		setUpMockMethods(SecurityWrapper.class, SecurityWrapperMock.class);
		setUpMockMethods(LogEvent.class, LogEventMock.class);
		setUpMockMethods(TPContrattiProdottoDataAccess.class, TPContrattiProdottoDataAccessMock.class);
		expecting( getStateMachineSession().get( "PlichiContentsHashTable" )).andReturn((Serializable) getPlichiContentsHashTable());
		try {
			expecting( getStateMachineSession().get( CONSTANTS.IS_STAMPA.getValue( ) )).andReturn(Boolean.TRUE).anyTimes();
			playAll();
			executer.execute(getRequestEvent());
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private Map getPlichiContentsHashTable()
	{
		final Map PlichiContentsHashTable = new Hashtable();
		PlichiContentsHashTable.put(CONSTANTS.IS_CONTRACT_REPRINT_ALLOWED , Boolean.TRUE);
		final TracciabilitaPlichiView tpView = new TracciabilitaPlichiView();
		final BustaDeiciAttributeView bdView= new BustaDeiciAttributeView();
		bdView.setCodProdottoContratto("1234");
		bdView.setOggettoId(1L);
		bdView.setNumeroCodiceDerivati("12345678954125");
		tpView.setBustaDeiciAttributeView(bdView);
		final ContrattiProdottoView cpView = new ContrattiProdottoView();
		cpView.setDescrizioneContratto("abc");
		tpView.setContrattiProdottoView(cpView);
		PlichiContentsHashTable.put( "TracciabilitaPlichiView",tpView);
		return PlichiContentsHashTable;
	}

}
