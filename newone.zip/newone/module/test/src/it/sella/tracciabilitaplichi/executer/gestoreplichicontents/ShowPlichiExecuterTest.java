package it.sella.tracciabilitaplichi.executer.gestoreplichicontents;

import static org.easymock.EasyMock.expect;
import it.sella.tracciabilitaplichi.ITPConstants;
import it.sella.tracciabilitaplichi.enumaration.CONSTANTS;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.Stack;

import org.easymock.EasyMock;



public class ShowPlichiExecuterTest extends AbstractSellaExecuterMock{

	public ShowPlichiExecuterTest(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	ShowPlichiExecuter executer=new ShowPlichiExecuter();
	public void testShowPlichiExecuter_01(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn(ITPConstants.BORSA_VERDE);
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("1245");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiExecuter_02(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.FALSE);
		expecting(getRequestEvent().getEventName()).andReturn(ITPConstants.BORSA_VERDE);
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("1245");
		expect( getStateMachineSession().put( CONSTANTS.BARCODE_STACK.getValue( ), new Stack( ) ) ).andReturn( new Stack( ) );
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiExecuter_03(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("ShowPlichiB10");
		expecting(getRequestEvent().getEventName()).andReturn("ShowPlichiB10");
		expecting(getRequestEvent().getAttribute("B10SearchFrom")).andReturn("");
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getRequestEvent().getAttribute("ID")).andReturn("2");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiExecuter_04(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("DummyDefaultEvent");
		expecting(getRequestEvent().getEventName()).andReturn("DummyDefaultEvent");
		expecting(getRequestEvent().getEventName()).andReturn("DummyDefaultEvent");
		expecting(getStateMachineSession().containsKey("SearchFrom")).andReturn(true);
		expecting(getStateMachineSession().get("SearchFrom")).andReturn("");
		expecting(getStateMachineSession().get("BarcodeFromSession")).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testShowPlichiExecuter_05(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_DOC_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getStateMachineSession().get("BarcodeFromSession")).andReturn(stack);
		expecting(getStateMachineSession().remove("BarcodeFromSession")).andReturn("");
		expecting(getRequestEvent().getAttribute("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().containsKey("isOneRec")).andReturn(true);
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey(ITPConstants.POP )).andReturn(true);
		expecting(getStateMachineSession().remove(ITPConstants.POP )).andReturn("");
		expecting(getStateMachineSession().remove(CONSTANTS.SEARCH_MAP.getValue( ) )).andReturn("");
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiExecuter_06(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_DOC_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getStateMachineSession().get("BarcodeFromSession")).andReturn(stack);
		expecting(getStateMachineSession().remove("BarcodeFromSession")).andReturn("");
		expecting(getRequestEvent().getAttribute("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().containsKey("isOneRec")).andReturn(false);
		expecting(getStateMachineSession().remove("SearchFrom" )).andReturn("");
		expecting(getStateMachineSession().containsKey(ITPConstants.POP )).andReturn(false);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiExecuter_07(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_DOC_ID)).andReturn("");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getStateMachineSession().get("BarcodeFromSession")).andReturn(stack);
		expecting(getStateMachineSession().remove("BarcodeFromSession")).andReturn("");
		expecting(getRequestEvent().getAttribute("SearchFrom")).andReturn("A");
		expecting(getRequestEvent().getAttribute("SearchFrom")).andReturn("A");
		expecting(getStateMachineSession().put( (String ) EasyMock.anyObject(),   EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("isOneRec")).andReturn(false);
		expecting(getStateMachineSession().remove("SearchFrom" )).andReturn("");
		expecting(getStateMachineSession().containsKey(ITPConstants.POP )).andReturn(false);
		playAll();
		executer.execute(getRequestEvent());
	}
	
	public void testShowPlichiExecuter_08(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("A");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_DOC_ID)).andReturn("2");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("");
		expecting(getRequestEvent().getAttribute("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().containsKey("isOneRec")).andReturn(false);
		expecting(getStateMachineSession().remove("SearchFrom" )).andReturn("");
		expecting(getStateMachineSession().containsKey(ITPConstants.POP )).andReturn(false);
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testShowPlichiExecuter_09(){
		Stack stack=getStack();
		expecting( getStateMachineSession().put( (String)EasyMock.anyObject(),( String) EasyMock.anyObject() ) ).andReturn( null ).anyTimes();
		expecting(getStateMachineSession().containsKey("BarCodeStack")).andReturn(Boolean.TRUE);
		expecting(getStateMachineSession().get("BarCodeStack")).andReturn(stack);
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getEventName()).andReturn("");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_CODE)).andReturn("A");
		expecting(getRequestEvent().getAttribute(ITPConstants.BV_DOC_ID)).andReturn("2");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("1234556464646");
		expecting(getRequestEvent().getAttribute("BarCode")).andReturn("1234556464646");
		expecting(getRequestEvent().getAttribute("SearchFrom")).andReturn(null);
		expecting(getStateMachineSession().containsKey("isOneRec")).andReturn(false);
		expecting(getStateMachineSession().remove("SearchFrom" )).andReturn("");
		expecting(getStateMachineSession().containsKey(ITPConstants.POP )).andReturn(false);
		playAll();
		executer.execute(getRequestEvent());
	}
	private static Stack getStack()
	{
		Stack stack=new Stack();
		stack.push("2");
		return stack;
	}
}
