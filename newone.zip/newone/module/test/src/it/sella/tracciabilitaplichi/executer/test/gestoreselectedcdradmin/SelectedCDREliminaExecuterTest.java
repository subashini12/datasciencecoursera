package it.sella.tracciabilitaplichi.executer.test.gestoreselectedcdradmin;

import it.sella.tracciabilitaplichi.executer.gestoreselectedcdradmin.SelectedCDREliminaExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;
import it.sella.tracciabilitaplichi.implementation.admin.SelectedCDRAdminImpl;
import it.sella.tracciabilitaplichi.implementation.mock.admin.SelectedCDRAdminImplMock;
import it.sella.tracciabilitaplichi.implementation.mock.log.LogEventMock;
import it.sella.tracciabilitaplichi.implementation.view.TpMaSelectedCdrView;
import it.sella.tracciabilitaplichi.log.LogEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import mockit.Mockit;

public class SelectedCDREliminaExecuterTest  extends AbstractSellaExecuterMock {

	 SelectedCDREliminaExecuter  selectedCDREliminaExecuter = new  SelectedCDREliminaExecuter();

	public  SelectedCDREliminaExecuterTest(final String name) {
		super(name);
	}

	public void testselectedCDREliminaExecuter_01() {
		 Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		 setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		 final Map bancaMap = new HashMap();
		 final TpMaSelectedCdrView view = new TpMaSelectedCdrView();
		 bancaMap.put("SELECTED_CDR_VIEW_MODIFY", view);
		 expecting(getRequestEvent().getAttribute("keyId")).andReturn("33").anyTimes();
		 expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn((Serializable)bancaMap).anyTimes();
		 playAll();
		selectedCDREliminaExecuter.execute(getRequestEvent());
	}
	
	public void testselectedCDREliminaExecuter_02() {
		 Mockit.setUpMock(LogEvent.class,LogEventMock.class );
		 SelectedCDRAdminImplMock.setTracciabilitaException();
		 setUpMockMethods(SelectedCDRAdminImpl.class, SelectedCDRAdminImplMock.class);
		 final Map bancaMap = new HashMap();
		 final TpMaSelectedCdrView view = new TpMaSelectedCdrView();
		 bancaMap.put("SELECTED_CDR_VIEW_MODIFY", view);
		 expecting(getRequestEvent().getAttribute("keyId")).andReturn("33").anyTimes();
		 expecting(getStateMachineSession().get("SELECTED_CDR_MAP")).andReturn((Serializable)bancaMap).anyTimes();
		 playAll();
		selectedCDREliminaExecuter.execute(getRequestEvent());
	}
	
}
