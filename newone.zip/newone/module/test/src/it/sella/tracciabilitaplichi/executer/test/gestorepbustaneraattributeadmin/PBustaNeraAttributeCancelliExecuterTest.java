package it.sella.tracciabilitaplichi.executer.test.gestorepbustaneraattributeadmin;

import it.sella.tracciabilitaplichi.executer.gestorepbustaneraattributeadmin.PBustaNeraAttributeCancelliExecuter;
import it.sella.tracciabilitaplichi.executer.test.AbstractSellaExecuterMock;

import java.util.HashMap;

public class PBustaNeraAttributeCancelliExecuterTest extends AbstractSellaExecuterMock
{

	PBustaNeraAttributeCancelliExecuter executer = new PBustaNeraAttributeCancelliExecuter();
	
	public PBustaNeraAttributeCancelliExecuterTest(String name) 
	{
		super(name);		
	}

	public void testExecuter_01()
	{
		expecting(getRequestEvent().getAttribute("id")).andReturn("ab").anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
	public void testExecuter_02()
	{
		expecting(getRequestEvent().getAttribute("id")).andReturn("1").anyTimes();
		expecting( getStateMachineSession().get( "mapPBustaNeraAttribute" )).andReturn(  new HashMap()  ).anyTimes();
		playAll();
		executer.execute(getRequestEvent());
	}
}
