package it.sella.tracciabilitaplichi.testcases;

import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;

public class Busta1020Assegni extends SeleneseTestCase {
	private String hostname;
	private String userId;
	private String password;
	
	public void setUp( ) throws Exception 
	{
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}

	public void testUntitled() throws Exception {
		selenium.open("http://" + hostname + "/x-net/index.jsp");
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("1500000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("1500000");
		selenium.click("link=Gestore Plichi");
		selenium.waitForPageToLoad("1500000");	
		selenium.click("link=Busta 10");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Preparazione busta dieci"));
		selenium.click("sm-event.Indietro");
		selenium.waitForPageToLoad("1500000");
		selenium.click("link=Busta 10");
		selenium.waitForPageToLoad("1500000");
		selenium.click("Form_Submit");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Il campo codice a barre non puo' essere vuoto"));
		selenium.type("barCode", "test");
		selenium.click("Form_Submit");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido"));
		selenium.type("barCode", "@#@#@#");
		selenium.click("Form_Submit");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido"));
		selenium.type("barCode", "1111111111111");
		selenium.click("Form_Submit");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido"));
		selenium.click("sm-event.Indietro");
		selenium.waitForPageToLoad("1500000");
		selenium.click("link=Busta 20");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Preparazione Busta 20"));
		selenium.click("sm-event.Indietro");
		selenium.waitForPageToLoad("1500000");
		selenium.click("link=Busta 20");
		selenium.waitForPageToLoad("1500000");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Non e' stato inserito nessun codice a barre"));
		selenium.type("BarCode", "test");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido TEST"));
		selenium.type("BarCode", "1111111111111");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido 1111111111111"));
		selenium.type("BarCode", "9000900090000");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido 9000900090000"));
		selenium.type("noOfPages", "tes");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Numero del codice a barre non valido 9000900090000"));
		selenium.click("sm-event.Indietro");
		selenium.waitForPageToLoad("1500000");
	}
}
