package it.sella.tracciabilitaplichi.testcases;

import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;

public class BustaNera extends SeleneseTestCase {
	private String hostname;
	private String userId;
	private String password;
	
	public void setUp( ) throws Exception 
	{
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}

	public void testUntitled() throws Exception {
		selenium.open("http://" + hostname + "/x-net/index.jsp");
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("1500000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("1500000");
		selenium.click("link=Gestore Plichi");
		selenium.waitForPageToLoad("1500000");	
		selenium.click("link=Busta Nera");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Preparazione busta nera (quasi valori)"));
		selenium.click("sm-event.Verifica");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Il codice del destinatario non e' un codice utente o CDR valido null"));
		selenium.select("widelyUsedCdr", "label=SIST. PAG. TRADIZIONALI (ASSEGNI CIRCOLARI,BOLLETTINI,PAGHE,SCHEDINE,EFFETTI),SHB,099318");
		selenium.waitForPageToLoad("1500000");
		selenium.click("sm-event.Verifica");
		selenium.waitForPageToLoad("1500000");
		selenium.select("SelectedBankId", "label=Banca Sella S.p.A.");
		selenium.type("UserOrCdr", "099505");
		selenium.click("sm-event.Verifica");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Seleziona solo una delle opzioni per il destinatario"));
		selenium.type("NoteForDest", "test");
		selenium.click("sm-event.Verifica");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Seleziona solo una delle opzioni per il destinatario"));
		selenium.type("BarCode", "test");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("La descrizione del contenuto non puo' essere vuota"));
		selenium.type("dateDD", "00");
		selenium.type("dateMM", "01");
		selenium.type("dateYYYY", "2010");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("La descrizione del contenuto non puo' essere vuota"));
		selenium.type("Desc", "test");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Data non valida 00/01/2010"));
		selenium.type("dateDD", "32");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Data non valida 32/01/2010"));
		selenium.type("dateDD", "30");
		selenium.type("dateMM", "02");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Data non valida 30/02/2010"));
		selenium.type("dateMM", "00");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Data non valida 30/00/2010"));
		selenium.type("dateMM", "01");
		selenium.type("dateYYYY", "0000");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Data non valida 30/01/0000"));
		selenium.type("dateYYYY", "2010");
		selenium.type("Importo", "test");
		selenium.type("ImportoDec", "te");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Formato dell'importo non valido test,te"));
		selenium.type("Importo", "100");
		selenium.type("ImportoDec", "00");
		selenium.type("Note", "test");
		selenium.click("sm-event.Inserisci");
		selenium.waitForPageToLoad("1500000");
		selenium.click("sm-event.Elimina");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Nessun record selezionato per essere eliminato"));
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("1500000");
		assertTrue(selenium.isTextPresent("Seleziona solo una delle opzioni per il destinatario"));
		selenium.click("checkbox");
		selenium.click("sm-event.Elimina");
		selenium.waitForPageToLoad("1500000");
	}
}
