package it.sella.tracciabilitaplichi.testcases;

import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;

public class WinboxAdminTest extends SeleneseTestCase 
{
	private String hostname;
	private String userId;
	private String password;

	public void setUp() throws Exception {
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}
	
	public void testUntitled() throws Exception 
	{
		selenium.open("http://" + hostname + "/x-net/index.jsp" );
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("120000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("30000");
		selenium.click("link=Gestore Plichi");
		selenium.waitForPageToLoad("30000");
		selenium.click("link=Winbox Admin");
		selenium.waitForPageToLoad("30000");
		selenium.select("tipoOggetto", "label=Documentazione");
		selenium.select("tipoOggetto", "label=Pratica");
		selenium.select("tipoOggetto", "label=Documentazione");
		selenium.select("abilitato", "label=SI");
		selenium.click("sm-event.Ricerca");
		selenium.waitForPageToLoad("30000");
		selenium.select("tipoOggetto", "label=Pratica");
		selenium.type("Desc", "TEST");
		selenium.click("Inserci");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("30000");
		selenium.type("Desc", "TEST");
		selenium.click("//input[@name='customAccess' and @value='1']");
		selenium.click("Inserci");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("30000");
		selenium.type("Desc", "TEST");
		selenium.click("sm-event.Ricerca");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.Modifica");
		selenium.waitForPageToLoad("30000");
		selenium.select("tipoOggetto", "label=Documentazione");
		selenium.select("tipoOggetto", "label=Pratica");
		selenium.type("Desc", "TEST ONE");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.Cancelli");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("30000");
	}
}
