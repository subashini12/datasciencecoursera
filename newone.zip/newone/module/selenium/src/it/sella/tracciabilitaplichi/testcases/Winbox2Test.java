package it.sella.tracciabilitaplichi.testcases;

import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;

public class Winbox2Test extends SeleneseTestCase 
{
	private String hostname;
	private String userId;
	private String password;

	public void setUp( ) throws Exception 
	{
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}

	public void testUntitled() throws Exception 
	{
		selenium.open("http://" + hostname + "/x-net/index.jsp" );
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("120000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("30000");
		selenium.click("link=Gestore Plichi");
		selenium.waitForPageToLoad("30000");
		selenium.select("plichiType", "label=Winbox2 (arch ottica)");
		selenium.waitForPageToLoad("30000");
		selenium.select("plichiStatus", "label=Preparata");
		selenium.click("sm-event.TrRicerca");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.TrBack");
		selenium.waitForPageToLoad("30000");
		selenium.select("plichiType", "label=Winbox2 (arch ottica)");
		selenium.waitForPageToLoad("30000");
		selenium.click("//input[@name='isCdr' and @value='1']");
		selenium.select("plichiStatus", "label=Preparata");
		selenium.click("sm-event.TrRicerca");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.TrFiltra");
		selenium.waitForPageToLoad("30000");
		selenium.click("sm-event.TrBack");
		selenium.waitForPageToLoad("30000");

		//

selenium.click("link=Winbox2(arch. ottica)");
selenium.waitForPageToLoad("30000");
selenium.click("folderFlow");
selenium.waitForPageToLoad("30000");
selenium.click("AggiungiPratica");
selenium.type("protocollo", "&");
selenium.click("sm-event.Inserisci");
selenium.waitForPageToLoad("30000");
selenium.click("sm-event.StampaCopertina");
selenium.waitForPageToLoad("30000");
selenium.click("AggiungiPratica");
selenium.type("protocollo", "&");
selenium.click("sm-event.Inserisci");
selenium.waitForPageToLoad("30000");
selenium.click("//a[@id='1']/img");
//assertEquals("Si vuole cancellare la pratica \"9012000000295 DOCUMENTO GENERICO\"", selenium.getConfirmation());
selenium.click("AggiungiPratica");
selenium.type("protocollo", "&&");
selenium.click("sm-event.Inserisci");
selenium.waitForPageToLoad("30000");
selenium.click("folderFlow");
selenium.waitForPageToLoad("30000");
selenium.click("AggiungiPratica");
selenium.type("protocollo", "&&");
selenium.click("sm-event.Inserisci");
selenium.waitForPageToLoad("30000");
selenium.click("sm-event.StampaCopertina");
selenium.waitForPageToLoad("30000");
selenium.click("//a[@id='1']/img");
selenium.waitForPageToLoad("30000");

//

selenium.click("//input[@name='folderFlow' and @value='0']");
selenium.waitForPageToLoad("30000");

	}
}
