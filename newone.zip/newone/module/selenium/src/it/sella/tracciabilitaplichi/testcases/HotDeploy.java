package it.sella.tracciabilitaplichi.testcases;

import com.thoughtworks.selenium.SeleneseTestCase;

public class HotDeploy extends SeleneseTestCase {
	public void setUp() throws Exception {
		setUp("http://172.20.35.137:19000/console/", "*chrome");
	}
	public void testUntitled() throws Exception {
		selenium.open("/console/login/LoginForm.jsp;ADMINCONSOLESESSION=WmS2LGCBnGJrFqfh7RW8L78nH1S9Qqz34vd4fQt7BBK2DqqJ74Vz!803715096");
		selenium.type("j_username", "9999999");
		selenium.type("j_password", "bsella81");
		selenium.click("//input[@value='Log In']");
		selenium.waitForPageToLoad("30000");
		selenium.click("linkAppDeploymentsControlPage");
		selenium.waitForPageToLoad("30000");
		selenium.click("AppDeploymentsControlPortletchosenContents");
		selenium.click("AppDeploymentsControlPortletchosenContents");
		selenium.click("AppDeploymentsControlPortletchosenContents");
		selenium.click("AppDeploymentsControlPortletchosenContents");
		selenium.click("AppDeploymentsControlPortletchosenContents");
		selenium.click("save");
		selenium.waitForPageToLoad("120000");
		selenium.click("AppDeploymentsControlPortletchosenContents");
		selenium.click("//form[@id='genericTableForm']/table[2]/tbody/tr/td/table[3]/tbody/tr/td[1]/table/tbody/tr/td/input[2]");
		selenium.waitForPageToLoad("120000");
		selenium.click("Finish");
		selenium.waitForPageToLoad("120000");
		selenium.click("save");
		selenium.waitForPageToLoad("720000");
	}
}
