package it.sella.tracciabilitaplichi.testcases;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;


public class SistemazioneBarcodeConfermaTest extends SeleneseTestCase 
{
	private String hostname;
	private String userId;
	private String password;
	
	public void setUp( ) throws Exception 
	{
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}
	
	public void testSearchConferma( ) throws Exception 
	{
		selenium.open("http://" + hostname + "/x-net/index.jsp" );
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("120000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("120000");
		selenium.click("link=Contrattualistica (Busta 10)");
		selenium.waitForPageToLoad("120000");
		selenium.click("link=Sistemazione Barcode");
		selenium.waitForPageToLoad("120000");
		
		/**
		 * case1
		 */
		selenium.type( "nc", "@@@@" );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Inserire un valore valido in NumeroConto" ) );
		
		/**
		 * case2
		 */
		selenium.type( "nc", "" );
		selenium.type( "cif8", "@@@@" );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Inserire un valore valido in 8 cifre" ) );
		
		/**
		 * case3
		 */
		selenium.type( "cif8", "" );
		selenium.type( "daigg", "" );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Data di inizio periodo non valida" ) );
		
		/**
		 * case4
		 */
		selenium.type( "daigg", "" );
		selenium.type( "daimm", "" );
		selenium.type( "daiaa", "" );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Data non valida" ) );
		
		
		final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		final Calendar calendar = Calendar.getInstance();
		final String datacurr = dateFormat.format(calendar.getTime());
		calendar.add(Calendar.MONTH, -3);
		final String datain = dateFormat.format(calendar.getTime());
		
		final String ddi = datain.substring(8);
		final String mmi = datain.substring(5, 7);
		final String yyi = datain.substring(0, 4);
		
		final String ddf = datacurr.substring(8);
		final String mmf = datacurr.substring(5, 7);
		final String yyf = datacurr.substring(0, 4);
		
		
		/**
		 * case5
		 */
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", "" );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Data di fine periodo non valida" ) );
		
		/**
		 * case6
		 */
		final Calendar calendar2 = Calendar.getInstance( );
		calendar2.add( Calendar.YEAR, 1 );
		selenium.type( "daiaa", dateFormat.format( calendar2.getTime( ) ).substring( 0, 4 ) );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", mmf );
		selenium.type( "dafaa", yyf );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Non puo' essere inserita una data futura " + ddi+"/"+mmi+"/"+dateFormat.format( calendar2.getTime( ) ).substring( 0, 4 ) ) );
		
		/**
		 * case7
		 */
		selenium.type( "daiaa", yyi );
		selenium.type( "dafaa", dateFormat.format( calendar2.getTime( ) ).substring( 0, 4 ) );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Non puo' essere inserita una data futura " + ddf+"/"+mmf+"/"+dateFormat.format( calendar2.getTime( ) ).substring( 0, 4 ) ) );
		
		/**
		 * case8
		 */
		calendar.add( Calendar.MONTH, -1 );
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", dateFormat.format( calendar.getTime( ) ).substring( 5, 7 ) );
		selenium.type( "dafaa", yyi );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		final StringBuilder expectedMsg = new StringBuilder( "La data di inizio periodo deve essere inferiore o uguale a quella di fine periodo " )
		.append( ddi ).append( "/" ).append( mmi ).append( "/" ).append( yyi )
		.append( "," ).append( ddf ).append( "/" ).append( dateFormat.format( calendar.getTime( ) ).substring( 5, 7 ) ).append( "/" ).append( yyi );
		assertTrue( selenium.isTextPresent( expectedMsg.toString( ) ) );
		
		/**
		 * case9
		 */
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", "1889" );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", mmf );
		selenium.type( "dafaa", yyf );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "La data deve essere successiva al 1900" ) );
		
		/**
		 * case10
		 */
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", mmf );
		selenium.type( "dafaa", "1889" );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "La data deve essere successiva al 1900" ) );

		
		/**
		 * case11
		 */
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", dateFormat.format( calendar.getTime( ) ).substring( 5, 7 ) );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", mmf );
		selenium.type( "dafaa", yyf );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Intervallo di date troppo ampio per la ricerca effettuata. Ridurre a tre mesi l'intervallo delle date o aggiungere ulteriori criteri di ricerca" ) );
		
		
		/**
		 * case12
		 */
		selenium.type( "codecdr", "!!!!!!" );
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", mmf );
		selenium.type( "dafaa", yyf );
		selenium.click("sm-event.Conferma");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Codice CDR Errato" ) );

	}
}
