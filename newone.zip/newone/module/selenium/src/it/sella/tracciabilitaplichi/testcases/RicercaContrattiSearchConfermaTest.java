package it.sella.tracciabilitaplichi.testcases;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;

public class RicercaContrattiSearchConfermaTest extends SeleneseTestCase 
{
	private String hostname;
	private String userId;
	private String password;
	
	public void setUp( ) throws Exception 
	{
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}

	public void testRicercaConferma( ) throws Exception 
	{
		selenium.open("http://" + hostname + "/x-net/index.jsp" );
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("120000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("120000");
		selenium.click("link=Contrattualistica (Busta 10)");
		selenium.waitForPageToLoad("120000");
		selenium.click("link=Ricerca Contratti");
		selenium.waitForPageToLoad("120000");
		
		selenium.isSomethingSelected( "statcon" );
		assertEquals( "ST_11", selenium.getSelectedValue( "statcon" ) );
		
		selenium.isSomethingSelected( "ultimoesito" );
		assertEquals( "-1", selenium.getSelectedValue( "ultimoesito" ) );
		
		
		selenium.type("nc", "@@@@@@@@@@@@@");
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Inserire un valore valido in NumeroConto" ) );
		
		selenium.type("nc", "");
		selenium.type("ncd", "@@@@@@@@@@@@@");
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Inserire un valore valido in Codice Derivati" ) );
		
		selenium.type("ncd", "");
		selenium.type("cif8", "@@@@@@@@");
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Inserire un valore valido in 8 cifre" ) );
		
		selenium.type("cif8", "");
		selenium.type( "daigg", "" );
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Data di inizio periodo non valida" ) );
		
		final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		final Calendar calendar = Calendar.getInstance();
		final String datacurr = dateFormat.format(calendar.getTime());
		calendar.add(Calendar.MONTH, -3);
		final String datain = dateFormat.format(calendar.getTime());
		
		final String ddi = datain.substring(8);
		final String mmi = datain.substring(5, 7);
		final String yyi = datain.substring(0, 4);
		
		final String ddf = datacurr.substring(8);
		final String mmf = datacurr.substring(5, 7);
		final String yyf = datacurr.substring(0, 4);

		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", "" );
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad( "120000" );
		assertTrue( selenium.isTextPresent( "Data di fine periodo non valida" ) );
		
		calendar.add( Calendar.MONTH, -1 );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafmm", dateFormat.format(calendar.getTime( ) ).substring( 5, 7 ) );
		selenium.type( "dafaa", yyi );
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad( "120000" );
		assertTrue( selenium.isTextPresent( "La data di inizio periodo deve essere inferiore o uguale a quella di fine periodo" ) );
		
		selenium.type( "daimm", dateFormat.format(calendar.getTime( ) ).substring( 5, 7 ) );
		selenium.type( "dafmm", mmf );
		selenium.type( "dafaa", yyf );
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad( "120000" );
		assertTrue( selenium.isTextPresent( "Intervallo di date troppo ampio per la ricerca effettuata. Ridurre a tre mesi l'intervallo delle date o aggiungere ulteriori criteri di ricerca" ) );
		
		selenium.type( "daigg", ddi );
		selenium.type( "daimm", mmi );
		selenium.type( "daiaa", yyi );
		selenium.type( "dafgg", ddf );
		selenium.type( "dafgg", mmf );
		selenium.type( "dafgg", yyf );
		selenium.select( "ultimoesito", "Tutti i tipi di KO" );
		selenium.click("sm-event.GestoreRicercaContratti-RicercaPageGestCon.RicercaConfermaEvent");
		selenium.waitForPageToLoad( "120000" );
		assertEquals( "ST_11", selenium.getSelectedValue( "statcon" ) );
		assertEquals( 1, selenium.getSelectedIds( "statcon" ).length );
	}
}
