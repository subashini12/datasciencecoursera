package it.sella.tracciabilitaplichi.testcases;

import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import com.thoughtworks.selenium.SeleneseTestCase;

public class SituazionePlichiTest1 extends SeleneseTestCase 
{
	private String hostname;
	private String userId;
	private String password;

	public void setUp( ) throws Exception 
	{
		final ResourceBundle resourceBundle = ResourceBundle.getBundle( "it.sella.tracciabilitaplichi.properties.Testcase" );
		hostname = resourceBundle.getString( "host" );
		userId = resourceBundle.getString( "UserId" );
		password = resourceBundle.getString( "Password" );
		setUp("http://"+ hostname +"/x-net/index/", "*chrome");
	}
	
	public void testUntitled( ) throws Exception 
	{
		selenium.open("http://" + hostname + "/x-net/index.jsp" );
		selenium.type("UserId", userId );
		selenium.type("Password", password );
		selenium.click("Entra");
		selenium.waitForPageToLoad("120000");
		selenium.click("//td[3]/b/a/b");
		selenium.waitForPageToLoad("120000");
		selenium.click("link=Gestore Plichi");
		selenium.waitForPageToLoad("120000");

		assertTrue( selenium.isSomethingSelected( "plichiType" ) );
		assertEquals( "", selenium.getSelectedValue( "plichiType" ) );
		assertEquals( "- Tutti -", selenium.getSelectedLabel( "plichiType" ) );
		assertEquals( "", selenium.getSelectedValue( "plichiStatus" ) );
		assertEquals( "- Tutti -", selenium.getSelectedLabel( "plichiStatus" ) );
		assertEquals( 1, selenium.getSelectOptions( "plichiStatus" ).length );
		
		
		
		final List<String> allPlichiTypes = Arrays.asList( new String[ ] {"- Tutti -", "Borsa Blu", "Borsa Corrispondenza Interna",	"Busta 10",	"Busta 20",	"Busta Cinque",	"Busta assegni", "Busta nera", "Documentazione", "Plico Buste5", "Winbox2 (arch ottica)" } );
		final List<String> allPlichiTypesFromSelenium = Arrays.asList( selenium.getSelectOptions( "plichiType" ) );
		for ( String option : allPlichiTypesFromSelenium )
		{
			assertTrue( allPlichiTypes.contains( option ) );
		}
		for ( String option : allPlichiTypes )
		{
			assertTrue( allPlichiTypes.contains( option ) );
		}
		assertEquals( allPlichiTypes.size( ), allPlichiTypesFromSelenium.size( ) );
		
		
		selenium.click("sm-event.TrRicerca");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "Occorre inserire almeno un dato per la ricerca " ) );
		
		selenium.type( "fromdd", "00" );
		selenium.type( "frommm", "00" );
		selenium.type( "fromyyyy", "0000" );
		selenium.type( "tilldd", "01" );
		selenium.type( "tillmm", "01" );
		selenium.type( "tillyyyy", "2009" );
		selenium.click( "sm-event.TrRicerca" );
		selenium.waitForPageToLoad( "120000" );
		assertTrue( selenium.isTextPresent( "Data di inizio periodo non valida" ) );
		
		
		selenium.type( "fromdd", "01" );
		selenium.type( "frommm", "01" );
		selenium.type( "fromyyyy", "2008" );
		selenium.type( "tilldd", "00" );
		selenium.click( "sm-event.TrRicerca" );
		selenium.waitForPageToLoad( "120000" );
		assertTrue( selenium.isTextPresent( "Data di fine periodo non valida" ) );
		
		selenium.type("fromyyyy", "1889");
		selenium.type("tilldd", "01");
		selenium.click("sm-event.TrRicerca");
		selenium.waitForPageToLoad("120000");
		assertTrue( selenium.isTextPresent( "La data deve essere successiva al 1900" ) );
		
		selenium.type( "fromyyyy", "2009" );
		selenium.type( "frommm", "02" );
		selenium.click( "sm-event.TrRicerca" );
		selenium.waitForPageToLoad( "120000" );
		assertTrue( selenium.isTextPresent( "La data di inizio periodo deve essere inferiore o uguale a quella di fine periodo" ) );

		selenium.type( "frommm", "01" );
		selenium.type( "tillmm", "09" );
		selenium.select("plichiType", "label=Borsa Blu");
		selenium.waitForPageToLoad("120000");
		final String borsaBluOggetto = selenium.getSelectedValue( "plichiType" );
		System.out.println(borsaBluOggetto );
		
	}
}
