package it.sella.anagrafe.implementation.operazioneanagrafe;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.IAnagrafeLoggerView;
import it.sella.anagrafe.UpdateAMMBAScanView;
import it.sella.anagrafe.az.DatiAnagraficiAZView;
import it.sella.anagrafe.hostlog.LogHostCallView;
import it.sella.anagrafe.hostlog.LogOperationDataView;
import it.sella.anagrafe.implementation.AltriTipoSoggetto;
import it.sella.anagrafe.implementation.AttributiTramite;
import it.sella.anagrafe.implementation.CodiciSoggetto;
import it.sella.anagrafe.implementation.Collegamento;
import it.sella.anagrafe.implementation.DatiFiscali;
import it.sella.anagrafe.implementation.DatiPrivacy;
import it.sella.anagrafe.implementation.DatiPrivacyFiveLevel;
import it.sella.anagrafe.implementation.Documento;
import it.sella.anagrafe.implementation.Evento;
import it.sella.anagrafe.implementation.IAMMBALink;
import it.sella.anagrafe.implementation.ICanalePreferito;
import it.sella.anagrafe.implementation.IClienteClassificazione;
import it.sella.anagrafe.implementation.IDAIRegole;
import it.sella.anagrafe.implementation.IDipctAlignDetails;
import it.sella.anagrafe.implementation.IDocEventi;
import it.sella.anagrafe.implementation.IGeograficaAdminstrazione;
import it.sella.anagrafe.implementation.IMigration;
import it.sella.anagrafe.implementation.ISocketRollBackLog;
import it.sella.anagrafe.implementation.Log;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.anagrafe.implementation.Recapiti;
import it.sella.anagrafe.implementation.TipoAttributiEsterni;
import it.sella.anagrafe.implementation.TipoDatiAnagrafici;
import it.sella.anagrafe.implementation.TipoSoggetto;
import it.sella.anagrafe.poste.exception.PosteException;
import it.sella.anagrafe.tiposoggetto.TipoSoggettoView;
import it.sella.anagrafe.util.SoggettiPromotoreException;
import it.sella.anagrafe.view.PosteCustomerView;
import it.sella.anagrafe.view.SoggettoView;
import it.sella.anagrafe.view.TransferContoView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.ejb.IEJBSessionObject;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.persistence.EntityManager;

public interface OperazioneAnagrafeSession extends TipoAttributiEsterni, CodiciSoggetto, DatiFiscali, DatiPrivacy, DatiPrivacyFiveLevel, Recapiti, Evento, TipoSoggetto, TipoDatiAnagrafici, AltriTipoSoggetto, Collegamento, Documento, IDocEventi , IGeograficaAdminstrazione, Log, IEJBSessionObject, IDipctAlignDetails , AttributiTramite, ISocketRollBackLog, IAMMBALink, IMigration ,IClienteClassificazione, ICanalePreferito, IDAIRegole {

    public void updateSconfWithHost( final Long soggettoId, final String newSconfValue, final String codiceHost, final Long opId ) throws OperazioneAnagrafeManagerException,RemoteException;
    public String mergeAnagraficDetails( final Long soggettoIdExisting, final Long soggettoIdDuplicate ) throws RemoteException,OperazioneAnagrafeManagerException ;
    public Collection getCompatibleTipoIntermediari() throws OperazioneAnagrafeManagerException,RemoteException ;
    public void updateDaiForPrincipalIds( final Long pfSoggettoId, final boolean oldDai, final boolean newDai, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException;

    /**
     * The below method terminates all the existing links for the motivs (AMMBA, SINBA, AMMGR, SINGR, CLLAG, CLLSG, CLLAB, CLLSB)
     * and creates a new link with the newly selected motiv.  The codiceHost given is used for the Mapper Alignment.
     * @param soggettoId
     * @param classificazioneView
     * @param codiceHost
     * @param existingCausales
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public String updateAmministratoriBanca( final Long soggettoId, final ClassificazioneView classificazioneView, final String codiceHost, final Collection existingCausales, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException;
	/**
	 *
	 * @param updateAMMBALinkView
	 * @param hostUserCode
	 * @throws OperazioneAnagrafeManagerException
	 * @throws RemoteException
	 */
    public void updateAmministratoriBancaInHost( final UpdateAMMBAScanView updateAMMBALinkView, final String hostUserCode ) throws OperazioneAnagrafeManagerException, RemoteException;

    public Long createLogHOSTCall( final LogHostCallView logHostCallView ) throws OperazioneAnagrafeManagerException, RemoteException;

	/**
	 * inserts a record in ANADD_LG_OPERATION_DETAILS
	 * @param logOperationDataView
	 * @throws OperazioneAnagrafeManagerException
	 * @throws RemoteException
	 */
	public void createLogHOSTOperationData( final LogOperationDataView logOperationDataView ) throws OperazioneAnagrafeManagerException, RemoteException;
	/**
	 *
	 * @param transferContoView
	 * @param opId
	 * @throws OperazioneAnagrafeManagerException
	 * @throws RemoteException
	 */
    public void transferConto( final TransferContoView transferContoView, final Long opId ) throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     *
     * @param operationId
     * @param soggettoId
     * @param errorMessage
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public void updateAnagrafeLog( final Long operationId, final Long soggettoId, final String errorMessage ) throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     *
     * @param operationId
     * @param soggettoId
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public void updateAnagrafeLog( final Long operationId, final Long soggettoId ) throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     * This method to written only to maintain transaction case. ( If bustta failure to rollback all transaction in to create soggetto )
     * @param soggettoView
     * @param stampaTable
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public Long performCensimentoAndBusta( final SoggettoView soggettoView, final Hashtable stampaTable ) throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     * This method to written only to maintain transaction case. ( If bustta failure to rollback all transaction in varia of soggetto )
     * @param soggettoView
     * @param stampaTable
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public void performCensimentoModificaAndBusta( final SoggettoView soggettoView, final Hashtable stampaTable ) throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     * This method used to get error message as the input param is errorcode
     * @param errorCode
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public String getMessage( final String errorCode ) throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     * The method return to all operation code in logger table
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public List getAllOperationCode() throws OperazioneAnagrafeManagerException, RemoteException;
    /**
     *
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public Long getLoginSoggettoId() throws OperazioneAnagrafeManagerException, RemoteException;
	/**
	 *
	 * @param soggettoId
	 * @param operation
	 * @param data
	 * @param operationCode
	 * @param operationSuccess
	 * @throws OperazioneAnagrafeManagerException
	 * @throws RemoteException
	 */
    public void logMessageForAnagrafeManager( final Long soggettoId, final String operation, final String data, final String operationCode, final boolean operationSuccess ) throws OperazioneAnagrafeManagerException, RemoteException;

    /**
	 *
	 * @param soggettoId
	 * @param operation
	 * @param data
	 * @param operationCode
	 * @param operationSuccess
	 * @param errorMessage
	 * @throws OperazioneAnagrafeManagerException
	 * @throws RemoteException
	 */
    public void logMessageWithErrorMsg( final Long soggettoId, final String operation, final String data, final String operationCode, final boolean operationSuccess , final String errorMessage ) throws OperazioneAnagrafeManagerException, RemoteException;


    /**
     * Method to create soggetto by passing ID which contains XML data for persisting in a particular bank (BPA)
     * @param soggettoPromotoreId
     * @param operationCode
     * @return
     * @throws OperazioneAnagrafeManagerException
     * @throws RemoteException
     */
    public String createSoggettoFromXMLForBPA(final Long soggettoPromotoreId, final String operationCode) throws OperazioneAnagrafeManagerException, RemoteException;
  /**
   * Method to update the status of createSoggettoFromXMLForBPA method invocation
   * @param soggettoPromotoreId
   * @param error
   * @param stato
   * @param rifDate
   * @param opId
   * @throws SoggettiPromotoreException
   */
   public void updateAutoCensitoStatus(final Long soggettoPromotoreId,final String error, final String stato,final String rifDate,final Long opId) throws SoggettiPromotoreException,RemoteException;


   /**
    * Method to create TipoSoggetto
    * @param tipoSoggettoView
    * @throws GestoreAnagrafeException
    * @throws RemoteException
    */
   public void createTipoSoggetto(TipoSoggettoView tipoView) throws GestoreAnagrafeException,RemoteException;

   /**
    * Method to update TipoSoggetto
    * @param tipoSoggettoView
    * @throws GestoreAnagrafeException
    * @throws RemoteException
    */

   public it.sella.anagrafe.tiposoggetto.TipoSoggetto setTipoSoggetto(TipoSoggettoView tipoView) throws GestoreAnagrafeException,RemoteException;

   /**
    * Method to get EntityManager by JNDI look up
    * @return EntityManager
    */
   public EntityManager getPersistenceEntityManager() throws NamingException,RemoteException;

   /**
    *
    * @param mainSoggettoId
    * @param denominazione
    * @param dataDiCostituzione
    * @param operationId
    * @return
    * @throws OperazioneAnagrafeManagerException
    * @throws RemoteException
    */
   public Long createSellaLifeCustomer(final Long mainSoggettoId,final DatiAnagraficiAZView datiAnagraficiAZView,final Long operationId) throws OperazioneAnagrafeManagerException, RemoteException;
   
	/**
	* Method to terminate the duplicate soggetto 
	* @param soggetoIdOne
	* @param soggetoIdTwo
	* @param terminateCollegamentoLinks
	* @return String
	* @throws OperazioneAnagrafeManagerException
	* @throws RemoteException
	*/
	public String maintainTerminateSoggetto(final Long soggetoIdOne,final Long soggetoIdTwo,final String terminateCollegamentoLinks) throws OperazioneAnagrafeManagerException, RemoteException;
	/**
	* Method to invoke procedure for merge anagrafe data 
	* @param soggetoIdOne
	* @param soggetoIdTwo
	* @param terminateCollegamentoLinks
	* @return String
	* @throws OperazioneAnagrafeManagerException
	* @throws RemoteException
	*/
	public Map<String, String> terminateSoggetto(final Long mainSoggetto,final Long terminateSoggetto,final String terminateCollegamentoLinks) throws OperazioneAnagrafeManagerException, RemoteException;
	
	
	/**
	 * Method to Log the data to Security logger table. (External Subsystem LogServer API Called internally)
	 * @param loggerView
	 * @throws RemoteException
	 */
	public void logMessageToSecurity(final IAnagrafeLoggerView loggerView) throws RemoteException;
	
	  /**
	   * Method to update the status of createSoggettoFromXMLForBPA method invocation
	   * @param soggettoPromotoreId
	   * @param error
	   * @param stato
	   * @param rifDate
	   * @param opId
	   * @throws SoggettiPromotoreException
	   */
	   public void updateProcessedPosteStatus(final PosteCustomerView view) throws PosteException,RemoteException;
	   /**
	    * 
	    * Method to set the document details for an existing soggettoId
	    * @param soggettoId
	    * @param documentiCollection
	    * @throws GestoreAnagrafeException
	    */
	   public void setDocumenti(final Long soggettoId,Collection documentiCollection,ClassificazioneView modalita) throws RemoteException, GestoreAnagrafeException;
}
