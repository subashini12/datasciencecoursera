package it.sella.anagrafe.implementation.operazioneanagrafe;

import it.sella.ejb.IEJBSessionHome;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public interface OperazioneAnagrafeSessionHome extends IEJBSessionHome {

    OperazioneAnagrafeSession create() throws CreateException, RemoteException;
    
}