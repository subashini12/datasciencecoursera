package it.sella.anagrafe.implementation;

import it.sella.ejb.IEJBHome;

import java.rmi.RemoteException;

import javax.ejb.CreateException;

public interface GeograficaValidatorImplHome extends IEJBHome {

    public GeograficaValidatorImpl create() throws CreateException, RemoteException;
}
