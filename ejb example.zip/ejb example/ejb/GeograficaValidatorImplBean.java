package it.sella.anagrafe.implementation;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreDatiFiscaliException;
import it.sella.anagrafe.GestoreProvinciaException;
import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.az.FatcaAZView;
import it.sella.anagrafe.common.AlboProfessione;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.common.Provincia;
import it.sella.anagrafe.common.Ramo;
import it.sella.anagrafe.common.RecapitiCanaleComptView;
import it.sella.anagrafe.common.Settore;
import it.sella.anagrafe.common.SettoreDiAttivita;
import it.sella.anagrafe.common.TAE;
import it.sella.anagrafe.dbaccess.AlboProfessioneHandler;
import it.sella.anagrafe.dbaccess.AttivitaHandler;
import it.sella.anagrafe.dbaccess.CanalePreferitoDBAccessHelper;
import it.sella.anagrafe.dbaccess.CapTableHandler;
import it.sella.anagrafe.dbaccess.CittaDBAccessHelper;
import it.sella.anagrafe.dbaccess.ClasseATECODBAccessHelper;
import it.sella.anagrafe.dbaccess.ClassificazioneFatcaGetter;
import it.sella.anagrafe.dbaccess.CompatibilityHelper;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.dbaccess.DocumentiDBAccessHelper;
import it.sella.anagrafe.dbaccess.NazioneDBAccessHelper;
import it.sella.anagrafe.dbaccess.OrigineClienteDBAccessHelper;
import it.sella.anagrafe.dbaccess.ProvinciaDBAccessHelper;
import it.sella.anagrafe.dbaccess.RamoDBAccessHelper;
import it.sella.anagrafe.dbaccess.RamoHandler;
import it.sella.anagrafe.dbaccess.SettoreDiAttivitaHandler;
import it.sella.anagrafe.dbaccess.SettoreHandler;
import it.sella.anagrafe.dbaccess.TAEHandler;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.originecliente.OrigineClienteMasterView;
import it.sella.anagrafe.util.CanalePreferitoException;
import it.sella.anagrafe.util.ProfessioneClassificazioneHandler;
import it.sella.anagrafe.util.ProfessioneException;
import it.sella.anagrafe.view.InvalidDocumentoView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.ejb.SessionBeanAdapter;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import javax.ejb.EJBException;

public class GeograficaValidatorImplBean extends SessionBeanAdapter {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(GeograficaValidatorImplBean.class);

    public Collection listNazione() throws RemoteException {
    	return new NazioneDBAccessHelper().listNazione();
    }

    public Collection listAnagraficNazione() throws RemoteException {
    	return new NazioneDBAccessHelper().listAnagraficNazione();
    }

    public Nazione getNazioneForIndirizzo(final String nazioneNome) throws RemoteException {
    	return new NazioneDBAccessHelper().getNazioneForIndirizzo(nazioneNome);
    }

    public Collection listNazione(final String nazioneNome) throws RemoteException {
    	return new NazioneDBAccessHelper().listNazione(nazioneNome);
    }

    public Nazione getNazione(final String nome) throws RemoteException {
    	return new NazioneDBAccessHelper().getNazione(nome);
    }

    public Nazione getNazione(final Long nazioneId) throws RemoteException {
    	return new NazioneDBAccessHelper().getNazioneOfGVBean(nazioneId);
    }

    /**
     * This method checks the CAP passed is existing in the table or not
     * @ param String cap
     * @ exception RemoteException
     * @ return boolean
     */

    public boolean isValidCAP(final String cap) throws RemoteException {
        try {
        	return new CapTableHandler().isValidCAP(cap);
        } catch(final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * This method checks the first two letters of CAP and Province passed is existing in the table or not
     * @ param String cap
     * @ param String province
     * @ exception RemoteException
     * @ return boolean indicates whether the first two letters of CAP and Province is existing or not
     */

    public boolean isValidCAP(final String cap, final String provinciaSigla) throws RemoteException {
        try {
        	return new CapTableHandler().isValidCAP(cap, provinciaSigla);
        } catch(final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * This method checks the province passed is existing in the table or not
     * @ param String province
     * @ exception RemoteException
     * @ return boolean
     */

    public boolean isValidProvince(final String province) throws RemoteException {
        try {
        	return new ProvinciaDBAccessHelper().isValidProvince(province);
        } catch(final GestoreProvinciaException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * This method checks the province and citta passed is existing in the table or not
     * @ param String province
     * @ exception RemoteException
     * @ return boolean
     */

    public boolean isValidProvince(final String province, final String citta) throws RemoteException {
        try {
        	return new ProvinciaDBAccessHelper().isValidProvince(province, citta);
        } catch(final GestoreProvinciaException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * This method retrieves the data for the specified cittaName
     * @return Citta
     * @exception RemoteException
     */
    public Citta getCitta(final String cittaName, final String province) throws RemoteException {
    	return new CittaDBAccessHelper().getCittaOfGVBean(cittaName, province);
    }

    /**
     * This method retrieves the data for the specified cittaName
     * @return Citta
     * @exception RemoteException
     */
    // This is being used by address management

    public Citta getCitta(final String cittaName) throws RemoteException {
    	return new CittaDBAccessHelper().getCittaOfGVBean(cittaName);
    }

    /**
     * This method retrieves the data for the specified cittaName
     * @return Citta
     * @exception RemoteException
     */

    public Citta getAnagraficCitta(final String cittaName) throws RemoteException {
    	return new CittaDBAccessHelper().getAnagraficCitta(cittaName);
    }

    /**
     * This method retrieves the Collection of citta's data for the specified cittaName
     * @return Collection citta objects collection
     * @exception RemoteException
     */

    public Collection getAnagraficValidCitta(final String cittaName) throws RemoteException {
    	return new CittaDBAccessHelper().getAnagraficValidCitta(cittaName);
    }

    /**
     * This method retrieves the data for the specified cittaName
     * @return Collection of Citta Object
     * @exception RemoteException
     */

    public Collection getCittaCollection(final String cittaName) throws RemoteException {
    	return new CittaDBAccessHelper().getCittaCollection(cittaName);
    }

    /**
     * This method retrieves the data for the specified cittaId
     * @return citta
     * @exception RemoteException
     */

    public Citta getCitta(final Long cittaId) throws RemoteException {
    	return new CittaDBAccessHelper().getCittaOfGVBean(cittaId);
    }

    /**
     * This method retrieves the data for the specified ramoId
     * @return ramo
     * @exception RemoteException
     */

    public Ramo getRamo(final Long ramoId) throws RemoteException {
    	return new RamoDBAccessHelper().getRamoOfGVBean(ramoId);
    }

    /**
     * This method retrieves the citta data for the specified cab
     * @param cab java.lang.String for which citta has to be retrieved
     * @return Citta
     * @exception InformazioneManagerException RemoteException
     */

    public Citta getCittaForCab(final String cab) throws InformazioneManagerException, RemoteException {
    	return new CittaDBAccessHelper().getCittaForCab(cab);
    }

    /**
     * @ param provinceId
     * @ return Provincia object
     * @ exception RemoteException
     */

    public Provincia getProvincia(final Long provinceId) throws RemoteException {
    	return new ProvinciaDBAccessHelper().getProvincia(provinceId);
    }

    /**
     * @ param provinceSigla
     * @ return Provincia object
     * @ exception RemoteException
     */

    public Provincia getProvincia(final String provinceSigla) throws RemoteException {
    	return new ProvinciaDBAccessHelper().getProvincia(provinceSigla);
    }

    public Collection getAllProvincia(final String sigla) throws RemoteException {
    	return new ProvinciaDBAccessHelper().getAllProvincia(sigla);
    }

    public Collection getAllProvinciaByName(final String provinciaNome) throws RemoteException {
    	return new ProvinciaDBAccessHelper().getAllProvinciaByName(provinciaNome);
    }

    /**
     * @ param capId
     * @ return CAP object
     * @ exception RemoteException
     */

    public CAP getCap(final Long capId) throws RemoteException {
    	return new CapTableHandler().getCap(capId);
    }

    /**
     * @ param String cap
     * @ return CAP object
     * @ exception RemoteException
     */

    public CAP getCap(final String capValue) throws RemoteException {
    	return new CapTableHandler().getCap(capValue);
    }

    /** Returns collections of caps retrieved for the cap value passed
     * @ param String capValue
     * @ return Collection
     * @ exception RemoteException
     */

    public Collection getAllCaps(final String capValue) throws RemoteException {
    	return new CapTableHandler().getAllCaps(capValue);
    }

    /** This creates the CAP object based on the cap U pass
     * @ param String cap
     * @ return CAP
     * @ exception RemoteException
     */

    public CAP getCap(final String caCap, final Citta citta) throws RemoteException {
    	return new CapTableHandler().getCap(caCap, citta);
    }

    /**
     * This returns the lingua
     * @ return Collection
     * @ exception RemoteException
     */

    public Collection listLingua() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("LINGUA");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * The method which retrieves the data of titolo1 using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listTitolo1() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("TITOLO_1");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * The method which retrieves the data of TitoloDiStudio using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listTitoloDiStudio() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("TLS");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * The method which retrieves the data of titolo2 using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listTitolo2() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("TITOLO_2");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * The method which retrieves the data of sesso using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listSesso() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("SESSO");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * The method which retrieves the data of professione using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listProfessione() throws RemoteException {
        try {
        	return new ProfessioneClassificazioneHandler().listProfessione();
        	//return ClassificazioneHandler.getClassificazioneViews("PROFESSIONE");
        } catch (final ProfessioneException e) {
        	 log4Debug.severeStackTrace(e);
        	throw new EJBException(e);
		}
    }

    /**
     * The method which retrieves the data of statocivile using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listStatoCivile() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("STATO_CIVILE");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /**
     * The method which retrieves the data of patrimoniale using classificazione
     * @return Collection
     * @exception RemoteException
     */

    public Collection listRegimePatrimoniale() throws RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("REGIME_PATRIMONIALE");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /** This method returns the attivita details
     * @ return Collection ClassificazioneViews
     * @ exception InformazioneManagerException, RemoteException
     */

    public Collection listAttivita() throws InformazioneManagerException, RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("ATTIVITA");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /** This method returns the attivita details
     * @ return Collection collection of attivita objects
     * @ exception InformazioneManagerException, RemoteException
     */
    public Collection getCompatibleAttivita(final String ramo) throws InformazioneManagerException,RemoteException {
    	return new AttivitaHandler().getCompatibleAttivita(ramo);
    }

    /** This method retrieves the descrizione of attivita
     * @ return String
     * @ exception InformazioneManagerException, RemoteException
     */
    public String getAttivitaDescrizione(final String codiceISTAT) throws InformazioneManagerException,RemoteException {
    	return new AttivitaHandler().getAttivitaDescrizione(codiceISTAT);
    }

    /** This method retrieves the tiposocieta
     * @ return Collection ClassificazioneViews
     * @ exception InformazioneManagerException, RemoteException
     */

    public Collection listTipoSocieta() throws InformazioneManagerException, RemoteException {
        try {
            return ClassificazioneHandler.getClassificazioneViews("TIPO_SOCIETA");
        } catch(final SubSystemHandlerException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    /** This methods retrieves the ramo of lower level where codici gruppo
     is not null
     @ return Collection -- Collection of ramo views
     @ exception RemoteException, InformazioneManagerException
     */

    public Collection listRamo() throws InformazioneManagerException, RemoteException {
    	return new RamoHandler().listRamo();
    }

    /** This method retrieves the Ramo based on the codiceGruppo
     * @ param String codiceGruppo
     * @ return Ramo Ramoobject
     * @ exception RemoteException, InformazioneManagerException
     */

    public Ramo getRamo(final String codiceGruppo) throws InformazioneManagerException, RemoteException {
    	return new RamoHandler().getRamo(codiceGruppo);
    }

    /**
     * The method which takes the tipoSoggettoId and returns the
     * compatible settore for that tipoSoggetto
     * @return Collection Settore
     * @exception InformazioneManagerException
     */

    public Collection listSettore(final Long tipoSoggettoId,final Long tipoSocietaId) throws InformazioneManagerException, RemoteException {
    	return new SettoreHandler().listSettore(tipoSoggettoId,tipoSocietaId);
    }

    public Collection listSettore(final Long tipoSoggettoId) throws InformazioneManagerException, RemoteException {
    	return new SettoreHandler().listSettore(tipoSoggettoId);
    }

    /**
     * The method which takes the codiceSottoGruppo and returns the
     * Settore
     * @param codiceSottoGruppo
     * @return Settore
     * @exception InformazioneManagerException
     */

    public Settore getSettore(final String codiceSottoGruppo) throws InformazioneManagerException, RemoteException {
    	return new SettoreHandler().getSettore(codiceSottoGruppo);
    }

	/**
	 * This method to returns all the settore
	 * @return
	 * @throws InformazioneManagerException
	 * @throws RemoteException
	 */

    public Collection getAllSettore() throws InformazioneManagerException, RemoteException {

        try {
			return new SettoreHandler().getAllSettore();
		} catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
		}
    }

    /**
     * The method which takes the codiceSottoGruppo and returns the Settore
     * @return Hashtable key : tipoSoggettoId value : tipoSoggettoDesc
     * @exception InformazioneManagerException
     */

    public Hashtable getCompatibleTipoSoggetto() throws InformazioneManagerException, RemoteException {
    	return new CompatibilityHelper().getCompatibleTipoSoggetto();
    }

    /**
     * The method which retrieves the soggettoId based on the causale and datifiscali code
     * @return Long soggettoId
     * @exception RemoteException
     */

    public Long getSoggettoIdForDatiFiscali(final String causale, final String valoreDatiFiscal) throws RemoteException {
        try {
            return new DatiFiscaliDBAccessHelper().getSoggettoIdDF(causale,valoreDatiFiscal);
        } catch(final GestoreDatiFiscaliException e) {
            log4Debug.severeStackTrace(e);
            throw new EJBException(e);
        }
    }

    public Collection getSoggettoIdsForDatiFiscali(final String causale, final String valoreDatiFiscal) throws InformazioneManagerException, RemoteException {
    	return new DatiFiscaliDBAccessHelper().getSoggettoIdsForDatiFiscali(causale, valoreDatiFiscal);
    }

    public Collection getCompatibleMotivi(final Long tipoSoggettoId, final Long tipoSocietaId) throws InformazioneManagerException, RemoteException {
    	return new CompatibilityHelper().getCompatibleMotivi(tipoSoggettoId, tipoSocietaId);
    }

    public boolean isExistsDatiFiscali(final String code, final String causale) throws RemoteException {
    	return new DatiFiscaliDBAccessHelper().isExistsDatiFiscali(code, causale);
    }

    public Collection listInvalidDocumento(final String tipoDocumento) throws InformazioneManagerException, RemoteException{
    	return new DocumentiDBAccessHelper().listInvalidDocumento(tipoDocumento);
    }

    public void updateInvalidDocumento(final InvalidDocumentoView invalidDocumentoView) throws InformazioneManagerException, RemoteException{
    	new DocumentiDBAccessHelper().updateInvalidDocumento(invalidDocumentoView);
    }

    public void addInvalidDocumento(final InvalidDocumentoView invalidDocumentoView) throws InformazioneManagerException, RemoteException{
    	new DocumentiDBAccessHelper().addInvalidDocumento(invalidDocumentoView);
    }

    public void deleteInvalidDocumento(final Long id) throws InformazioneManagerException, RemoteException{
    	new DocumentiDBAccessHelper().deleteInvalidDocumento(id);
    }

    public Collection getAllCampagna() throws InformazioneManagerException, RemoteException {
        try {
            return new OrigineClienteDBAccessHelper().getCampagnaCollection();
        } catch (final OperazioneAnagrafeManagerException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        }
    }

    public void createOrigineClienteMaster(final OrigineClienteMasterView origineClienteMasterView) throws InformazioneManagerException, RemoteException {
        try {
        	new OrigineClienteDBAccessHelper().createOrigineClienteMaster(origineClienteMasterView);
        } catch (final CollegamentoException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        }
    }

    public void updateOrigineClienteMaster(final OrigineClienteMasterView origineClienteMasterView) throws InformazioneManagerException, RemoteException {
        try {
        	new OrigineClienteDBAccessHelper().updateOrigineClienteMaster(origineClienteMasterView);
        } catch (final CollegamentoException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        }
    }

    public void removeOrigineClienteMaster(final OrigineClienteMasterView origineClienteMasterView) throws InformazioneManagerException, RemoteException {
        try {
        	new OrigineClienteDBAccessHelper().removeOrigineClienteMaster(origineClienteMasterView);
        } catch (final CollegamentoException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
        }
    }

    public List getAttSezione(final String codiceSotto) throws InformazioneManagerException, RemoteException {
    	try {
			return new ClasseATECODBAccessHelper().getCompatibleAteco2007(codiceSotto);
		} catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
		}
    }

    public List getAttClasse(final String classeCode) throws InformazioneManagerException, RemoteException {
    	try {
			return new ClasseATECODBAccessHelper().getClasseATECOByParentCode(classeCode);
		} catch (final GestoreAnagrafeException e) {
            log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
		}
    }

    //To get all the Modalita values to select who has verified the document
    public Collection getAllModalita() throws InformazioneManagerException, RemoteException {
    	try {
			return ClassificazioneHandler.getClassificazioneViews("MODALITA");
		} catch (final SubSystemHandlerException e) {
			log4Debug.severeStackTrace(e);
            throw new EJBException(e);
		}
    }

    public List<TAE> getTAE(final Long professioneId)throws InformazioneManagerException, RemoteException{
		try {log4Debug.info("called in GeograficaValidatorImplBean professioneId=",professioneId);
			return new TAEHandler().getTAEList(professioneId);
		} catch (final GestoreAnagrafeException e) {
			 log4Debug.severeStackTrace(e);
	            throw new InformazioneManagerException(e.getMessage());
		}

    }
    public List<AlboProfessione> getAlboProfessiones(final Long tipoSoggettoId)throws InformazioneManagerException, RemoteException{
		try {
			log4Debug.info("called in GeograficaValidatorImplBean getAlboProfessioneList professioneId=",tipoSoggettoId);
			return new AlboProfessioneHandler().getAlboProfessioneList(tipoSoggettoId);
		} catch (final GestoreAnagrafeException e) {
			 log4Debug.severeStackTrace(e);
	            throw new InformazioneManagerException(e.getMessage());
		}

    }

    /*public List<AlboProfessione> getAlboProfessiones()throws InformazioneManagerException, RemoteException{
		try {
			return new AlboProfessioneHandler().getAlboProfessione();
		} catch (final GestoreAnagrafeException e) {
			 log4Debug.severeStackTrace(e);
	            throw new InformazioneManagerException(e.getMessage());
		}
    }*/
    /**
     * This method returns list of nazione's with storic equal to zero having prefisso
     */
    public Collection<Nazione> listNazioneWithPrefisso() throws RemoteException {
    	return new NazioneDBAccessHelper().listNazioneWithPrefisso();
    	
    }
   /* *//**
     * 
     * @param atecoCode
     * @return
     * @throws InformazioneManagerException
     * @throws RemoteException
     *//*
    public ClassificazioneView getSettoreCommerciale(final String atecoCode)throws InformazioneManagerException, RemoteException{
		try {
			log4Debug.info("called in GeograficaValidatorImplBean getSettoreCommercialeByAtecoCode =",atecoCode);
			return new SettoreCommercialeHandler().getSettoreCommercialeByAtecoCode(atecoCode);
		} catch (final GestoreAnagrafeException e) {
			 log4Debug.severeStackTrace(e);
	            throw new InformazioneManagerException(e.getMessage());
		}

    }
    *//**
     * 
     * @param taeCode
     * @return
     * @throws InformazioneManagerException
     * @throws RemoteException
     *//*
    public ClassificazioneView getSettoreCommercialeByTAE(final String taeCode)throws InformazioneManagerException, RemoteException{
		try {
			log4Debug.info("called in GeograficaValidatorImplBean getSettoreCommercialeBytaeCodeCode =",taeCode);
			return new SettoreCommercialeHandler().getSettoreCommercialeByTAECode(taeCode);
		} catch (final GestoreAnagrafeException e) {
			 log4Debug.severeStackTrace(e);
	            throw new InformazioneManagerException(e.getMessage());
		}

    }*/
    
    /**
     * @param tipoSoggetto
     * @return
     * @throws InformazioneManagerException
     * @throws RemoteException
     * Collection<FatcaAZView>
     */
    public Collection<FatcaAZView> listFatcaConfermata(final String tipoSoggetto) throws InformazioneManagerException, RemoteException{
    	try {
    		return new ClassificazioneFatcaGetter().getAZClassificazioneFatca(tipoSoggetto);
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			throw new InformazioneManagerException(e.getMessage());
		}
    }
    
    /**
     * This Method Returns all the available Tipo PoteriFirma documents.
     * @throws RemoteException 
     * @throws InformazioneManagerException 
     * 
     */
    public Collection listAllPoteriFirmaDocumento() throws RemoteException, InformazioneManagerException{
    	Collection poteriFirmaDocList = null;
    	try {
    		poteriFirmaDocList = ClassificazioneHandler.getClassificazioneViews("TIPO_DOC_POTERI_FIRMA");
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
			throw new InformazioneManagerException(e.getMessage());
		}
		return poteriFirmaDocList;
    }
    
    /**
     * This methos is to retrieve SettoreAttivita List by passing proffessione id
     * @param professioneId
     * @return
     * @throws RemoteException
     * @throws InformazioneManagerException
     */
    public List<SettoreDiAttivita> getSettoreDiAttivitaByProffessioneId(final Long professioneId)throws RemoteException, InformazioneManagerException{
    	try {
			return new SettoreDiAttivitaHandler().getSettoreDiAttivitaByProffessioneId(professioneId);
		} catch (GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
		}
    }
    
    /**
     * This method is to retrieve TAE list by passing professione and settore attivita id
     * @param professioneId
     * @param settoreAttivitaId
     * @return
     * @throws RemoteException
     * @throws InformazioneManagerException
     */
    public List<TAE> getTAEListByPorfessionAndSettoreAttivitaId(final Long professioneId,final Long settoreAttivitaId)throws RemoteException, InformazioneManagerException{
    	try {
			return new TAEHandler().getTAEListByPorfessionAndSettoreAttivitaId(professioneId, settoreAttivitaId);
		} catch (GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
            throw new InformazioneManagerException(e.getMessage());
		}
    }
    
    /**
     * This method returns The channels Of Communication
     * @return
     * @throws RemoteException
     * @throws InformazioneManagerException
     */
    public Collection<ClassificazioneView> getCanalePreferitoList() throws RemoteException, InformazioneManagerException {
		try {
			return ClassificazioneHandler.getClassificazioneViews("CANALE_PREFERITO");
		} catch (final SubSystemHandlerException e) {
			log4Debug.severeStackTrace(e);
			throw new InformazioneManagerException(e.getMessage());
		}
    }
    
    /**
     * This method returns Compatible Recapiti for the channelsofCommunication.
     * @return
     * @throws RemoteException
     * @throws InformazioneManagerException
     */
    public Collection<RecapitiCanaleComptView> getCompatibleRecapitiCanale() throws RemoteException, InformazioneManagerException {
		try {
			return new CanalePreferitoDBAccessHelper().getCompatibleRecapitiCanale();
		} catch (CanalePreferitoException e) {
			log4Debug.severeStackTrace(e);
			throw new InformazioneManagerException(e.getMessage());
		}
    }
}
