package it.sella.anagrafe.dairegole;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author GBS03447
 * 
 */

@Entity
@Table(name="AN_TR_DAI_REGOLE_DETT")
@SequenceGenerator(name="DaiRegoleSequenceGenerator", sequenceName="AN_SQ_DAI_REGOLE_DETT", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name="DAIRegoleBean.findBySoggettoId",query="select o from DAIRegoleBean o where o.soggettoId = :soggettoId"),
	@NamedQuery(name="DAIRegoleBean.findBySoggettoAndPesoId",query="select o from DAIRegoleBean o where o.soggettoId = :soggettoId and o.pesoId = :pesoId")
})
public class DAIRegoleBean implements DAIRegole {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DaiRegoleSequenceGenerator")
	@Column(name="DR_ID")
	private Long daiRegoleId;
	
	@Column(name="DR_SOGGETTO_ID")
	private Long soggettoId;
	
	@Column(name="DR_PESO_ID")
	private Long pesoId;
	
	@Column(name="DR_DAI_CODE_ID")
	private Long daiCodeId;
	
	@Column(name="DR_DAI_WEIGHT_ID")
	private Long daiWeightId;
	
	@Column(name="DR_OP_ID")
	private Long opId;

	public Long getDaiRegoleId() {
		return daiRegoleId;
	}

	public void setDaiRegoleId(final Long daiRegoleId) {
		this.daiRegoleId = daiRegoleId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getPesoId() {
		return pesoId;
	}

	public void setPesoId(final Long pesoId) {
		this.pesoId = pesoId;
	}

	public Long getDaiCodeId() {
		return daiCodeId;
	}

	public void setDaiCodeId(final Long daiCodeId) {
		this.daiCodeId = daiCodeId;
	}

	public Long getDaiWeightId() {
		return daiWeightId;
	}

	public void setDaiWeightId(final Long daiWeightId) {
		this.daiWeightId = daiWeightId;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
