package it.sella.anagrafe.canalepreferito;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "AN_TR_CANALE_PREFERITO")
@SequenceGenerator(name = "CanaleSequenceGenerator", sequenceName = "AN_SQ_CANALE_PREFERITO", allocationSize = 1)
@NamedQueries({
	@NamedQuery(name = "CanalePreferitoBean.findBySoggettoId", query = "select o from CanalePreferitoBean o where o.soggettoId= :soggettoId and o.dataFine is null"),
	@NamedQuery(name = "CanalePreferitoBean.findBySoggettoAndCanaleId",query="select o from CanalePreferitoBean o where (o.soggettoId= :soggettoId and o.canaleId=:canaleId) and o.dataFine is null")
})
public class CanalePreferitoBean implements CanalePreferito {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CanaleSequenceGenerator")
	@Column(name="CP_ID")
	private Long canalePreferitoId;

	@Column(name="CP_ID_SOGGETTO")
	private Long soggettoId;
	
	@Column(name="CP_CANALE_ID")
	private Long canaleId;
	
	@Column(name="CP_CANALE_VALUE")
	private String canaleValue;
	
	@Column(name="CP_TIPO_RECAPITI")
	private Long tipoRecapiti;
	
	@Column(name="CP_DATA_INIZIO_VALIDITA")
	private Timestamp dataInizio;
	
	@Column(name="CP_DATA_FINE_VALIDITA")
	private Timestamp dataFine;
	
	@Column(name="CP_UTENTE_INSERIMENTO")
	private String utenteInserimento;
	
	@Column(name="CP_UTENTE_MODIFICATO")
	private String utenteModificato;
	
	@Column(name="CP_OP_ID")
	private Long opId;

	public Long getCanalePreferitoId() {
		return canalePreferitoId;
	}

	public void setCanalePreferitoId(final Long canalePreferitoId) {
		this.canalePreferitoId = canalePreferitoId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getCanaleId() {
		return canaleId;
	}

	public void setCanaleId(final Long canaleId) {
		this.canaleId = canaleId;
	}

	public String getCanaleValue() {
		return canaleValue;
	}

	public void setCanaleValue(final String canaleValue) {
		this.canaleValue = canaleValue;
	}

	public Long getTipoRecapiti() {
		return tipoRecapiti;
	}

	public void setTipoRecapiti(final Long tipoRecapiti) {
		this.tipoRecapiti = tipoRecapiti;
	}

	public Timestamp getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Timestamp getDataFine() {
		return dataFine;
	}

	public void setDataFine(final Timestamp dataFine) {
		this.dataFine = dataFine;
	}

	public String getUtenteInserimento() {
		return utenteInserimento;
	}

	public void setUtenteInserimento(final String utenteInserimento) {
		this.utenteInserimento = utenteInserimento;
	}

	public String getUtenteModificato() {
		return utenteModificato;
	}

	public void setUtenteModificato(final String utenteModificato) {
		this.utenteModificato = utenteModificato;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
