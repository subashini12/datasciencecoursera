package it.sella.anagrafe.canalepreferito;

import java.util.Collection;

import javax.ejb.FinderException;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.factory.AnagrafeEntityManagerFactory;
import it.sella.anagrafe.factory.BeanUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;


/**
 * @author GBS03447
 *
 */
public class CanalePreferitoBeanManager implements ICanalePreferitoBeanManager {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CanalePreferitoBeanManager.class);
	
	private EntityManager entityManager = null;
	
	public CanalePreferitoBeanManager() {
		entityManager = AnagrafeEntityManagerFactory.getInstance()
				.getEntityManager();
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.canalepreferito.ICanalePreferitoBeanManager#create(it.sella.anagrafe.canalepreferito.CanalePreferito)
	 */
	public CanalePreferito create(final CanalePreferito canalePreferito) throws GestoreAnagrafeException  {
		log4Debug.debug("CanalePreferitoBeanManager   ::::  create  :::  CanalePreferito.");
		final CanalePreferitoBean canalePreferitoBean = new CanalePreferitoBean();
		BeanUtil.copyProperties(canalePreferitoBean, canalePreferito);
		entityManager.persist(canalePreferitoBean);
		entityManager.flush();
		BeanUtil.copyProperties(canalePreferito, canalePreferitoBean);
		return canalePreferito;
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.canalepreferito.ICanalePreferitoBeanManager#update(it.sella.anagrafe.canalepreferito.CanalePreferito)
	 */
	public CanalePreferito update(final CanalePreferito canalePreferito) {
		log4Debug.debug("CanalePreferitoBeanManager   ::  update  ::  CanalePreferito.");
		entityManager.persist(canalePreferito);
		return canalePreferito;
	}
	
	/* (non-Java doc)
	 * @see it.sella.anagrafe.canalepreferito.ICanalePreferitoBeanManager#remove(it.sella.anagrafe.canalepreferito.CanalePreferito)
	 */
	public void remove(final CanalePreferito canalePreferito) {
		log4Debug.debug("CanalePreferitoBeanManager   :::  remove  :::  CanalePreferito.");
		entityManager.remove(canalePreferito);
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.canalepreferito.ICanalePreferitoBeanManager#findByPrimaryKey(java.lang.Long)
	 */
	public CanalePreferito findByPrimaryKey(final Long primaryKey) throws FinderException {
		if(primaryKey == null){
			throw new FinderException("PrimaryKey is null");
		}
		final CanalePreferito canalePreferito = entityManager.find(CanalePreferitoBean.class, primaryKey);
		if(canalePreferito == null){
			throw new FinderException("Record Not Found For PrimaryKey "+ primaryKey);
		}
		return canalePreferito;
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.canalepreferito.ICanalePreferitoBeanManager#findBySoggettoId(java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<CanalePreferito> findBySoggettoId(final Long soggettoId) throws FinderException {
		final Query findBySoggettoId = entityManager.createNamedQuery("CanalePreferitoBean.findBySoggettoId");
		findBySoggettoId.setParameter("soggettoId", soggettoId);
		return findBySoggettoId.getResultList();
	}
	
	/* (non-Javadoc)
	 * @see it.sella.anagrafe.canalepreferito.ICanalePreferitoBeanManager#findBySoggettoIdAndCanaleId(java.lang.Long, java.lang.Long)
	 */
	@SuppressWarnings("unchecked")
	public Collection<CanalePreferito> findBySoggettoIdAndCanaleId (final Long soggettoId, final Long canaleId) throws FinderException {
		try {
			final Query findBySoggettoAndCanaleId = entityManager.createNamedQuery("CanalePreferitoBean.findBySoggettoAndCanaleId");
			findBySoggettoAndCanaleId.setParameter("soggettoId", soggettoId);
			findBySoggettoAndCanaleId.setParameter("canaleId", canaleId);
			return findBySoggettoAndCanaleId.getResultList();
		} catch (final NoResultException noResultExcep){
			log4Debug.warnStackTrace(noResultExcep);
			throw new FinderException(noResultExcep.getMessage());
		}
	}
}