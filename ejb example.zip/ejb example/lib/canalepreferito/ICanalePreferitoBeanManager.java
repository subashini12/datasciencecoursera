package it.sella.anagrafe.canalepreferito;

import java.util.Collection;

import javax.ejb.FinderException;

import it.sella.anagrafe.GestoreAnagrafeException;

public interface ICanalePreferitoBeanManager {
	
	
	/**
	 * Method to create CanalePreferito
	 * @param canalePreferito
	 * @return
	 * @throws GestoreAnagrafeException
	 */
	CanalePreferito create(final CanalePreferito canalePreferito) throws GestoreAnagrafeException;
	
	/**
	 * Method to update CanalePreferito
	 * @param canalePreferito
	 * @return
	 */
	CanalePreferito update(final CanalePreferito canalePreferito);
	
	/**
	 * Method to remove CanalePreferito
	 * @param canalePreferito
	 */
	void remove(final CanalePreferito canalePreferito);
	
	/**
	 * Method to find by using PrimaryKey
	 * @param primaryKey
	 * @return
	 * @throws FinderException
	 */
	CanalePreferito findByPrimaryKey(final Long primaryKey) throws FinderException;
	
	/**
	 * Method to find by using SoggettoId
	 * @param soggettoId
	 * @return
	 * @throws FinderException
	 */
	Collection<CanalePreferito> findBySoggettoId(final Long soggettoId) throws FinderException;
	
	/**
	 * Method to find by using SoggettoId, canaleId
	 * @param soggettoId
	 * @param canaleId
	 * @return
	 * @throws FinderException
	 */
	Collection<CanalePreferito> findBySoggettoIdAndCanaleId (final Long soggettoId, final Long canaleId) throws FinderException;
	
}
