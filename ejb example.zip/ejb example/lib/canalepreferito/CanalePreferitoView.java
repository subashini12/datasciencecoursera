package it.sella.anagrafe.canalepreferito;

import java.sql.Timestamp;

/**
 * @author GBS03447
 *
 */
public class CanalePreferitoView implements CanalePreferito {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long canalePreferitoId;
	private Long soggettoId;
	private Long canaleId;
	private String canaleValue;
	private Long tipoRecapiti;
	private Timestamp dataInizio;
	private Timestamp dataFine;
	private String utenteInserimento;
	private String utenteModificato;
	private Long opId;

	public Long getCanalePreferitoId() {
		return canalePreferitoId;
	}

	public void setCanalePreferitoId(final Long canalePreferitoId) {
		this.canalePreferitoId = canalePreferitoId;
	}

	public Long getSoggettoId() {
		return soggettoId;
	}

	public void setSoggettoId(final Long soggettoId) {
		this.soggettoId = soggettoId;
	}

	public Long getCanaleId() {
		return canaleId;
	}

	public void setCanaleId(final Long canaleId) {
		this.canaleId = canaleId;
	}

	public String getCanaleValue() {
		return canaleValue;
	}

	public void setCanaleValue(final String canaleValue) {
		this.canaleValue = canaleValue;
	}

	public Long getTipoRecapiti() {
		return tipoRecapiti;
	}

	public void setTipoRecapiti(final Long tipoRecapiti) {
		this.tipoRecapiti = tipoRecapiti;
	}

	public Timestamp getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(final Timestamp dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Timestamp getDataFine() {
		return dataFine;
	}

	public void setDataFine(final Timestamp dataFine) {
		this.dataFine = dataFine;
	}

	public String getUtenteInserimento() {
		return utenteInserimento;
	}

	public void setUtenteInserimento(final String utenteInserimento) {
		this.utenteInserimento = utenteInserimento;
	}

	public String getUtenteModificato() {
		return utenteModificato;
	}

	public void setUtenteModificato(final String utenteModificato) {
		this.utenteModificato = utenteModificato;
	}

	public Long getOpId() {
		return opId;
	}

	public void setOpId(final Long opId) {
		this.opId = opId;
	}
}
