package it.sella.anagrafe.canalepreferito;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author GBS03447
 *
 */
public interface CanalePreferito extends Serializable {
	
	Long getCanalePreferitoId();
	Long getSoggettoId();
	Long getCanaleId();
	String getCanaleValue();
	Long getTipoRecapiti();
	Timestamp getDataInizio();
	Timestamp getDataFine();
	String getUtenteInserimento();
	String getUtenteModificato();
	Long getOpId();
	
	void setCanalePreferitoId(final Long canalePreferitoId);
	void setSoggettoId(final Long soggettoId);
	void setCanaleId(final Long canaleId);
	void setCanaleValue(final String canaleValue);
	void setTipoRecapiti(final Long tipoRecapiti);
	void setDataInizio(final Timestamp dataInizio);
	void setDataFine(final Timestamp dataFine);
	void setUtenteInserimento(final String utenteInserimento);
	void setUtenteModificato(final String utenteModificato);
	void setOpId(final Long opId);
}
