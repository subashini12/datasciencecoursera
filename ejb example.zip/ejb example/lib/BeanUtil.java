package it.sella.anagrafe.factory;

import it.sella.anagrafe.GestoreAnagrafeException;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.PropertyUtils;

public class BeanUtil {
	
	public static Object copyProperties(final Object dest, final Object orig) throws GestoreAnagrafeException{
		try {
			PropertyUtils.copyProperties(dest, orig);
		} catch (final IllegalAccessException e) {
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final InvocationTargetException e) {
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final NoSuchMethodException e) {
			throw new GestoreAnagrafeException(e.getMessage());
		}
		return dest;
	}
}
