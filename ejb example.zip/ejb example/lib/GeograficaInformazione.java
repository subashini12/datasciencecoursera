package it.sella.anagrafe.implementation;

import it.sella.anagrafe.InformazioneManagerException;
import it.sella.anagrafe.common.CAP;
import it.sella.anagrafe.common.Citta;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.common.Provincia;
import it.sella.anagrafe.common.Ramo;
import it.sella.anagrafe.common.RecapitiCanaleComptView;
import it.sella.anagrafe.common.SettoreDiAttivita;
import it.sella.anagrafe.common.TAE;
import it.sella.anagrafe.originecliente.OrigineClienteMasterView;
import it.sella.anagrafe.view.InvalidDocumentoView;
import it.sella.classificazione.ClassificazioneView;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;

public interface GeograficaInformazione {

    Collection listNazione() throws RemoteException;

    Collection listNazione(String nazioneNome) throws RemoteException;

    Collection listAnagraficNazione() throws RemoteException;

    boolean isValidCAP(String cap) throws RemoteException;

    boolean isValidCAP(String cap, String citta) throws RemoteException;

    boolean isValidProvince(String province) throws RemoteException;

    boolean isValidProvince(String province, String citta) throws RemoteException;

    //boolean isValidCitta(String cittaName) throws RemoteException;
    Citta getCitta(Long cittaId) throws RemoteException;
    //added by pals
    Ramo getRamo(Long ramoId) throws RemoteException;

    Collection getCittaCollection(String cittaName) throws RemoteException;

    Citta getCitta(String cittaName) throws RemoteException;

    Collection getAnagraficValidCitta(String cittaName) throws RemoteException;

    Citta getAnagraficCitta(String cittaName) throws RemoteException;

    Citta getCitta(String cittaName, String province) throws RemoteException;

    Citta getCittaForCab(String cab) throws InformazioneManagerException, RemoteException;

    Nazione getNazione(Long nazioneId) throws RemoteException;

    Nazione getNazione(String nazione) throws RemoteException;

    Nazione getNazioneForIndirizzo(String nazione) throws RemoteException;

    Provincia getProvincia(Long provinceId) throws RemoteException;

    Provincia getProvincia(String sigla) throws RemoteException;

    Collection getAllProvincia(String sigla) throws RemoteException;

    Collection getAllProvinciaByName(String provinciaNome) throws RemoteException;

    CAP getCap(Long capID) throws RemoteException;

    CAP getCap(String capValue) throws RemoteException;

    Collection getAllCaps(String capValue) throws RemoteException;

    CAP getCap(String cap, Citta citta) throws RemoteException;
    

    /** This method returns the lists of details for the given Tipo Documento Causale ID.
     * @param tipoDocumento
     * @return Collection
     * @exception InformazioneManagerException
     * @exception RemoteException
     */
    public Collection listInvalidDocumento(String tipoDocumento) throws InformazioneManagerException, RemoteException;

    /** This method inserts a row in the INVALID_DOCUMENTO table.
     * @param invalidDocumentoView
     * @exception InformazioneManagerException
     * @exception RemoteException
     */
    public void addInvalidDocumento(InvalidDocumentoView invalidDocumentoView) throws InformazioneManagerException, RemoteException;

    /** This method updates a row in the INVALID_DOCUMENTO table.
     * @param invalidDocumentoView
     * @exception InformazioneManagerException
     * @exception RemoteException
     */
    public void updateInvalidDocumento(InvalidDocumentoView invalidDocumentoView) throws InformazioneManagerException, RemoteException;

    /** This method deletes a row from the INVALID_DOCUMENTO table for the Primary key ID passed as input.
     * @param id
     * @exception InformazioneManagerException
     * @exception RemoteException
     */
    public void deleteInvalidDocumento(Long id) throws InformazioneManagerException, RemoteException;

    public Collection getAllCampagna() throws InformazioneManagerException, RemoteException;

    public void createOrigineClienteMaster(OrigineClienteMasterView origineClienteMasterView) throws InformazioneManagerException, RemoteException ;

    public void updateOrigineClienteMaster(OrigineClienteMasterView origineClienteMasterView) throws InformazioneManagerException, RemoteException ;

    public void removeOrigineClienteMaster(OrigineClienteMasterView origineClienteMasterView) throws InformazioneManagerException, RemoteException ;

    /**
     * This method is used to get all the modalita values to select the person who has done the verification of the document
     * @return Collection
     * @throws InformazioneManagerException
     * @throws RemoteException
     */

    public Collection getAllModalita() throws InformazioneManagerException, RemoteException;
    /**
     * This method is used to get the nazione collection with storic equla to zero having prefisso
     */
    public Collection<Nazione> listNazioneWithPrefisso() throws  RemoteException;
    
    public Collection listAllPoteriFirmaDocumento() throws RemoteException, InformazioneManagerException;
    /**
     * This method is used to get the SettoreDiAttivita List by passing professione id
     */
    public List<SettoreDiAttivita> getSettoreDiAttivitaByProffessioneId(final Long professioneId) throws RemoteException, InformazioneManagerException;
    /**
     * This methos is to get tae list by seelcting professione and attivita id
     */
    public List<TAE> getTAEListByPorfessionAndSettoreAttivitaId(final Long professioneId,final Long settoreAttivitaId ) throws RemoteException, InformazioneManagerException;
    
    /**
     * This Method Returns the Canale preferito List.
     */
    public Collection<ClassificazioneView> getCanalePreferitoList() throws RemoteException, InformazioneManagerException;
    
    /**
     * This Method Returns the Compatible Recapiti Canale preferito.
     */
    public Collection<RecapitiCanaleComptView> getCompatibleRecapitiCanale() throws RemoteException, InformazioneManagerException;
}