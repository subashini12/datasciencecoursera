package it.sella.anagrafe.dairegole;

import java.io.Serializable;

/**
 * @author GBS03447
 *
 */
public interface DAIRegole extends Serializable {
	
	Long getDaiRegoleId();
	Long getSoggettoId();
	Long getPesoId();
	Long getDaiCodeId();
	Long getDaiWeightId();
	Long getOpId();
	
	void setDaiRegoleId(final Long daiRegoleId);
	void setSoggettoId(final Long soggettoId);
	void setPesoId(final Long pesoId);
	void setDaiCodeId(final Long daiCodeId);
	void setDaiWeightId(final Long daiWeightId);
	void setOpId(final Long opId);
}
