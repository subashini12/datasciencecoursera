package it.sella.anagrafe.dairegole;

import java.util.Collection;
import javax.ejb.FinderException;
import it.sella.anagrafe.GestoreAnagrafeException;

/**
 * @author GBS03447
 *
 */
public interface IDAIRegoleBeanManager {

	public DAIRegole create(final DAIRegole daiRegole) throws GestoreAnagrafeException;

	public DAIRegole update(final DAIRegole daiRegole);

	public void remove(final DAIRegole daiRegole);

	public Collection<DAIRegole> findBySoggettoId(final Long soggettoId) throws FinderException;
	
	public DAIRegole findByPrimaryKey(final Long primaryKey) throws FinderException;
	
	public DAIRegole findBySoggettoIdAndPesoId(final Long soggettoId, final Long pesoId) throws FinderException;

}
