package it.sella.anagrafe.factory;

import it.sella.anagrafe.AnagrafeDAIException;
import it.sella.anagrafe.DAISoggettoException;
import it.sella.anagrafe.IDAIRegoleDetailsView;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.SoggettoDAIDataView;
import it.sella.anagrafe.discriminator.AttributiEsterniDiscriminatorException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

/**
 * @author GBS03447
 *
 */
public class AnagrafeDAIFactory extends Factory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AnagrafeDAIFactory.class);

	/**
	 * @param daiRegoleColl
	 * @param opId
	 * @param soggettoId
	 * @throws RemoteException 
	 * @throws FactoryException 
	 */
	public void createDAIRegole(final Collection<IDAIRegoleDetailsView> daiRegoleColl, final Long soggettoId, final Long opId) throws RemoteException, FactoryException {
		log4Debug.debug("AnagrafeDAIFactory  ::  createDAIRegole   ::::  daiRegoleColl ::  ", daiRegoleColl);
		try {
			if (daiRegoleColl != null && !daiRegoleColl.isEmpty()) {
				for (final IDAIRegoleDetailsView daiRegoleView : daiRegoleColl) {
					getOperazioneAnagrafeManager().createDAIRegole(daiRegoleView, soggettoId, opId);
				}
			}
		} catch (final AnagrafeDAIException e) {
			log4Debug.warnStackTrace(e);
			throw new FactoryException(e.getMessage());
		}
	}
	
	/**
	 * @param daiRegoleCollNew
	 * @param daiRegoleCollOld
	 * @param soggettoId
	 * @param opId
	 * @throws RemoteException 
	 * @throws FactoryException 
	 */
	public void setDAIRegole(final Collection<IDAIRegoleDetailsView> daiRegoleCollNew, final Collection<IDAIRegoleDetailsView> daiRegoleCollOld, final Long soggettoId, final Long opId) throws RemoteException, FactoryException {
		try {
			log4Debug.debug("AnagrafeDAIFactory  ::  setDAIRegole   ::::  daiRegoleCollOld ::  ", daiRegoleCollOld);
			log4Debug.debug("AnagrafeDAIFactory  ::  setDAIRegole   ::::  daiRegoleCollNew ::  ", daiRegoleCollNew);
			
			if((daiRegoleCollOld == null || daiRegoleCollOld.isEmpty()) && daiRegoleCollNew != null && !daiRegoleCollNew.isEmpty()) {
				createDAIRegole(daiRegoleCollNew, soggettoId, opId);
			} else if(daiRegoleCollNew != null && !daiRegoleCollNew.isEmpty()) {
				for (final IDAIRegoleDetailsView daiRegoleDetailView : daiRegoleCollNew) {
					getOperazioneAnagrafeManager().setDAIRegole(daiRegoleDetailView, soggettoId, opId);
				}
			}
		} catch (final FactoryException e) {
			log4Debug.warnStackTrace(e);
			throw new FactoryException(e.getMessage());
		} catch (final AnagrafeDAIException e) {
			log4Debug.warnStackTrace(e);
			throw new FactoryException(e.getMessage());
		}
	}
	
	/**
	 * @param daiView
	 * @param soggettoId
	 * @param opId
	 * @throws FactoryException
	 * @throws RemoteException
	 */
	public void createDAISoggetto (final SoggettoDAIDataView daiView, final Long soggettoId, final Long opId) throws FactoryException, RemoteException {
		try {
			if(daiView != null) {
				getOperazioneAnagrafeManager().createDAISoggetto(daiView, soggettoId, opId);
			}
		} catch (final DAISoggettoException e) {
			log4Debug.warnStackTrace(e);
			throw new FactoryException(e.getMessage());
		}
	}
	
	/**
	 * @param daiSoggettoViewNew
	 * @param soggettoId
	 * @param opId
	 * @throws FactoryException
	 * @throws RemoteException
	 */
	public void setDAISoggetto(final SoggettoDAIDataView daiSoggettoView, final Long soggettoId, final Long opId) throws FactoryException, RemoteException {
		try {
			getOperazioneAnagrafeManager().setDAISoggetto(daiSoggettoView, soggettoId, opId);
		} catch (final DAISoggettoException e) {
			log4Debug.warnStackTrace(e);
			throw new FactoryException(e.getMessage());
		}
	}
	
	/**
	 * @param soggettoId
	 * @param dai
	 * @param daiSwitchAllowed
	 * @param opId
	 * @throws RemoteException
	 * @throws FactoryException
	 */
	public void setAttributiDAIForSoggetto (final Long soggettoId, final boolean dai, final Boolean daiSwitchAllowed , final Long opId) throws RemoteException, FactoryException {
		final String daiValue = dai ? "true" : "false";
		final String causale = (daiSwitchAllowed != null && daiSwitchAllowed) ? "dai" : "newDai";
		
		try {
			OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager().setAttributiEsterniValues(soggettoId, daiValue, causale, opId);
		} catch (final AttributiEsterniDiscriminatorException e) {
			log4Debug.warnStackTrace(e);
			throw new FactoryException(e.getMessage());
		}
	}
}
