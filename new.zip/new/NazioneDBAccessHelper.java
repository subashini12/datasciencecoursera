package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.INazioneView;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.implementation.OperazioneAnagrafeManagerException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import javax.ejb.EJBException;

public class NazioneDBAccessHelper extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(NazioneDBAccessHelper.class);

    public INazioneView getNazione(final Long nazioneId) throws GestoreNazioneException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        NazioneView nazioneview = null;
        ResultSet resultset = null;
        try {
            connection = getConnection();
            preparedstatement = connection.prepareStatement("select NA_NOME, NA_NAZIONALITA, NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE, NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO, NA_AREA_GEOGRAFICA, NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME, NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE, NA_CONTINENTE, NA_STORICO, NA_NAZIONE, NA_NAZIONE_APPARTENENZA, NA_HA_EMBARGO, NA_NORMALIZZATO, NA_DOC_AGGIUNTIVI, NA_INTERNATIONALE_NOME, NA_INTERNATIONALE_SHORT_NOME, NA_ADERENTE_GAFI,NA_CODICE_ISO_NUM,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE from AN_MA_NAZIONE where NAZIONE_ID = ?");
            preparedstatement.setLong(1, nazioneId.longValue());
            resultset = preparedstatement.executeQuery();
            if (resultset.next()) {
            	final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
                nazioneview = new NazioneView();
                nazioneview.setNome(resultset.getString("NA_NOME"));
                nazioneview.setAderenteTarget(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_ADERENTE_TARGET")));
                nazioneview.setAltradenominazione(resultset.getString("NA_ALTRADENOMINAZIONE"));
                nazioneview.setAppartenenteBlackList(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_APPARTENENTE_BLACK_LIST")));
                nazioneview.setAreaGeografica(resultset.getString("NA_AREA_GEOGRAFICA"));
                nazioneview.setCncf(resultset.getString("NA_CNCF"));
                nazioneview.setCodiceDivisa(resultset.getString("NA_CODICE_DIVISA"));
                nazioneview.setCodiceIso(resultset.getString("NA_CODICE_ISO"));
                nazioneview.setCodiceProvincia(resultset.getString("NA_CODICE_PROVINCIA"));
                nazioneview.setCodiceUic(resultset.getString("NA_CODICE_UIC"));
                nazioneview.setContinente(String.valueOf(resultset.getLong("NA_CONTINENTE")));
                nazioneview.setHa_embargo(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_HA_EMBARGO")));
                nazioneview.setLinguaParlata(resultset.getString("NA_LINGUA_PARLATA"));
                nazioneview.setMembroUe(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_MEMBRO_UE")));
                nazioneview.setMembroUme(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_MEMBRO_UME")));
                nazioneview.setNazionalita(resultset.getString("NA_NAZIONALITA"));
                nazioneview.setNazione(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_NAZIONE")));
                nazioneview.setNazioneAppartenenza(resultset.getString("NA_NAZIONE_APPARTENENZA"));
                nazioneview.setNazioneId(nazioneId);
                nazioneview.setSinglaInternazionale(resultset.getString("NA_SINGLA_INTERNAZIONALE"));
                nazioneview.setStorico(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_STORICO")));
                nazioneview.setValutario(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_VALUTARIO")));
                nazioneview.setZcr(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_ZCR")));
                nazioneview.setZonaBilanciGrandiRischi(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_ZONA_BILANCI_GRANDI_RISCHI")));
                nazioneview.setDocAggiuntivi(resultset.getString("NA_DOC_AGGIUNTIVI"));
                nazioneview.setNormalisedName(resultset.getString("NA_NORMALIZZATO"));
                nazioneview.setInternationaleNome(resultset.getString("NA_INTERNATIONALE_NOME"));
                nazioneview.setInternationaleShortNome(resultset.getString("NA_INTERNATIONALE_SHORT_NOME"));
                nazioneview.setAderenteGafi(Long.valueOf(resultset.getLong("NA_ADERENTE_GAFI")));
                nazioneview.setCodiceIsoNum(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_CODICE_ISO_NUM")));
                nazioneview.setAppartenenteBlackListFiscale(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_APPARTEN_BLACK_LIST_FISCALE")));
                nazioneview.setAppartenenteWhiteListFiscale(nazioneHelper.getLongObjectFromPrimitive(resultset.getString("NA_APPARTEN_WHITE_LIST_FISCALE")));
                nazioneview.setPrefissoCode(resultset.getString("NA_PREFISSO"));
                nazioneview.setAccordoFatca(resultset.getString("NA_ACCORDO_FATCA"));
                nazioneview.setCodiceIsoTre(resultset.getString("NA_CODICE_ISO_TRE"));
                nazioneview.setTinCode(resultset.getString("NA_TIN_CODE"));
            }
        } catch (final SQLException sqlexception) {
            log4Debug.debug("<<GA>> Exception while getting the nazione ", sqlexception.getMessage());
            throw new GestoreNazioneException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
        return nazioneview;
    }

    public Collection getNazione(final Hashtable searchCriteria) throws GestoreNazioneException {
        Connection connection = null;
        PreparedStatement nazioneStatement = null;
        ArrayList nazioneList = null;
        ResultSet nazioneResultSet = null;
        try {
            connection = getConnection();
            final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
            final String query = nazioneHelper.buildQueryForNazioneTable(searchCriteria);
            nazioneStatement = connection.prepareStatement(query);
            nazioneHelper.setWhereConditionsForNazioneQuery(searchCriteria, nazioneStatement);
            nazioneResultSet = nazioneStatement.executeQuery();
            nazioneList = new ArrayList();
            while (nazioneResultSet.next()) {
                nazioneList.add(nazioneHelper.getNazioneViewFromResultSet(nazioneResultSet));
            }
        } catch (final SQLException se) {
            log4Debug.warn(se);
            throw new GestoreNazioneException(se.getMessage());
        } finally {
            cleanup(connection, nazioneStatement, nazioneResultSet);
        }
        return nazioneList;
    }

    public Collection getAllNazione() throws GestoreNazioneException {
        Connection connection = null;
        PreparedStatement nazioneStatement = null;
        Vector nazioneVector = null;
        ResultSet nazioneResultSet = null;
        final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
        try {
            connection = getConnection();
            nazioneStatement = connection.prepareStatement("select NAZIONE_ID,NA_NOME,NA_CODICE_ISO,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_CNCF,NA_PREFISSO,NA_CODICE_ISO_TRE from AN_MA_NAZIONE ORDER BY NA_NOME");
            nazioneResultSet = nazioneStatement.executeQuery();
            nazioneVector = new Vector();
            while (nazioneResultSet.next()) {
                final NazioneView nazioneView = new NazioneView();
                nazioneView.setNazioneId(Long.valueOf(nazioneResultSet.getLong("NAZIONE_ID")));
                nazioneView.setNome(nazioneResultSet.getString("NA_NOME"));
                nazioneView.setCodiceIso(nazioneResultSet.getString("NA_CODICE_ISO"));
                nazioneView.setAppartenenteBlackListFiscale(nazioneHelper.getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_BLACK_LIST_FISCALE")));
                nazioneView.setAppartenenteWhiteListFiscale(nazioneHelper.getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_WHITE_LIST_FISCALE")));
                nazioneView.setCncf(nazioneResultSet.getString("NA_CNCF"));
                nazioneView.setPrefissoCode(nazioneResultSet.getString("NA_PREFISSO"));
                nazioneView.setCodiceIsoTre(nazioneResultSet.getString("NA_CODICE_ISO_TRE"));                
                nazioneVector.add(nazioneView);
            }
        } catch (final SQLException se) {
            log4Debug.warn("<<GA>> Exception while getting the nazione ", se.getMessage());
            throw new GestoreNazioneException(se.getMessage());
        } finally {
            cleanup(connection, nazioneStatement, nazioneResultSet);
        }
        return nazioneVector;
    }

    public Collection listNazione() throws RemoteException {
    	final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
        final String query = "SELECT  NAZIONE_ID, NA_NOME, NA_CNCF, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO FROM AN_MA_NAZIONE WHERE NA_NAZIONE = 1 AND NA_STORICO = 0 ORDER BY NA_NOME";
        return nazioneHelper.getNazioneCollectionForTheInputQuery(query,null);
    }
    public Collection<Nazione> listNazioneWithPrefisso() throws RemoteException {
    	final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
        final String query = "SELECT  NAZIONE_ID, NA_NOME, NA_CNCF, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO FROM AN_MA_NAZIONE WHERE NA_STORICO = 0 AND NA_PREFISSO IS NOT NULL ORDER BY NA_NOME";
        return nazioneHelper.getNazioneCollectionForTheInputQuery(query,null);
    }

    public Collection listAnagraficNazione() throws RemoteException {
    	final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
        final String query = "SELECT  NAZIONE_ID, NA_NOME, NA_CNCF, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO FROM AN_MA_NAZIONE WHERE NA_NAZIONE = 1  ORDER BY NA_NOME";
        return nazioneHelper.getNazioneCollectionForTheInputQuery(query,null);
    }

    public Nazione getNazioneForIndirizzo(final String nazioneNome) throws RemoteException {
    	final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
        final String query = "Select NAZIONE_ID,NA_NOME, NA_CNCF, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO from AN_MA_NAZIONE WHERE NA_NOME = ?";
        final Collection nazioneCollection = nazioneHelper.getNazioneCollectionForTheInputQuery(query,nazioneNome.toUpperCase().trim());
        return (nazioneCollection != null && !nazioneCollection.isEmpty()) ?
        		(Nazione)nazioneCollection.iterator().next() : null;
    }

    public Collection listNazione(final String nazioneNome) throws RemoteException {
        final ArrayList nazioneList = new ArrayList();
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("select NAZIONE_ID, NA_NOME, NA_NAZIONALITA, NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE, NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO, NA_AREA_GEOGRAFICA, NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME, NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE, NA_CONTINENTE, NA_STORICO, NA_NAZIONE, NA_NAZIONE_APPARTENENZA, NA_HA_EMBARGO, NA_NORMALIZZATO, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE from AN_MA_NAZIONE where NA_NORMALIZZATO "); //NA_ACCORDO_FATCA added For FATCA
            query.append(nazioneNome.endsWith("%") ? "like ?" : "= ?");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setString(1,nazioneNome);
            nazioneResultSet = selectStatement.executeQuery();
            final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
            while(nazioneResultSet.next()) {
                nazioneList.add(nazioneHelper.getNazioneFromResultSet(nazioneResultSet));
            }
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazioneList;
    }

    public Nazione getNazione(final String nome) throws RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        Nazione nazione = null;
        try {
            connection = getConnection();
            //nome = new StringHandler().addSingleQuotes(nome);
            final StringBuffer query = new StringBuffer("select NAZIONE_ID , NA_NOME, NA_NAZIONALITA,NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE,NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO,");
            query.append("NA_AREA_GEOGRAFICA,  NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME,NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE,NA_CONTINENTE, NA_STORICO, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE  from AN_MA_NAZIONE WHERE  NA_NOME = ?");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setString(1,nome);
            nazioneResultSet = selectStatement.executeQuery();
            final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
            nazione = nazioneResultSet.next() ? nazioneHelper.getNazioneFromResultSet(nazioneResultSet) : null;
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazione;
    }

    public Nazione getNazioneOfGVBean(final Long nazioneId) throws RemoteException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        Nazione nazione = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("select  NAZIONE_ID , NA_NOME, NA_NAZIONALITA,NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE,NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO,");
            query.append("NA_AREA_GEOGRAFICA,  NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME,NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE,NA_CONTINENTE, NA_STORICO, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE from AN_MA_NAZIONE WHERE NAZIONE_ID = ?");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setLong(1, nazioneId.longValue());
            nazioneResultSet = selectStatement.executeQuery();
            final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
            nazione = nazioneResultSet.next() ? nazioneHelper.getNazioneFromResultSet(nazioneResultSet) : null;
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazione;
    }

    public void createNazione(final NazioneView nazioneView) throws OperazioneAnagrafeManagerException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final ResultSet resultSet = null;
        final StringBuffer queryBuffer = new StringBuffer();
        try {
            connection = getConnection();
            queryBuffer.append(" INSERT INTO AN_MA_NAZIONE( ");
            queryBuffer.append(" NAZIONE_ID, NA_NOME, NA_NAZIONALITA, NA_CODICE_UIC, NA_CODICE_ISO, ");
            queryBuffer.append(" NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE, NA_LINGUA_PARLATA, ");
            queryBuffer.append(" NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO, NA_AREA_GEOGRAFICA, ");
            queryBuffer.append(" NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME, NA_APPARTENENTE_BLACK_LIST, ");
            queryBuffer.append(" NA_CNCF, NA_ALTRADENOMINAZIONE, NA_CONTINENTE, NA_STORICO, NA_NAZIONE, ");
            queryBuffer.append(" NA_NAZIONE_APPARTENENZA, NA_HA_EMBARGO, NA_NORMALIZZATO, NA_DOC_AGGIUNTIVI,");
            queryBuffer.append(" NA_INTERNATIONALE_NOME, NA_INTERNATIONALE_SHORT_NOME, NA_ADERENTE_GAFI,NA_CODICE_ISO_NUM,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE) ");
            queryBuffer.append(" VALUES(SEQ_NAZIONE.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            preparedStatement = connection.prepareStatement(queryBuffer.toString());
            setNazioneDetails(preparedStatement,nazioneView);
            preparedStatement.executeQuery();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement, resultSet);
        }
    }

    public void setNazione(final NazioneView nazioneView) throws OperazioneAnagrafeManagerException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        final StringBuffer queryBuffer = new StringBuffer();
        try {
            connection = getConnection();
            queryBuffer.append(" UPDATE AN_MA_NAZIONE ");
            queryBuffer.append(" SET NA_NOME= ?, NA_NAZIONALITA= ?, NA_CODICE_UIC= ?, NA_CODICE_ISO= ?,");
            queryBuffer.append(" NA_CODICE_DIVISA= ?, NA_CODICE_PROVINCIA= ?, NA_SINGLA_INTERNAZIONALE= ?,");
            queryBuffer.append(" NA_LINGUA_PARLATA= ?, NA_ZCR= ?, NA_ZONA_BILANCI_GRANDI_RISCHI= ?, NA_VALUTARIO= ?,");
            queryBuffer.append(" NA_AREA_GEOGRAFICA= ?, NA_ADERENTE_TARGET= ?, NA_MEMBRO_UE= ?, NA_MEMBRO_UME= ?,");
            queryBuffer.append(" NA_APPARTENENTE_BLACK_LIST= ?, NA_CNCF= ?, NA_ALTRADENOMINAZIONE= ?, NA_CONTINENTE= ?, NA_STORICO= ?,");
            queryBuffer.append(" NA_NAZIONE= ?, NA_NAZIONE_APPARTENENZA= ?, NA_HA_EMBARGO= ?, NA_NORMALIZZATO= ?, NA_DOC_AGGIUNTIVI= ?,");
            queryBuffer.append(" NA_INTERNATIONALE_NOME = ?, NA_INTERNATIONALE_SHORT_NOME = ?, NA_ADERENTE_GAFI = ?, NA_CODICE_ISO_NUM=?, NA_APPARTEN_BLACK_LIST_FISCALE = ? , NA_APPARTEN_WHITE_LIST_FISCALE = ? , NA_PREFISSO = ? , NA_ACCORDO_FATCA = ? , NA_CODICE_ISO_TRE = ? , NA_TIN_CODE=? ");
            queryBuffer.append(" WHERE NAZIONE_ID = ? ");
            preparedStatement = connection.prepareStatement(queryBuffer.toString());
            setNazioneDetails(preparedStatement,nazioneView);
            preparedStatement.setLong(36, nazioneView.getNazioneId().longValue());
            preparedStatement.executeQuery();
        } catch (final SQLException e) {
            log4Debug.warnStackTrace(e);
            throw new OperazioneAnagrafeManagerException(e.getMessage());
        } finally {
            cleanup(connection, preparedStatement);
        }
    }

    private void setNazioneDetails(final PreparedStatement preparedStatement,final NazioneView nazioneView) throws SQLException {
        final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
        preparedStatement.setString(1, nazioneView.getNome());
        preparedStatement.setString(2, nazioneView.getNazionalita());
        preparedStatement.setString(3, nazioneView.getCodiceUic());
        preparedStatement.setString(4, nazioneView.getCodiceIso());
        preparedStatement.setString(5, nazioneView.getCodiceDivisa());
        preparedStatement.setString(6, nazioneView.getCodiceProvincia());
        preparedStatement.setString(7, nazioneView.getSinglaInternazionale());
        preparedStatement.setString(8, nazioneView.getLinguaParlata());
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getZcr(),9);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getZonaBilanciGrandiRischi(),10);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getValutario(),11);
        preparedStatement.setString(12, nazioneView.getAreaGeografica());
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getAderenteTarget(),13);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getMembroUe(),14);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getMembroUme(),15);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getAppartenenteBlackList(),16);
        preparedStatement.setString(17, nazioneView.getCncf());
        preparedStatement.setString(18, nazioneView.getAltradenominazione());
        preparedStatement.setString(19, nazioneView.getContinente());
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getStorico(),20);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getNazione(),21);
        preparedStatement.setString(22, nazioneView.getNazioneAppartenenza());
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getHa_embargo(),23);
        preparedStatement.setString(24, nazioneView.getNormalisedNome());
        preparedStatement.setString(25, nazioneView.getDocAggiuntivi());
        preparedStatement.setString(26, nazioneView.getInternationaleNome());
        preparedStatement.setString(27, nazioneView.getInternationaleShortNome());
        preparedStatement.setLong(28, nazioneView.getAderenteGafi() != null ? nazioneView.getAderenteGafi().longValue()
        		: 0);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getCodiceIsoNum(),29);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getAppartenenteBlackListFisicale(),30);
        nazioneHelper.checkForNullAndSetValueInStmt(preparedStatement,nazioneView.getAppartenenteWhiteListFisicale(),31);
        preparedStatement.setString(32, nazioneView.getPrefissoCode());
        preparedStatement.setString(33, nazioneView.getAccordoFatca());
        preparedStatement.setString(34, nazioneView.getCodiceIsoTre());
        preparedStatement.setString(35, nazioneView.getTinCode());
    }
//TODO
    public Collection<Nazione> nazioneList(final String nome) throws RemoteException, GestoreNazioneException {
        final ArrayList<Nazione> nazioneList = new ArrayList<Nazione>();
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("select NAZIONE_ID, NA_NOME, NA_NAZIONALITA, NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE, NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO, NA_AREA_GEOGRAFICA, NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME, NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE, NA_CONTINENTE, NA_STORICO, NA_NAZIONE, NA_NAZIONE_APPARTENENZA, NA_HA_EMBARGO, NA_NORMALIZZATO, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE from AN_MA_NAZIONE where NA_NAZIONE = 1 and NA_NOME ");
            query.append(nome.endsWith("%") ? "like ?" : "= ?");
            query.append(!nome.equalsIgnoreCase("ITALIA") ? "and NA_CNCF IS NOT NULL" : "");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setString(1,nome);
            nazioneResultSet = selectStatement.executeQuery();
            final NazioneDBAccessUtil nazioneHelper = new NazioneDBAccessUtil();
            while(nazioneResultSet.next()) {
                nazioneList.add(nazioneHelper.getNazioneFromResultSet(nazioneResultSet));
            }
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreNazioneException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazioneList;
    }

    public List<String> getAllNazioneWithCNCF() throws RemoteException, GestoreNazioneException {
        final List<String> nazioneList = new ArrayList<String>();
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT   NA_NOME || DECODE (NA_CNCF , NULL ,'' , ' - ' ||NA_CNCF)  FROM AN_MA_NAZIONE ORDER BY NA_NOME");
            selectStatement = connection.prepareStatement(query.toString());
            nazioneResultSet = selectStatement.executeQuery();
            while(nazioneResultSet.next()) {
                nazioneList.add(nazioneResultSet.getString(1));
            }
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreNazioneException(se.getMessage());
        } finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazioneList;
    }
    /**
     * This method is used to check whether the prefisso is valid or not
     */
    public Boolean isPrefissoValid(final String prefissoCode,final String nazioneNome) throws GestoreAnagrafeException {

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		final StringBuffer query = new StringBuffer();
		query.append("SELECT 1 FROM AN_MA_NAZIONE NA  WHERE NA.NA_PREFISSO = ?  AND NA.NA_NOME = ?");

		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setString(1, prefissoCode);
			statement.setString(2, nazioneNome);
			resultSet = statement.executeQuery();
			if(resultSet.next()) {
				return Boolean.TRUE;
			}
		} catch (final SQLException se) {
			log4Debug.debugStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return Boolean.FALSE;
	}
   
    
    /**
     * This method is used to check whether the isotre is unique
     *//*
    public Boolean isToCheckCodiceIsoTre(final String codiceIsoTre) throws GestoreAnagrafeException {

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		final StringBuffer query = new StringBuffer();
		query.append("SELECT 1 FROM AN_MA_NAZIONE NA  WHERE NA.NA_CODICE_ISO_TRE = ? AND NA_STORICO = 0 ");

		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setString(1, codiceIsoTre);
			resultSet = statement.executeQuery();
			if(resultSet.next()) {
				return Boolean.TRUE;
			}
		} catch (final SQLException se) {
			log4Debug.debugStackTrace(se);
			throw new GestoreAnagrafeException(se.getMessage());
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return Boolean.FALSE;
	}*/
    
    /**
     * This method is used to check whether the residence nazione is black listed because if it is black listed need to thrown exception
     * Flow simulated in PF,AZ creea or varia flow
     * @param nazioneId
     * @return true if black listed else false 
     * @throws GestoreNazioneException
     */
    public Boolean isNazioneBlockListed(final Long nazioneId) throws GestoreNazioneException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        Boolean isBlackListNazione = Boolean.FALSE;
        ResultSet resultset = null;
        try {
            connection = getConnection();
            preparedstatement = connection.prepareStatement("select NA_APPARTENENTE_BLACK_LIST from AN_MA_NAZIONE where NAZIONE_ID = ?");
            preparedstatement.setLong(1, nazioneId);
            resultset = preparedstatement.executeQuery();
            if (resultset.next()) {
            	final String appartenenteBlackListFiscale = resultset.getString("NA_APPARTENENTE_BLACK_LIST");
            	isBlackListNazione = appartenenteBlackListFiscale != null && "1".equals(appartenenteBlackListFiscale) ? Boolean.TRUE : isBlackListNazione;
            }
        } catch (final SQLException sqlexception) {
            log4Debug.debug("<<GA>> Exception while getting the nazione ", sqlexception.getMessage());
            throw new GestoreNazioneException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
        log4Debug.debug("isBlackListNazione ",isBlackListNazione);
        return isBlackListNazione;
    }
    
    /**
     * To get nazione with stoirc zero
     * @param nazioneNome
     * @return
     * @throws RemoteException
     * @throws GestoreNazioneException 
     */
    public Nazione getNazioneWithStoricoZero(final String nazioneNome) throws  GestoreNazioneException {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        Nazione nazione = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT  NAZIONE_ID , NA_NOME, NA_NAZIONALITA,NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE,NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO,");
            query.append("NA_AREA_GEOGRAFICA,  NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME,NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE,NA_CONTINENTE, NA_STORICO, NA_DOC_AGGIUNTIVI,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE from AN_MA_NAZIONE WHERE NA_NOME = ? AND NA_STORICO = 0");
            selectStatement = connection.prepareStatement(query.toString());
            selectStatement.setString(1, nazioneNome);
            nazioneResultSet = selectStatement.executeQuery();
            nazione = nazioneResultSet.next() ? new NazioneDBAccessUtil().getNazioneFromResultSet(nazioneResultSet) : null;
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new GestoreNazioneException(se.getMessage());
        } catch (RemoteException se) {
        	 log4Debug.warnStackTrace(se);
             throw new GestoreNazioneException(se.getMessage());
		} finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazione;
    }
    
    /**
     * 
     * @param nazioneId
     * @return
     * @throws GestoreNazioneException
     */
    public Boolean isCodiceFiscaleEsteroMandatory(final Long nazioneId) throws GestoreNazioneException {
        Connection connection = null;
        PreparedStatement preparedstatement = null;
        Boolean isCFERequired = Boolean.FALSE;
        ResultSet resultset = null;
        try {
            connection = getConnection();
            preparedstatement = connection.prepareStatement("select NA_TIN_CODE from AN_MA_NAZIONE where NAZIONE_ID = ?");
            preparedstatement.setLong(1, nazioneId);
            resultset = preparedstatement.executeQuery();
            if (resultset.next()) {
            	final String tinCode = resultset.getString("NA_TIN_CODE");
            	isCFERequired = (tinCode != null && "Y".equals(tinCode)) ? Boolean.TRUE : isCFERequired;
            }
        } catch (final SQLException sqlexception) {
            log4Debug.debug("<<GA>> Exception while getting the nazione ", sqlexception.getMessage());
            throw new GestoreNazioneException(sqlexception.getMessage());
        } finally {
            cleanup(connection, preparedstatement, resultset);
        }
        log4Debug.debug("isCFERequired ",isCFERequired);
        return isCFERequired;
    }
    
    
    /**
     * To check whether partitaiva is mandatory or not
     * @param cittaName 
     * @param nazioneId 
     * @param nazioneId
     * @param cittaName
     * @return
     * @throws GestoreNazioneException
     */
    
    public Boolean isPartitaIvaNotMandatory(final Long nazioneId, final String cittaName) throws GestoreNazioneException {
    	Connection connection = null;
    	PreparedStatement preparedstatement = null;
    	Boolean isPartitaIvaNotMandatory = Boolean.FALSE;
    	ResultSet resultset = null;
    	try {
    		connection = getConnection();
    		preparedstatement = connection.prepareStatement("Select 1 from AN_MA_PIVA_NO_CHECK PC WHERE PC.PC_NAZIONE_ID = ? AND PC.PC_CITTA_NOME= ?");
    		preparedstatement.setLong(1, nazioneId);
    		preparedstatement.setString(2, cittaName);
    		resultset = preparedstatement.executeQuery();
    		if (resultset.next()) {
    			isPartitaIvaNotMandatory=Boolean.TRUE;
    		}
    	} catch (final SQLException sqlexception) {
    		log4Debug.debug("<<GA>> Exception while getting the nazione ", sqlexception.getMessage());
    		throw new GestoreNazioneException(sqlexception.getMessage());
    	} finally {
    		cleanup(connection, preparedstatement, resultset);
    	}
    	log4Debug.debug("isPartitaIvaNotMandatory ",isPartitaIvaNotMandatory);
    	return isPartitaIvaNotMandatory;
    }
    
   
}
