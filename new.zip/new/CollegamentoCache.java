package it.sella.anagrafe.implementation;

import it.sella.util.CacheFactory;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

public class CollegamentoCache implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Map collegamentoCache = CacheFactory.getInstance(CollegamentoCache.class).getCacheInstance("collegamentoCache");

    /**
     * @param soggettoId
     * @return boolean if the linkedcollegamentoCollection exists return true else false
     */
    public boolean isCollegamentoExists(final Long soggettoId) {
        return collegamentoCache.containsKey(soggettoId);
    }

    /**
     * @ param Long soggettoId
     * @return Collection object is returned from the cache
     */

    public Collection getCollegamentoCollection(final Long soggettoId) {
        return (Collection) collegamentoCache.get(soggettoId);
    }

    /** puts the collegamentoCollection by using this soggettoId as the key
     * @ param Long soggettoId Used as key
     * @ param Collection linkedCollegamentoCollection
     */
    public void putCollegamentoCollection(final Long soggettoId, final Collection collegamentoCollection) {
        collegamentoCache.put(soggettoId, collegamentoCollection);
    }

}

