package it.sella.anagrafe.util;


import it.sella.anagrafe.ResourceLookupException;
import it.sella.anagrafe.implementation.HomeInterfacesCache;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.util.MissingResourceException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

public class ResourceLookupHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ResourceLookupHelper.class);

    private static HomeInterfacesCache homeInterfacesCache = null;

    /**
     * checks whether the homeobject exists in cache.If exists return that. Or will lookup for the object
     * and stores in cache. and then returns that object
     * @param key
     * @param className
     * @return Object
     * @throws ResourceLookupException
     */
    public static Object getHomeObject(final String key, final String className) throws ResourceLookupException {
        try {
            if(homeInterfacesCache == null) {
                homeInterfacesCache = new HomeInterfacesCache();
            }
            if(homeInterfacesCache.isHomeObjectExists(key)) {
				return homeInterfacesCache.getHomeInterface(key);
			}
            final Context context = getInitialContext();
            final String homeName = CommonPropertiesHandler.getValueFromProperty(key);
            final Object returnObject = PortableRemoteObject.narrow(context.lookup(homeName), Class.forName(className));
            homeInterfacesCache.putHomeInterface(key, returnObject);
            return returnObject;
        } catch (final NamingException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        } catch (final MissingResourceException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        } catch (final ClassCastException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        } catch (final ClassNotFoundException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        }
    }

    /**
     * It makes use of the context which is being passed
     * @ param String JNDI Name
     * @ param String Class Name
     * @ param Context context
     * @ return Object
     * @ exception NamingException,ClassNotFoundException
     */

    public static Object getHomeObject(final String key, final String className, final Context context) throws ResourceLookupException {
        try {
            final String homeName = CommonPropertiesHandler.getValueFromProperty(key);
            return PortableRemoteObject.narrow(context.lookup(homeName), Class.forName(className));
        } catch (final MissingResourceException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        } catch (final ClassCastException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        } catch (final NamingException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        } catch (final ClassNotFoundException e) {
            log4Debug.severeStackTrace(e);
            throw new ResourceLookupException(e.getMessage());
        }
    }

    private static InitialContext getInitialContext() throws NamingException {
        return new InitialContext();
    }

}
