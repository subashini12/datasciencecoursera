package it.sella.anagrafe.implementation;

import it.sella.anagrafe.IDAIConfigView;
import it.sella.util.Cache;
import it.sella.util.CacheFactory;
import it.sella.util.CacheInfo;

import java.io.Serializable;


/**
 * @author GBS03447
 *
 */
public final class DAIConfigCache implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final CacheInfo<Object, Object> cacheInfo = CacheInfo.getCacheInfo("DAIConfigCache", Cache.NO_TIMEOUT);
	private static final Cache<Object, Object> daiConfigCacheMap = CacheFactory.getInstance(DAIConfigCache.class).getCacheInstance(cacheInfo);
	
	
	public boolean isDaiConfigIdExist (final Long configId) {
		return daiConfigCacheMap.containsKey(configId);
	}
	
	public boolean isDaiConfigCodeExist(final String configCode) {
		return daiConfigCacheMap.containsKey(configCode);
	}
	
	public IDAIConfigView getDaiConfigView(final Long configId) {
		return (IDAIConfigView) daiConfigCacheMap.get(configId);
	}
	
	public IDAIConfigView getDaiConfigView(final String configCode) {
		return (IDAIConfigView) daiConfigCacheMap.get(configCode);
	}
	
	public void putDaiConfigView(final Long configId, final IDAIConfigView configView) {
		daiConfigCacheMap.put(configId, configView);
	}
	
	public void putDaiConfigView(final String configCode, final IDAIConfigView configView) {
		daiConfigCacheMap.put(configCode, configView);
	}
}
