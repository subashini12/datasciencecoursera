package it.sella.anagrafe.factory;

import it.sella.address.implementation.AddressAdminFactory;
import it.sella.address.implementation.IAddressAdmin;
import it.sella.anagrafe.OperazioneAnagrafeFactory;
import it.sella.anagrafe.OperazioneAnagrafeManager;

import java.io.Serializable;
import java.util.ArrayList;

public class Factory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static ArrayList pfCollegateMotivs = null;
	static ArrayList azCollegateMotivs = null;

	public Factory() {
		// pfCollegateMotivs
		if(pfCollegateMotivs == null) {
			pfCollegateMotivs = new ArrayList();
			pfCollegateMotivs.add("CURAT");
			pfCollegateMotivs.add("TUTOR");
			pfCollegateMotivs.add("ESERC");
			pfCollegateMotivs.add("ABIL8CIFRE");
		}
		
		// azCollegateMotivs
		if(azCollegateMotivs == null) {
			azCollegateMotivs = new ArrayList();
			azCollegateMotivs.add("ABIL8CIFRE");
			azCollegateMotivs.add("AMMCO");
			azCollegateMotivs.add("AMMDE");
			azCollegateMotivs.add("AMMUN");
			azCollegateMotivs.add("CFALL");
			azCollegateMotivs.add("COMMI");
			azCollegateMotivs.add("DELEG");
			azCollegateMotivs.add("DIRGE");
			azCollegateMotivs.add("LIQUI");
			azCollegateMotivs.add("MCDA");
			azCollegateMotivs.add("PCDA");
			azCollegateMotivs.add("PROCU");
			azCollegateMotivs.add("SARIO");
			azCollegateMotivs.add("SOCIO");
			azCollegateMotivs.add("TITOL");
			azCollegateMotivs.add("VCDA");
			azCollegateMotivs.add("SANTE");
		}
	}

	protected OperazioneAnagrafeManager getOperazioneAnagrafeManager() {
		return OperazioneAnagrafeFactory.getInstance().getOperazioneAnagrafeManager();
	}

	protected IAddressAdmin getAddressAdmin(){
		return AddressAdminFactory.getInstance().getAddressAdmin();
	}

}
