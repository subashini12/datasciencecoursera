package it.sella.anagrafe.implementation;

import it.sella.util.CacheFactory;

import java.io.Serializable;
import java.util.Map;

public class HomeInterfacesCache implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Map homeInterfacesCache = CacheFactory.getInstance(HomeInterfacesCache.class).getCacheInstance("homeInterfacesCache");

    /**
     * @ param Sting homeObject checks whether the homeObject passed is existing in the map
     * @return boolean if the homeObject exists return true else false
     */
    public boolean isHomeObjectExists(final String homeObject) {
        return homeInterfacesCache.containsKey(homeObject);
    }

    /**
     * @ param homeObject checks whether it is there in the map
     * @return Object object is returned from the cache
     */

    public Object getHomeInterface(final String homeObject) {
        return homeInterfacesCache.get(homeObject);
    }

    /** puts the homeObjectInterface Object by using this homeObject as the key
     * @ param homeObject used as the key for putting in to the map
     * @ param homeObjectInterface is placed in to the map object
     */
    public void putHomeInterface(final String homeObject, final Object homeObjectInterface) {
        homeInterfacesCache.put(homeObject, homeObjectInterface);
    }

}
