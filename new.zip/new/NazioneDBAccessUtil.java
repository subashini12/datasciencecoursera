package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreNazioneException;
import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.NazioneView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import javax.ejb.EJBException;

public class NazioneDBAccessUtil extends DBAccessHelper {

    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(NazioneDBAccessUtil.class);

    protected void checkForNullAndSetValueInStmt(final PreparedStatement preparedStatement,final Long value,final int index) throws SQLException {
    	if(value != null) {
			preparedStatement.setLong(index,value.longValue());
		} else {
			preparedStatement.setString(index,null);
		}
    }

    protected Nazione getNazioneFromResultSet(final ResultSet nazioneResultSet) throws RemoteException,SQLException {
        try {
            final Nazione nazione = new Nazione();
            nazione.setAderenteTarget(getViewFromValue("ADERENTE_TARGET",nazioneResultSet.getString("NA_ADERENTE_TARGET")));
            nazione.setAppartenenteBlackList(getViewFromValue("APPARTENENTE_BLACK_LIST",nazioneResultSet.getString("NA_APPARTENENTE_BLACK_LIST")));
            nazione.setAreaGeografica(getViewFromValue("AREA_GEOGRAFICA",nazioneResultSet.getString("NA_AREA_GEOGRAFICA")));
            nazione.setCncf(nazioneResultSet.getString("NA_CNCF"));
            nazione.setCodiceDivisa(nazioneResultSet.getString("NA_CODICE_DIVISA"));
            nazione.setCodiceISO(nazioneResultSet.getString("NA_CODICE_ISO"));
            nazione.setCodiceProvincia(nazioneResultSet.getString("NA_CODICE_PROVINCIA"));
            nazione.setCodiceUIC(nazioneResultSet.getString("NA_CODICE_UIC"));
            nazione.setAltradenominazione(nazioneResultSet.getString("NA_ALTRADENOMINAZIONE"));
            nazione.setLinguaParlata(getViewFromValue("LINGUA",nazioneResultSet.getString("NA_LINGUA_PARLATA")));
            nazione.setMembroUE(getViewFromValue("MEMBRO_UE",nazioneResultSet.getString("NA_MEMBRO_UE")));
            nazione.setMembroUME(getViewFromValue("MEMBRO_UME",nazioneResultSet.getString("NA_MEMBRO_UME")));
            nazione.setNazionalita(nazioneResultSet.getString("NA_NAZIONALITA"));
            nazione.setNazioneId(Long.valueOf(nazioneResultSet.getString("NAZIONE_ID")));
            nazione.setNome(nazioneResultSet.getString("NA_NOME"));
            nazione.setSiglaInternazionale(nazioneResultSet.getString("NA_SINGLA_INTERNAZIONALE"));
            nazione.setValutario(getViewFromValue("VALUTARIO",nazioneResultSet.getString("NA_VALUTARIO")));
            nazione.setZcr(getViewFromValue("ZCP",nazioneResultSet.getString("NA_ZCR")));
            nazione.setZonaBilanciEGrandiRischi(getViewFromValue("ZBGR",nazioneResultSet.getString("NA_ZONA_BILANCI_GRANDI_RISCHI")));
            nazione.setContinente(getViewFromValue("CON",nazioneResultSet.getString("NA_CONTINENTE")));
            nazione.setStorico(getViewFromValue("STO",nazioneResultSet.getString("NA_STORICO")));
            nazione.setDocAggiuntivi(nazioneResultSet.getString("NA_DOC_AGGIUNTIVI"));
            nazione.setAppartenenteBlackListFisicale(getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_BLACK_LIST_FISCALE")));
            nazione.setAppartenenteWhiteListFisicale(getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_WHITE_LIST_FISCALE")));
            nazione.setPrefissoCode(nazioneResultSet.getString("NA_PREFISSO"));
            nazione.setAccordoFatca(nazioneResultSet.getString("NA_ACCORDO_FATCA"));
            nazione.setCodiceIsoTre(nazioneResultSet.getString("NA_CODICE_ISO_TRE"));
            nazione.setTinCode(nazioneResultSet.getString("NA_TIN_CODE"));
            return nazione;
        } catch(final SubSystemHandlerException e) {
            log4Debug.warnStackTrace(e);
            throw new EJBException(e);
        }
    }

    protected Collection getNazioneCollectionForTheInputQuery(final String query,final String whereCondition) {
        Connection connection = null;
        PreparedStatement selectStatement = null;
        ResultSet nazioneResultSet = null;
        List nazioneList = null;
        try {
            connection = getConnection();
            selectStatement = connection.prepareStatement(query);
            if(whereCondition != null) {
				selectStatement.setString(1,whereCondition);
			}
            nazioneResultSet = selectStatement.executeQuery();
            while(nazioneResultSet.next()) {
                nazioneList = nazioneList == null ? new ArrayList() : nazioneList;
                final Nazione nazione = new Nazione();
                nazione.setCncf(nazioneResultSet.getString("NA_CNCF"));
                nazione.setNazioneId(Long.valueOf(nazioneResultSet.getLong("NAZIONE_ID")));
                nazione.setNome(nazioneResultSet.getString("NA_NOME"));
                nazione.setDocAggiuntivi(nazioneResultSet.getString("NA_DOC_AGGIUNTIVI"));
                nazione.setAppartenenteBlackListFisicale(getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_BLACK_LIST_FISCALE")));
                nazione.setAppartenenteWhiteListFisicale(getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_WHITE_LIST_FISCALE")));
                nazione.setPrefissoCode(nazioneResultSet.getString("NA_PREFISSO"));
                nazioneList.add(nazione);
            }
        } catch(final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new EJBException(se);
        } finally {
            cleanup(connection, selectStatement, nazioneResultSet);
        }
        return nazioneList;
    }

    protected String buildQueryForNazioneTable(final Hashtable searchCriteria) {
        final StringBuffer selectQuery = new StringBuffer("SELECT NAZIONE_ID, NA_NOME, NA_NAZIONALITA,NA_CODICE_UIC, NA_CODICE_ISO, NA_CODICE_DIVISA, NA_CODICE_PROVINCIA, NA_SINGLA_INTERNAZIONALE,");
        selectQuery.append("NA_LINGUA_PARLATA, NA_ZCR, NA_ZONA_BILANCI_GRANDI_RISCHI, NA_VALUTARIO,NA_AREA_GEOGRAFICA,  NA_ADERENTE_TARGET, NA_MEMBRO_UE, NA_MEMBRO_UME,");
        selectQuery.append("NA_APPARTENENTE_BLACK_LIST, NA_CNCF, NA_ALTRADENOMINAZIONE,NA_CONTINENTE, NA_STORICO,NA_NAZIONE,NA_NAZIONE_APPARTENENZA,NA_HA_EMBARGO,NA_DOC_AGGIUNTIVI,");
        // added fields
        selectQuery.append("NA_INTERNATIONALE_NOME, NA_INTERNATIONALE_SHORT_NOME, NA_ADERENTE_GAFI,NA_CODICE_ISO_NUM,NA_APPARTEN_BLACK_LIST_FISCALE,NA_APPARTEN_WHITE_LIST_FISCALE,NA_PREFISSO,NA_ACCORDO_FATCA,NA_CODICE_ISO_TRE,NA_TIN_CODE ");
        selectQuery.append(" FROM AN_MA_NAZIONE WHERE");
        selectQuery.append(searchCriteria.get("NAZIONE_ID") != null ?
        		" NAZIONE_ID = ? AND" : "");
        selectQuery.append(searchCriteria.get("NA_NOME") != null ?
        		" NA_NOME = ? AND" : "");
        selectQuery.append(searchCriteria.get("NA_CODICE_UIC") != null ?
        		" NA_CODICE_UIC = ? AND" : "");
        selectQuery.append(searchCriteria.get("NA_CODICE_ISO") != null ?
        		" NA_CODICE_ISO = ? AND" : "");
        selectQuery.append(searchCriteria.get("NA_STORICO") != null ?
        		" NA_STORICO = ? AND" : "");
        selectQuery.append(searchCriteria.get("NA_NAZIONE") != null ?
        		" NA_NAZIONE = ? AND" : "");
        selectQuery.append(searchCriteria.get("NA_HA_EMBARGO") != null ?
        		" NA_HA_EMBARGO= ? AND" : "");
        return selectQuery.substring(0, selectQuery.length() - 3) + " order by NA_NOME";
    }

    protected void setWhereConditionsForNazioneQuery(final Hashtable searchCriteria, final PreparedStatement nazioneStatement) throws SQLException, GestoreNazioneException {
        int counter = 0;
        if (searchCriteria.get("NAZIONE_ID") != null) {
			nazioneStatement.setLong(++counter, Long.parseLong((String) searchCriteria.get("NAZIONE_ID")));
		}
        if (searchCriteria.get("NA_NOME") != null) {
			nazioneStatement.setString(++counter, (String) searchCriteria.get("NA_NOME"));
		}
        if (searchCriteria.get("NA_CODICE_UIC") != null) {
			nazioneStatement.setString(++counter, (String) searchCriteria.get("NA_CODICE_UIC"));
		}
        if (searchCriteria.get("NA_CODICE_ISO") != null) {
			nazioneStatement.setString(++counter, (String) searchCriteria.get("NA_CODICE_ISO"));
		}
        if (searchCriteria.get("NA_STORICO") != null) {
			nazioneStatement.setLong(++counter, Long.parseLong((String) searchCriteria.get("NA_STORICO")));
		}
        if (searchCriteria.get("NA_NAZIONE") != null) {
			nazioneStatement.setLong(++counter, Long.parseLong((String) searchCriteria.get("NA_NAZIONE")));
		}
        if (searchCriteria.get("NA_HA_EMBARGO") != null) {
			nazioneStatement.setLong(++counter, Long.parseLong((String) searchCriteria.get("NA_HA_EMBARGO")));
		}
        if (counter == 0) {
			throw new GestoreNazioneException(new AnagrafeHelper().getMessage("ANAG-1319"));
		}
    }

    protected NazioneView getNazioneViewFromResultSet(final ResultSet nazioneResultSet) throws SQLException {
        final NazioneView nazioneView = new NazioneView();
        nazioneView.setNazioneId(Long.valueOf(nazioneResultSet.getLong("NAZIONE_ID")));
        nazioneView.setNome(nazioneResultSet.getString("NA_NOME"));
        nazioneView.setNazionalita(nazioneResultSet.getString("NA_NAZIONALITA"));
        nazioneView.setCodiceUic(nazioneResultSet.getString("NA_CODICE_UIC"));
        nazioneView.setCodiceIso(nazioneResultSet.getString("NA_CODICE_ISO"));
        nazioneView.setCodiceDivisa(nazioneResultSet.getString("NA_CODICE_DIVISA"));
        nazioneView.setCodiceProvincia(nazioneResultSet.getString("NA_CODICE_PROVINCIA"));
        nazioneView.setSinglaInternazionale(nazioneResultSet.getString("NA_SINGLA_INTERNAZIONALE"));
        nazioneView.setZcr(Long.valueOf(nazioneResultSet.getLong("NA_ZCR")));
        nazioneView.setZonaBilanciGrandiRischi(Long.valueOf(nazioneResultSet.getLong("NA_ZONA_BILANCI_GRANDI_RISCHI")));
        nazioneView.setValutario(Long.valueOf(nazioneResultSet.getLong("NA_VALUTARIO")));
        nazioneView.setAderenteTarget(Long.valueOf(nazioneResultSet.getLong("NA_ADERENTE_TARGET")));
        nazioneView.setMembroUe(Long.valueOf(nazioneResultSet.getLong("NA_MEMBRO_UE")));
        nazioneView.setMembroUme(Long.valueOf(nazioneResultSet.getLong("NA_MEMBRO_UME")));
        nazioneView.setAppartenenteBlackList(Long.valueOf(nazioneResultSet.getLong("NA_APPARTENENTE_BLACK_LIST")));
        nazioneView.setCncf(nazioneResultSet.getString("NA_CNCF"));
        nazioneView.setAltradenominazione(nazioneResultSet.getString("NA_ALTRADENOMINAZIONE"));
        nazioneView.setStorico(Long.valueOf(nazioneResultSet.getLong("NA_STORICO")));
        nazioneView.setHa_embargo(Long.valueOf(nazioneResultSet.getLong("NA_HA_EMBARGO")));
        nazioneView.setNazione(Long.valueOf(nazioneResultSet.getLong("NA_NAZIONE")));
        nazioneView.setNazioneAppartenenza(nazioneResultSet.getString("NA_NAZIONE_APPARTENENZA"));
        nazioneView.setAreaGeografica(nazioneResultSet.getString("NA_AREA_GEOGRAFICA"));
        nazioneView.setContinente(nazioneResultSet.getString("NA_CONTINENTE"));
        nazioneView.setLinguaParlata(nazioneResultSet.getString("NA_LINGUA_PARLATA"));
        nazioneView.setDocAggiuntivi(nazioneResultSet.getString("NA_DOC_AGGIUNTIVI"));
        // added fields
        nazioneView.setInternationaleNome(nazioneResultSet.getString("NA_INTERNATIONALE_NOME"));
        nazioneView.setInternationaleShortNome(nazioneResultSet.getString("NA_INTERNATIONALE_SHORT_NOME"));
        nazioneView.setAderenteGafi(Long.valueOf(nazioneResultSet.getLong("NA_ADERENTE_GAFI")));
        nazioneView.setCodiceIsoNum(new NazioneDBAccessUtil().getLongObjectFromPrimitive(nazioneResultSet.getString("NA_CODICE_ISO_NUM")));
        nazioneView.setAppartenenteBlackListFiscale(getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_BLACK_LIST_FISCALE")));
        nazioneView.setAppartenenteWhiteListFiscale(getLongObjectFromPrimitive(nazioneResultSet.getString("NA_APPARTEN_WHITE_LIST_FISCALE")));
        nazioneView.setPrefissoCode(nazioneResultSet.getString("NA_PREFISSO"));
        nazioneView.setAccordoFatca(nazioneResultSet.getString("NA_ACCORDO_FATCA"));
        nazioneView.setCodiceIsoTre(nazioneResultSet.getString("NA_CODICE_ISO_TRE"));
        nazioneView.setTinCode(nazioneResultSet.getString("NA_TIN_CODE"));
        return nazioneView;
    }

    protected Long getLongObjectFromPrimitive(final String value) {
    	return value != null ? Long.valueOf(value) : null;
    }

    public ClassificazioneView getViewFromValue(final String parentCausale, final String value) throws RemoteException, SubSystemHandlerException {
        return value != null ? ClassificazioneHandler.getClassificazioneViewForChildByParentCausale(parentCausale, value) : null;
    }
  
}
