package it.sella.anagrafe.dbaccess.dai;

import it.sella.anagrafe.DAIConfigException;
import it.sella.anagrafe.DAIConfigView;
import it.sella.anagrafe.IDAIConfigView;
import it.sella.anagrafe.dbaccess.DBAccessHelper;
import it.sella.anagrafe.implementation.DAIConfigCache;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author GBS03447
 *
 */
public class DAIConfigGetterHelper extends DBAccessHelper {
	
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DAIConfigGetterHelper.class);
	private static DAIConfigCache daiConfigCache = null;
	
	/**
	 * Returns DAI Config View For the Given Input config Id
	 * @param configId
	 * @return
	 * @throws DAIConfigException 
	 */
	public DAIConfigView getDAIConfig(final Long configId) throws DAIConfigException {
		DAIConfigView configView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		getDaiConfigCache();
		if(daiConfigCache.isDaiConfigIdExist(configId)) {
			configView = (DAIConfigView) daiConfigCache.getDaiConfigView(configId);
		} else {
			try {
				query.append("SELECT DC_DAI_ID, DC_DAI_CONFIG_CODE, DC_DAI_PARENT_ID, DAI_DESCRIZIONE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_ID = ?");
				connection = getConnection();
				statement = connection.prepareStatement(query.toString());
				statement.setLong(1, configId);
				resultSet = statement.executeQuery();
				while (resultSet.next()) {
					configView = new DAIConfigView();
					configView.setDaiConfigId(resultSet.getLong("DC_DAI_ID"));
					configView.setDaiConfigCode(resultSet.getString("DC_DAI_CONFIG_CODE"));
					configView.setDaiDescription(resultSet.getString("DAI_DESCRIZIONE"));
					configView.setDaiParentId(resultSet.getLong("DC_DAI_PARENT_ID"));
					daiConfigCache.putDaiConfigView(configId, configView);
				}
			} catch (final SQLException e) {
				log4Debug.severeStackTrace(e);
				throw new DAIConfigException(e.getMessage(), e);
			} finally {
				cleanup(connection, statement, resultSet);
			}
		}
		return configView;
	}
	
	/**
	 * Returns DAI Config View For the Given Input config Code
	 * @param configCode
	 * @return
	 * @throws DAIConfigException 
	 */
	public DAIConfigView getDAIConfig(final String configCode) throws DAIConfigException {
		
		DAIConfigView configView = null;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		getDaiConfigCache();
		if(daiConfigCache.isDaiConfigCodeExist(configCode)) {
			configView = (DAIConfigView) daiConfigCache.getDaiConfigView(configCode);
		} else {
			try {
				query.append("SELECT DC_DAI_ID, DC_DAI_CONFIG_CODE, DC_DAI_PARENT_ID, DAI_DESCRIZIONE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_CONFIG_CODE = ?");
				connection = getConnection();
				statement = connection.prepareStatement(query.toString());
				statement.setString(1, configCode);
				resultSet = statement.executeQuery();
				while (resultSet.next()) {
					configView = new DAIConfigView();
					configView.setDaiConfigId(resultSet.getLong("DC_DAI_ID"));
					configView.setDaiConfigCode(resultSet.getString("DC_DAI_CONFIG_CODE"));
					configView.setDaiDescription(resultSet.getString("DAI_DESCRIZIONE"));
					configView.setDaiParentId(resultSet.getLong("DC_DAI_PARENT_ID"));
					daiConfigCache.putDaiConfigView(configCode, configView);
				}
			} catch (final SQLException e) {
				log4Debug.severeStackTrace(e);
				throw new DAIConfigException(e.getMessage(), e);
			} finally {
				cleanup(connection, statement, resultSet);
			}
		}
		return configView;
	}
	
	/**
	 * Not Used
	 * @param parentConfigCode
	 * @return
	 * @throws DAIConfigException
	 */
	public Collection<DAIConfigView> listDAIConfigCodes(final String parentConfigCode) throws DAIConfigException {
		final DAIConfigView parentConfigView = getDAIConfig(parentConfigCode);
		final Collection<DAIConfigView> daiConfigDataCollection = new ArrayList<DAIConfigView>();
		if(parentConfigView != null) {
			Connection connection = null;
			PreparedStatement statement = null;
			ResultSet resultSet = null;
			final StringBuffer query = new StringBuffer();
			query.append("SELECT DC_DAI_ID, DC_DAI_CONFIG_CODE, DC_DAI_PARENT_ID, DAI_DESCRIZIONE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_PARENT_ID = ?");
			
			try {
				connection = getConnection();
				statement = connection.prepareStatement(query.toString());
				statement.setLong(1, parentConfigView.getDaiParentId());
				resultSet = statement.executeQuery();
				DAIConfigView configView = null;
				while (resultSet.next()) {
					configView = new DAIConfigView();
					configView.setDaiConfigId(resultSet.getLong("DC_DAI_ID"));
					configView.setDaiConfigCode(resultSet.getString("DC_DAI_CONFIG_CODE"));
					configView.setDaiDescription(resultSet.getString("DAI_DESCRIZIONE"));
					configView.setDaiParentId(resultSet.getLong("DC_DAI_PARENT_ID"));
					
					daiConfigDataCollection.add(configView);
				}
			} catch (final SQLException e) {
				log4Debug.severeStackTrace(e);
				throw new DAIConfigException(e.getMessage(), e);
			} finally {
				cleanup(connection, statement, resultSet);
			}
		}
		return daiConfigDataCollection;
	}
	
	/**
	 * This Method Returns the Compatible DAI Group With Corresponding Regole Data based on TipoSoggetto
	 * Key : GruopCode   value : List of DAI Regole Types
	 * @param tipoSoggetto
	 * @throws DAIConfigException 
	 */
	public Map<String, Collection<IDAIConfigView>> getCompatibleDAICodesWithGroup (final String tipoSoggetto) throws DAIConfigException {
		final Map<String, Collection<IDAIConfigView>> compMap = new LinkedHashMap<String, Collection<IDAIConfigView>>();
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		final StringBuffer query = new StringBuffer();
		query.append("SELECT DP_DAI_GR_TYPE_ID, (SELECT DC_DAI_CONFIG_CODE FROM AN_MA_DAI_CONFIG WHERE DC_DAI_ID = DP_DAI_GR_TYPE_ID) DC_DAI_GROUP_CODE, DP_DAI_CODE_PR_ID FROM AN_MA_DAI_COMP_TIPOSOGGETTO C, AN_MA_DAI_PESO P WHERE C.DA_TIPO_SOGGETTO = ? AND C.DA_CONFIG_ID = P.DP_DAI_CODE_PR_ID AND DP_DATA_FINE IS NULL ORDER BY DP_DAI_GR_TYPE_ID");
		
		try {
			connection = getConnection();
			statement = connection.prepareStatement(query.toString());
			statement.setString(1, tipoSoggetto);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				final String groupCode = resultSet.getString("DC_DAI_GROUP_CODE");
				final Long daiCodeId = resultSet.getLong("DP_DAI_CODE_PR_ID");
				final DAIConfigView daiConfig = new DAIConfigGetterHelper().getDAIConfig(daiCodeId);
				if(compMap.containsKey(groupCode)) {
					final Collection<IDAIConfigView> daidataCodeColl = compMap.get(groupCode);
					daidataCodeColl.add(daiConfig);
				} else {
					final Collection<IDAIConfigView> daiConfigcoll = new ArrayList<IDAIConfigView>();
					daiConfigcoll.add(daiConfig);
					compMap.put(groupCode, daiConfigcoll);
				}
			}
		} catch(final SQLException e) {
			log4Debug.severeStackTrace(e);
			throw new DAIConfigException(e.getMessage(), e);
		} finally {
			cleanup(connection, statement, resultSet);
		}
		return Collections.synchronizedMap(compMap);
	}
	
	private void getDaiConfigCache() {
		if(daiConfigCache == null) {
			daiConfigCache = new DAIConfigCache();
		}
	}
}
