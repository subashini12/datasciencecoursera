package it.sella.anagrafe.ivaapplicazione;

import it.sella.anagrafe.SubSystemHandlerException;
import it.sella.anagrafe.common.Nazione;
import it.sella.anagrafe.controllo.ControlloDatiException;
import it.sella.anagrafe.dbaccess.DatiFiscaliDBAccessHelper;
import it.sella.anagrafe.discriminator.DatiFiscaliDiscriminatorException;
import it.sella.anagrafe.factory.IMCreationException;
import it.sella.anagrafe.factory.IMFactory;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.pf.DatiFiscaliPFView;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.view.PlurintestazioneView;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.util.Collection;

public class ApplicazioneIvaCalculator {

	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ApplicazioneIvaCalculator.class);
	private static final String PARENT_CAUSALE = "APIVA";


	/**
	 * Method to calculate VAT for AZ.
	 * If ResidenzaFiscali, ResidenzaFiscali2, ResidenzaFiscali3  all are null then  APIVA  value is  "0".
	 * If any of the ResidenzaFiscali, ResidenzaFiscali2, ResidenzaFiscali3  is not null &  ITALIA  then APIVA value is "1".
	 * If None of the ResidenzaFiscali, ResidenzaFiscali2, ResidenzaFiscali3 is ITALIA   &   menbroUE is "1"  & VIES is True  then APIVA Value is  "2"
	 * If None of the ResidenzaFiscali, ResidenzaFiscali2, ResidenzaFiscali3 is ITALIA   &   menbroUE is "1" & VIES is false / null  then APIVA Value is  "1".
	 * If None of the ResidenzaFiscali, ResidenzaFiscali2, ResidenzaFiscali3 is ITALIA   &   menbroUE is not "1"  then  APIVA Value is  "2".
	 * @param datiFiscaliPFView
	 */
	public void setCalculatedIVAForAZ(final DatiFiscaliPFView datiFiscaliPFView){
		ClassificazioneView classificazioneView = null;
		final AnagrafeHelper helper =new AnagrafeHelper();
		String childCausale = null;
		try {
			if(datiFiscaliPFView != null){
				if(datiFiscaliPFView.getResidenteFiscali() == null && datiFiscaliPFView.getResidenteFiscali2() == null && datiFiscaliPFView.getResidenteFiscali3() == null){
					childCausale = "0";
					classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
				} else if (helper.isItaliaNazione(datiFiscaliPFView.getResidenteFiscali()) || helper.isItaliaNazione(datiFiscaliPFView.getResidenteFiscali2()) || helper.isItaliaNazione(datiFiscaliPFView.getResidenteFiscali3())) {
					childCausale = "1";
					classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
				} else {
					classificazioneView = calcolaIVAForAZ(datiFiscaliPFView);
				}
			}
			if(classificazioneView != null){
				datiFiscaliPFView.setApiva(classificazioneView);
			}
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
		}
	}

	/**
	 * Method to calculate VAT for AZ
	 * @param resdenFiscali
	 * @param vies
	 * @param membroUE
	 * @return
	 */
	public ClassificazioneView calcolaIVAForAZ(final DatiFiscaliPFView datiFiscaliPFView){
		ClassificazioneView classificazioneView = null;
		String childCausale = null;
		try {
			final Boolean vies = datiFiscaliPFView.getVIES();
			final Nazione residenteFiscali = datiFiscaliPFView.getResidenteFiscali();
			final Nazione residenteFiscali2 = datiFiscaliPFView.getResidenteFiscali2();
			final Nazione residenteFiscali3 = datiFiscaliPFView.getResidenteFiscali3();
			
			if((residenteFiscali != null && !"ITALIA".equals(residenteFiscali.getNome()) && "1".equals(getMembroUEById(residenteFiscali.getNazioneId()))) || 
					(residenteFiscali2 != null && !"ITALIA".equals(residenteFiscali2.getNome()) && "1".equals(getMembroUEById(residenteFiscali2.getNazioneId()))) ||
					(residenteFiscali3 != null && !"ITALIA".equals(residenteFiscali3.getNome()) && "1".equals(getMembroUEById(residenteFiscali3.getNazioneId()))) ) {
				if(vies!=null && vies){
					childCausale = "2";
					classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
				}else{
					childCausale = "1";
					classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
				}
			} else {
				childCausale = "2";
				classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
			}
		} catch (final RemoteException e) {
			log4Debug.warnStackTrace(e);
		} catch (final SubSystemHandlerException e) {
			log4Debug.warnStackTrace(e);
		} catch (final ControlloDatiException e) {
			log4Debug.warnStackTrace(e);
		}
		return classificazioneView;
	}



	/**
	 * Method to calculate VAT for PF
	 * @param datiFiscaliPFView
	 * @return
	 * @throws SubSystemHandlerException
	 * @throws RemoteException
	 * @throws ControlloDatiException
	 */
	public DatiFiscaliPFView calculateVATForPF(final DatiFiscaliPFView datiFiscaliPFView) throws SubSystemHandlerException, RemoteException, ControlloDatiException{
		ClassificazioneView classificazioneView = null;
		if(datiFiscaliPFView.getResidenteFiscali()==null && datiFiscaliPFView.getResidenteFiscali2()==null && datiFiscaliPFView.getResidenteFiscali3()==null){
			final String childCausale = "0";
			classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
		}
		else{
			final String membroUEId = datiFiscaliPFView.getResidenteFiscali()!=null ?getMembroUEById(datiFiscaliPFView.getResidenteFiscali().getNazioneId()):null;
			final String membroUEIdRF2 =datiFiscaliPFView.getResidenteFiscali2()!=null? getMembroUEById(datiFiscaliPFView.getResidenteFiscali2().getNazioneId()):null;
			final String membroUEIdRF3 = datiFiscaliPFView.getResidenteFiscali3()!=null ?getMembroUEById(datiFiscaliPFView.getResidenteFiscali3().getNazioneId()):null;
			String childCausale = null;

			if("1".equals(membroUEId) || "1".equals(membroUEIdRF2)||"1".equals( membroUEIdRF3)){
				childCausale = "1";
				classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
			}else if("0".equals(membroUEId) || "0".equals(membroUEIdRF2)||"0".equals( membroUEIdRF3)){
				childCausale = "3";
				classificazioneView = getViewFromValue(PARENT_CAUSALE, childCausale);
			}
		}
		datiFiscaliPFView.setApiva(classificazioneView);
		return datiFiscaliPFView;



	}



	/**
	 * Method to calculate VAT for PL
	 * @param plurintestazioneView
	 * @throws DatiFiscaliDiscriminatorException
	 * @throws RemoteException
	 * @throws SubSystemHandlerException
	 * @throws ControlloDatiException
	 */
	public void calcVATForPL(final PlurintestazioneView plurintestazioneView)
	throws DatiFiscaliDiscriminatorException, RemoteException,
	SubSystemHandlerException, ControlloDatiException {
		final Collection<Long> CollecSoggettoId = plurintestazioneView.getSoggettoIds();
		final DatiFiscaliPFView datiFiscaliPLView = plurintestazioneView.getDatiFiscaliPFView() == null ? new DatiFiscaliPFView() : plurintestazioneView.getDatiFiscaliPFView() ;
		if(CollecSoggettoId!=null && !CollecSoggettoId.isEmpty()) {
			for(final Long soggettoId :CollecSoggettoId){
				ClassificazioneView classificazioneView= null;
				final DatiFiscaliPFView datiFiscaliPFView =  (DatiFiscaliPFView) new DatiFiscaliDBAccessHelper().getDatiFiscaliPF(soggettoId);
				if( datiFiscaliPFView.getApiva() != null){
					classificazioneView =  datiFiscaliPFView.getApiva();
				}
				else{
					calculateVATForPF(datiFiscaliPFView)  ;
					classificazioneView =  datiFiscaliPFView.getApiva();
				}
				if(classificazioneView !=null && classificazioneView.getCausale().equals("1")){
					datiFiscaliPLView.setApiva(classificazioneView);
					plurintestazioneView.setDatiFiscaliPFView(datiFiscaliPLView);
					break;
				}
			}
		}
		if( datiFiscaliPLView.getApiva() == null){
			datiFiscaliPLView.setApiva(ClassificazioneHandler.getClassificazioneViewForChildByParentCausale(PARENT_CAUSALE, "3"));
			plurintestazioneView.setDatiFiscaliPFView(datiFiscaliPLView);
		}
	}



	private ClassificazioneView getViewFromValue( final String parentCausale, final String value ) throws RemoteException, SubSystemHandlerException {
		return value != null ? ClassificazioneHandler.getClassificazioneViewForChildByParentCausale(parentCausale, value) : null;
	}


	private String getMembroUEById(final Long nazioneId) throws ControlloDatiException, RemoteException{
		try {
			final Nazione nazione = IMFactory.getInstance().getNazione(nazioneId);
			return nazione.getMembroUE().getCausale();
		} catch (final IMCreationException e) {
			throw new ControlloDatiException(e.getMessage());
		}
	}


}
