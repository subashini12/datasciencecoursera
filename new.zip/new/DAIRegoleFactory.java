package it.sella.anagrafe.factory;

import it.sella.anagrafe.DAIRegoleException;
import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.dairegole.IDAIRegoleBeanManager;
import it.sella.anagrafe.util.ReflectionUtil;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

/**
 * @author GBS03447
 *
 */
public final class DAIRegoleFactory extends Factory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(DAIRegoleFactory.class);
	
	private static DAIRegoleFactory daiRegoleFactoryObj = null;
	private IDAIRegoleBeanManager daiRegoleBeanManager = null;
	
	private DAIRegoleFactory() {
		
	}
	
	public static DAIRegoleFactory getInstance() {
		if (daiRegoleFactoryObj == null) {
			daiRegoleFactoryObj = new DAIRegoleFactory();
		}
		return daiRegoleFactoryObj;
	}
	
	public IDAIRegoleBeanManager getDAIRegoleBeanManager() throws DAIRegoleException {
		try {
			if(daiRegoleBeanManager == null) {
				daiRegoleBeanManager = ((IDAIRegoleBeanManager)ReflectionUtil.createServiceImplInstance("INTERNAL", "Manager.DAIRegole"));
			}
		} catch (final GestoreAnagrafeException e) {
			log4Debug.warnStackTrace(e);
			throw new DAIRegoleException(e.getMessage());
		}
		return daiRegoleBeanManager;
	}
}
