package it.sella.anagrafe.dbaccess;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.anagrafe.GestoreCollegamentoException;
import it.sella.anagrafe.discriminator.CollegamentoException;
import it.sella.anagrafe.implementation.ClassificazioneHandler;
import it.sella.anagrafe.implementation.CollegamentoCache;
import it.sella.anagrafe.util.AnagrafeHelper;
import it.sella.anagrafe.util.SecurityHandler;
import it.sella.classificazione.ClassificazioneView;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CollegamentoLinkedSoggettiHandler extends DBAccessHelper {
	
    private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(CollegamentoLinkedSoggettiHandler.class);
    private static CollegamentoCache collegamentoCache = null;

    public Collection getLinkedSoggetto( final Long soggettoId ) throws GestoreCollegamentoException, RemoteException {
        try {
            if ( soggettoId != null ) {
            	if ( bankIdArr.contains(soggettoId) ) {
            		throw new GestoreCollegamentoException(new AnagrafeHelper().getMessage("ANAG-1515"));
            	}
            	return listCollegamento(soggettoId);
            }
        } catch (final CollegamentoException fe) {
            log4Debug.warnStackTrace(fe);
            throw new GestoreCollegamentoException(fe.getLocalizedMessage());
        }
        return new ArrayList(1);
    }

    public Collection getLinkedSoggetto( final Long soggettoId, final String tipoCollagamentoCausale ) throws GestoreCollegamentoException, RemoteException {
        try {
            if ( soggettoId != null ) {
                return listCollegamento(soggettoId, getClassificazioneIdFromCausale(tipoCollagamentoCausale, "MOTIV"));
            }
        } catch (final GestoreAnagrafeException ne) {
            log4Debug.warnStackTrace(ne);
            throw new GestoreCollegamentoException(ne.getLocalizedMessage());
        }  catch (final CollegamentoException fe) {
            log4Debug.warnStackTrace(fe);
            throw new GestoreCollegamentoException(fe.getLocalizedMessage());
        }
        return new ArrayList(1);
    }
    
    public Collection listCollegamento( final Long soggettoPrincipaleId ) throws CollegamentoException, RemoteException {
        final List collegamentoViewList = new ArrayList(1);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        try {
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT CL_ID,CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE A.CL_SOGGETTO_PRINCIPALE= ? AND");
            query.append(" A.CL_DATA_FINE IS NULL AND EXISTS (SELECT 1 from AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ? AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.CL_SOGGETTO_PRINCIPALE AND CL_DATA_FINE IS NULL)");
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, soggettoPrincipaleId.longValue());
            preparedStatement.setLong(2,SecurityHandler.getLoginBancaId().longValue());
            preparedStatement.setLong(3,getClassificazioneIdFromCausale("CENST","MOTIV").longValue());
            collegamentoResultSet = preparedStatement.executeQuery();
            //logStackDumpForBankSoggettoIds(soggettoPrincipaleId);
            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoViewList);
        } catch (final SQLException ce) {
            log4Debug.warnStackTrace(ce);
            throw new CollegamentoException(ce.getLocalizedMessage());
        } catch(final GestoreAnagrafeException e) {
            log4Debug.warnStackTrace(e);
            throw new CollegamentoException(e.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoViewList;
    }
    
    public Collection listForPrincipalAndLinked( final Long principalId, final Long linkedId ) throws CollegamentoException, RemoteException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        final List collegamentoList = new ArrayList(1);
        try {
            connection = getConnection();
            final String query = "select CL_SOGGETTO_PRINCIPALE,CL_MOTIVO from an_tr_collagamento_soggetto where CL_LINKED_SOGGETTO= ? and cl_motivo not in (?,?) and cl_data_fine is null";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1,linkedId.longValue());
            preparedStatement.setLong(2,getClassificazioneIdFromCausale("DIPCT","MOTIV").longValue());
            preparedStatement.setLong(3,getClassificazioneIdFromCausale("PROCT","MOTIV").longValue());
            collegamentoResultSet = preparedStatement.executeQuery();
            Long principaleIdFromDb = null;
            it.sella.anagrafe.CollegamentoView collegamentoView = null;
            while (collegamentoResultSet.next()) {
                principaleIdFromDb = Long.valueOf(collegamentoResultSet.getLong("CL_SOGGETTO_PRINCIPALE"));
                if ( principaleIdFromDb.equals(principalId) ) {
                    collegamentoView = new it.sella.anagrafe.CollegamentoView();
                    collegamentoView.setMotivoCausale(ClassificazioneHandler.getClassificazioneView(Long.valueOf(collegamentoResultSet.getLong("CL_MOTIVO"))).getCausale());
                    collegamentoList.add(collegamentoView);
                }
            }
        } catch (final GestoreAnagrafeException ce) {
            log4Debug.warnStackTrace(ce);
            throw new CollegamentoException(ce.getLocalizedMessage());
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoList;
    }
    
    public Collection listCollegamento( final Long soggettoId, final Long motivoCollegamento ) throws CollegamentoException, RemoteException {
        final List collegamentoList = new ArrayList(1);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        try {
            final ClassificazioneView motivView = ClassificazioneHandler.getClassificazioneView(motivoCollegamento);
            if ("APART".equals(motivView.getCausale())) {
                if (collegamentoCache == null) {
					collegamentoCache = new CollegamentoCache();
				} else if (collegamentoCache.isCollegamentoExists(soggettoId)) {
                    final Collection cachedCollegamentoCollection = collegamentoCache.getCollegamentoCollection(soggettoId);
                    if (cachedCollegamentoCollection != null && !cachedCollegamentoCollection.isEmpty()) {
						return cachedCollegamentoCollection;
					}
                }
            }
            connection = getConnection();
            final StringBuffer query = new StringBuffer("SELECT CL_ID,CL_SOGGETTO_PRINCIPALE, CL_MOTIVO, CL_NOTE, CL_DATA_INIZIO, CL_DATA_FINE, CL_LINKED_SOGGETTO FROM AN_TR_COLLAGAMENTO_SOGGETTO A WHERE A.CL_SOGGETTO_PRINCIPALE= ? AND CL_MOTIVO = ? AND");
            query.append(" A.CL_DATA_FINE IS NULL AND EXISTS (SELECT 1 from AN_TR_COLLAGAMENTO_SOGGETTO WHERE CL_SOGGETTO_PRINCIPALE = ?");
            query.append(" AND CL_MOTIVO = ? AND CL_LINKED_SOGGETTO = A.CL_SOGGETTO_PRINCIPALE AND CL_DATA_FINE IS NULL)");
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, soggettoId.longValue());
            preparedStatement.setLong(2, motivoCollegamento.longValue());
            preparedStatement.setLong(3, SecurityHandler.getLoginBancaId().longValue());
            preparedStatement.setLong(4, getClassificazioneIdFromCausale("CENST","MOTIV").longValue());
            collegamentoResultSet = preparedStatement.executeQuery();
            //logStackDumpForBankSoggettoIds(soggettoId);
            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoList);
            if ("APART".equals(motivView.getCausale())) {
				collegamentoCache.putCollegamentoCollection(soggettoId, collegamentoList);
			}
        } catch (final SQLException se) {
            log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getLocalizedMessage());
        } catch (final GestoreAnagrafeException fe) {
            log4Debug.warnStackTrace(fe);
            throw new CollegamentoException(fe.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoList;
    }
    public List listCollegamento( final Long linkedSoggettoId, final String motivoCollegamento ) throws CollegamentoException, RemoteException {
        final List collegamentoViewList = new ArrayList(1);
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet collegamentoResultSet = null;
        boolean isMotivCenst = true;
        try {
        	log4Debug.debug(" CollegamentoLinkedSoggettiHandler : listCollegamento : linkedSoggettoId ====>",linkedSoggettoId);
        	log4Debug.debug(" CollegamentoLinkedSoggettiHandler : listCollegamento : motivoCollegamento ====>",motivoCollegamento);
            connection = getConnection();
            final StringBuffer query = new StringBuffer(" SELECT CL_ID, ");
            						query.append("			CL_SOGGETTO_PRINCIPALE, ");
            						query.append("			CL_MOTIVO, ");
            						query.append("			CL_NOTE, ");
            						query.append("			CL_DATA_INIZIO, ");
            						query.append("			CL_DATA_FINE, ");
            						query.append("			CL_LINKED_SOGGETTO ");
            						query.append("	FROM AN_TR_COLLAGAMENTO_SOGGETTO A ");
            						query.append("	WHERE CL_LINKED_SOGGETTO = ? ");
            						query.append("	AND CL_MOTIVO = ? ");
            						query.append("	AND CL_DATA_FINE IS NULL ");
           if( !"CENST".equals(motivoCollegamento) ) {  						
            						query.append("	AND EXISTS (SELECT 1 ");
            						query.append("		FROM AN_TR_COLLAGAMENTO_SOGGETTO ");
            						query.append("	WHERE CL_MOTIVO = ? ");
            						query.append("	AND CL_LINKED_SOGGETTO = A.CL_LINKED_SOGGETTO ");
            						query.append("	AND CL_DATA_FINE IS NULL) ");
            	isMotivCenst = false;					
           } 						
           log4Debug.debug(" CollegamentoLinkedSoggettiHandler : listCollegamento : query ====>",query);
            preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.setLong(1, linkedSoggettoId.longValue());
            preparedStatement.setLong(2, getClassificazioneIdFromCausale(motivoCollegamento, "MOTIV").longValue());
            if( !isMotivCenst ) {
            	preparedStatement.setLong(3, getClassificazioneIdFromCausale("CENST","MOTIV").longValue());	
            }
            collegamentoResultSet = preparedStatement.executeQuery();
            //logStackDumpForBankSoggettoIds(linkedSoggettoId);
            new CollegamentoViewBuilder().setCollegamentoViewListFromResultSet(collegamentoResultSet, collegamentoViewList);
        }  catch (final SQLException se) {
        	log4Debug.warnStackTrace(se);
            throw new CollegamentoException(se.getLocalizedMessage());
        }  catch(final GestoreAnagrafeException e) {
        	log4Debug.warnStackTrace(e);
            throw new CollegamentoException(e.getLocalizedMessage());
        } finally {
            cleanup(connection, preparedStatement, collegamentoResultSet);
        }
        return collegamentoViewList;
    }
    
    private static final List<Long> bankIdArr = constructBankIdList();

    private static final List<Long> constructBankIdList() {
    	 final List<Long> list = new ArrayList<Long>();
    	try {
    		list.addAll(new BancaDettagliGetterHelper().getAllBankSoggettoIds());
		} catch (final Exception ex) {
			log4Debug.severe("#####<ANAGSTACKDUMP> Exception Raised To getALLBankSoggettoId API #####  ");
			log4Debug.severeStackTrace(ex);
		} 
        return list;
    }
    
    // This log used for getLinkedSoggetto( final Long soggettoId ) if passing input params as bankSoggettoID
    /* private void logStackDumpForBankSoggettoIds(Long linkedSoggettoId) {
        try {
            if (bankIdArr.contains(linkedSoggettoId)) {
                throw new Exception();
            }
        } catch (Exception ex) {
        	log4Debug.severe("#####<ANAGSTACKDUMP>#####  " , "Input Soggetto Id : " , linkedSoggettoId);
        	log4Debug.severe("#####<ANAGSTACKDUMP>#####  " , "Logged In User Id : " , getUserId());
        	log4Debug.severeStackTrace(ex);
        }
    }    

   private static String getUserId() {
	   try {
		   return SecurityManagerFactory.getSecurityManager().getIdentity().getUserId();
	   } catch (it.sella.security.SecurityException ex) {
		   log4Debug.severe(ex.getMessage());
		   log4Debug.severe("#####<ANAGSTACKDUMP>#####  " , " Not Possible to Retrieve User Id " );
	   }
	   return null;
   } */	   
}

