package it.sella.anagrafe.util;

import it.sella.anagrafe.GestoreAnagrafeException;
import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public class ReflectionUtil {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(ReflectionUtil.class);

    public static Object  newInstance(final String loadingClassName) throws GestoreAnagrafeException {
        try {
            return Class.forName(loadingClassName).newInstance();

        } catch (final ClassNotFoundException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } catch (final InstantiationException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        } catch (final IllegalAccessException e) {
            log4Debug.severeStackTrace(e);
            throw new GestoreAnagrafeException(e.getMessage());
        }
    }

    public static Object  createServiceImplInstance(final String bundleKey, final String daoImplKey) throws GestoreAnagrafeException {
		Object daoImplObj = null;
		//Class partypes[] = null;
		try {
			daoImplObj = newInstance(ResourceFinder.getString(bundleKey, daoImplKey));
			//partypes = new Class[1];
			//partypes[0] = Object.class;
			return daoImplObj;
		} catch (final SecurityException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final IllegalArgumentException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		} catch (final GestoreAnagrafeException e) {
			log4Debug.severeStackTrace(e);
			throw new GestoreAnagrafeException(e.getMessage());
		}
	}
}
