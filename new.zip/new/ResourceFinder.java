package it.sella.anagrafe.util;

import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ResourceFinder
{
    private static ResourceBundle INTERNAL_BUNDLE = ResourceBundle.getBundle("it.sella.anagrafe.factory.InternalFinder");
    private static final Map<String,ResourceBundle> RESOURCEMAP = new HashMap<String, ResourceBundle>();
    
    private static void initializeBundle()
    {
       RESOURCEMAP.put("INTERNAL", INTERNAL_BUNDLE );
    }   
    
    public static String getString( final String bundleKey, final String key) 
    {
        initializeBundle();    
        try {
            return RESOURCEMAP.get(bundleKey).getString(key);           
        } catch (final MissingResourceException e) {
            return '!' + key + '!';
        }
    }   
}


