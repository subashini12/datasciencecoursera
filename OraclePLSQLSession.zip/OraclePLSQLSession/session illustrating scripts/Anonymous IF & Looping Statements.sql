

----Anonymous Block Samples
--if Illustration


DECLARE

  v_input number := null;-- if the value is '' also if block will be executed since we are trimming

BEGIN

  IF TRIM(v_input) IS NULL THEN
  
    dbms_output.put_line('v_input value is null ');
  
  END IF;

END;

--IF ELSE    Illustration

DECLARE

  v_input number := 2;

BEGIN

  v_input := ''; --if this value is not empty or null then else block will  be executed

  IF TRIM(v_input) IS NOT NULL THEN
    
     dbms_output.put_line('v_input value is: ' || v_input);
  ELSE
  
    dbms_output.put_line('v_input value is null ');
  
  END IF;

END;

--IF ELSIF ELSE Illustration

DECLARE

  v_input number := 3;

BEGIN

  IF TRIM(v_input) IS NULL THEN
  
    dbms_output.put_line('v_input value is null ');
  
  ELSIF TRIM(v_input) = 2 THEN
  
    dbms_output.put_line('v_input value is 2 ');
  
  ELSE
  
    dbms_output.put_line('v_input value is NEITHER NULL NOR 2 ');
  
  END IF;

END;


----LOOPING STATEMENTS

---- SAMPLE FOR for loop 
 declare
   v_end  number := 5;
   v_hold number;
 begin
   for i in 1 .. v_end loop
     v_hold := i;
     dbms_output.put_line(' v_hold >>>:' || v_hold);
   end loop;
 
 end;
 


 declare
   v_str  varchar2(20) := 'ravi';
   v_size varchar2(20);
 
 begin
 
   SELECT LENGTH(v_str) INTO v_size FROM DUAL;
 
   FOR I IN REVERSE 1 .. v_size LOOP
     dbms_output.put_line(' My Spelling in Reverse >>>:' || SUBSTR(v_str, I, 1));
   end loop;
 
 end;
 
 
 ----while loop sample 
 
DECLARE
   a number(2) := 0;
BEGIN
   WHILE a <= 10 LOOP
      dbms_output.put_line('value of a: ' || a);
      a := a + 1;
   END LOOP;
END;



