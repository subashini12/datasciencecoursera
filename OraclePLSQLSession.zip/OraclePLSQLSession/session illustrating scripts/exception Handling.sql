SELECT * FROM SA_MA_EMPLOYEE;

CREATE TABLE SA_TR_EMP_LOG(EL_ID NUMBER,EL_EMP_NAME VARCHAR2(30))

CREATE SEQUENCE SA_SQ_EMP_LOG START WITH 1
----Without Exception Handling

DECLARE

  v_emp_name SA_MA_EMPLOYEE.EMP_NAME%TYPE;
  v_emp_id   number := 4;

BEGIN

  SELECT emp_name
    INTO v_emp_name
    FROM SA_MA_EMPLOYEE
   WHERE EMP_ID = v_emp_id;

  dbms_output.put_line('Logged In Employee Is: ' || v_emp_name);

  INSERT INTO SA_TR_EMP_LOG VALUES (SA_SQ_EMP_LOG.NEXTVAL, v_emp_name);
  COMMIT;
  
  dbms_output.put_line('Logged In Employee Info Inserted : ');
  

END;

CREATE TABLE SA_MA_EMP_ADDRESS(EA_ID NUMBER,EA_EMP_NAME VARCHAR2(30),EA_EMP_ADDRESS VARCHAR2(100))

CREATE SEQUENCE SA_SQ_EMP_ADDRESS START WITH 1


INSERT INTO SA_MA_EMP_ADDRESS VALUES (SA_SQ_EMP_ADDRESS.NEXTVAL,'RAVI','HYDERABAD');
COMMIT;


SELECT * FROM SA_MA_EMP_ADDRESS;
----Exception Handling For Named system exceptions

DECLARE

  v_emp_name     SA_MA_EMPLOYEE.EMP_NAME%TYPE := 'HARISH';
  v_new_address  SA_MA_EMP_ADDRESS.EA_EMP_ADDRESS%TYPE := 'TamilNadu';
  v_selected_emp SA_MA_EMPLOYEE.EMP_NAME%TYPE;

BEGIN

  BEGIN
    SELECT EA_EMP_NAME
      INTO v_selected_emp
      FROM SA_MA_EMP_ADDRESS
    
     WHERE EA_EMP_NAME = v_emp_name;
  
    UPDATE SA_MA_EMP_ADDRESS
       SET EA_EMP_ADDRESS = v_new_address
     WHERE EA_EMP_NAME = v_emp_name;
  
    dbms_output.put_line(' Record Updated in SA_MA_EMP_ADDRESS table ');
  
    COMMIT;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    
      INSERT INTO SA_MA_EMP_ADDRESS
      VALUES
        (SA_SQ_EMP_ADDRESS.NEXTVAL, v_emp_name, v_new_address);
      COMMIT;
    
      dbms_output.put_line('New Record Inserted into SA_MA_EMP_ADDRESS table ');
  END;
  
  dbms_output.put_line('end of the Process ');

END;

/*User Defined Exception (I Want to Insert a record if the person's record is not present in the SA_MA_EMP_ADDRESS 
otherwise i want to raise my user defined exception with message "ADDRESS IS ALREADY EXISTED,YOU NO NEED TO GIVE ADREESS NEWLY" ) */



DECLARE
  v_emp_name     SA_MA_EMPLOYEE.EMP_NAME%TYPE := 'AJITH';
  v_new_address  SA_MA_EMP_ADDRESS.EA_EMP_ADDRESS%TYPE := 'Maharastra';
  v_selected_emp SA_MA_EMPLOYEE.EMP_NAME%TYPE;
  ADDRESS_ALREADY_EXIST exception;
  v_error_message varchar2(300);
BEGIN
  BEGIN
    SELECT EA_EMP_NAME
      INTO v_selected_emp
      FROM SA_MA_EMP_ADDRESS
    
     WHERE EA_EMP_NAME = v_emp_name;
  
    IF v_selected_emp IS NOT NULL THEN
      RAISE ADDRESS_ALREADY_EXIST;
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    
      INSERT INTO SA_MA_EMP_ADDRESS
      VALUES
        (SA_SQ_EMP_ADDRESS.NEXTVAL, v_emp_name, v_new_address);
      COMMIT;
    
      dbms_output.put_line('New Record Inserted into SA_MA_EMP_ADDRESS table ');
  END;

EXCEPTION

  WHEN ADDRESS_ALREADY_EXIST THEN
    ROLLBACK;
    v_error_message := 'ADDRESS IS ALREADY EXISTED,YOU NO NEED TO GIVE ADREESS NEWLY';
    --- some bussiness logic we can do 
    RAISE_APPLICATION_ERROR(-20007,
                            v_error_message || '  ' || SQLERRM(SQLCODE));
  
  WHEN OTHERS THEN
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20007, SQLERRM(SQLCODE));
END;



/* Raising user defined exception,if "IF" Block executed,then bussiness logic like some insert statement 
and some update statements wont be executed.the program will be terminated by giving the message like 
"input is null or Empty thus no action can take place" */

declare

  v_input number := null;

begin

 IF  trim(v_input) is null THEN
    RAISE_APPLICATION_ERROR(-20007,
                            'input is null or Empty thus no action can take place');
  else
  
    dbms_output.put_line('v_input>>>>>>>: ' || v_input);
  
  END IF;
  
  ---some bussiness logic like some insert statement and some update statements

end;


 


