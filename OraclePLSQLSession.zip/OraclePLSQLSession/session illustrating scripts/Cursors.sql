--- Implicu Cursor Sample

SELECT * FROM SA_MA_EMPLOYEE;


CREATE TABLE SA_MA_EMPLOYEE(EMP_ID NUMBER PRIMARY KEY,EMP_NAME VARCHAR2(20),EMP_SAL NUMBER)

DECLARE
  var_rows number(5);
BEGIN
  UPDATE SA_MA_EMPLOYEE SET emp_name = 'raju'  where emp_id=1;
  IF SQL%NOTFOUND THEN
    dbms_output.put_line('None of the employee names where updated');
  ELSIF SQL%FOUND THEN
    var_rows := SQL%ROWCOUNT;
    dbms_output.put_line(' Names for  ' || var_rows ||
                         ' employees are updated');
  END IF;
END;



---Explicit Cursor Samples



DECLARE
 CURSOR c_emp_detail IS 
   SELECT EMP_ID,EMP_NAME,EMP_SAL
   FROM SA_MA_EMPLOYEE;
   rec_emp_detail SA_MA_EMPLOYEE%ROWTYPE;
   /* A cursor based record is based on elements of pre-Defined cursor.
      A cursor based record can be only declared after its corresponding
      cursor, else an error occurs.*/
BEGIN
 OPEN c_emp_detail;
   LOOP
    FETCH c_emp_detail INTO rec_emp_detail;
    EXIT WHEN c_emp_detail%NOTFOUND; -- cursor attribute to exit when no rows found to fetch.
    DBMS_OUTPUT.PUT_LINE('Employees Details : '||' '||rec_emp_detail.EMP_ID
    ||' '||rec_emp_detail.EMP_NAME||' '||rec_emp_detail.EMP_SAL);
   END LOOP;
    DBMS_OUTPUT.PUT_LINE('Total number of rows : '||c_emp_detail%ROWCOUNT);
    -- cursor attribute to find the total number of rows executed.
 CLOSE c_emp_detail;
END;



--Cursor with a FOR Loop:
/*-When using FOR LOOP you need not declare a record or variables to store the cursor values, need not open, fetch 
and close the cursor. These functions are accomplished by the FOR LOOP automatically.*/


DECLARE
  v_no_of_employees number;

  CURSOR c1 IS
    SELECT EMP_ID, EMP_NAME, EMP_SAL FROM SA_MA_EMPLOYEE;

  rec_emp_detail SA_MA_EMPLOYEE%ROWTYPE;
BEGIN
  v_no_of_employees := 0;
  FOR rec_emp_detail in c1 LOOP
    v_no_of_employees := v_no_of_employees + 1;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('No Of Employees are>>> ' || v_no_of_employees);

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('EXCEPTION OCCURRED ' || SQLERRM(SQLCODE));
END;
    
-- FOR Cursor


DECLARE
  V_PREPARED_STATUS NUMBER;
  V_ARCHIVED_STATUS NUMBER;
  V_ISE_USER_ID     VARCHAR2(20);
BEGIN
  SELECT ST_ID
    INTO V_PREPARED_STATUS
    FROM TP_MA_STATUS
   WHERE ST_TYPE = 'ST_11';
  SELECT ST_ID
    INTO V_ARCHIVED_STATUS
    FROM TP_MA_STATUS
   WHERE ST_TYPE = 'ST_88';
  FOR CUR IN (SELECT *
                FROM TP_TR_BUSTA_DEICI_ATTRIBUTE BD
               WHERE BD.BD_NCD IN ('1000652845607', '1000652846659',
                      '1000652846765', '1000653292998'))
               ORDER BY BD_NCD)
  LOOP--loop starts
    IF (CUR.BD_CURR_STATUS_ID = V_ARCHIVED_STATUS AND
       CUR.BD_ID_ESITO_CONTROLLO = 40 AND
       CUR.BD_NOTE_CONTROLLO = 'DIGITAL SIGNATURE CONTRACT') THEN
      IF CUR.BD_BANK = 1 THEN
        V_ISE_USER_ID := 'BSISEPLICHI';
      ELSIF CUR.BD_BANK = 238 THEN
        V_ISE_USER_ID := 'BBCISEPLICHI';
      ELSIF CUR.BD_BANK = 57992 THEN
        V_ISE_USER_ID := 'BAGISEPLICHI';
      ELSIF CUR.BD_BANK = 1367924 THEN
        V_ISE_USER_ID := 'SIBISEPLICHI';
      ELSIF CUR.BD_BANK = 1483455 THEN
        V_ISE_USER_ID := 'SHBISEPLICHI';
      END IF;
      UPDATE TP_TR_OGGETTO OG
         SET OG.OG_CURR_STATUS_ID = V_PREPARED_STATUS
       WHERE OG.OG_ID = CUR.BD_OGGETTO_ID;
      
      INSERT INTO TP_TR_OGGETTO_STATUS_REFERENCE
        (OS_ID, OS_DOC_ID, OS_STATUS_ID, OS_USER, OS_DATE_TIME)
      VALUES
        (TP_SQ_OGGETTO_STATUS.NEXTVAL,
         CUR.BD_OGGETTO_ID,
         V_PREPARED_STATUS,
         V_ISE_USER_ID,
         SYSDATE);      
      COMMIT;
    END IF;
  END LOOP;----loop ends here
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('EXCEPTION OCCURRED ' || SQLERRM(SQLCODE));
END;

