--Package

CREATE OR REPLACE PACKAGE MOF_PA_RICHIESTA_RILEVAMENTI AS

  PROCEDURE MOF_PR_EXPORT_REQ_RILEVAMENTI(i_abibanca IN VARCHAR2,
                                          i_date     IN VARCHAR2);

END MOF_PA_RICHIESTA_RILEVAMENTI;


--Package Body


CREATE OR REPLACE PACKAGE BODY MOF_PA_RICHIESTA_RILEVAMENTI AS

  -------------------------------------------------------------------------------------
  FUNCTION ADD_PADDING(i_value IN VARCHAR2, i_total_size IN NUMBER)
    RETURN VARCHAR2 IS
  
  BEGIN
    RETURN RPAD(NVL(i_value, ' '), i_total_size);
  END ADD_PADDING;

  -------------------------------------------------------------------------------------
  FUNCTION MOF_FN_GET_BANK_PREFIX(i_abi_banca IN VARCHAR2) RETURN VARCHAR2 AS
  
    v_bank_prefix VARCHAR2(5);
  
  BEGIN
    IF i_abi_banca = '03268' THEN
      v_bank_prefix := 'BSE';
    ELSIF i_abi_banca = '03064' THEN
      v_bank_prefix := 'BBC';
    ELSIF i_abi_banca = '03049' THEN
      v_bank_prefix := 'BAG';
    ELSIF i_abi_banca = '08657' THEN
      v_bank_prefix := 'BDP';
    ELSIF i_abi_banca = '03211' THEN
      v_bank_prefix := 'SIB';
    ELSIF i_abi_banca = '03311' THEN
      v_bank_prefix := 'SHB';
    END IF;
    RETURN v_bank_prefix;
  END MOF_FN_GET_BANK_PREFIX;

  -------------------------------------------------------------------------------------
  PROCEDURE MOF_PR_EXPORT_REQ_RILEVAMENTI(i_abibanca IN VARCHAR2,
                                                          i_date     IN VARCHAR2) AS

  v_output_dir        VARCHAR2(30) := 'MONITORAGGIOFISCH2O_OUTPUT_';
  v_oracle_output_dir VARCHAR2(30);
  v_bank_prefix       VARCHAR2(3);
  v_nomeFile          VARCHAR2(200);
  v_out_file          UTL_FILE.FILE_TYPE;
  v_text_line         VARCHAR2(111);
  v_importo           VARCHAR2(15);
  v_process_date      VARCHAR2(10);
  v_start_time        varchar2(19);
  v_end_time          varchar2(19);

BEGIN

  SELECT to_char(to_date(i_date, 'YYYYMMDD'), 'MM/DD/YYYY')
    INTO v_process_date
    FROM dual;

  v_start_time        := v_process_date || ' 00:00:00';
  v_end_time          := v_process_date || ' 23:59:59';
  v_bank_prefix       := MOF_FN_GET_BANK_PREFIX(i_abibanca);
  v_oracle_output_dir := v_output_dir || v_bank_prefix;
  v_nomeFile          := i_abibanca || '-Richiesta-Rilevamenti-' || i_date ||
                         '.txt';
  v_out_file          := utl_file.fopen(v_oracle_output_dir,
                                        v_nomeFile,
                                        'W');

  FOR CUR IN (SELECT *
                FROM mof_tr_richiesta_rilevamenti
               WHERE rr_data_inserimento BETWEEN
                     to_date(v_start_time, 'mm/dd/yyyy hh24:mi:ss') AND
                     to_date(v_end_time, 'mm/dd/yyyy hh24:mi:ss')
                 AND rr_abibanca = i_abibanca
                 AND rr_data_lavorazione IS NULL
               ORDER BY rr_st_id) LOOP
  
    v_text_line := null;
    v_text_line := v_text_line || ADD_PADDING(cur.rr_abibanca, 5) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_conto_cliente, 13) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_st_id, 2) || ';';
    v_importo   := CUR.rr_importo;
    v_text_line := v_text_line || LPAD(v_importo, 15, '0') || ';';
    v_text_line := v_text_line ||
                   TO_CHAR(cur.rr_data_inserimento, 'dd/mm/yyyy') || ';';
    v_text_line := v_text_line ||
                   ADD_PADDING(cur.rr_disposta_o_ricevuta, 1) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_codice_uic, 4) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_stato_estero, 3) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_stato, 25) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_codice_titolo, 12) || ';';
    v_text_line := v_text_line || ADD_PADDING(cur.rr_utente_modifica, 10) || ';';
  
    UTL_FILE.PUT_LINE(v_out_file, v_text_line);
  
    UPDATE mof_tr_richiesta_rilevamenti
       SET rr_data_lavorazione = SYSDATE
     WHERE rr_id = CUR.rr_id;
  
  END LOOP;

  IF UTL_FILE.IS_OPEN(v_out_file) THEN
    UTL_FILE.FCLOSE(v_out_file);
  END IF;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    IF UTL_FILE.IS_OPEN(v_out_file) THEN
      UTL_FILE.FCLOSE(v_out_file);
    END IF;
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20111, SQLERRM(SQLCODE));
END MOF_PR_EXPORT_REQ_RILEVAMENTI;
  -------------------------------------------------------------------------------------

END MOF_PA_RICHIESTA_RILEVAMENTI;

