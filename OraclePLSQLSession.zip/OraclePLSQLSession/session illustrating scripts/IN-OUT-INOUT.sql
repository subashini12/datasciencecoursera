
create table employee(eno number,ename varchar2(20),CONSTRAINT employee_pk PRIMARY KEY (eno))

CREATE SEQUENCE emp_SQ_ID START WITH 1  

insert into employee values(emp_SQ_ID.Nextval,'ravi');
commit;




--- difference between OUT and IN OUT param is: if the value is IN OUT param value then if the called procedure do not assign any value,then it will take the value assigned in he caller
--- OUT param means although if we assign the value for the param which we are passing as OUT param,it wont consider the caller value in case called procedure do not get value for that param
--- Run the below anonymous block for the sa_pr_getIdbyName by changing the o_errmsg to out and observe the changes


create or replace procedure sa_pr_getIdbyName(v_empname in varchar2,
                                              o_empid   out number,
                                              o_errmsg  out varchar2) as


begin
  begin
    select eno into o_empid from employee where ename = trim(v_empname);
  exception
    WHEN OTHERS THEN
      o_errmsg := 'Error While Executing sa_pr_getIdbyName ' || sqlerrm;
  end;
end sa_pr_getIdbyName;


declare
  v_empid number;  
  v_ename varchar2(20):= 'ravii';
  o_errmsg   varchar2(3000);
begin

   sa_pr_getIdbyName(v_ename,v_empid,o_errmsg);
  
  DBMS_OUTPUT.put_line('v_empid>>>>>>>>'||v_empid);
  DBMS_OUTPUT.put_line('-------------------------------');
  
  DBMS_OUTPUT.put_line('o_errmsg>>>>>>>>'||o_errmsg);
  EXCEPTION 
   WHEN OTHERS THEN
   DBMS_OUTPUT.put_line('Errore while getting the employeeId'||sqlerrm);

end;



CREATE OR REPLACE PROCEDURE SA_PR_UPDATE_EMP_SAL(i_o_sal in out number) as

BEGIN

  i_o_sal := i_o_sal + (i_o_sal * 0.1);

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RAISE_APPLICATION_ERROR(-20007, SQLERRM(SQLCODE));
  
end SA_PR_UPDATE_EMP_SAL;


DECLARE
  v_sal_to_update number := 300;

BEGIN

  SA_PR_UPDATE_EMP_SAL(v_sal_to_update);
  DBMS_OUTPUT.put_line('salary After Updation>>>>>>>>' || v_sal_to_update);

EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20007, SQLERRM(SQLCODE));
  
END;


