CREATE TABLE product_price_history 
(product_id number(5), 
product_name varchar2(32), 
supplier_name varchar2(32), 
unit_price number(7,2) ); 

CREATE TABLE product 
(product_id number(5), 
product_name varchar2(32), 
supplier_name varchar2(32), 
unit_price number(7,2) ); 


insert into product values(1,'Boost','COCo',10);
commit;

update product set unit_price = unit_price + (unit_price*0.1) where product_id=1;
commit;

select * from product_price_history;

CREATE or REPLACE TRIGGER price_history_trigger
  BEFORE UPDATE OF unit_price ON product
  FOR EACH ROW
BEGIN
  INSERT INTO product_price_history
  VALUES
    (:old.product_id,
     :old.product_name,
     :old.supplier_name,
     :old.unit_price);
END;
