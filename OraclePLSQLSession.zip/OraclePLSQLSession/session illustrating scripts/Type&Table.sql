-- Like A View

CREATE OR REPLACE TYPE CN_TY_OBJ_BANK_CDR AS OBJECT

(

  cdr varCHAR2(10),
  bank_id number
)

---creating collection of objects(collection of views)

CREATE OR REPLACE TYPE CN_TY_TBL_BANK_CDR IS TABLE OF CN_TY_OBJ_BANK_CDR


CREATE OR REPLACE FUNCTION TP_FN_GET_KO_BY_CDR_LIST(IN_CN_TY_TB_BANK_CDR CN_TY_TBL_BANK_CDR)
  RETURN NUMBER AS

  V_CN_TY_OB_BANK_CDR    CN_TY_OBJ_BANK_CDR := NULL;
  V_CN_TY_TB_BANK_CDR    CN_TY_TBL_BANK_CDR;
  V_TYPE_COUNT           NUMBER := 0;
  V_KO_COUNT             NUMBER := 0;
  V_TOTAL_KO_COUNT       NUMBER := 0;
  V_WKSC_DATE_RANGE      NUMBER := 0;
  V_CDR                  VARCHAR2(10);
  V_FLAG                 NUMBER := 0;
  V_TIME_STAMP           VARCHAR2(30);
  V_FUNCTION_NAME        VARCHAR2(30) := 'TP_FN_GET_KO_BY_CDR_LIST';
  V_START_TIME           TIMESTAMP;
  V_END_TIME             TIMESTAMP;
  V_LOG_STRING           VARCHAR2(800);
  V_INVALID_BANK_ID_COLL VARCHAR2(200) := '';
  V_INVALID_CDR_COLL     VARCHAR2(200) := '';
  V_WRONG_DATA_COUNT     NUMBER := 0;
  V_IS_VALID_BANK        NUMBER := 0;

BEGIN

  V_START_TIME := SYSDATE;

  SELECT TO_CHAR(CURRENT_TIMESTAMP, 'DD/MM/YYYY HH24:MI:SS')
    INTO V_TIME_STAMP
    FROM DUAL;

  V_LOG_STRING := V_TIME_STAMP || ' ' || V_FUNCTION_NAME || ' ';

  SELECT PR_VALUE
    INTO V_WKSC_DATE_RANGE
    FROM TP_MA_PROPERTIES
   WHERE PR_KEY = 'WKSC_DATE_RANGE';
  V_CN_TY_TB_BANK_CDR := IN_CN_TY_TB_BANK_CDR;
  V_TYPE_COUNT        := V_CN_TY_TB_BANK_CDR.COUNT;

  FOR I IN 1 .. V_TYPE_COUNT LOOP
  
    V_FLAG              := 0;
    V_KO_COUNT          := 0;
    V_IS_VALID_BANK     := 0;
    V_CN_TY_OB_BANK_CDR := V_CN_TY_TB_BANK_CDR(I);
  
    IF (NOT (V_CN_TY_OB_BANK_CDR.BANK_ID = 1 OR
        V_CN_TY_OB_BANK_CDR.BANK_ID = 1367924 OR
        V_CN_TY_OB_BANK_CDR.BANK_ID = 1483455)) THEN
      V_INVALID_BANK_ID_COLL := 'malformed bank id: ' ||
                                V_CN_TY_OB_BANK_CDR.BANK_ID || ' ';
      V_WRONG_DATA_COUNT     := V_WRONG_DATA_COUNT + 1;
      V_FLAG                 := 1;
      V_IS_VALID_BANK        := 1;
    END IF;
  
    IF (V_IS_VALID_BANK = 0) THEN
      BEGIN
      
        V_CDR := AN_PKG_IGESTORE_ANAGRAFE.AN_FN_SOGGETTOIDCS(V_CN_TY_OB_BANK_CDR.CDR,
                                                             'cdr',
                                                             V_CN_TY_OB_BANK_CDR.BANK_ID);
      
      EXCEPTION
      
        WHEN OTHERS THEN
        
          RAISE_APPLICATION_ERROR(-20007, SQLERRM(SQLCODE));
      END;
    
      IF (V_CDR IS NULL) THEN
        V_INVALID_CDR_COLL := 'malformed cdr: ' ||
                              V_CN_TY_OB_BANK_CDR.BANK_ID || ' ';
        V_WRONG_DATA_COUNT := V_WRONG_DATA_COUNT + 1;
      
        V_FLAG := 1;
      END IF;
    END IF;
    IF (V_FLAG = 0) THEN
      SELECT COUNT(BD_ID)
        INTO V_KO_COUNT
        FROM TP_TR_BUSTA_DEICI_ATTRIBUTE
       WHERE BD_BANK = V_CN_TY_OB_BANK_CDR.BANK_ID
         AND BD_CDR = V_CN_TY_OB_BANK_CDR.CDR
         AND EXISTS
       (SELECT 1
                FROM (SELECT DISTINCT REGEXP_SUBSTR(PR_VALUE,
                                                    '[^,]+',
                                                    1,
                                                    LEVEL) PR_VALUE
                        FROM (SELECT PR_VALUE
                                FROM TP_MA_PROPERTIES
                               WHERE PR_KEY = 'WKSC_KO_WHITE_LIST') S
                      CONNECT BY REGEXP_SUBSTR(PR_VALUE, '[^,]+', 1, LEVEL) IS NOT NULL)
               WHERE BD_ID_ESITO_CONTROLLO = PR_VALUE)
         AND BD_CURR_STATUS_ID <> 30
            
         AND BD_ACTUAL_DATE BETWEEN TRUNC(SYSDATE) - V_WKSC_DATE_RANGE AND
             TRUNC(SYSDATE);
    END IF;
  
    V_TOTAL_KO_COUNT := V_TOTAL_KO_COUNT + V_KO_COUNT;
  
  END LOOP;

  IF (V_WRONG_DATA_COUNT >= 1) THEN
  
    V_END_TIME   := SYSDATE;
    V_LOG_STRING := V_LOG_STRING || (V_END_TIME - V_START_TIME) || ' ' ||
                    V_INVALID_BANK_ID_COLL || V_INVALID_CDR_COLL;
    TP_PR_LOG_WSKC_FAILURES(V_LOG_STRING);
  
  END IF;

  RETURN V_TOTAL_KO_COUNT;

END TP_FN_GET_KO_BY_CDR_LIST;


Testing:

---HOW TO TEST ABOVE FUNCTION IS IS MENTIONED BELOW
DECLARE

  V_CN_TY_OB_BANK_CDR    CN_TY_OBJ_BANK_CDR := NULL;
  V_CN_TY_TB_BANK_CDR    CN_TY_TBL_BANK_CDR;
  V_COUNT                NUMBER := 0;
  V_CN_TY_TBL_ESITI_INFO WEBLOGIC_DBA.CN_TY_TBL_ESITI_INFO;

BEGIN

  ----------initializing the table of object(CN_TY_TBL_BANK_CDR)-------------

  V_CN_TY_TB_BANK_CDR := CN_TY_TBL_BANK_CDR();

  ---assigning values to the table of object(CN_TY_TB_BANK_CDR)----------

  V_CN_TY_OB_BANK_CDR := CN_TY_OBJ_BANK_CDR('02V82V', 1);
  V_CN_TY_TB_BANK_CDR.EXTEND;
  V_CN_TY_TB_BANK_CDR(1) := V_CN_TY_OB_BANK_CDR;
  V_CN_TY_OB_BANK_CDR := CN_TY_OBJ_BANK_CDR('01J81J', 1);
  V_CN_TY_TB_BANK_CDR.EXTEND;
  V_CN_TY_TB_BANK_CDR(2) := V_CN_TY_OB_BANK_CDR;

  V_COUNT := WEBLOGIC_DBA.TP_PA_EXTERNAL_INTERFACE.TP_FN_GET_KO_BY_CDR_LIST(V_CN_TY_TB_BANK_CDR);

  V_CN_TY_TBL_ESITI_INFO := WEBLOGIC_DBA.TP_PA_EXTERNAL_INTERFACE.TP_FN_GET_KO_BY_CDR_LIST_DET(V_CN_TY_TB_BANK_CDR);

  DBMS_OUTPUT.PUT_LINE('count of results: ' ||
                       V_CN_TY_TBL_ESITI_INFO.count);
  FOR I IN 1 .. V_CN_TY_TBL_ESITI_INFO.count LOOP
    DBMS_OUTPUT.PUT_LINE('Iteration Number:: ' || I);
    -- DBMS_OUTPUT.PUT_LINE('contracode: ' || V_CN_TY_TBL_ESITI_INFO(I).CTR_CODE);
  -- DBMS_OUTPUT.PUT_LINE('cdr: ' || V_CN_TY_TBL_ESITI_INFO(I).CDR);
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('No Of Qualified records as per my search criteria are: ' ||
                       V_COUNT);

END;
